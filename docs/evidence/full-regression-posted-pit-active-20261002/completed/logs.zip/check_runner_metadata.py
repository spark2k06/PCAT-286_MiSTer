from pathlib import Path
import importlib.util
import json
from types import SimpleNamespace
from unittest.mock import Mock, patch

run = Path(__file__).resolve().parent
project = run.parent.parent
spec = importlib.util.spec_from_file_location('regression_runner',project/'tools/perf01/run_full_regression.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
out = run/'replays/runner-prepare-metadata-check'
out.mkdir(exist_ok=False)
prepared = SimpleNamespace(out=out,started='2026-10-02T00:00:00+00:00',run=Mock())
with patch.object(module,'Regression',return_value=prepared) as factory, patch('sys.argv',
    ['runner',str(out),'--corpus',str(project),'--production-only','--prepare-only']):
    module.main()
    assert factory.call_args.args[2] is True
    prepared.run.assert_not_called()
    status = json.loads((out/'progress.json').read_text())
    assert status['status']=='PREPARED_NOT_EXECUTED' and status['stages']==[]
print('REGRESSION_RUNNER_PREPARE_METADATA_PASS')
