"""Compare direct pin-array injection with coherent physical loader writes."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

run = Path(__file__).resolve().parent
frozen = run/'work'
out = run/'replays/mrbios-fixture-probe'
work = out/'work'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert not out.exists()
shutil.copytree(frozen, work, ignore=shutil.ignore_patterns('build','__pycache__','.cache'))
tb = work/'sim/spk286_integration/spk286_at_bios_first_fetch_tb.sv'
text = tb.read_text()
extra = '''
    logic fixture_loader_valid = 0;
    logic [23:0] fixture_loader_address = 0;
    logic [1:0] fixture_loader_be = 0;
    logic [15:0] fixture_loader_data = 0;
    integer fixture_stale_reads = 0;
    always @(posedge clk) begin
        if (!reset && mrbios_irq_fixture && p03_in_ready && p03_in_read_data_valid &&
            backend_owner == 0 && backend_code_fetch &&
            backend_address >= 25'h7000 && backend_address < 25'h7400 &&
            p03_in_read_data !== pins.mem[backend_address >> 1]) begin
            fixture_stale_reads = fixture_stale_reads + 1;
            if (fixture_stale_reads <= 20)
                $display("MRBIOS_FIXTURE_STALE_READ restart=%0d address=%h cached=%h physical=%h",
                    mrbios_restarts, backend_address, p03_in_read_data, pins.mem[backend_address >> 1]);
        end
    end
    task automatic load_mrbios_fixture_physical;
        integer offset, guard;
        begin
            for (offset = 0; offset < mrbios_fixture_bytes; offset = offset + 2) begin
                @(negedge clk);
                fixture_loader_address = 24'h7000 + 24'(offset);
                fixture_loader_be = offset+1 < mrbios_fixture_bytes ? 2'b11 : 2'b01;
                fixture_loader_data = {offset+1 < mrbios_fixture_bytes ? mrbios_fixture[offset+1] : 8'h00,
                                       mrbios_fixture[offset]};
                fixture_loader_valid = 1;
                #1; guard = 0;
                while (!loader_accept) begin
                    @(negedge clk); #1; guard = guard + 1;
                    if (guard > 10000) $fatal(1,"fixture loader accept timeout");
                end
                @(posedge clk); @(negedge clk);
                fixture_loader_valid = 0;
                #1; guard = 0;
                while (!loader_ready) begin
                    @(negedge clk); #1; guard = guard + 1;
                    if (guard > 10000) $fatal(1,"fixture loader completion timeout");
                end
            end
            @(negedge clk);
            for (offset = 0; offset < mrbios_fixture_bytes; offset = offset + 1)
                if (pins.mem[(24'h7000+offset)>>1][(offset&1)*8 +: 8] !== mrbios_fixture[offset])
                    $fatal(1,"fixture physical installation differs offset=%0d",offset);
            $display("MRBIOS_FIXTURE_PHYSICAL_INSTALL bytes=%0d",mrbios_fixture_bytes);
        end
    endtask
'''
anchor = '    task automatic inject_keyboard_byte(input logic [7:0] value);'
assert text.count(anchor) == 1
text = text.replace(anchor, extra+'\n'+anchor)
original = '''        .loader_valid(loader_valid), .loader_write(loader_write),
        .loader_address(loader_address), .loader_byte_enable(loader_be),
        .loader_data_out(loader_data), .loader_accept(loader_accept), .loader_ready(loader_ready),'''
replacement = '''        .loader_valid(loader_valid || fixture_loader_valid),
        .loader_write(fixture_loader_valid ? 1'b1 : loader_write),
        .loader_address(fixture_loader_valid ? fixture_loader_address : loader_address),
        .loader_byte_enable(fixture_loader_valid ? fixture_loader_be : loader_be),
        .loader_data_out(fixture_loader_valid ? fixture_loader_data : loader_data),
        .loader_accept(loader_accept), .loader_ready(loader_ready),'''
assert text.count(original) == 1
text = text.replace(original,replacement)
original = '''                        for (integer offset = 0; offset < mrbios_fixture_bytes; offset = offset + 1)
                            pins.mem[('h7000 + offset) >> 1][(offset & 1)*8 +: 8] = mrbios_fixture[offset];'''
replacement = '''                        if ($test$plusargs("MRBIOS_PHYSICAL_FIXTURE_LOAD"))
                            load_mrbios_fixture_physical();
                        else begin
                            for (integer offset = 0; offset < mrbios_fixture_bytes; offset = offset + 1)
                                pins.mem[('h7000 + offset) >> 1][(offset & 1)*8 +: 8] = mrbios_fixture[offset];
                        end'''
assert text.count(original) == 1
tb.write_text(text.replace(original,replacement))
rtl = {p.relative_to(frozen).as_posix():sha(p)
       for folder in ('rtl','vendor/spk286/rtl','vendor/spk286/microcode/generated')
       for p in (frozen/folder).rglob('*') if p.is_file()}
assert all(sha(work/n)==h for n,h in rtl.items())
env = dict(os.environ,PATH=str(run/'production-tools')+os.pathsep+os.environ['PATH'],
           PCAT_BUILD_DIR=str(out/'build'))
record = dict(production_sha256=rtl, original_test_sha256=sha(frozen/tb.relative_to(work)),
              probe_test_sha256=sha(tb),runs=[])
build_log = out/'build.log'
with build_log.open('w') as log:
    result = subprocess.run(['bash','scripts/test_at_bios_first_fetch.sh'],cwd=work,env=env,
                            stdout=log,stderr=subprocess.STDOUT,timeout=1800)
assert result.returncode == 0, 'Private fixture build or original BIOS gates failed'
exe = out/'build/verilator-obj/first_fetch_vlt'
record['binary_sha256'] = sha(exe)
rom = run/'replays/external-bios/mrbios.rom'
assert sha(rom) == '6f936ee53ba58663d1ccc7b80b1f5caba841f3f816c4dca15477ca540f9f252f'
for variant in ('irq','irq-rep'):
    args = ['nasm','-f','bin']
    if variant == 'irq-rep': args += ['-DMRBIOS_REP_IDLE=1']
    subprocess.run(args+['tests/firmware/mrbios_irq_restart.asm','-o',str(out/(variant+'.bin'))],
                   cwd=work,check=True)
for mode,variant in (('direct','irq'),('physical','irq'),('physical','irq-rep')):
    command = [str(exe),'+ROM='+str(rom),'+FULL_BOOT',
               '+MRBIOS_IRQ_FIXTURE='+str(out/(variant+'.bin')),
               '+MRBIOS_RESTARTS=3','+TRACE_POST','+MAX_CPU_CYCLES=15000000']
    if mode == 'physical': command += ['+MRBIOS_PHYSICAL_FIXTURE_LOAD']
    if variant == 'irq-rep': command += ['+MRBIOS_REQUIRE_REP']
    log_path = out/(mode+'-'+variant+'.log')
    with log_path.open('w') as log:
        result = subprocess.run(command,cwd=work/'rtl/video',stdout=log,stderr=subprocess.STDOUT,timeout=600)
    record['runs'].append(dict(mode=mode,variant=variant,command=command,
        exit_status=result.returncode,log=log_path.name,log_sha256=sha(log_path)))
    (out/'comparison.json').write_text(json.dumps(record,indent=2)+'\n')
    print('MRBIOS_FIXTURE_PROBE',mode,variant,result.returncode,flush=True)
assert sha(exe)==record['binary_sha256']
assert all(sha(work/n)==h for n,h in rtl.items())
record['complete']=True
(out/'comparison.json').write_text(json.dumps(record,indent=2)+'\n')
