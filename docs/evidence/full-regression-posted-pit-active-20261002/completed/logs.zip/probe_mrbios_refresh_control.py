"""Keep active CPU options and compare the MR BIOS fixture with old AT cadence."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

run = Path(__file__).resolve().parent
project = run.parent.parent
frozen = run/'work'
out = run/'replays/mrbios-old-refresh-control'
work = out/'work'
assert not out.exists()
shutil.copytree(frozen,work,ignore=shutil.ignore_patterns('build','__pycache__','.cache'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
relative = Path('rtl/spk286_integration/spk286_at_refresh.sv')
old = project/'docs/evidence/perf01-posted-write-20261002/refresh/baseline'/relative
text = old.read_text()
anchor = '    input  logic        refresh_enable,'
assert text.count(anchor) == 1
# The old cadence ignores PIT OUT1; add only the binding required by the new
# machine interface. No CPU/cache/controller input or option is changed.
text = text.replace(anchor,anchor+'\n    input  logic        timer_1_out, // unused in this old-policy control')
(work/relative).write_text(text)
cpu_hashes = {p.relative_to(frozen).as_posix():sha(p)
              for folder in ('vendor/spk286/rtl','vendor/spk286/microcode/generated')
              for p in (frozen/folder).rglob('*') if p.is_file()}
assert all(sha(work/n)==h for n,h in cpu_hashes.items())
rom = run/'replays/external-bios/mrbios.rom'
env = dict(os.environ,PATH=str(run/'production-tools')+os.pathsep+os.environ['PATH'],
           PCAT_BUILD_DIR=str(out/'build'),AT_MRBIOS_ROM=str(rom))
command = ['bash','scripts/test_at_mrbios_restart.sh']
log = out/'run.log'
with log.open('w') as output:
    result = subprocess.run(command,cwd=work,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=1800)
record = dict(command=command,exit_status=result.returncode,log_sha256=sha(log),
    cpu_sha256=cpu_hashes,source_old_refresh_sha256=sha(old),
    adapted_old_refresh_sha256=sha(work/relative),bios_sha256=sha(rom),
    statement='Old AT periodic requester only; active CPU macros, CPU RTL, caches and SDRAM controller unchanged.')
(out/'comparison.json').write_text(json.dumps(record,indent=2)+'\n')
assert all(sha(work/n)==h for n,h in cpu_hashes.items())
print('MRBIOS_OLD_REFRESH_CONTROL',result.returncode,flush=True)
