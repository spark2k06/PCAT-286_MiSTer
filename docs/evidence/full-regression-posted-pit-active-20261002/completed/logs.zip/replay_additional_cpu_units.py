from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

run = Path(__file__).resolve().parent
project = run.parent.parent
cpu = project/'vendor/spk286'
frozen = run/'work/vendor/spk286'
private = run/'replays/missing-unit-package'
source = Path('/mnt/d/GitHub/SPK286/sim/unit/spk286_loadall_integration_tb.sv')
target = private/'sim/unit'/source.name
if target.exists():
    source = frozen/'sim/unit'/target.name
    assert source.read_bytes() == target.read_bytes()
else:
    shutil.copyfile(source,target)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
rtl = {p.relative_to(frozen).as_posix():sha(p)
       for folder in ('rtl','microcode/generated')
       for p in (frozen/folder).rglob('*') if p.is_file()}
env = dict(os.environ,PATH=str(run/'production-tools')+os.pathsep+os.environ['PATH'],
           SPK286_BUILD_DIR='/tmp/pcat-active-additional-cpu-banks-20261002',SPK286_BUILD_JOBS='2')
rows = []
for name,cwd in (('spk286_event_lifecycle',cpu),('spk286_loadall_integration',private)):
    assert all(sha(cwd/n)==h for n,h in rtl.items())
    command = ['bash','scripts/test_units.sh','both',name]
    log = run/('additional-unit-'+name+'.log')
    with log.open('w') as output:
        result = subprocess.run(command,cwd=cwd,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=1800)
    rows.append(dict(stage=name,command=command,exit_status=result.returncode,log=log.name,
                     log_sha256=sha(log),test_bench_sha256=sha(cwd/'sim/unit'/(name+'_tb.sv'))))
    (run/'additional-unit-replays.json').write_text(json.dumps(dict(rtl_sha256=rtl,
        loadall_test_source=str(source),loadall_test_sha256=sha(source),runs=rows),indent=2)+'\n')
    print('ADDITIONAL_CPU_UNIT',name,result.returncode,flush=True)
assert all(sha(cpu/n)==h and sha(private/n)==h for n,h in rtl.items())
