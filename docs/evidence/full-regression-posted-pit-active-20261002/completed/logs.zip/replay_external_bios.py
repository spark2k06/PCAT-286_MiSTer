"""Supply existing local BIOS inputs to the unchanged frozen test scripts."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess

run = Path(__file__).resolve().parent
project = run.parent.parent
work = run/'work'
out = run/'replays/external-bios'
out.mkdir(parents=True,exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
mr_source = project/'build/mrbios_1.65_286.bin'
assert sha(mr_source) == '6f936ee53ba58663d1ccc7b80b1f5caba841f3f816c4dca15477ca540f9f252f'
mr = out/'mrbios.rom'
mr.write_bytes(mr_source.read_bytes())
roms = Path('/mnt/d/Desktop/86Box/roms/machines/ibmatpx')
even = roms/'BIOS ROM - PhoenixBIOS A286 - Version 1.01 - Even.bin'
odd = roms/'BIOS ROM - PhoenixBIOS A286 - Version 1.01 - Odd.bin'
assert even.stat().st_size == odd.stat().st_size == 32768
data = bytearray(65536)
data[0::2],data[1::2] = even.read_bytes(),odd.read_bytes()
phoenix = out/'phoenix.rom'
phoenix.write_bytes(data)
assert sha(phoenix) == '306ac7c3a0ee713385de53f5dd0625ee040f3ea6606b09e9d5fce3c6a00b273e'
rtl = {p.relative_to(work).as_posix():sha(p)
       for folder in ('rtl','vendor/spk286/rtl','vendor/spk286/microcode/generated')
       for p in (work/folder).rglob('*') if p.is_file()}
record = dict(frozen_production_sha256=rtl, source_bios_sha256={str(p):sha(p) for p in (mr_source,even,odd)},
              supplied_bios_sha256={p.name:sha(p) for p in (mr,phoenix)},runs=[])
for name in ('test_at_mrbios_restart','test_at_phoenix_pm87','test_at_phoenix_fdc_post'):
    command = ['bash','scripts/'+name+'.sh']
    log = run/('bios-'+name+'-supplied.log')
    env = dict(os.environ, PATH=str(run/'production-tools')+os.pathsep+os.environ['PATH'],
               AT_MRBIOS_ROM=str(mr),AT_PHOENIX_ROM=str(phoenix),
               PCAT_BUILD_DIR=str(out/name))
    start = datetime.now(timezone.utc).isoformat()
    with log.open('w') as output:
        result = subprocess.run(command,cwd=work,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=1800)
    record['runs'].append(dict(stage=name,command=command,exit_status=result.returncode,
        start_utc=start,end_utc=datetime.now(timezone.utc).isoformat(),log=log.name,log_sha256=sha(log)))
    (run/'bios-replays.json').write_text(json.dumps(record,indent=2)+'\n')
    print('EXTERNAL_BIOS_REPLAY',name,result.returncode,flush=True)
assert all(sha(work/n)==h for n,h in rtl.items())
record['complete']=True
(run/'bios-replays.json').write_text(json.dumps(record,indent=2)+'\n')
