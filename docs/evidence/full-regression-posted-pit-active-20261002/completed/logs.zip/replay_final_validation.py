"""Replay corrected validation contracts without editing production inputs."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

run = Path(__file__).resolve().parent
project = run.parent.parent
frozen = run/'work'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
rtl = {p.relative_to(frozen).as_posix(): sha(p)
       for folder in ('rtl','vendor/spk286/rtl','vendor/spk286/microcode/generated')
       for p in (frozen/folder).rglob('*') if p.is_file()}
assert all(sha(project/n)==h for n,h in rtl.items())

def execute(name):
    work = project
    output = run/'replays'/(name+'-contract-corrected')
    if name == 'test_at_stack_offset_arithmetic':
        work = run/'replays/stack-source-proof-package'
        work.mkdir(exist_ok=False)
        for folder in ('vendor','scripts'):
            shutil.copytree(frozen/folder, work/folder,
                            ignore=shutil.ignore_patterns('build','__pycache__'))
        shutil.copy2(frozen/'config.tcl',work/'config.tcl')
        evidence = Path('docs/evidence/stack-offset-arithmetic-20261002/upstream-formal')
        shutil.copytree(project/evidence,work/evidence)
        proof = json.loads((work/evidence/'receipt.json').read_text())
        assert proof['candidate_source_sha256'] == sha(work/'vendor/spk286/rtl/spk286_micro_executor.sv')
        for n,h in proof['artifacts_sha256'].items():
            assert sha(work/evidence/n) == h
        script = work/'scripts'/('test_at_stack_offset_arithmetic.sh')
        original = script.read_text()
        assert original.count('for profile in base pcat; do') == 1
        script.write_text(original.replace('for profile in base pcat; do',
                                          'for profile in pcat; do'))
        # The user requests the enabled profile only; all original assertions,
        # byte proof and both simulators remain required.
    command = ['bash','scripts/'+name+'.sh',str(output)]
    log = run/('contract-'+name+'-corrected.log')
    env = dict(os.environ, PATH=str(run/'production-tools')+os.pathsep+os.environ['PATH'])
    with log.open('w') as stream:
        result = subprocess.run(command,cwd=work,env=env,stdout=stream,
                                stderr=subprocess.STDOUT,timeout=1800)
    print('CONTRACT_REPLAY',name,result.returncode,flush=True)
    return dict(stage=name,command=command,exit_status=result.returncode,
                log=log.name,log_sha256=sha(log))

with ThreadPoolExecutor(max_workers=3) as pool:
    rows = list(pool.map(execute,('test_at_sdram_entry','test_at_sdram_phase',
                                 'test_at_stack_offset_arithmetic')))
assert all(sha(project/n)==h for n,h in rtl.items())
(run/'contract-replays.json').write_text(json.dumps(dict(production_sha256=rtl,runs=rows,
    changes='Early-write launch checks match unchanged accepted source; retained payload/reset/memory assertions remain. Stack proof supplied and only active profile selected.'),indent=2)+'\n')
