"""Use upstream verification banks absent from the vendored test package.

Keep the frozen PCAT CPU and all existing fixtures intact. This is supplemental
coverage, with separately recorded upstream test identities, not a waiver of
the initial packaging failures.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import subprocess

run = Path(__file__).resolve().parent
project = run.parent.parent
frozen = run/'work/vendor/spk286'
upstream = Path('/mnt/d/GitHub/SPK286')
work = run/'replays/missing-unit-package'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
units = json.loads((run/'production/registered-units.json').read_text())
missing = [name for name in units if not (frozen/'sim/unit'/(name+'_tb.sv')).is_file()]
assert not work.exists()
shutil.copytree(frozen, work, ignore=shutil.ignore_patterns('build', '__pycache__', '.cache'))
copies = {}
for name in missing:
    rel = Path('sim/unit')/(name+'_tb.sv')
    assert (upstream/rel).is_file(), str(rel)
    shutil.copyfile(upstream/rel, work/rel)
    copies[str(rel)] = dict(source=str(upstream/rel), sha256=sha(work/rel))
rtl = {p.relative_to(frozen).as_posix():sha(p)
       for folder in ('rtl','microcode/generated')
       for p in (frozen/folder).rglob('*') if p.is_file()}
assert all(sha(work/n)==h for n,h in rtl.items())
build = Path('/tmp/pcat-active-missing-unit-package-20261002')
assert not build.exists()
env = dict(os.environ, PATH=str(run/'production-tools')+os.pathsep+os.environ['PATH'],
           SPK286_BUILD_DIR=str(build), SPK286_BUILD_JOBS='2')
record = dict(upstream_revision=subprocess.check_output(
    ['git','-C',str(upstream),'rev-parse','HEAD'],text=True).strip(),
    imported_test_benches=copies, frozen_cpu_sha256=rtl, runs=[])
(run/'missing-unit-replays.json').write_text(json.dumps(record,indent=2)+'\n')
for name in missing:
    command = ['bash','scripts/test_units.sh','both',name]
    log = run/('missing-unit-'+name+'.log')
    start = datetime.now(timezone.utc).isoformat()
    with log.open('w') as output:
        result = subprocess.run(command,cwd=work,env=env,stdout=output,
                                stderr=subprocess.STDOUT,timeout=1200)
    record['runs'].append(dict(stage=name,command=command,start_utc=start,
        end_utc=datetime.now(timezone.utc).isoformat(),exit_status=result.returncode,
        log_sha256=sha(log),log=log.name))
    (run/'missing-unit-replays.json').write_text(json.dumps(record,indent=2)+'\n')
    print('MISSING_UNIT_REPLAY',name,result.returncode,flush=True)
assert all(sha(work/n)==h for n,h in rtl.items())
assert all(sha(Path(row['source']))==row['sha256'] for row in copies.values())
record['complete'] = True
(run/'missing-unit-replays.json').write_text(json.dumps(record,indent=2)+'\n')
