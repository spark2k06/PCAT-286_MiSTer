from pathlib import Path
import hashlib
import json
import os
import subprocess

run = Path(__file__).resolve().parent
project = run.parent.parent
cpu = project/'vendor/spk286'
frozen = run/'work/vendor/spk286'
env = dict(os.environ, PATH=str(run/'production-tools')+os.pathsep+os.environ['PATH'])
identities = {p.relative_to(frozen).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
              for folder in ('rtl', 'microcode/generated')
              for p in (frozen/folder).rglob('*') if p.is_file()}
assert all(hashlib.sha256((cpu/n).read_bytes()).hexdigest() == h for n,h in identities.items())
commands = [('source-manifest', ['python3', '-m', 'unittest', 'tests.test_rtl_sources', '-v'])]
commands += [(name, ['python3', str(project/'tools/perf01/run_with_host_budget.py'),
                     '--seconds', '600', 'tools.audit_'+name, '--build-dir',
                     str(run/'replays'/(name+'-receipts-corrected'))])
             for name in ('unary', 'segment')]
rows = []
for name, command in commands:
    log = run/('mutation-'+name+'-corrected.log')
    with log.open('w') as output:
        result = subprocess.run(command, cwd=cpu, env=env, stdout=output,
                                stderr=subprocess.STDOUT, timeout=1800)
    rows.append(dict(stage=name, command=command, exit_status=result.returncode,
                     log_sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
    (run/'mutation-replays.json').write_text(json.dumps(dict(rtl_sha256=identities,
        changes='Only exact functional rejection messages and complete RTL source ordering; no assertions or production RTL changed.',
        runs=rows), indent=2)+'\n')
    print('MUTATION_REPLAY', name, result.returncode, flush=True)
assert all(hashlib.sha256((cpu/n).read_bytes()).hexdigest() == h for n,h in identities.items())
assert all(row['exit_status'] == 0 for row in rows)
