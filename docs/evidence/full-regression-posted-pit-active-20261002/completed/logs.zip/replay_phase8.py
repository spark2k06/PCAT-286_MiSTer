from pathlib import Path
import hashlib
import json
import os
import subprocess

run = Path(__file__).resolve().parent
project = run.parent.parent
cpu = project/'vendor/spk286'
frozen = run/'work/vendor/spk286'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
identities = {p.relative_to(frozen).as_posix():sha(p)
              for folder in ('rtl','microcode/generated')
              for p in (frozen/folder).rglob('*') if p.is_file()}
assert all(sha(cpu/n)==h for n,h in identities.items())
command = ['python3',str(project/'tools/perf01/run_with_host_budget.py'),
           '--seconds','600','tools.audit_phase8','--build-dir',str(run/'replays/phase8-receipts-corrected')]
env = dict(os.environ,PATH=str(run/'production-tools')+os.pathsep+os.environ['PATH'])
log_path = run/'mutation-phase8-corrected.log'
with log_path.open('w') as log:
    result = subprocess.run(command,cwd=cpu,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
(run/'phase8-replays.json').write_text(json.dumps(dict(rtl_sha256=identities,
    runs=[dict(stage='phase8',command=command,exit_status=result.returncode,log_sha256=sha(log_path))],
    changes='Exact dispatch/queue assertion messages only; all test properties and production source bytes preserved.'),indent=2)+'\n')
assert all(sha(cpu/n)==h for n,h in identities.items())
print('PHASE8_REPLAY',result.returncode,flush=True)
assert result.returncode==0
