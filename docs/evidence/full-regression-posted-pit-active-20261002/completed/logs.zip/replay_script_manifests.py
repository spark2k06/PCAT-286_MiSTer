from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import subprocess

run = Path(__file__).resolve().parent
project = run.parent.parent
frozen = run/'work'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
rtl = {p.relative_to(frozen).as_posix():sha(p)
       for folder in ('rtl','vendor/spk286/rtl','vendor/spk286/microcode/generated')
       for p in (frozen/folder).rglob('*') if p.is_file()}
assert all(sha(project/n)==h for n,h in rtl.items())
def execute(name):
    command = ['bash','scripts/'+name+'.sh']
    log = run/('manifest-'+name+'-corrected.log')
    env = dict(os.environ,PATH=str(run/'production-tools')+os.pathsep+os.environ['PATH'],
               PCAT_BUILD_DIR=str(run/'replays'/(name+'-manifest-corrected')))
    with log.open('w') as output:
        result = subprocess.run(command,cwd=project,env=env,stdout=output,
                                stderr=subprocess.STDOUT,timeout=1800)
    print('SCRIPT_MANIFEST_REPLAY',name,result.returncode,flush=True)
    return dict(stage=name,command=command,exit_status=result.returncode,
                log=log.name,log_sha256=sha(log))
with ThreadPoolExecutor(max_workers=2) as pool:
    rows = list(pool.map(execute,('test_at_xtide_machine','test_code_buffer_capacity')))
(run/'manifest-replays.json').write_text(json.dumps(dict(production_sha256=rtl,runs=rows,
    changes='Missing EMS, posted-write and production code-buffer modules in script source lists only; all test assertions unchanged.'),indent=2)+'\n')
assert all(sha(project/n)==h for n,h in rtl.items())
