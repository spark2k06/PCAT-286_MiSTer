from pathlib import Path
import hashlib
import json
import subprocess

run = Path(__file__).resolve().parent
project = run.parent.parent
cpu = project/'vendor/spk286'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
exe = run/'production/cpu/verilator/obj_dir/spk286_smoke'
exe_hash = sha(exe)
build = run/'replays/singlestep-audit-corrected'
(build/'verilator/obj_dir').mkdir(parents=True,exist_ok=False)
(build/'verilator/obj_dir/spk286_smoke').symlink_to(exe)
command = ['python3','-m','tools.audit_singlestep',
           '--repo','/mnt/d/GitHub/SPK286/.cache/singlestep-80286','--build-dir',str(build)]
log = run/'mutation-singlestep-corrected.log'
with log.open('w') as output:
    result = subprocess.run(command,cwd=cpu,stdout=output,stderr=subprocess.STDOUT,timeout=1800)
(run/'singlestep-replays.json').write_text(json.dumps(dict(executable_sha256=exe_hash,
    runs=[dict(stage='singlestep',command=command,exit_status=result.returncode,log_sha256=sha(log))],
    changes='Complete reserved two-byte sequence in the unsupported-input fault probe; unchanged production executable.'),indent=2)+'\n')
assert sha(exe)==exe_hash
print('SINGLESTEP_AUDIT_REPLAY',result.returncode,flush=True)
assert result.returncode==0
