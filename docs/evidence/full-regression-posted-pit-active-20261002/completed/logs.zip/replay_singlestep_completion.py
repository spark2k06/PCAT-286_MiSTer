from pathlib import Path
import hashlib
import json
import subprocess

run = Path(__file__).resolve().parent
project = run.parent.parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
exe = run/'production/cpu/verilator/obj_dir/spk286_smoke'
exe_hash = sha(exe)
build = run/'replays/singlestep-completion-corrected'
(build/'verilator/obj_dir').mkdir(parents=True,exist_ok=False)
(build/'verilator/obj_dir/spk286_smoke').symlink_to(exe)
command = ['python3','-u','-m','tools.audit_singlestep',
           '--repo','/mnt/d/GitHub/SPK286/.cache/singlestep-80286','--build-dir',str(build)]
log = run/'mutation-singlestep-completion-corrected.log'
with log.open('w') as output:
    result = subprocess.run(command,cwd=project/'vendor/spk286',stdout=output,
                            stderr=subprocess.STDOUT,timeout=1800)
assert sha(exe)==exe_hash
(run/'singlestep-completion-replays.json').write_text(json.dumps(dict(
    executable_sha256=exe_hash,
    tool_sha256=sha(project/'vendor/spk286/tools/audit_singlestep.py'),
    runs=[dict(stage='singlestep',command=command,exit_status=result.returncode,
               log=log.name,log_sha256=sha(log))],
    changes='Reserved two-byte form with a seeded #UD vector must be rejected by the architectural completion comparator; the original MOV with the same vector is a required positive control. Original failed unsupported-latch probe preserved separately.'),indent=2)+'\n')
print('SINGLESTEP_COMPLETION_REPLAY',result.returncode,flush=True)
