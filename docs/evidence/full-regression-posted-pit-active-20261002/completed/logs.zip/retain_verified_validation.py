"""Retain completed verification repairs; no aggregate PASS is inferred."""
from pathlib import Path
import hashlib
import json
import shutil

run = Path(__file__).resolve().parent
project = run.parent.parent
dest = project/'docs/evidence/full-regression-posted-pit-active-20261002/verification-repairs'
dest.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
progress = json.loads((run/'progress.json').read_text())
inputs = json.loads((run/'inputs.json').read_text())
records = {}

def retain(source,name=None):
    target = dest/(name or source.name)
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(source,target)
    records[target.relative_to(dest).as_posix()] = sha(target)

audits = ('phase3_boundaries alu stack_control events byte_prefix scalar shift '
          'data unary adjust segment stack_frame far strings io muldiv '
          'double_fault phase8 task_late null_ldtr').split()
corrected = {'events':'event-audit-corrected.log','unary':'mutation-unary-corrected.log',
             'segment':'mutation-segment-corrected.log','phase8':'mutation-phase8-corrected.log'}
for name in audits:
    stage = next(row for row in progress['stages'] if row.get('lane')=='audits' and row['stage']==name)
    retain(run/stage['log'],'initial-audits/'+name+'.log')
    if name in corrected:
        retain(run/corrected[name],'completed-audits/'+name+'.log')
        assert 'PASS:' in (run/corrected[name]).read_text() or '_AUDIT PASS' in (run/corrected[name]).read_text()
    else:
        assert stage['status']=='PASS'
for receipt in ('event-replays.json','mutation-replays.json','phase8-replays.json',
                'memory-replays.json','manifest-replays.json','contract-replays.json',
                'additional-unit-replays.json'):
    obj = json.loads((run/receipt).read_text())
    assert all(r['exit_status']==0 for r in obj['runs']), receipt
    retain(run/receipt)
    for row in obj['runs']:
        log = row.get('log')
        if log and (run/log).is_file(): retain(run/log)
for log in ('event-directed-corrected.log','memory-comparator-negative-controls-corrected.log',
            'memory-memory-perf-corrected.log','memory-integration-corrected.log',
            'mutation-source-manifest-corrected.log'):
    retain(run/log)
for stage_name in ('test_i1_cpu_package','test_at_machine_boundary','spk286_protected_retf'):
    stage = next(row for row in progress['stages'] if row['stage']==stage_name)
    assert stage['status']=='PASS'
    retain(run/stage['log'])
production = {n:h for n,h in inputs['source_sha256'].items()
              if n.startswith(('rtl/','sys/','vendor/spk286/rtl/','vendor/spk286/microcode/'))
              or n=='config.tcl'}
assert all(sha(project/n)==h for n,h in production.items())
(dest/'receipt.json').write_text(json.dumps(dict(status='VERIFICATION_REPAIRS_PASS',
    aggregate_regression_status='RUNNING_WITH_SEPARATE_OPEN_FAILURES',
    frozen_head=inputs['head'],cpu_macros=inputs['cpu_macros'],
    source_sha256=production,evidence_sha256=records,
    statement='All 20 CPU mutation families completed, including corrected exact rejection receipts. Source-manifest, event arbitration, memory-state comparator, SDRAM launch contract and machine manifest replays passed. This is not aggregate regression acceptance.'),indent=2)+'\n')
print('VERIFIED_VALIDATION_RETAINED',len(records),flush=True)
