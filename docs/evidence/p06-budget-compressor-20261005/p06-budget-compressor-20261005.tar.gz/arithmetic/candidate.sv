module budget_miter (
    input [9:0] profile_base_clocks, profile_repeat_setup, profile_repeat_iteration,
    input [2:0] profile_ea_clocks,
    input profile_repeated_string, profile_candidate_body, profile_repeat_nonempty_q,
    input profile_delivery_metadata,
    input [3:0] profile_prefix_count_q,
    input [31:0] register_state
);
    logic [11:0] profile_metadata_sum;
    logic [9:0] profile_metadata_clocks, candidate;
    function automatic logic [9:0] profile_metadata_budget(
        input logic [9:0] base, setup_clocks, iteration_clocks,
        input logic [2:0] ea,
        input logic repeated, nonempty, delivery,
        input logic [3:0] prefixes
    );
        logic [3:0] remaining_prefixes;
        logic [11:0] first, second, prefix_clocks, sum_bits, carry_bits, full_sum;
        remaining_prefixes = prefixes == 0 ? 4'd0 : prefixes - 4'd1;
        first = {2'd0, repeated ? setup_clocks : base};
        second = repeated ? (nonempty ? {2'd0, iteration_clocks} : 12'd0) : {9'd0, ea};
        prefix_clocks = repeated ? {7'd0, remaining_prefixes, 1'b0} :
                        delivery ? 12'd0 : {7'd0, prefixes, 1'b0};
        sum_bits = first ^ second ^ prefix_clocks;
        carry_bits = (first & second) | (first & prefix_clocks) | (second & prefix_clocks);
        full_sum = sum_bits + (carry_bits << 1);
        profile_metadata_budget = |full_sum[11:10] ? 10'd1023 : full_sum[9:0];
    endfunction
    always_comb begin
        profile_metadata_sum = {2'd0, profile_base_clocks} + {9'd0, profile_ea_clocks};
        if (profile_repeated_string) begin
            profile_metadata_sum = {2'd0, profile_repeat_setup} +
                ((profile_candidate_body ? register_state[16 +: 16] != 0 : profile_repeat_nonempty_q) ?
                 {2'd0, profile_repeat_iteration} : 12'd0);
            // Setup already includes one REP prefix. Any remaining counted
            // override/repeated prefix uses the estimated native fallback.
            if (profile_prefix_count_q != 0)
                profile_metadata_sum = profile_metadata_sum +
                    {7'd0, profile_prefix_count_q, 1'b0} - 12'd2;
        end else if (!profile_delivery_metadata) begin
            // Provisional native fallback; LOCK and 0F are not charged again.
            profile_metadata_sum = profile_metadata_sum + {7'd0, profile_prefix_count_q, 1'b0};
        end
        profile_metadata_clocks = profile_metadata_sum > 12'd1023 ?
                                  10'd1023 : profile_metadata_sum[9:0];
    end

    assign candidate = profile_metadata_budget(profile_base_clocks,
        profile_repeat_setup, profile_repeat_iteration, profile_ea_clocks,
        profile_repeated_string,
        profile_candidate_body ? register_state[16 +: 16] != 0 : profile_repeat_nonempty_q,
        profile_delivery_metadata, profile_prefix_count_q);
    always @* assert(candidate == profile_metadata_clocks);
endmodule
