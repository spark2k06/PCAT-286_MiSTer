import hashlib, io, json, subprocess, tarfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
dest=root/'docs/evidence/p06-budget-compressor-20261005'
dest.mkdir(exist_ok=False)
def sha(data):return hashlib.sha256(data).hexdigest()
def write(name,value):
    (dest/name).write_text(json.dumps(value,indent=2)+'\n',newline='\n')
runs={name:root/f'build/p06-budget-compressor-{name}-20261005-v1' for name in ('formal','integration','components','cost','arithmetic')}
receipts={name:json.loads((path/('components.json' if name=='components' else 'receipt.json')).read_text()) for name,path in runs.items()}
assert receipts['formal']['status']=='EXECUTION_DEADLINE_EQUIVALENCE_PASS'
assert receipts['integration']['status']=='PASS'
assert receipts['cost']['status']=='PASS'
assert receipts['arithmetic']['status']=='METADATA_BUDGET_EQUIVALENCE_PASS'
baseline=root/'docs/evidence/p06-event-late-20261005/integration.json'
control=json.loads(baseline.read_text())
assert receipts['integration']['results']==control['results']
comparison={'status':'EXACT_DIRECTED_RESULTS_IDENTICAL','baseline':str(baseline.relative_to(root)),
    'baseline_sha256':sha(baseline.read_bytes()),'scope':'Entire results list, all eight profiles, both simulators, events/faults/cancellation/HOLD and raw MAX stream',
    'candidate_result_entries':len(receipts['integration']['results']),'full_regression':'USER_DEFERRED'}
payload={'collector.py':Path(__file__).read_bytes(),'baseline-integration.json':baseline.read_bytes()}
for label,path in runs.items():
    for p in sorted(path.rglob('*')):
        parts=p.relative_to(path).parts
        if p.is_file() and not any(v in ('obj','prefix-verilator','schedule-verilator') for v in parts) and p.suffix!='.vvp':
            payload[f'{label}/{p.relative_to(path).as_posix()}']=p.read_bytes()
    for name,digest in receipts[label].get('sources_sha256',{}).items():
        name=name.replace('\\','/');p=root/name
        assert p.resolve().is_relative_to(root.resolve()),name
        data=p.read_bytes();assert sha(data)==digest,name
        payload['sources/'+name]=data
for name in ['scripts/test_p06_metadata_budget_equivalence.py','scripts/test_p06_target_handoff_integration.py','scripts/check_p06_profile_components.py',
    'scripts/build_p06_profile_cpu.py','scripts/test_p06_execution_deadline_equivalence.py',
    'build/cost-p06-budget-compressor-20261005.py','SYSTEM.sdc','vendor/spk286/rtl/timed/generation.json']:
    payload['sources/'+name]=(root/name).read_bytes()
payload['reference-builder.py']=subprocess.check_output(['git','show','c38898c:scripts/build_p06_profile_cpu.py'],cwd=root)
archive=dest/'p06-budget-compressor-20261005.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as target:
    for name,data in payload.items():
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
        target.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as target:
    assert set(target.getnames())==set(payload)
    for member in target:
        assert target.extractfile(member).read()==payload[member.name],member.name
for label,value in receipts.items():write(label+'.json',value)
write('baseline-comparison.json',comparison)
write('manifest.json',{'status':'SEALED_DIRECTED_PASS_NOT_FITTED','archive':archive.name,
    'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'members':len(payload),
    'verification':'Every archived member read back equal to original bytes',
    'source_sha256':{name[8:]:sha(data) for name,data in payload.items() if name.startswith('sources/')},
    'full_regression':'USER_DEFERRED','hardware':'NOT_RUN'})
write('cleanup.json',{'status':'PENDING','targets':[str(p.relative_to(root)) for p in runs.values()]+
    ['build/cost-p06-budget-compressor-20261005.py','build/archive-p06-budget-compressor-20261005.py'],
    'removed_logical_bytes':None,'archive_sha256':sha(archive.read_bytes()),'verification':'Archive bytes verified before cleanup'})
print('EVENT_LATE_SEALED',len(payload),archive.stat().st_size,sha(archive.read_bytes()))
