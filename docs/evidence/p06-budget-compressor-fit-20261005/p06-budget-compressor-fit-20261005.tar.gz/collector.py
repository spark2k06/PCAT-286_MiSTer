import hashlib,io,json,re,sys,tarfile
from datetime import datetime
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'scripts'))
from audit_fixed50_fit import resources,fitted_seed
from analyze_pcat_resources import parse
from check_sync_microcode_image import analyze_compiled_image
label=sys.argv[1]
assert label in ('event-late','budget-compressor','repeat-local')
prior={'event-late':'deadline-csa','budget-compressor':'event-late','repeat-local':'budget-compressor'}[label]
guard='0.700' if label=='event-late' else '0.500'
fit=root/f'build/p06-{label}-allfeatures-20261005-v1'
original=root/f'build/p06-{label}-original-sdc-sta-20261005-v1'
baseline=root/f'build/p06-{prior}-allfeatures-20261005-v1'
packet=root/f'docs/evidence/p06-{label}-20261005'
dest=root/f'docs/evidence/p06-{label}-fit-20261005'
assert not (dest/'manifest.json').exists(), 'Completed packets are immutable'
dest.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text())
def write(name,value): (dest/name).write_text(json.dumps(value,indent=2)+'\n',newline='\n')
manifest=read(fit/'manifest.json');control=read(baseline/'manifest.json')
assert (fit/'completed.txt').is_file() and (original/'summary.json').is_file()
assert 'Full Compilation was successful. 0 errors' in (fit/'compile.log').read_text()
assert 'All original fitted artifacts verified unchanged after original-SDC STA' in (original/'original-artifacts-verified.log').read_text()
current=read(fit/'summary.json');old_sdc=read(original/'summary.json');previous=read(baseline/'summary.json')
def margins(summary):
    return {kind:min((groups[kind]['global']['tool_worst_slack_ns'],corner)
                    for corner,groups in summary['corners'].items()) for kind in ('setup','hold','recovery','removal')}
def scoped(summary,kind,group):
    return min((groups[kind][group]['tool_worst_slack_ns'],corner)
               for corner,groups in summary['corners'].items())
assert len(current['corners'])==len(old_sdc['corners'])==4
assert margins(old_sdc)['hold'][0]>0
new_sdc=(fit/'work/SYSTEM.sdc').read_text()
without_added=new_sdc[:new_sdc.index("# The palette's MLAB")]+new_sdc[new_sdc.index('proc at_clock'):]
assert sha(without_added.encode())==sha((root/'build/p06-original-sdc-20261005/SYSTEM.sdc').read_bytes())
assert f'set_min_delay -from $at_dac_write_index -to $at_dac_write_address {guard}' in new_sdc
unchanged=[]
for name,digest in manifest['source_sha256'].items():
    if name.endswith(('.sdc','.qsf','.qip','.qpf','.tcl')) and name!='SYSTEM.sdc':
        assert control['source_sha256'][name]==digest,name
        unchanged.append(name)
changes=[];payload={'collector.py':Path(__file__).read_bytes()}
for name,digest in manifest['source_sha256'].items():
    data=(fit/'work'/name).read_bytes()
    if sha(data)!=digest:
        assert name=='build_id.v',name
        value='`define BUILD_DATE "'+datetime.fromisoformat((fit/'compile-started.txt').read_text().strip()).strftime('%y%m%d')+'"'
        assert data.decode()==value
        changes.append({'path':name,'before_sha256':digest,'compiled_sha256':sha(data),'rule':'Unchanged sys/build_id.tcl compile preflow, BUILD_DATE only'})
    payload['effective-source/'+name]=data
bindings={}
for name in (('formal','components','integration','arithmetic') if label=='budget-compressor' else ('formal','components','integration')):
    value=read(packet/(name+'.json'))
    for key in ('sources_sha256','source_sha256'):
        for source,digest in value.get(key,{}).items():
            assert sha((fit/'work'/source).read_bytes())==digest,source
    for source,digest in value.get('generated_sha256',{}).items():
        assert sha((fit/'work/vendor/spk286/rtl/timed'/source).read_bytes())==digest,source
    bindings[name]=sha((packet/(name+'.json')).read_bytes())
    payload['functional/'+name+'.json']=(packet/(name+'.json')).read_bytes()
out=fit/'work/output_files'
rows=parse(out/'PCAT-286.fit.rpt')
cpu=next(row for row in rows if row['path'].endswith('|spk286_profiled:cpu'))
res=resources(out);res['cpu']={key:cpu[key]['inclusive'] for key in ('alm_needed','alm_placed','registers','io_registers','memory_bits','m10k')}
seed=fitted_seed((fit/'work/PCAT-286.qsf').read_text(),(out/'PCAT-286.fit.rpt').read_text())
assert 'AT SDC DAC minimum route: 8 sources, 288 endpoints' in (fit/'compile.log').read_text()
rom=analyze_compiled_image(fit);payload['compiled-rom/'+rom['mif']]=(fit/'work'/rom['mif']).read_bytes()
rbf=out/'PCAT-286.rbf'
result={'status':'SETUP_OPEN_ORIGINAL_SDC_HOLD_POSITIVE','baseline':baseline.relative_to(root).as_posix(),'candidate':fit.relative_to(root).as_posix(),
    'baseline_resources':resources(baseline/'work/output_files'),'resources':res,'seed':seed,
    'baseline_margins_ns':margins(previous),'palette_minimum_route_ns':float(guard),'with_extra_route_requirement':margins(current),
    'same_fit_original_sdc':margins(old_sdc),'cpu_setup_ns':scoped(current,'setup','cpu'),
    'cpu_hold_ns':scoped(current,'hold','cpu'),
    'sdram':{kind:{group:scoped(current,kind,group) for group in ('sdram_input','sdram_output')} for kind in ('setup','hold')},
    'scope_binding':{'sources':8,'endpoints':288},'unchanged_settings_constraints':unchanged,
    'controlled_generated_changes':changes,'functional_receipt_bindings':bindings,'compiled_rom':rom,
    'rbf':{'path':rbf.relative_to(root).as_posix(),'bytes':rbf.stat().st_size,'sha256':sha(rbf.read_bytes())},
    'full_regression':'USER_DEFERRED','hardware':'NOT_RUN',
    'interpretation':'Original-SDC STA uses identical fitted artifacts and preserves all original clocked paths. Additional palette minimum route is measured separately. Setup remains open unless every reported global setup/hold/recovery/removal margin is positive.'}
result['status']='SETUP_OPEN_ORIGINAL_SDC_HOLD_POSITIVE' if margins(current)['setup'][0]<0 else 'CHECK_ALL_MARGINS_FOR_CLOSURE'
write('result.json',result)
write('hierarchy.json',rows)
for run_label,run in [('fit',fit),('original-sdc',original)]:
    for p in run.rglob('*'):
        if not p.is_file():continue
        parts=p.relative_to(run).parts
        if parts[0]=='work':
            if len(parts)<3 or parts[1]!='output_files' or p.suffix in ('.rbf','.sof','.smsg'):continue
        payload[run_label+'/'+p.relative_to(run).as_posix()]=p.read_bytes()
for name in (f'run-p06-{label}-allfeatures-20261005-v1.sh','prepare-p06-original-sdc-sta-20261005.py','run-p06-original-sdc-sta-20261005.sh','prepare-p06-original-sdc-20261005.py'):
    payload['launch/'+name]=(root/'build'/name).read_bytes()
payload['reference-original-sdc.json']=(root/'build/p06-original-sdc-20261005/reference.json').read_bytes()
payload['result.json']=(dest/'result.json').read_bytes();payload['hierarchy.json']=(dest/'hierarchy.json').read_bytes()
archive=dest/f'p06-{label}-fit-20261005.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as target:
    for name,data in payload.items():
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
        target.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as target:
    assert set(target.getnames())==set(payload)
    for member in target:assert target.extractfile(member).read()==payload[member.name],member.name
write('manifest.json',{'status':'SEALED_FIT_AND_INDEPENDENT_ORIGINAL_SDC_STA','archive':archive.name,
    'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'members':len(payload),
    'frozen_head':manifest['head'],'fitted_source_count':len(manifest['source_sha256']),
    'verification':'Every archived member matched original bytes before cleanup','rbf':result['rbf'],
    'excluded':'RBF/SOF retained in output_files; compiler databases excluded; actual compiled M10K ROM retained'})
write('cleanup.json',{'status':'PENDING','targets':[str((fit/'work'/p.name).relative_to(root)).replace('\\','/') for p in (fit/'work').iterdir() if p.name!='output_files'],
    'removed_logical_bytes':None,'archive_sha256':sha(archive.read_bytes()),'rbf_sha256':result['rbf']['sha256']})
print('NEXT_FIT_SEALED',label,len(payload),archive.stat().st_size)
