#!/usr/bin/env python3
"""Seal completed bounded buffer proofs; do not execute tests or edit RTL."""
import gzip
import hashlib
import io
import json
import shutil
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
DEST = ROOT / 'docs/evidence/p06-buffer-idle-payload-20261005'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

proof = json.loads((WORK / 'proof-v3/receipt.json').read_text())
directed = json.loads((WORK / 'directed-v2/receipt.json').read_text())
assert proof['status'] == 'AT_BUFFER_IDLE_PAYLOAD_EQUIVALENCE_PASS'
assert directed['status'] == 'AT_BUFFER_IDLE_PAYLOAD_DIRECTED_PASS'
assert len(proof['cases']) == 6
assert len(directed['runs']) == 26
for run in directed['runs']:
    log = WORK / 'directed-v2' / (run['name'] + '.log')
    assert sha(log) == run['log_sha256'] and run['exit_code'] == 0
    if run['marker']:
        assert run['marker'] in log.read_text()
for case in proof['cases']:
    folder = WORK / 'proof-v3' / case['case']
    assert 'SUCCESS!' in (folder / 'proof.log').read_text()
    assert 'proof did fail' in (folder / 'negative/proof.log').read_text()
    assert (folder / 'negative/counterexample.json').is_file()
sources = dict(directed['sources_sha256'])
sources['scripts/prove_at_buffer_payload.py'] = proof['proof_script_sha256']
for relative, digest in sources.items():
    path = ROOT / relative
    assert sha(path) == digest, f'Completed check input changed: {relative}'
    frozen = WORK / 'final-source' / relative
    frozen.parent.mkdir(parents=True, exist_ok=True)
    frozen.write_bytes(path.read_bytes())

reference = {}
for case in proof['cases']:
    module = {'read': 'spk286_at_sdram_read_buffer',
              'data': 'spk286_at_sdram_data_buffer',
              'posted': 'spk286_at_posted_write_buffer'}[case['case'].split('-')[0]]
    relative = f'rtl/spk286_integration/{module}.sv'
    path = WORK / 'reference' / relative
    assert sha(path) == case['reference_sha256']
    assert sources[relative] == case['candidate_sha256']
    reference[relative] = case['reference_sha256']

# Retain exact generated proof cones, comparisons and counterexamples, rather
# than reducing the induction claim to a manually written behavioral model.
artifact_paths = []
for path in sorted(WORK.rglob('*')):
    if not path.is_file() or path.name == 'receipt.json' and path.parent == WORK:
        continue
    relative = path.relative_to(WORK)
    if any(part.endswith('-obj') or part == 'tmp' for part in relative.parts):
        continue
    if path.suffix in ('.vvp', '.gch', '.o', '.a'):
        continue
    artifact_paths.append(path)
artifacts = {str(p.relative_to(WORK)).replace('\\', '/'): {'sha256': sha(p), 'bytes': p.stat().st_size}
             for p in artifact_paths}
receipt = {
    'status': 'AT_BUFFER_IDLE_PAYLOAD_VALIDATION_PASS',
    'sources_sha256': sources,
    'reference_sha256': reference,
    'proof': {
        'receipt': 'proof-v3/receipt.json', 'receipt_sha256': sha(WORK / 'proof-v3/receipt.json'),
        'cases': [{'case': c['case'], 'parameters': c['parameters'], 'actual_ff_bits': c['state_bits'],
                   'memory_count': len(c['memories']), 'positive': 'PASS',
                   'negative_address_mutant': 'REJECTED_WITH_SAT_COUNTEREXAMPLE'} for c in proof['cases']],
        'assumptions': proof['assumptions'], 'qualified_outputs': proof['qualified_outputs'],
        'unconditional': proof['unconditional'],
        'state_and_memory_geometry': 'Actual FF type/width/reset and RAM descriptors are identical in each reference/candidate pair.',
    },
    'directed': {
        'receipt': 'directed-v2/receipt.json', 'receipt_sha256': sha(WORK / 'directed-v2/receipt.json'),
        'lint': 'PASS: exact frozen reference/candidate diagnostic equality; no new warnings.',
        'lint_warning_matches': directed['lint_warning_matches'],
        'tests': [{'name': r['name'], 'status': 'PASS', 'marker': r['marker'],
                   'log_sha256': r['log_sha256']} for r in directed['runs'] if r['marker']],
        'exceptions': directed['exceptions'],
        'compile_reuse': directed['compile_reuse'], 'source_guard': directed['source_guard'],
    },
    'earlier_trials': {
        'proof-v1': 'Incomplete exporter trial: generated hierarchy dots required safe identifier sanitization; no accepted proof.',
        'proof-v2': 'Default positive/negative passed; unoptimized production SAT explicitly interrupted. Superseded by complete proof-v3, no PASS claim for interrupted case.',
        'directed-v1': 'Stopped on pre-existing strict isolated lint warnings. Superseded by exact reference/candidate diagnostic comparison in directed-v2; RTL and existing assertions unchanged.',
    },
    'full_regression': 'USER_DEFERRED: no complete regression was run or claimed for this change.',
    'timing_and_hardware': 'No fit, STA or hardware result is claimed by this bounded validation receipt.',
    'preserved_contract': 'No new state bits, added acceptance/response cycles, clock changes, SDRAM timing changes or disabled features. Inactive outgoing payload is deliberately unspecified when out_valid=0.',
    'artifacts_sha256': artifacts,
}
(WORK / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
artifact_paths.append(WORK / 'receipt.json')
DEST.mkdir(parents=True, exist_ok=True)
archive = DEST / 'evidence.tar.gz'
assert not archive.exists()
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0, filename='') as gz:
    with tarfile.open(fileobj=gz, mode='w') as tar:
        for path in sorted(artifact_paths):
            data = path.read_bytes()
            info = tarfile.TarInfo(str(path.relative_to(WORK)).replace('\\', '/'))
            info.size = len(data)
            info.mtime = 0
            info.mode = 0o644
            tar.addfile(info, io.BytesIO(data))
members = {}
with tarfile.open(archive, 'r:gz') as tar:
    for member in tar.getmembers():
        assert member.isfile() and member.name not in members
        data = tar.extractfile(member).read()
        original = WORK / member.name
        assert original.read_bytes() == data
        members[member.name] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
assert len(members) == len(artifact_paths)
manifest = {'status': 'ARCHIVE_MEMBERS_READBACK_VERIFIED', 'archive': archive.name,
            'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size,
            'members': members, 'sources_sha256': sources,
            'full_regression': receipt['full_regression']}
(DEST / 'archive-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
shutil.copyfile(WORK / 'receipt.json', DEST / 'receipt.json')
print(json.dumps({'status': receipt['status'], 'sources_sha256': sources,
                  'archive': str(archive), 'archive_sha256': sha(archive),
                  'members': len(members), 'archive_bytes': archive.stat().st_size}, indent=2))
