module invariant(
input wire clk,
input wire reset,
input wire cancel_cpu,
input wire enable,
input wire in_valid,
input wire in_command_valid,
input wire [1:0] in_owner,
input wire in_write,
input wire in_refresh,
input wire in_code_fetch,
input wire [3:0] in_cycle_class,
input wire [24:0] in_address,
input wire [1:0] in_byte_enable,
input wire [15:0] in_data_out,
input wire out_accept,
input wire out_ready,
input wire [15:0] out_read_data,
input wire out_read_data_valid,
input wire [31:0] previous_debug_hit_count,
input wire [31:0] previous_debug_miss_count,
input wire [31:0] previous_debug_fill_count,
input wire [31:0] previous_debug_physical_read_count,
input wire [31:0] previous_debug_invalidation_count,
input wire [1:0] previous_state_q,
input wire previous_physical_inflight_q,
input wire [1:0] previous_fill_index_q,
input wire [63:0] previous_line_valid_q,
input wire [15:0] previous_fill_word_q,
input wire [5:0] previous_request_index_q,
input wire [1:0] previous_request_owner_q,
input wire previous_request_write_q,
input wire previous_request_refresh_q,
input wire previous_request_code_fetch_q,
input wire [3:0] previous_request_cycle_class_q,
input wire [24:0] previous_request_address_q,
input wire [1:0] previous_request_byte_enable_q,
input wire [15:0] previous_request_data_out_q,
input wire [24:0] previous_request_line_base_q,
input wire previous_request_cancelled_q,
input wire [15:0] previous_hit_data_q,
input wire [31:0] memory_g_async_tags_scope_line_tag_q_RD_DATA,
input wire [15:0] memory_line_data_q_RD_DATA,
output wire step_ok
);
wire in_accept_gold;
wire in_accept_gate;
wire in_ready_gold;
wire in_ready_gate;
wire [15:0] in_read_data_gold;
wire [15:0] in_read_data_gate;
wire in_read_data_valid_gold;
wire in_read_data_valid_gate;
wire out_valid_gold;
wire out_valid_gate;
wire out_command_valid_gold;
wire out_command_valid_gate;
wire [1:0] out_owner_gold;
wire [1:0] out_owner_gate;
wire out_write_gold;
wire out_write_gate;
wire out_refresh_gold;
wire out_refresh_gate;
wire out_code_fetch_gold;
wire out_code_fetch_gate;
wire out_burst_gold;
wire out_burst_gate;
wire [3:0] out_cycle_class_gold;
wire [3:0] out_cycle_class_gate;
wire [24:0] out_address_gold;
wire [24:0] out_address_gate;
wire [1:0] out_byte_enable_gold;
wire [1:0] out_byte_enable_gate;
wire [15:0] out_data_out_gold;
wire [15:0] out_data_out_gate;
wire [31:0] debug_hit_count_gold;
wire [31:0] debug_hit_count_gate;
wire [31:0] debug_miss_count_gold;
wire [31:0] debug_miss_count_gate;
wire [31:0] debug_fill_count_gold;
wire [31:0] debug_fill_count_gate;
wire [31:0] debug_physical_read_count_gold;
wire [31:0] debug_physical_read_count_gate;
wire [31:0] debug_invalidation_count_gold;
wire [31:0] debug_invalidation_count_gate;
wire [4:0] debug_state_gold;
wire [4:0] debug_state_gate;
wire [31:0] next_debug_hit_count_gold;
wire [31:0] next_debug_hit_count_gate;
wire [31:0] next_debug_miss_count_gold;
wire [31:0] next_debug_miss_count_gate;
wire [31:0] next_debug_fill_count_gold;
wire [31:0] next_debug_fill_count_gate;
wire [31:0] next_debug_physical_read_count_gold;
wire [31:0] next_debug_physical_read_count_gate;
wire [31:0] next_debug_invalidation_count_gold;
wire [31:0] next_debug_invalidation_count_gate;
wire [1:0] next_state_q_gold;
wire [1:0] next_state_q_gate;
wire next_physical_inflight_q_gold;
wire next_physical_inflight_q_gate;
wire [1:0] next_fill_index_q_gold;
wire [1:0] next_fill_index_q_gate;
wire [63:0] next_line_valid_q_gold;
wire [63:0] next_line_valid_q_gate;
wire [15:0] next_fill_word_q_gold;
wire [15:0] next_fill_word_q_gate;
wire [5:0] next_request_index_q_gold;
wire [5:0] next_request_index_q_gate;
wire [1:0] next_request_owner_q_gold;
wire [1:0] next_request_owner_q_gate;
wire next_request_write_q_gold;
wire next_request_write_q_gate;
wire next_request_refresh_q_gold;
wire next_request_refresh_q_gate;
wire next_request_code_fetch_q_gold;
wire next_request_code_fetch_q_gate;
wire [3:0] next_request_cycle_class_q_gold;
wire [3:0] next_request_cycle_class_q_gate;
wire [24:0] next_request_address_q_gold;
wire [24:0] next_request_address_q_gate;
wire [1:0] next_request_byte_enable_q_gold;
wire [1:0] next_request_byte_enable_q_gate;
wire [15:0] next_request_data_out_q_gold;
wire [15:0] next_request_data_out_q_gate;
wire [24:0] next_request_line_base_q_gold;
wire [24:0] next_request_line_base_q_gate;
wire next_request_cancelled_q_gold;
wire next_request_cancelled_q_gate;
wire [15:0] next_hit_data_q_gold;
wire [15:0] next_hit_data_q_gate;
wire [11:0] memory_g_async_tags_scope_line_tag_q_RD_ADDR_gold;
wire [11:0] memory_g_async_tags_scope_line_tag_q_RD_ADDR_gate;
wire [1:0] memory_g_async_tags_scope_line_tag_q_RD_ARST_gold;
wire [1:0] memory_g_async_tags_scope_line_tag_q_RD_ARST_gate;
wire [1:0] memory_g_async_tags_scope_line_tag_q_RD_CLK_gold;
wire [1:0] memory_g_async_tags_scope_line_tag_q_RD_CLK_gate;
wire [1:0] memory_g_async_tags_scope_line_tag_q_RD_EN_gold;
wire [1:0] memory_g_async_tags_scope_line_tag_q_RD_EN_gate;
wire [1:0] memory_g_async_tags_scope_line_tag_q_RD_SRST_gold;
wire [1:0] memory_g_async_tags_scope_line_tag_q_RD_SRST_gate;
wire [5:0] memory_g_async_tags_scope_line_tag_q_WR_ADDR_gold;
wire [5:0] memory_g_async_tags_scope_line_tag_q_WR_ADDR_gate;
wire memory_g_async_tags_scope_line_tag_q_WR_CLK_gold;
wire memory_g_async_tags_scope_line_tag_q_WR_CLK_gate;
wire [15:0] memory_g_async_tags_scope_line_tag_q_WR_DATA_gold;
wire [15:0] memory_g_async_tags_scope_line_tag_q_WR_DATA_gate;
wire [15:0] memory_g_async_tags_scope_line_tag_q_WR_EN_gold;
wire [15:0] memory_g_async_tags_scope_line_tag_q_WR_EN_gate;
wire [7:0] memory_line_data_q_RD_ADDR_gold;
wire [7:0] memory_line_data_q_RD_ADDR_gate;
wire memory_line_data_q_RD_ARST_gold;
wire memory_line_data_q_RD_ARST_gate;
wire memory_line_data_q_RD_CLK_gold;
wire memory_line_data_q_RD_CLK_gate;
wire memory_line_data_q_RD_EN_gold;
wire memory_line_data_q_RD_EN_gate;
wire memory_line_data_q_RD_SRST_gold;
wire memory_line_data_q_RD_SRST_gate;
wire [7:0] memory_line_data_q_WR_ADDR_gold;
wire [7:0] memory_line_data_q_WR_ADDR_gate;
wire memory_line_data_q_WR_CLK_gold;
wire memory_line_data_q_WR_CLK_gate;
wire [15:0] memory_line_data_q_WR_DATA_gold;
wire [15:0] memory_line_data_q_WR_DATA_gate;
wire [15:0] memory_line_data_q_WR_EN_gold;
wire [15:0] memory_line_data_q_WR_EN_gate;
buffer_gold u_gold(.clk(clk),.reset(reset),.cancel_cpu(cancel_cpu),.enable(enable),.in_valid(in_valid),.in_command_valid(in_command_valid),.in_owner(in_owner),.in_write(in_write),.in_refresh(in_refresh),.in_code_fetch(in_code_fetch),.in_cycle_class(in_cycle_class),.in_address(in_address),.in_byte_enable(in_byte_enable),.in_data_out(in_data_out),.in_accept(in_accept_gold),.in_ready(in_ready_gold),.in_read_data(in_read_data_gold),.in_read_data_valid(in_read_data_valid_gold),.out_valid(out_valid_gold),.out_command_valid(out_command_valid_gold),.out_owner(out_owner_gold),.out_write(out_write_gold),.out_refresh(out_refresh_gold),.out_code_fetch(out_code_fetch_gold),.out_burst(out_burst_gold),.out_cycle_class(out_cycle_class_gold),.out_address(out_address_gold),.out_byte_enable(out_byte_enable_gold),.out_data_out(out_data_out_gold),.out_accept(out_accept),.out_ready(out_ready),.out_read_data(out_read_data),.out_read_data_valid(out_read_data_valid),.debug_hit_count(debug_hit_count_gold),.debug_miss_count(debug_miss_count_gold),.debug_fill_count(debug_fill_count_gold),.debug_physical_read_count(debug_physical_read_count_gold),.debug_invalidation_count(debug_invalidation_count_gold),.debug_state(debug_state_gold),.previous_debug_hit_count(previous_debug_hit_count),.next_debug_hit_count(next_debug_hit_count_gold),.previous_debug_miss_count(previous_debug_miss_count),.next_debug_miss_count(next_debug_miss_count_gold),.previous_debug_fill_count(previous_debug_fill_count),.next_debug_fill_count(next_debug_fill_count_gold),.previous_debug_physical_read_count(previous_debug_physical_read_count),.next_debug_physical_read_count(next_debug_physical_read_count_gold),.previous_debug_invalidation_count(previous_debug_invalidation_count),.next_debug_invalidation_count(next_debug_invalidation_count_gold),.previous_state_q(previous_state_q),.next_state_q(next_state_q_gold),.previous_physical_inflight_q(previous_physical_inflight_q),.next_physical_inflight_q(next_physical_inflight_q_gold),.previous_fill_index_q(previous_fill_index_q),.next_fill_index_q(next_fill_index_q_gold),.previous_line_valid_q(previous_line_valid_q),.next_line_valid_q(next_line_valid_q_gold),.previous_fill_word_q(previous_fill_word_q),.next_fill_word_q(next_fill_word_q_gold),.previous_request_index_q(previous_request_index_q),.next_request_index_q(next_request_index_q_gold),.previous_request_owner_q(previous_request_owner_q),.next_request_owner_q(next_request_owner_q_gold),.previous_request_write_q(previous_request_write_q),.next_request_write_q(next_request_write_q_gold),.previous_request_refresh_q(previous_request_refresh_q),.next_request_refresh_q(next_request_refresh_q_gold),.previous_request_code_fetch_q(previous_request_code_fetch_q),.next_request_code_fetch_q(next_request_code_fetch_q_gold),.previous_request_cycle_class_q(previous_request_cycle_class_q),.next_request_cycle_class_q(next_request_cycle_class_q_gold),.previous_request_address_q(previous_request_address_q),.next_request_address_q(next_request_address_q_gold),.previous_request_byte_enable_q(previous_request_byte_enable_q),.next_request_byte_enable_q(next_request_byte_enable_q_gold),.previous_request_data_out_q(previous_request_data_out_q),.next_request_data_out_q(next_request_data_out_q_gold),.previous_request_line_base_q(previous_request_line_base_q),.next_request_line_base_q(next_request_line_base_q_gold),.previous_request_cancelled_q(previous_request_cancelled_q),.next_request_cancelled_q(next_request_cancelled_q_gold),.previous_hit_data_q(previous_hit_data_q),.next_hit_data_q(next_hit_data_q_gold),.memory_g_async_tags_scope_line_tag_q_RD_ADDR(memory_g_async_tags_scope_line_tag_q_RD_ADDR_gold),.memory_g_async_tags_scope_line_tag_q_RD_ARST(memory_g_async_tags_scope_line_tag_q_RD_ARST_gold),.memory_g_async_tags_scope_line_tag_q_RD_CLK(memory_g_async_tags_scope_line_tag_q_RD_CLK_gold),.memory_g_async_tags_scope_line_tag_q_RD_DATA(memory_g_async_tags_scope_line_tag_q_RD_DATA),.memory_g_async_tags_scope_line_tag_q_RD_EN(memory_g_async_tags_scope_line_tag_q_RD_EN_gold),.memory_g_async_tags_scope_line_tag_q_RD_SRST(memory_g_async_tags_scope_line_tag_q_RD_SRST_gold),.memory_g_async_tags_scope_line_tag_q_WR_ADDR(memory_g_async_tags_scope_line_tag_q_WR_ADDR_gold),.memory_g_async_tags_scope_line_tag_q_WR_CLK(memory_g_async_tags_scope_line_tag_q_WR_CLK_gold),.memory_g_async_tags_scope_line_tag_q_WR_DATA(memory_g_async_tags_scope_line_tag_q_WR_DATA_gold),.memory_g_async_tags_scope_line_tag_q_WR_EN(memory_g_async_tags_scope_line_tag_q_WR_EN_gold),.memory_line_data_q_RD_ADDR(memory_line_data_q_RD_ADDR_gold),.memory_line_data_q_RD_ARST(memory_line_data_q_RD_ARST_gold),.memory_line_data_q_RD_CLK(memory_line_data_q_RD_CLK_gold),.memory_line_data_q_RD_DATA(memory_line_data_q_RD_DATA),.memory_line_data_q_RD_EN(memory_line_data_q_RD_EN_gold),.memory_line_data_q_RD_SRST(memory_line_data_q_RD_SRST_gold),.memory_line_data_q_WR_ADDR(memory_line_data_q_WR_ADDR_gold),.memory_line_data_q_WR_CLK(memory_line_data_q_WR_CLK_gold),.memory_line_data_q_WR_DATA(memory_line_data_q_WR_DATA_gold),.memory_line_data_q_WR_EN(memory_line_data_q_WR_EN_gold));
buffer_gate u_gate(.clk(clk),.reset(reset),.cancel_cpu(cancel_cpu),.enable(enable),.in_valid(in_valid),.in_command_valid(in_command_valid),.in_owner(in_owner),.in_write(in_write),.in_refresh(in_refresh),.in_code_fetch(in_code_fetch),.in_cycle_class(in_cycle_class),.in_address(in_address),.in_byte_enable(in_byte_enable),.in_data_out(in_data_out),.in_accept(in_accept_gate),.in_ready(in_ready_gate),.in_read_data(in_read_data_gate),.in_read_data_valid(in_read_data_valid_gate),.out_valid(out_valid_gate),.out_command_valid(out_command_valid_gate),.out_owner(out_owner_gate),.out_write(out_write_gate),.out_refresh(out_refresh_gate),.out_code_fetch(out_code_fetch_gate),.out_burst(out_burst_gate),.out_cycle_class(out_cycle_class_gate),.out_address(out_address_gate),.out_byte_enable(out_byte_enable_gate),.out_data_out(out_data_out_gate),.out_accept(out_accept),.out_ready(out_ready),.out_read_data(out_read_data),.out_read_data_valid(out_read_data_valid),.debug_hit_count(debug_hit_count_gate),.debug_miss_count(debug_miss_count_gate),.debug_fill_count(debug_fill_count_gate),.debug_physical_read_count(debug_physical_read_count_gate),.debug_invalidation_count(debug_invalidation_count_gate),.debug_state(debug_state_gate),.previous_debug_hit_count(previous_debug_hit_count),.next_debug_hit_count(next_debug_hit_count_gate),.previous_debug_miss_count(previous_debug_miss_count),.next_debug_miss_count(next_debug_miss_count_gate),.previous_debug_fill_count(previous_debug_fill_count),.next_debug_fill_count(next_debug_fill_count_gate),.previous_debug_physical_read_count(previous_debug_physical_read_count),.next_debug_physical_read_count(next_debug_physical_read_count_gate),.previous_debug_invalidation_count(previous_debug_invalidation_count),.next_debug_invalidation_count(next_debug_invalidation_count_gate),.previous_state_q(previous_state_q),.next_state_q(next_state_q_gate),.previous_physical_inflight_q(previous_physical_inflight_q),.next_physical_inflight_q(next_physical_inflight_q_gate),.previous_fill_index_q(previous_fill_index_q),.next_fill_index_q(next_fill_index_q_gate),.previous_line_valid_q(previous_line_valid_q),.next_line_valid_q(next_line_valid_q_gate),.previous_fill_word_q(previous_fill_word_q),.next_fill_word_q(next_fill_word_q_gate),.previous_request_index_q(previous_request_index_q),.next_request_index_q(next_request_index_q_gate),.previous_request_owner_q(previous_request_owner_q),.next_request_owner_q(next_request_owner_q_gate),.previous_request_write_q(previous_request_write_q),.next_request_write_q(next_request_write_q_gate),.previous_request_refresh_q(previous_request_refresh_q),.next_request_refresh_q(next_request_refresh_q_gate),.previous_request_code_fetch_q(previous_request_code_fetch_q),.next_request_code_fetch_q(next_request_code_fetch_q_gate),.previous_request_cycle_class_q(previous_request_cycle_class_q),.next_request_cycle_class_q(next_request_cycle_class_q_gate),.previous_request_address_q(previous_request_address_q),.next_request_address_q(next_request_address_q_gate),.previous_request_byte_enable_q(previous_request_byte_enable_q),.next_request_byte_enable_q(next_request_byte_enable_q_gate),.previous_request_data_out_q(previous_request_data_out_q),.next_request_data_out_q(next_request_data_out_q_gate),.previous_request_line_base_q(previous_request_line_base_q),.next_request_line_base_q(next_request_line_base_q_gate),.previous_request_cancelled_q(previous_request_cancelled_q),.next_request_cancelled_q(next_request_cancelled_q_gate),.previous_hit_data_q(previous_hit_data_q),.next_hit_data_q(next_hit_data_q_gate),.memory_g_async_tags_scope_line_tag_q_RD_ADDR(memory_g_async_tags_scope_line_tag_q_RD_ADDR_gate),.memory_g_async_tags_scope_line_tag_q_RD_ARST(memory_g_async_tags_scope_line_tag_q_RD_ARST_gate),.memory_g_async_tags_scope_line_tag_q_RD_CLK(memory_g_async_tags_scope_line_tag_q_RD_CLK_gate),.memory_g_async_tags_scope_line_tag_q_RD_DATA(memory_g_async_tags_scope_line_tag_q_RD_DATA),.memory_g_async_tags_scope_line_tag_q_RD_EN(memory_g_async_tags_scope_line_tag_q_RD_EN_gate),.memory_g_async_tags_scope_line_tag_q_RD_SRST(memory_g_async_tags_scope_line_tag_q_RD_SRST_gate),.memory_g_async_tags_scope_line_tag_q_WR_ADDR(memory_g_async_tags_scope_line_tag_q_WR_ADDR_gate),.memory_g_async_tags_scope_line_tag_q_WR_CLK(memory_g_async_tags_scope_line_tag_q_WR_CLK_gate),.memory_g_async_tags_scope_line_tag_q_WR_DATA(memory_g_async_tags_scope_line_tag_q_WR_DATA_gate),.memory_g_async_tags_scope_line_tag_q_WR_EN(memory_g_async_tags_scope_line_tag_q_WR_EN_gate),.memory_line_data_q_RD_ADDR(memory_line_data_q_RD_ADDR_gate),.memory_line_data_q_RD_ARST(memory_line_data_q_RD_ARST_gate),.memory_line_data_q_RD_CLK(memory_line_data_q_RD_CLK_gate),.memory_line_data_q_RD_DATA(memory_line_data_q_RD_DATA),.memory_line_data_q_RD_EN(memory_line_data_q_RD_EN_gate),.memory_line_data_q_RD_SRST(memory_line_data_q_RD_SRST_gate),.memory_line_data_q_WR_ADDR(memory_line_data_q_WR_ADDR_gate),.memory_line_data_q_WR_CLK(memory_line_data_q_WR_CLK_gate),.memory_line_data_q_WR_DATA(memory_line_data_q_WR_DATA_gate),.memory_line_data_q_WR_EN(memory_line_data_q_WR_EN_gate));
assign step_ok = (in_accept_gold === in_accept_gate) &&
(in_ready_gold === in_ready_gate) &&
(in_read_data_gold === in_read_data_gate) &&
(in_read_data_valid_gold === in_read_data_valid_gate) &&
(out_valid_gold === out_valid_gate) &&
(out_command_valid_gold === out_command_valid_gate) &&
(!out_valid_gold || (out_owner_gold === out_owner_gate)) &&
(!out_valid_gold || (out_write_gold === out_write_gate)) &&
(!out_valid_gold || (out_refresh_gold === out_refresh_gate)) &&
(!out_valid_gold || (out_code_fetch_gold === out_code_fetch_gate)) &&
(!out_valid_gold || (out_burst_gold === out_burst_gate)) &&
(!out_valid_gold || (out_cycle_class_gold === out_cycle_class_gate)) &&
(!out_valid_gold || (out_address_gold === out_address_gate)) &&
(!out_valid_gold || (out_byte_enable_gold === out_byte_enable_gate)) &&
(!out_valid_gold || (out_data_out_gold === out_data_out_gate)) &&
(debug_hit_count_gold === debug_hit_count_gate) &&
(debug_miss_count_gold === debug_miss_count_gate) &&
(debug_fill_count_gold === debug_fill_count_gate) &&
(debug_physical_read_count_gold === debug_physical_read_count_gate) &&
(debug_invalidation_count_gold === debug_invalidation_count_gate) &&
(debug_state_gold === debug_state_gate) &&
(next_debug_hit_count_gold === next_debug_hit_count_gate) &&
(next_debug_miss_count_gold === next_debug_miss_count_gate) &&
(next_debug_fill_count_gold === next_debug_fill_count_gate) &&
(next_debug_physical_read_count_gold === next_debug_physical_read_count_gate) &&
(next_debug_invalidation_count_gold === next_debug_invalidation_count_gate) &&
(next_state_q_gold === next_state_q_gate) &&
(next_physical_inflight_q_gold === next_physical_inflight_q_gate) &&
(next_fill_index_q_gold === next_fill_index_q_gate) &&
(next_line_valid_q_gold === next_line_valid_q_gate) &&
(next_fill_word_q_gold === next_fill_word_q_gate) &&
(next_request_index_q_gold === next_request_index_q_gate) &&
(next_request_owner_q_gold === next_request_owner_q_gate) &&
(next_request_write_q_gold === next_request_write_q_gate) &&
(next_request_refresh_q_gold === next_request_refresh_q_gate) &&
(next_request_code_fetch_q_gold === next_request_code_fetch_q_gate) &&
(next_request_cycle_class_q_gold === next_request_cycle_class_q_gate) &&
(next_request_address_q_gold === next_request_address_q_gate) &&
(next_request_byte_enable_q_gold === next_request_byte_enable_q_gate) &&
(next_request_data_out_q_gold === next_request_data_out_q_gate) &&
(next_request_line_base_q_gold === next_request_line_base_q_gate) &&
(next_request_cancelled_q_gold === next_request_cancelled_q_gate) &&
(next_hit_data_q_gold === next_hit_data_q_gate) &&
(memory_g_async_tags_scope_line_tag_q_RD_ADDR_gold === memory_g_async_tags_scope_line_tag_q_RD_ADDR_gate) &&
(memory_g_async_tags_scope_line_tag_q_RD_ARST_gold === memory_g_async_tags_scope_line_tag_q_RD_ARST_gate) &&
(memory_g_async_tags_scope_line_tag_q_RD_CLK_gold === memory_g_async_tags_scope_line_tag_q_RD_CLK_gate) &&
(memory_g_async_tags_scope_line_tag_q_RD_EN_gold === memory_g_async_tags_scope_line_tag_q_RD_EN_gate) &&
(memory_g_async_tags_scope_line_tag_q_RD_SRST_gold === memory_g_async_tags_scope_line_tag_q_RD_SRST_gate) &&
(memory_g_async_tags_scope_line_tag_q_WR_ADDR_gold === memory_g_async_tags_scope_line_tag_q_WR_ADDR_gate) &&
(memory_g_async_tags_scope_line_tag_q_WR_CLK_gold === memory_g_async_tags_scope_line_tag_q_WR_CLK_gate) &&
((memory_g_async_tags_scope_line_tag_q_WR_DATA_gold & memory_g_async_tags_scope_line_tag_q_WR_EN_gold) === (memory_g_async_tags_scope_line_tag_q_WR_DATA_gate & memory_g_async_tags_scope_line_tag_q_WR_EN_gate)) &&
(memory_g_async_tags_scope_line_tag_q_WR_EN_gold === memory_g_async_tags_scope_line_tag_q_WR_EN_gate) &&
(memory_line_data_q_RD_ADDR_gold === memory_line_data_q_RD_ADDR_gate) &&
(memory_line_data_q_RD_ARST_gold === memory_line_data_q_RD_ARST_gate) &&
(memory_line_data_q_RD_CLK_gold === memory_line_data_q_RD_CLK_gate) &&
(memory_line_data_q_RD_EN_gold === memory_line_data_q_RD_EN_gate) &&
(memory_line_data_q_RD_SRST_gold === memory_line_data_q_RD_SRST_gate) &&
(memory_line_data_q_WR_ADDR_gold === memory_line_data_q_WR_ADDR_gate) &&
(memory_line_data_q_WR_CLK_gold === memory_line_data_q_WR_CLK_gate) &&
((memory_line_data_q_WR_DATA_gold & memory_line_data_q_WR_EN_gold) === (memory_line_data_q_WR_DATA_gate & memory_line_data_q_WR_EN_gate)) &&
(memory_line_data_q_WR_EN_gold === memory_line_data_q_WR_EN_gate);
endmodule
