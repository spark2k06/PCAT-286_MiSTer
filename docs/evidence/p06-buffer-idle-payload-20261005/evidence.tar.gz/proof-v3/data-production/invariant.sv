module invariant(
input wire clk,
input wire reset,
input wire cancel_cpu,
input wire enable,
input wire in_valid,
input wire in_command_valid,
input wire [1:0] in_owner,
input wire in_write,
input wire in_refresh,
input wire in_code_fetch,
input wire in_burst,
input wire [3:0] in_cycle_class,
input wire [24:0] in_address,
input wire [1:0] in_byte_enable,
input wire [15:0] in_data_out,
input wire out_accept,
input wire out_ready,
input wire [15:0] out_read_data,
input wire out_read_data_valid,
input wire [31:0] previous_debug_hit_count,
input wire [31:0] previous_debug_miss_count,
input wire [31:0] previous_debug_fill_count,
input wire [31:0] previous_debug_write_update_count,
input wire [1:0] previous_state_q,
input wire [255:0] previous_valid0_q,
input wire [255:0] previous_valid1_q,
input wire [255:0] previous_replace_q,
input wire previous_lookup_valid0_q,
input wire previous_lookup_valid1_q,
input wire previous_replace_way_q,
input wire [7:0] previous_index_q,
input wire [1:0] previous_owner_q,
input wire previous_write_q,
input wire previous_refresh_q,
input wire previous_code_q,
input wire previous_burst_q,
input wire previous_allocate_q,
input wire previous_cancelled_q,
input wire [3:0] previous_class_q,
input wire [24:0] previous_address_q,
input wire [1:0] previous_lanes_q,
input wire [15:0] previous_data_q,
input wire [31:0] previous_lookup0_q,
input wire [31:0] previous_lookup1_q,
input wire [31:0] memory_words0_q_RD_DATA,
input wire [31:0] memory_words1_q_RD_DATA,
output wire step_ok
);
wire in_accept_gold;
wire in_accept_gate;
wire in_ready_gold;
wire in_ready_gate;
wire [15:0] in_read_data_gold;
wire [15:0] in_read_data_gate;
wire in_read_data_valid_gold;
wire in_read_data_valid_gate;
wire out_valid_gold;
wire out_valid_gate;
wire out_command_valid_gold;
wire out_command_valid_gate;
wire [1:0] out_owner_gold;
wire [1:0] out_owner_gate;
wire out_write_gold;
wire out_write_gate;
wire out_refresh_gold;
wire out_refresh_gate;
wire out_code_fetch_gold;
wire out_code_fetch_gate;
wire out_burst_gold;
wire out_burst_gate;
wire [3:0] out_cycle_class_gold;
wire [3:0] out_cycle_class_gate;
wire [24:0] out_address_gold;
wire [24:0] out_address_gate;
wire [1:0] out_byte_enable_gold;
wire [1:0] out_byte_enable_gate;
wire [15:0] out_data_out_gold;
wire [15:0] out_data_out_gate;
wire [31:0] debug_hit_count_gold;
wire [31:0] debug_hit_count_gate;
wire [31:0] debug_miss_count_gold;
wire [31:0] debug_miss_count_gate;
wire [31:0] debug_fill_count_gold;
wire [31:0] debug_fill_count_gate;
wire [31:0] debug_write_update_count_gold;
wire [31:0] debug_write_update_count_gate;
wire [1:0] debug_state_gold;
wire [1:0] debug_state_gate;
wire [31:0] next_debug_hit_count_gold;
wire [31:0] next_debug_hit_count_gate;
wire [31:0] next_debug_miss_count_gold;
wire [31:0] next_debug_miss_count_gate;
wire [31:0] next_debug_fill_count_gold;
wire [31:0] next_debug_fill_count_gate;
wire [31:0] next_debug_write_update_count_gold;
wire [31:0] next_debug_write_update_count_gate;
wire [1:0] next_state_q_gold;
wire [1:0] next_state_q_gate;
wire [255:0] next_valid0_q_gold;
wire [255:0] next_valid0_q_gate;
wire [255:0] next_valid1_q_gold;
wire [255:0] next_valid1_q_gate;
wire [255:0] next_replace_q_gold;
wire [255:0] next_replace_q_gate;
wire next_lookup_valid0_q_gold;
wire next_lookup_valid0_q_gate;
wire next_lookup_valid1_q_gold;
wire next_lookup_valid1_q_gate;
wire next_replace_way_q_gold;
wire next_replace_way_q_gate;
wire [7:0] next_index_q_gold;
wire [7:0] next_index_q_gate;
wire [1:0] next_owner_q_gold;
wire [1:0] next_owner_q_gate;
wire next_write_q_gold;
wire next_write_q_gate;
wire next_refresh_q_gold;
wire next_refresh_q_gate;
wire next_code_q_gold;
wire next_code_q_gate;
wire next_burst_q_gold;
wire next_burst_q_gate;
wire next_allocate_q_gold;
wire next_allocate_q_gate;
wire next_cancelled_q_gold;
wire next_cancelled_q_gate;
wire [3:0] next_class_q_gold;
wire [3:0] next_class_q_gate;
wire [24:0] next_address_q_gold;
wire [24:0] next_address_q_gate;
wire [1:0] next_lanes_q_gold;
wire [1:0] next_lanes_q_gate;
wire [15:0] next_data_q_gold;
wire [15:0] next_data_q_gate;
wire [31:0] next_lookup0_q_gold;
wire [31:0] next_lookup0_q_gate;
wire [31:0] next_lookup1_q_gold;
wire [31:0] next_lookup1_q_gate;
wire [7:0] memory_words0_q_RD_ADDR_gold;
wire [7:0] memory_words0_q_RD_ADDR_gate;
wire memory_words0_q_RD_ARST_gold;
wire memory_words0_q_RD_ARST_gate;
wire memory_words0_q_RD_CLK_gold;
wire memory_words0_q_RD_CLK_gate;
wire memory_words0_q_RD_EN_gold;
wire memory_words0_q_RD_EN_gate;
wire memory_words0_q_RD_SRST_gold;
wire memory_words0_q_RD_SRST_gate;
wire [15:0] memory_words0_q_WR_ADDR_gold;
wire [15:0] memory_words0_q_WR_ADDR_gate;
wire [1:0] memory_words0_q_WR_CLK_gold;
wire [1:0] memory_words0_q_WR_CLK_gate;
wire [63:0] memory_words0_q_WR_DATA_gold;
wire [63:0] memory_words0_q_WR_DATA_gate;
wire [63:0] memory_words0_q_WR_EN_gold;
wire [63:0] memory_words0_q_WR_EN_gate;
wire [7:0] memory_words1_q_RD_ADDR_gold;
wire [7:0] memory_words1_q_RD_ADDR_gate;
wire memory_words1_q_RD_ARST_gold;
wire memory_words1_q_RD_ARST_gate;
wire memory_words1_q_RD_CLK_gold;
wire memory_words1_q_RD_CLK_gate;
wire memory_words1_q_RD_EN_gold;
wire memory_words1_q_RD_EN_gate;
wire memory_words1_q_RD_SRST_gold;
wire memory_words1_q_RD_SRST_gate;
wire [15:0] memory_words1_q_WR_ADDR_gold;
wire [15:0] memory_words1_q_WR_ADDR_gate;
wire [1:0] memory_words1_q_WR_CLK_gold;
wire [1:0] memory_words1_q_WR_CLK_gate;
wire [63:0] memory_words1_q_WR_DATA_gold;
wire [63:0] memory_words1_q_WR_DATA_gate;
wire [63:0] memory_words1_q_WR_EN_gold;
wire [63:0] memory_words1_q_WR_EN_gate;
buffer_gold u_gold(.clk(clk),.reset(reset),.cancel_cpu(cancel_cpu),.enable(enable),.in_valid(in_valid),.in_command_valid(in_command_valid),.in_owner(in_owner),.in_write(in_write),.in_refresh(in_refresh),.in_code_fetch(in_code_fetch),.in_burst(in_burst),.in_cycle_class(in_cycle_class),.in_address(in_address),.in_byte_enable(in_byte_enable),.in_data_out(in_data_out),.in_accept(in_accept_gold),.in_ready(in_ready_gold),.in_read_data(in_read_data_gold),.in_read_data_valid(in_read_data_valid_gold),.out_valid(out_valid_gold),.out_command_valid(out_command_valid_gold),.out_owner(out_owner_gold),.out_write(out_write_gold),.out_refresh(out_refresh_gold),.out_code_fetch(out_code_fetch_gold),.out_burst(out_burst_gold),.out_cycle_class(out_cycle_class_gold),.out_address(out_address_gold),.out_byte_enable(out_byte_enable_gold),.out_data_out(out_data_out_gold),.out_accept(out_accept),.out_ready(out_ready),.out_read_data(out_read_data),.out_read_data_valid(out_read_data_valid),.debug_hit_count(debug_hit_count_gold),.debug_miss_count(debug_miss_count_gold),.debug_fill_count(debug_fill_count_gold),.debug_write_update_count(debug_write_update_count_gold),.debug_state(debug_state_gold),.previous_debug_hit_count(previous_debug_hit_count),.next_debug_hit_count(next_debug_hit_count_gold),.previous_debug_miss_count(previous_debug_miss_count),.next_debug_miss_count(next_debug_miss_count_gold),.previous_debug_fill_count(previous_debug_fill_count),.next_debug_fill_count(next_debug_fill_count_gold),.previous_debug_write_update_count(previous_debug_write_update_count),.next_debug_write_update_count(next_debug_write_update_count_gold),.previous_state_q(previous_state_q),.next_state_q(next_state_q_gold),.previous_valid0_q(previous_valid0_q),.next_valid0_q(next_valid0_q_gold),.previous_valid1_q(previous_valid1_q),.next_valid1_q(next_valid1_q_gold),.previous_replace_q(previous_replace_q),.next_replace_q(next_replace_q_gold),.previous_lookup_valid0_q(previous_lookup_valid0_q),.next_lookup_valid0_q(next_lookup_valid0_q_gold),.previous_lookup_valid1_q(previous_lookup_valid1_q),.next_lookup_valid1_q(next_lookup_valid1_q_gold),.previous_replace_way_q(previous_replace_way_q),.next_replace_way_q(next_replace_way_q_gold),.previous_index_q(previous_index_q),.next_index_q(next_index_q_gold),.previous_owner_q(previous_owner_q),.next_owner_q(next_owner_q_gold),.previous_write_q(previous_write_q),.next_write_q(next_write_q_gold),.previous_refresh_q(previous_refresh_q),.next_refresh_q(next_refresh_q_gold),.previous_code_q(previous_code_q),.next_code_q(next_code_q_gold),.previous_burst_q(previous_burst_q),.next_burst_q(next_burst_q_gold),.previous_allocate_q(previous_allocate_q),.next_allocate_q(next_allocate_q_gold),.previous_cancelled_q(previous_cancelled_q),.next_cancelled_q(next_cancelled_q_gold),.previous_class_q(previous_class_q),.next_class_q(next_class_q_gold),.previous_address_q(previous_address_q),.next_address_q(next_address_q_gold),.previous_lanes_q(previous_lanes_q),.next_lanes_q(next_lanes_q_gold),.previous_data_q(previous_data_q),.next_data_q(next_data_q_gold),.previous_lookup0_q(previous_lookup0_q),.next_lookup0_q(next_lookup0_q_gold),.previous_lookup1_q(previous_lookup1_q),.next_lookup1_q(next_lookup1_q_gold),.memory_words0_q_RD_ADDR(memory_words0_q_RD_ADDR_gold),.memory_words0_q_RD_ARST(memory_words0_q_RD_ARST_gold),.memory_words0_q_RD_CLK(memory_words0_q_RD_CLK_gold),.memory_words0_q_RD_DATA(memory_words0_q_RD_DATA),.memory_words0_q_RD_EN(memory_words0_q_RD_EN_gold),.memory_words0_q_RD_SRST(memory_words0_q_RD_SRST_gold),.memory_words0_q_WR_ADDR(memory_words0_q_WR_ADDR_gold),.memory_words0_q_WR_CLK(memory_words0_q_WR_CLK_gold),.memory_words0_q_WR_DATA(memory_words0_q_WR_DATA_gold),.memory_words0_q_WR_EN(memory_words0_q_WR_EN_gold),.memory_words1_q_RD_ADDR(memory_words1_q_RD_ADDR_gold),.memory_words1_q_RD_ARST(memory_words1_q_RD_ARST_gold),.memory_words1_q_RD_CLK(memory_words1_q_RD_CLK_gold),.memory_words1_q_RD_DATA(memory_words1_q_RD_DATA),.memory_words1_q_RD_EN(memory_words1_q_RD_EN_gold),.memory_words1_q_RD_SRST(memory_words1_q_RD_SRST_gold),.memory_words1_q_WR_ADDR(memory_words1_q_WR_ADDR_gold),.memory_words1_q_WR_CLK(memory_words1_q_WR_CLK_gold),.memory_words1_q_WR_DATA(memory_words1_q_WR_DATA_gold),.memory_words1_q_WR_EN(memory_words1_q_WR_EN_gold));
buffer_gate u_gate(.clk(clk),.reset(reset),.cancel_cpu(cancel_cpu),.enable(enable),.in_valid(in_valid),.in_command_valid(in_command_valid),.in_owner(in_owner),.in_write(in_write),.in_refresh(in_refresh),.in_code_fetch(in_code_fetch),.in_burst(in_burst),.in_cycle_class(in_cycle_class),.in_address(in_address),.in_byte_enable(in_byte_enable),.in_data_out(in_data_out),.in_accept(in_accept_gate),.in_ready(in_ready_gate),.in_read_data(in_read_data_gate),.in_read_data_valid(in_read_data_valid_gate),.out_valid(out_valid_gate),.out_command_valid(out_command_valid_gate),.out_owner(out_owner_gate),.out_write(out_write_gate),.out_refresh(out_refresh_gate),.out_code_fetch(out_code_fetch_gate),.out_burst(out_burst_gate),.out_cycle_class(out_cycle_class_gate),.out_address(out_address_gate),.out_byte_enable(out_byte_enable_gate),.out_data_out(out_data_out_gate),.out_accept(out_accept),.out_ready(out_ready),.out_read_data(out_read_data),.out_read_data_valid(out_read_data_valid),.debug_hit_count(debug_hit_count_gate),.debug_miss_count(debug_miss_count_gate),.debug_fill_count(debug_fill_count_gate),.debug_write_update_count(debug_write_update_count_gate),.debug_state(debug_state_gate),.previous_debug_hit_count(previous_debug_hit_count),.next_debug_hit_count(next_debug_hit_count_gate),.previous_debug_miss_count(previous_debug_miss_count),.next_debug_miss_count(next_debug_miss_count_gate),.previous_debug_fill_count(previous_debug_fill_count),.next_debug_fill_count(next_debug_fill_count_gate),.previous_debug_write_update_count(previous_debug_write_update_count),.next_debug_write_update_count(next_debug_write_update_count_gate),.previous_state_q(previous_state_q),.next_state_q(next_state_q_gate),.previous_valid0_q(previous_valid0_q),.next_valid0_q(next_valid0_q_gate),.previous_valid1_q(previous_valid1_q),.next_valid1_q(next_valid1_q_gate),.previous_replace_q(previous_replace_q),.next_replace_q(next_replace_q_gate),.previous_lookup_valid0_q(previous_lookup_valid0_q),.next_lookup_valid0_q(next_lookup_valid0_q_gate),.previous_lookup_valid1_q(previous_lookup_valid1_q),.next_lookup_valid1_q(next_lookup_valid1_q_gate),.previous_replace_way_q(previous_replace_way_q),.next_replace_way_q(next_replace_way_q_gate),.previous_index_q(previous_index_q),.next_index_q(next_index_q_gate),.previous_owner_q(previous_owner_q),.next_owner_q(next_owner_q_gate),.previous_write_q(previous_write_q),.next_write_q(next_write_q_gate),.previous_refresh_q(previous_refresh_q),.next_refresh_q(next_refresh_q_gate),.previous_code_q(previous_code_q),.next_code_q(next_code_q_gate),.previous_burst_q(previous_burst_q),.next_burst_q(next_burst_q_gate),.previous_allocate_q(previous_allocate_q),.next_allocate_q(next_allocate_q_gate),.previous_cancelled_q(previous_cancelled_q),.next_cancelled_q(next_cancelled_q_gate),.previous_class_q(previous_class_q),.next_class_q(next_class_q_gate),.previous_address_q(previous_address_q),.next_address_q(next_address_q_gate),.previous_lanes_q(previous_lanes_q),.next_lanes_q(next_lanes_q_gate),.previous_data_q(previous_data_q),.next_data_q(next_data_q_gate),.previous_lookup0_q(previous_lookup0_q),.next_lookup0_q(next_lookup0_q_gate),.previous_lookup1_q(previous_lookup1_q),.next_lookup1_q(next_lookup1_q_gate),.memory_words0_q_RD_ADDR(memory_words0_q_RD_ADDR_gate),.memory_words0_q_RD_ARST(memory_words0_q_RD_ARST_gate),.memory_words0_q_RD_CLK(memory_words0_q_RD_CLK_gate),.memory_words0_q_RD_DATA(memory_words0_q_RD_DATA),.memory_words0_q_RD_EN(memory_words0_q_RD_EN_gate),.memory_words0_q_RD_SRST(memory_words0_q_RD_SRST_gate),.memory_words0_q_WR_ADDR(memory_words0_q_WR_ADDR_gate),.memory_words0_q_WR_CLK(memory_words0_q_WR_CLK_gate),.memory_words0_q_WR_DATA(memory_words0_q_WR_DATA_gate),.memory_words0_q_WR_EN(memory_words0_q_WR_EN_gate),.memory_words1_q_RD_ADDR(memory_words1_q_RD_ADDR_gate),.memory_words1_q_RD_ARST(memory_words1_q_RD_ARST_gate),.memory_words1_q_RD_CLK(memory_words1_q_RD_CLK_gate),.memory_words1_q_RD_DATA(memory_words1_q_RD_DATA),.memory_words1_q_RD_EN(memory_words1_q_RD_EN_gate),.memory_words1_q_RD_SRST(memory_words1_q_RD_SRST_gate),.memory_words1_q_WR_ADDR(memory_words1_q_WR_ADDR_gate),.memory_words1_q_WR_CLK(memory_words1_q_WR_CLK_gate),.memory_words1_q_WR_DATA(memory_words1_q_WR_DATA_gate),.memory_words1_q_WR_EN(memory_words1_q_WR_EN_gate));
assign step_ok = (in_accept_gold === in_accept_gate) &&
(in_ready_gold === in_ready_gate) &&
(in_read_data_gold === in_read_data_gate) &&
(in_read_data_valid_gold === in_read_data_valid_gate) &&
(out_valid_gold === out_valid_gate) &&
(out_command_valid_gold === out_command_valid_gate) &&
(!out_valid_gold || (out_owner_gold === out_owner_gate)) &&
(!out_valid_gold || (out_write_gold === out_write_gate)) &&
(!out_valid_gold || (out_refresh_gold === out_refresh_gate)) &&
(!out_valid_gold || (out_code_fetch_gold === out_code_fetch_gate)) &&
(!out_valid_gold || (out_burst_gold === out_burst_gate)) &&
(!out_valid_gold || (out_cycle_class_gold === out_cycle_class_gate)) &&
(!out_valid_gold || (out_address_gold === out_address_gate)) &&
(!out_valid_gold || (out_byte_enable_gold === out_byte_enable_gate)) &&
(!out_valid_gold || (out_data_out_gold === out_data_out_gate)) &&
(debug_hit_count_gold === debug_hit_count_gate) &&
(debug_miss_count_gold === debug_miss_count_gate) &&
(debug_fill_count_gold === debug_fill_count_gate) &&
(debug_write_update_count_gold === debug_write_update_count_gate) &&
(debug_state_gold === debug_state_gate) &&
(next_debug_hit_count_gold === next_debug_hit_count_gate) &&
(next_debug_miss_count_gold === next_debug_miss_count_gate) &&
(next_debug_fill_count_gold === next_debug_fill_count_gate) &&
(next_debug_write_update_count_gold === next_debug_write_update_count_gate) &&
(next_state_q_gold === next_state_q_gate) &&
(next_valid0_q_gold === next_valid0_q_gate) &&
(next_valid1_q_gold === next_valid1_q_gate) &&
(next_replace_q_gold === next_replace_q_gate) &&
(next_lookup_valid0_q_gold === next_lookup_valid0_q_gate) &&
(next_lookup_valid1_q_gold === next_lookup_valid1_q_gate) &&
(next_replace_way_q_gold === next_replace_way_q_gate) &&
(next_index_q_gold === next_index_q_gate) &&
(next_owner_q_gold === next_owner_q_gate) &&
(next_write_q_gold === next_write_q_gate) &&
(next_refresh_q_gold === next_refresh_q_gate) &&
(next_code_q_gold === next_code_q_gate) &&
(next_burst_q_gold === next_burst_q_gate) &&
(next_allocate_q_gold === next_allocate_q_gate) &&
(next_cancelled_q_gold === next_cancelled_q_gate) &&
(next_class_q_gold === next_class_q_gate) &&
(next_address_q_gold === next_address_q_gate) &&
(next_lanes_q_gold === next_lanes_q_gate) &&
(next_data_q_gold === next_data_q_gate) &&
(next_lookup0_q_gold === next_lookup0_q_gate) &&
(next_lookup1_q_gold === next_lookup1_q_gate) &&
(memory_words0_q_RD_ADDR_gold === memory_words0_q_RD_ADDR_gate) &&
(memory_words0_q_RD_ARST_gold === memory_words0_q_RD_ARST_gate) &&
(memory_words0_q_RD_CLK_gold === memory_words0_q_RD_CLK_gate) &&
(memory_words0_q_RD_EN_gold === memory_words0_q_RD_EN_gate) &&
(memory_words0_q_RD_SRST_gold === memory_words0_q_RD_SRST_gate) &&
(memory_words0_q_WR_ADDR_gold === memory_words0_q_WR_ADDR_gate) &&
(memory_words0_q_WR_CLK_gold === memory_words0_q_WR_CLK_gate) &&
((memory_words0_q_WR_DATA_gold & memory_words0_q_WR_EN_gold) === (memory_words0_q_WR_DATA_gate & memory_words0_q_WR_EN_gate)) &&
(memory_words0_q_WR_EN_gold === memory_words0_q_WR_EN_gate) &&
(memory_words1_q_RD_ADDR_gold === memory_words1_q_RD_ADDR_gate) &&
(memory_words1_q_RD_ARST_gold === memory_words1_q_RD_ARST_gate) &&
(memory_words1_q_RD_CLK_gold === memory_words1_q_RD_CLK_gate) &&
(memory_words1_q_RD_EN_gold === memory_words1_q_RD_EN_gate) &&
(memory_words1_q_RD_SRST_gold === memory_words1_q_RD_SRST_gate) &&
(memory_words1_q_WR_ADDR_gold === memory_words1_q_WR_ADDR_gate) &&
(memory_words1_q_WR_CLK_gold === memory_words1_q_WR_CLK_gate) &&
((memory_words1_q_WR_DATA_gold & memory_words1_q_WR_EN_gold) === (memory_words1_q_WR_DATA_gate & memory_words1_q_WR_EN_gate)) &&
(memory_words1_q_WR_EN_gold === memory_words1_q_WR_EN_gate);
endmodule
