module invariant(
input wire clk,
input wire reset,
input wire cancel_cpu,
input wire cpu_lock,
input wire in_valid,
input wire in_command_valid,
input wire [1:0] in_owner,
input wire in_write,
input wire in_refresh,
input wire in_code_fetch,
input wire in_burst,
input wire [3:0] in_cycle_class,
input wire [24:0] in_address,
input wire [1:0] in_byte_enable,
input wire [15:0] in_data_out,
input wire out_accept,
input wire out_ready,
input wire [15:0] out_read_data,
input wire out_read_data_valid,
input wire previous_protocol_error,
input wire [31:0] previous_debug_post_count,
input wire [31:0] previous_debug_drain_count,
input wire [31:0] previous_debug_stall_count,
input wire [1:0] previous_state_q,
input wire [1:0] previous_owner_q,
input wire previous_issued_q,
input wire previous_ack_q,
input wire previous_write_q,
input wire previous_refresh_q,
input wire previous_code_q,
input wire previous_burst_q,
input wire [3:0] previous_class_q,
input wire [24:0] previous_address_q,
input wire [1:0] previous_lanes_q,
input wire [15:0] previous_data_q,
output wire step_ok
);
wire in_accept_gold;
wire in_accept_gate;
wire in_ready_gold;
wire in_ready_gate;
wire [15:0] in_read_data_gold;
wire [15:0] in_read_data_gate;
wire in_read_data_valid_gold;
wire in_read_data_valid_gate;
wire out_valid_gold;
wire out_valid_gate;
wire out_command_valid_gold;
wire out_command_valid_gate;
wire [1:0] out_owner_gold;
wire [1:0] out_owner_gate;
wire out_write_gold;
wire out_write_gate;
wire out_refresh_gold;
wire out_refresh_gate;
wire out_code_fetch_gold;
wire out_code_fetch_gate;
wire out_burst_gold;
wire out_burst_gate;
wire [3:0] out_cycle_class_gold;
wire [3:0] out_cycle_class_gate;
wire [24:0] out_address_gold;
wire [24:0] out_address_gate;
wire [1:0] out_byte_enable_gold;
wire [1:0] out_byte_enable_gate;
wire [15:0] out_data_out_gold;
wire [15:0] out_data_out_gate;
wire pending_write_gold;
wire pending_write_gate;
wire idle_gold;
wire idle_gate;
wire protocol_error_gold;
wire protocol_error_gate;
wire [31:0] debug_post_count_gold;
wire [31:0] debug_post_count_gate;
wire [31:0] debug_drain_count_gold;
wire [31:0] debug_drain_count_gate;
wire [31:0] debug_stall_count_gold;
wire [31:0] debug_stall_count_gate;
wire next_protocol_error_gold;
wire next_protocol_error_gate;
wire [31:0] next_debug_post_count_gold;
wire [31:0] next_debug_post_count_gate;
wire [31:0] next_debug_drain_count_gold;
wire [31:0] next_debug_drain_count_gate;
wire [31:0] next_debug_stall_count_gold;
wire [31:0] next_debug_stall_count_gate;
wire [1:0] next_state_q_gold;
wire [1:0] next_state_q_gate;
wire [1:0] next_owner_q_gold;
wire [1:0] next_owner_q_gate;
wire next_issued_q_gold;
wire next_issued_q_gate;
wire next_ack_q_gold;
wire next_ack_q_gate;
wire next_write_q_gold;
wire next_write_q_gate;
wire next_refresh_q_gold;
wire next_refresh_q_gate;
wire next_code_q_gold;
wire next_code_q_gate;
wire next_burst_q_gold;
wire next_burst_q_gate;
wire [3:0] next_class_q_gold;
wire [3:0] next_class_q_gate;
wire [24:0] next_address_q_gold;
wire [24:0] next_address_q_gate;
wire [1:0] next_lanes_q_gold;
wire [1:0] next_lanes_q_gate;
wire [15:0] next_data_q_gold;
wire [15:0] next_data_q_gate;
buffer_gold u_gold(.clk(clk),.reset(reset),.cancel_cpu(cancel_cpu),.cpu_lock(cpu_lock),.in_valid(in_valid),.in_command_valid(in_command_valid),.in_owner(in_owner),.in_write(in_write),.in_refresh(in_refresh),.in_code_fetch(in_code_fetch),.in_burst(in_burst),.in_cycle_class(in_cycle_class),.in_address(in_address),.in_byte_enable(in_byte_enable),.in_data_out(in_data_out),.in_accept(in_accept_gold),.in_ready(in_ready_gold),.in_read_data(in_read_data_gold),.in_read_data_valid(in_read_data_valid_gold),.out_valid(out_valid_gold),.out_command_valid(out_command_valid_gold),.out_owner(out_owner_gold),.out_write(out_write_gold),.out_refresh(out_refresh_gold),.out_code_fetch(out_code_fetch_gold),.out_burst(out_burst_gold),.out_cycle_class(out_cycle_class_gold),.out_address(out_address_gold),.out_byte_enable(out_byte_enable_gold),.out_data_out(out_data_out_gold),.out_accept(out_accept),.out_ready(out_ready),.out_read_data(out_read_data),.out_read_data_valid(out_read_data_valid),.pending_write(pending_write_gold),.idle(idle_gold),.protocol_error(protocol_error_gold),.debug_post_count(debug_post_count_gold),.debug_drain_count(debug_drain_count_gold),.debug_stall_count(debug_stall_count_gold),.previous_protocol_error(previous_protocol_error),.next_protocol_error(next_protocol_error_gold),.previous_debug_post_count(previous_debug_post_count),.next_debug_post_count(next_debug_post_count_gold),.previous_debug_drain_count(previous_debug_drain_count),.next_debug_drain_count(next_debug_drain_count_gold),.previous_debug_stall_count(previous_debug_stall_count),.next_debug_stall_count(next_debug_stall_count_gold),.previous_state_q(previous_state_q),.next_state_q(next_state_q_gold),.previous_owner_q(previous_owner_q),.next_owner_q(next_owner_q_gold),.previous_issued_q(previous_issued_q),.next_issued_q(next_issued_q_gold),.previous_ack_q(previous_ack_q),.next_ack_q(next_ack_q_gold),.previous_write_q(previous_write_q),.next_write_q(next_write_q_gold),.previous_refresh_q(previous_refresh_q),.next_refresh_q(next_refresh_q_gold),.previous_code_q(previous_code_q),.next_code_q(next_code_q_gold),.previous_burst_q(previous_burst_q),.next_burst_q(next_burst_q_gold),.previous_class_q(previous_class_q),.next_class_q(next_class_q_gold),.previous_address_q(previous_address_q),.next_address_q(next_address_q_gold),.previous_lanes_q(previous_lanes_q),.next_lanes_q(next_lanes_q_gold),.previous_data_q(previous_data_q),.next_data_q(next_data_q_gold));
buffer_gate u_gate(.clk(clk),.reset(reset),.cancel_cpu(cancel_cpu),.cpu_lock(cpu_lock),.in_valid(in_valid),.in_command_valid(in_command_valid),.in_owner(in_owner),.in_write(in_write),.in_refresh(in_refresh),.in_code_fetch(in_code_fetch),.in_burst(in_burst),.in_cycle_class(in_cycle_class),.in_address(in_address),.in_byte_enable(in_byte_enable),.in_data_out(in_data_out),.in_accept(in_accept_gate),.in_ready(in_ready_gate),.in_read_data(in_read_data_gate),.in_read_data_valid(in_read_data_valid_gate),.out_valid(out_valid_gate),.out_command_valid(out_command_valid_gate),.out_owner(out_owner_gate),.out_write(out_write_gate),.out_refresh(out_refresh_gate),.out_code_fetch(out_code_fetch_gate),.out_burst(out_burst_gate),.out_cycle_class(out_cycle_class_gate),.out_address(out_address_gate),.out_byte_enable(out_byte_enable_gate),.out_data_out(out_data_out_gate),.out_accept(out_accept),.out_ready(out_ready),.out_read_data(out_read_data),.out_read_data_valid(out_read_data_valid),.pending_write(pending_write_gate),.idle(idle_gate),.protocol_error(protocol_error_gate),.debug_post_count(debug_post_count_gate),.debug_drain_count(debug_drain_count_gate),.debug_stall_count(debug_stall_count_gate),.previous_protocol_error(previous_protocol_error),.next_protocol_error(next_protocol_error_gate),.previous_debug_post_count(previous_debug_post_count),.next_debug_post_count(next_debug_post_count_gate),.previous_debug_drain_count(previous_debug_drain_count),.next_debug_drain_count(next_debug_drain_count_gate),.previous_debug_stall_count(previous_debug_stall_count),.next_debug_stall_count(next_debug_stall_count_gate),.previous_state_q(previous_state_q),.next_state_q(next_state_q_gate),.previous_owner_q(previous_owner_q),.next_owner_q(next_owner_q_gate),.previous_issued_q(previous_issued_q),.next_issued_q(next_issued_q_gate),.previous_ack_q(previous_ack_q),.next_ack_q(next_ack_q_gate),.previous_write_q(previous_write_q),.next_write_q(next_write_q_gate),.previous_refresh_q(previous_refresh_q),.next_refresh_q(next_refresh_q_gate),.previous_code_q(previous_code_q),.next_code_q(next_code_q_gate),.previous_burst_q(previous_burst_q),.next_burst_q(next_burst_q_gate),.previous_class_q(previous_class_q),.next_class_q(next_class_q_gate),.previous_address_q(previous_address_q),.next_address_q(next_address_q_gate),.previous_lanes_q(previous_lanes_q),.next_lanes_q(next_lanes_q_gate),.previous_data_q(previous_data_q),.next_data_q(next_data_q_gate));
assign step_ok = (in_accept_gold === in_accept_gate) &&
(in_ready_gold === in_ready_gate) &&
(in_read_data_gold === in_read_data_gate) &&
(in_read_data_valid_gold === in_read_data_valid_gate) &&
(out_valid_gold === out_valid_gate) &&
(out_command_valid_gold === out_command_valid_gate) &&
(!out_valid_gold || (out_owner_gold === out_owner_gate)) &&
(!out_valid_gold || (out_write_gold === out_write_gate)) &&
(!out_valid_gold || (out_refresh_gold === out_refresh_gate)) &&
(!out_valid_gold || (out_code_fetch_gold === out_code_fetch_gate)) &&
(!out_valid_gold || (out_burst_gold === out_burst_gate)) &&
(!out_valid_gold || (out_cycle_class_gold === out_cycle_class_gate)) &&
(!out_valid_gold || (out_address_gold === out_address_gate)) &&
(!out_valid_gold || (out_byte_enable_gold === out_byte_enable_gate)) &&
(!out_valid_gold || (out_data_out_gold === out_data_out_gate)) &&
(pending_write_gold === pending_write_gate) &&
(idle_gold === idle_gate) &&
(protocol_error_gold === protocol_error_gate) &&
(debug_post_count_gold === debug_post_count_gate) &&
(debug_drain_count_gold === debug_drain_count_gate) &&
(debug_stall_count_gold === debug_stall_count_gate) &&
(next_protocol_error_gold === next_protocol_error_gate) &&
(next_debug_post_count_gold === next_debug_post_count_gate) &&
(next_debug_drain_count_gold === next_debug_drain_count_gate) &&
(next_debug_stall_count_gold === next_debug_stall_count_gate) &&
(next_state_q_gold === next_state_q_gate) &&
(next_owner_q_gold === next_owner_q_gate) &&
(next_issued_q_gold === next_issued_q_gate) &&
(next_ack_q_gold === next_ack_q_gate) &&
(next_write_q_gold === next_write_q_gate) &&
(next_refresh_q_gold === next_refresh_q_gate) &&
(next_code_q_gold === next_code_q_gate) &&
(next_burst_q_gold === next_burst_q_gate) &&
(next_class_q_gold === next_class_q_gate) &&
(next_address_q_gold === next_address_q_gate) &&
(next_lanes_q_gold === next_lanes_q_gate) &&
(next_data_q_gold === next_data_q_gate);
endmodule
