import hashlib, io, json, tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'docs/evidence/p06-deadline-csa-20261005'
OUT.mkdir(exist_ok=False)
DIRS = [ROOT/'build'/f'p06-deadline-csa-{kind}-20261005-v1'
        for kind in ('formal','units','integration')]
sha = lambda b: hashlib.sha256(b).hexdigest()
files = {}
for directory in DIRS:
    for p in sorted(directory.rglob('*')):
        if not p.is_file() or 'obj' in p.relative_to(directory).parts: continue
        if p.suffix in ('.vvp',) or p.name in ('candidate','test'): continue
        files[directory.name+'/'+p.relative_to(directory).as_posix()] = p.read_bytes()
sources = ['rtl/spk286_timing/spk286_instruction_schedule.sv',
           'scripts/test_spk286_target_handoff.py',
           'scripts/test_p06_execution_deadline_equivalence.py',
           'scripts/test_p06_target_handoff_integration.py',
           'scripts/build_p06_profile_cpu.py',
           'SYSTEM.sdc', 'vendor/spk286/rtl/timed/generation.json']
integration=json.loads((DIRS[2]/'receipt.json').read_text())
sources += list(integration['sources_sha256'])
for n in sorted(set(sources)): files['source/'+n] = (ROOT/n).read_bytes()
for n,h in integration['sources_sha256'].items(): assert sha(files['source/'+n])==h,n
base = ROOT/'docs/evidence/p06-execution-deadline-20261005/integration.json'
previous=json.loads(base.read_bytes())
assert previous['results']==integration['results']
comparison={'status':'ALL_DIRECTED_RESULTS_AND_MAX_RAW_STREAM_EXACT',
    'baseline_path':base.relative_to(ROOT).as_posix(),'baseline_sha256':sha(base.read_bytes()),
    'candidate_sources_sha256':integration['sources_sha256'],
    'profiles':integration['profiles'],'full_regression':'USER_DEFERRED'}
files['baseline-comparison.json']=(json.dumps(comparison,indent=2)+'\n').encode()
files['collector.py']=Path(__file__).read_bytes()
files['members.json']=(json.dumps({n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())},indent=2)+'\n').encode()
archive=OUT/'p06-deadline-csa-20261005.tar.gz'
with tarfile.open(archive,'w:gz') as t:
    for n,b in sorted(files.items()):
        info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;t.addfile(info,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as t:
    assert {m.name:t.extractfile(m).read() for m in t.getmembers()}==files
for kind,directory in zip(('formal','units','integration'),DIRS):
    (OUT/(kind+'.json')).write_bytes((directory/'receipt.json').read_bytes())
(OUT/'baseline-comparison.json').write_bytes(files['baseline-comparison.json'])
(OUT/'manifest.json').write_text(json.dumps({'status':'DEADLINE_CSA_DIRECTED_EQUIVALENCE_PASS',
    'archive':archive.name,'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,
    'members':len(files),'verification':'Every member matched original bytes',
    'excluded':'Simulator executables, objects and compiler caches; no complete regression claimed'},indent=2)+'\n')
print('SEALED',len(files),'members',archive.stat().st_size,'bytes')
