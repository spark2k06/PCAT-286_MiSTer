import hashlib
import io
import json
from pathlib import Path
import tarfile

root=Path(__file__).resolve().parents[1]
packet=root/'docs/evidence/p06-deadline-fold-20261005'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
outputs={
    'formal':'p06-deadline-fold-repeat-formal-20261005-v1',
    'branches':'p06-deadline-fold-branch-formal-20261005-v1',
    'budget':'p06-deadline-fold-budget-formal-20261005-v1',
    'deadline':'p06-deadline-carry-save-formal-20261005-v2',
    'legacy-deadline':'p06-deadline-carry-save-legacy-formal-20261005-v1',
    'components':'p06-deadline-fold-components-20261005-v1',
    'integration':'p06-deadline-fold-integration-20261005-v1',
    'affected':'p06-deadline-fold-affected-20261005-v1',
    'live':'p06-deadline-fold-live-20261005-v1',
    'buffers':'p06-buffer-idle-payload-20261005',
    'palette':'p06-palette-address-encoding-20261005-v1',
    'elaboration':'p06-deadline-fold-top-20261005-v1',
}
receipts={};sources={}
for label,directory in outputs.items():
    folder=root/'build'/directory
    path=folder/('components.json' if label=='components' else 'receipt.json')
    data=json.loads(path.read_text())
    assert 'PASS' in data['status'] and 'FAIL' not in data['status'],(label,data['status'])
    receipts[label]=data
    for key in ('generated_sha256','generated_source_sha256'):
        for name,expected in data.get(key,{}).items():
            assert sha(root/'vendor/spk286/rtl/timed'/name)==expected,name
    for key in ('sources_sha256','source_sha256'):
        for name,expected in data.get(key,{}).items():
            assert sha(root/name)==expected,name
            assert sources.get(name,expected)==expected,name
            sources[name]=expected
baseline=root/'docs/evidence/p06-live-speed-20261005'
old=json.loads((baseline/'integration.json').read_text())
assert receipts['integration']['results']==old['results'],'Instruction/event handoff timings changed'
old=json.loads((baseline/'affected.json').read_text())
common_units=set(old['units'])
common=[r for r in receipts['affected']['results'] if r.get('unit') in common_units]
assert common==old['results'],'Common lifecycle results or per-edge traces changed'
top=root/'build/p06-deadline-fold-top-20261005-v1'
top_log=(top/'elab.log').read_text()
for marker in ('AT_CONFIG_NO_DEBUG_PASS','AT_PROFILE_SELECTOR_PASS','AT_PROFILE_ELAB_PASS'):
    assert marker in top_log,marker
packet.mkdir(parents=True,exist_ok=False)
for label,data in receipts.items():
    (packet/(label+'.json')).write_text(json.dumps(data,indent=2)+'\n',newline='\n')
(packet/'baseline-comparison.json').write_text(json.dumps({
    'baseline':baseline.relative_to(root).as_posix(),
    'handoff_complete_results_equal':True,'handoff_entries':len(receipts['integration']['results']),
    'common_lifecycle_results_equal':True,'common_lifecycle_entries':len(common),
    'additional_affected_units':sorted(set(receipts['affected']['units'])-common_units),
    'hardware':'NOT_RUN','full_regression':'USER_DEFERRED'},indent=2)+'\n',newline='\n')
files={}
for name in sources:files['source/'+name]=root/name
for directory in ('rtl','sys','sim'):
    for p in (root/directory).rglob('*'):
        if p.is_file() and p.suffix.lower() in ('.sv','.v','.vh','.svh','.qip'):
            files['source/'+p.relative_to(root).as_posix()]=p
for p in root.iterdir():
    if p.is_file() and p.suffix.lower() in ('.sv','.v','.qsf','.qpf','.qip','.tcl','.sdc'):
        files['source/'+p.name]=p
for p in (root/'vendor/spk286/rtl/timed').iterdir():
    if p.is_file():files['source/'+p.relative_to(root).as_posix()]=p
for label,directory in outputs.items():
    folder=root/'build'/directory
    for p in folder.rglob('*'):
        if not p.is_file() or p.suffix in ('.vvp','.o','.a') or any(
            part=='obj' or part.endswith('-obj') or part.endswith('-verilator')
            for part in p.relative_to(folder).parts):continue
        files['tests/'+label+'/'+p.relative_to(folder).as_posix()]=p
extras=['p06-repeat-branch-equivalence-20261005-v1','p06-repeat-selector-proof-20261005-v1',
    'p06-deadline-carry-save-formal-20261005-v1','p06-deadline-fold-top-20261005-v1',
    'p06-palette-address-encoding-20261005-before-diagnostic-binding',
    'p06-palette-address-encoding-20261005-initial-lint-wrapper',
    'p06-palette-address-encoding-20261005-line-ending-reference']
for directory in extras:
    folder=root/'build'/directory
    if not folder.exists():continue
    for p in folder.rglob('*'):
        if p.is_file() and p.suffix.lower() in ('.json','.log','.sv','.v','.ys','.py','.sh','.tcl'):
            files['superseded-and-elaboration/'+directory+'/'+p.relative_to(folder).as_posix()]=p
files['source/docs/optimization/P06_DEADLINE_FOLD_20261005.md']=root/'docs/optimization/P06_DEADLINE_FOLD_20261005.md'
for p in packet.iterdir():
    if p.is_file():files[p.name]=p
files['collector.py']=Path(__file__)
archive=packet/'p06-deadline-fold-20261005.tar.gz'
bindings={name:{'sha256':sha(p),'bytes':p.stat().st_size} for name,p in sorted(files.items())}
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
    for name,p in sorted(files.items()):
        data=p.read_bytes();entry=tarfile.TarInfo(name);entry.size=len(data);entry.mtime=0
        tar.addfile(entry,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    assert set(tar.getnames())==set(files)
    for entry in tar:
        data=tar.extractfile(entry).read()
        assert data==files[entry.name].read_bytes(),entry.name
        assert len(data)==bindings[entry.name]['bytes'],entry.name
        assert hashlib.sha256(data).hexdigest()==bindings[entry.name]['sha256'],entry.name
for name,expected in sources.items():assert sha(root/name)==expected,name
manifest={'status':'SEALED_DEADLINE_FOLD_BUFFER_PALETTE_DIRECTED_PASS_NOT_FITTED',
    'archive':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files),
    'verification':'Every member read back equal to original before cleanup',
    'source_sha256':sources,'members_sha256':bindings,
    'full_regression':'USER_DEFERRED','hardware':'NOT_RUN'}
(packet/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',newline='\n')
targets=['build/'+name for name in list(outputs.values())+extras if (root/'build'/name).exists()]
(packet/'cleanup.json').write_text(json.dumps({'status':'PENDING',
    'archive_sha256':sha(archive),'targets':targets},indent=2)+'\n',newline='\n')
print('DEADLINE_FOLD_DIRECTED_SEALED',archive.stat().st_size,len(files),flush=True)
