module budget_miter (
    input profile_delivery_metadata, profile_execution_repeated, profile_repeat_nonempty_q,
    input [9:0] profile_execution_base, profile_execution_repeat_setup,
    input [9:0] profile_execution_repeat_iteration, profile_event_base,
    input [2:0] profile_execution_ea,
    input [3:0] profile_prefix_count_q);

    wire [9:0] profile_execution_metadata_clocks;
    wire [23:0] profile_execution_metadata_carry_save;
    function automatic logic [9:0] profile_metadata_budget(
        input logic [9:0] base, setup_clocks, iteration_clocks,
        input logic [2:0] ea,
        input logic repeated, nonempty, delivery,
        input logic [3:0] prefixes
    );
        logic [3:0] remaining_prefixes;
        logic [11:0] first, second, prefix_clocks, sum_bits, carry_bits, full_sum;
        remaining_prefixes = prefixes == 0 ? 4'd0 : prefixes - 4'd1;
        first = {2'd0, repeated ? setup_clocks : base};
        second = repeated ? (nonempty ? {2'd0, iteration_clocks} : 12'd0) : {9'd0, ea};
        prefix_clocks = repeated ? {7'd0, remaining_prefixes, 1'b0} :
                        delivery ? 12'd0 : {7'd0, prefixes, 1'b0};
        sum_bits = first ^ second ^ prefix_clocks;
        carry_bits = (first & second) | (first & prefix_clocks) | (second & prefix_clocks);
        full_sum = sum_bits + (carry_bits << 1);
        profile_metadata_budget = |full_sum[11:10] ? 10'd1023 : full_sum[9:0];
    endfunction
    function automatic logic [23:0] profile_metadata_budget_carry_save(
        input logic [9:0] base, setup_clocks, iteration_clocks,
        input logic [2:0] ea,
        input logic repeated, nonempty,
        input logic [3:0] prefixes
    );
        logic [3:0] remaining_prefixes;
        logic [11:0] first, second, prefix_clocks, sum_bits, carry_bits;
        remaining_prefixes = prefixes == 0 ? 4'd0 : prefixes - 4'd1;
        first = {2'd0, repeated ? setup_clocks : base};
        second = repeated ? (nonempty ? {2'd0, iteration_clocks} : 12'd0) : {9'd0, ea};
        prefix_clocks = repeated ? {7'd0, remaining_prefixes, 1'b0} :
                                  {7'd0, prefixes, 1'b0};
        sum_bits = first ^ second ^ prefix_clocks;
        carry_bits = (first & second) | (first & prefix_clocks) | (second & prefix_clocks);
        profile_metadata_budget_carry_save = {sum_bits ^ 12'd1, carry_bits};
    endfunction    assign profile_execution_metadata_clocks = profile_delivery_metadata ? profile_event_base :
        profile_metadata_budget(profile_execution_base, profile_execution_repeat_setup,
            profile_execution_repeat_iteration, profile_execution_ea, profile_execution_repeated,
            profile_repeat_nonempty_q, 1'b0, profile_prefix_count_q);
    assign profile_execution_metadata_carry_save = profile_delivery_metadata ?
        {2'd0, profile_event_base, 12'd0} :
        profile_metadata_budget_carry_save(profile_execution_base, profile_execution_repeat_setup,
            profile_execution_repeat_iteration, profile_execution_ea, profile_execution_repeated,
            profile_repeat_nonempty_q, profile_prefix_count_q);


    wire [12:0] reconstructed = {1'b0, profile_execution_metadata_carry_save[23:12]} +
                                 {profile_execution_metadata_carry_save[11:0], 1'b0};
    wire [3:0] rep_prefixes = profile_prefix_count_q == 0 ? 0 : profile_prefix_count_q - 4'd1;
    // Independent wide arithmetic oracle, not the candidate compressor.
    wire [12:0] ordinary_total = {3'd0, profile_execution_base} +
                                {10'd0, profile_execution_ea} +
                                {8'd0, profile_prefix_count_q, 1'b0};
    wire [12:0] repeated_total = {3'd0, profile_execution_repeat_setup} +
        (profile_repeat_nonempty_q ? {3'd0, profile_execution_repeat_iteration} : 13'd0) +
        {8'd0, rep_prefixes, 1'b0};
    wire [12:0] independent_total = profile_delivery_metadata ? {3'd0, profile_event_base} :
        profile_execution_repeated ? repeated_total : ordinary_total;
    always @* begin
        assert(reconstructed == independent_total);
        assert(reconstructed <= 13'd2076);
        assert(profile_execution_metadata_clocks ==
            (independent_total > 13'd1023 ? 10'd1023 : independent_total[9:0]));
    end
endmodule
