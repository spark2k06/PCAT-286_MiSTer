module schedule_miter (
    input clk, reset, historical_enable, cpu_boundary, cancel, preserve_cancel,
    input start_interval, start_body, metadata_valid, metadata_freeze,
    input execution_metadata_valid, execution_read_wait_event,
    input [9:0] metadata_clocks,
    input target_length_ready, read_wait_event, alignment_event,
    input [3:0] target_length_clocks,
    input functional_retired, repeat_checkpoint,
    input [9:0] repeat_next_clocks,

    input profile_delivery_metadata, profile_execution_repeated, profile_repeat_nonempty_q,
    input [9:0] profile_execution_base, profile_execution_repeat_setup,
    input [9:0] profile_execution_repeat_iteration, profile_event_base,
    input [2:0] profile_execution_ea,
    input [3:0] profile_prefix_count_q
);

    wire [9:0] profile_execution_metadata_clocks;
    wire [23:0] profile_execution_metadata_carry_save;
    function automatic logic [9:0] profile_metadata_budget(
        input logic [9:0] base, setup_clocks, iteration_clocks,
        input logic [2:0] ea,
        input logic repeated, nonempty, delivery,
        input logic [3:0] prefixes
    );
        logic [3:0] remaining_prefixes;
        logic [11:0] first, second, prefix_clocks, sum_bits, carry_bits, full_sum;
        remaining_prefixes = prefixes == 0 ? 4'd0 : prefixes - 4'd1;
        first = {2'd0, repeated ? setup_clocks : base};
        second = repeated ? (nonempty ? {2'd0, iteration_clocks} : 12'd0) : {9'd0, ea};
        prefix_clocks = repeated ? {7'd0, remaining_prefixes, 1'b0} :
                        delivery ? 12'd0 : {7'd0, prefixes, 1'b0};
        sum_bits = first ^ second ^ prefix_clocks;
        carry_bits = (first & second) | (first & prefix_clocks) | (second & prefix_clocks);
        full_sum = sum_bits + (carry_bits << 1);
        profile_metadata_budget = |full_sum[11:10] ? 10'd1023 : full_sum[9:0];
    endfunction
    function automatic logic [23:0] profile_metadata_budget_carry_save(
        input logic [9:0] base, setup_clocks, iteration_clocks,
        input logic [2:0] ea,
        input logic repeated, nonempty,
        input logic [3:0] prefixes
    );
        logic [3:0] remaining_prefixes;
        logic [11:0] first, second, prefix_clocks, sum_bits, carry_bits;
        remaining_prefixes = prefixes == 0 ? 4'd0 : prefixes - 4'd1;
        first = {2'd0, repeated ? setup_clocks : base};
        second = repeated ? (nonempty ? {2'd0, iteration_clocks} : 12'd0) : {9'd0, ea};
        prefix_clocks = repeated ? {7'd0, remaining_prefixes, 1'b0} :
                                  {7'd0, prefixes, 1'b0};
        sum_bits = first ^ second ^ prefix_clocks;
        carry_bits = (first & second) | (first & prefix_clocks) | (second & prefix_clocks);
        profile_metadata_budget_carry_save = {sum_bits, carry_bits};
    endfunction    assign profile_execution_metadata_clocks = profile_delivery_metadata ? profile_event_base :
        profile_metadata_budget(profile_execution_base, profile_execution_repeat_setup,
            profile_execution_repeat_iteration, profile_execution_ea, profile_execution_repeated,
            profile_repeat_nonempty_q, 1'b0, profile_prefix_count_q);
    assign profile_execution_metadata_carry_save = profile_delivery_metadata ?
        {2'd0, profile_event_base, 12'd0} :
        profile_metadata_budget_carry_save(profile_execution_base, profile_execution_repeat_setup,
            profile_execution_repeat_iteration, profile_execution_ea, profile_execution_repeated,
            profile_repeat_nonempty_q, profile_prefix_count_q);

wire [0:0] carry_active;
wire [0:0] carry_body_active;
wire [0:0] carry_retire_pending;
wire [0:0] carry_head_permit;
wire [0:0] carry_deadline_ready;
wire [0:0] carry_retire_fire;
wire [9:0] carry_elapsed_clocks;
wire [9:0] carry_scheduled_clocks;
wire [0:0] carry_implementation_extension;
wire [36:0] carry_proof_state;
wire [0:0] legacy_active;
wire [0:0] legacy_body_active;
wire [0:0] legacy_retire_pending;
wire [0:0] legacy_head_permit;
wire [0:0] legacy_deadline_ready;
wire [0:0] legacy_retire_fire;
wire [9:0] legacy_elapsed_clocks;
wire [9:0] legacy_scheduled_clocks;
wire [0:0] legacy_implementation_extension;
wire [36:0] legacy_proof_state;
wire [0:0] reference_active;
wire [0:0] reference_body_active;
wire [0:0] reference_retire_pending;
wire [0:0] reference_head_permit;
wire [0:0] reference_deadline_ready;
wire [0:0] reference_retire_fire;
wire [9:0] reference_elapsed_clocks;
wire [9:0] reference_scheduled_clocks;
wire [0:0] reference_implementation_extension;
wire [36:0] reference_proof_state;
    wire [9:0] execution_metadata_clocks = profile_execution_metadata_clocks;
    wire [11:0] execution_metadata_sum_bits = profile_execution_metadata_carry_save[23:12];
    wire [11:0] execution_metadata_carry_bits = profile_execution_metadata_carry_save[11:0];
spk286_instruction_schedule #(.EXECUTION_METADATA_CARRY_SAVE(1)) carry(.active(carry_active),.body_active(carry_body_active),.retire_pending(carry_retire_pending),.head_permit(carry_head_permit),.deadline_ready(carry_deadline_ready),.retire_fire(carry_retire_fire),.elapsed_clocks(carry_elapsed_clocks),.scheduled_clocks(carry_scheduled_clocks),.implementation_extension(carry_implementation_extension),.proof_state(carry_proof_state),.*);
spk286_instruction_schedule legacy(.active(legacy_active),.body_active(legacy_body_active),.retire_pending(legacy_retire_pending),.head_permit(legacy_head_permit),.deadline_ready(legacy_deadline_ready),.retire_fire(legacy_retire_fire),.elapsed_clocks(legacy_elapsed_clocks),.scheduled_clocks(legacy_scheduled_clocks),.implementation_extension(legacy_implementation_extension),.proof_state(legacy_proof_state),.*);
reference_schedule reference(.active(reference_active),.body_active(reference_body_active),.retire_pending(reference_retire_pending),.head_permit(reference_head_permit),.deadline_ready(reference_deadline_ready),.retire_fire(reference_retire_fire),.elapsed_clocks(reference_elapsed_clocks),.scheduled_clocks(reference_scheduled_clocks),.implementation_extension(reference_implementation_extension),.proof_state(reference_proof_state),.*);
always @* begin
assert(carry_active == reference_active);
assert(carry_body_active == reference_body_active);
assert(carry_retire_pending == reference_retire_pending);
assert(carry_head_permit == reference_head_permit);
assert(carry_deadline_ready == reference_deadline_ready);
assert(carry_retire_fire == reference_retire_fire);
assert(carry_elapsed_clocks == reference_elapsed_clocks);
assert(carry_scheduled_clocks == reference_scheduled_clocks);
assert(carry_implementation_extension == reference_implementation_extension);
assert(carry_proof_state == reference_proof_state);
assert(legacy_active == reference_active);
assert(legacy_body_active == reference_body_active);
assert(legacy_retire_pending == reference_retire_pending);
assert(legacy_head_permit == reference_head_permit);
assert(legacy_deadline_ready == reference_deadline_ready);
assert(legacy_retire_fire == reference_retire_fire);
assert(legacy_elapsed_clocks == reference_elapsed_clocks);
assert(legacy_scheduled_clocks == reference_scheduled_clocks);
assert(legacy_implementation_extension == reference_implementation_extension);
assert(legacy_proof_state == reference_proof_state);
end
endmodule
