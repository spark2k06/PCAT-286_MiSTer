module palette_address_encoder(input wire [7:0] source_index, output wire [7:0] physical_index);
    function [7:0] palette_ram_address;
        input [7:0] logical_index;
        begin
            palette_ram_address[6:0] = logical_index[6:0] ^ logical_index[7:1];
            palette_ram_address[7] = logical_index[7] ^ logical_index[0] ^ logical_index[1];
        end
    endfunction
assign physical_index = palette_ram_address(source_index);
endmodule
