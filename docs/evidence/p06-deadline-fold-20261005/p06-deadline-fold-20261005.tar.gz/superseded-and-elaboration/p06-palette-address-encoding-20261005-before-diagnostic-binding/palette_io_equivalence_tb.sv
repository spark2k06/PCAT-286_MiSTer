`timescale 1ns/1ps
module palette_io_equivalence_tb;
reg clock = 0; always #5 clock = ~clock;
reg reset=0, load_defaults=0, invalidate=0, palette_64_mode=0;
reg read_index_write=0, write_index_write=0, data_write=0;
reg read_index_read=0, write_index_read=0, data_read=0;
reg [7:0] io_data_in=0, sample_index=0;
integer i, component, cycles=0;
wire [7:0] candidate_io_data_out;
wire [5:0] candidate_sample_red;
wire [5:0] candidate_sample_green;
wire [5:0] candidate_sample_blue;
wire [7:0] candidate_sample_red_8;
wire [7:0] candidate_sample_green_8;
wire [7:0] candidate_sample_blue_8;
wire [0:0] candidate_sample_valid;
wire [7:0] reference_io_data_out;
wire [5:0] reference_sample_red;
wire [5:0] reference_sample_green;
wire [5:0] reference_sample_blue;
wire [7:0] reference_sample_red_8;
wire [7:0] reference_sample_green_8;
wire [7:0] reference_sample_blue_8;
wire [0:0] reference_sample_valid;
vga_dac_io candidate(.clock(clock),.reset(reset),.load_defaults(load_defaults),.invalidate(invalidate),.palette_64_mode(palette_64_mode),.read_index_write(read_index_write),.write_index_write(write_index_write),.data_write(data_write),.read_index_read(read_index_read),.write_index_read(write_index_read),.data_read(data_read),.io_data_in(io_data_in),.io_data_out(candidate_io_data_out),.sample_index(sample_index),.sample_red(candidate_sample_red),.sample_green(candidate_sample_green),.sample_blue(candidate_sample_blue),.sample_red_8(candidate_sample_red_8),.sample_green_8(candidate_sample_green_8),.sample_blue_8(candidate_sample_blue_8),.sample_valid(candidate_sample_valid));
reference_vga_dac_io reference(.clock(clock),.reset(reset),.load_defaults(load_defaults),.invalidate(invalidate),.palette_64_mode(palette_64_mode),.read_index_write(read_index_write),.write_index_write(write_index_write),.data_write(data_write),.read_index_read(read_index_read),.write_index_read(write_index_read),.data_read(data_read),.io_data_in(io_data_in),.io_data_out(reference_io_data_out),.sample_index(sample_index),.sample_red(reference_sample_red),.sample_green(reference_sample_green),.sample_blue(reference_sample_blue),.sample_red_8(reference_sample_red_8),.sample_green_8(reference_sample_green_8),.sample_blue_8(reference_sample_blue_8),.sample_valid(reference_sample_valid));

task tick; begin
    @(posedge clock); #1;
if(candidate_io_data_out !== reference_io_data_out) $fatal(1,"Mismatch io_data_out");
if(candidate_sample_red !== reference_sample_red) $fatal(1,"Mismatch sample_red");
if(candidate_sample_green !== reference_sample_green) $fatal(1,"Mismatch sample_green");
if(candidate_sample_blue !== reference_sample_blue) $fatal(1,"Mismatch sample_blue");
if(candidate_sample_red_8 !== reference_sample_red_8) $fatal(1,"Mismatch sample_red_8");
if(candidate_sample_green_8 !== reference_sample_green_8) $fatal(1,"Mismatch sample_green_8");
if(candidate_sample_blue_8 !== reference_sample_blue_8) $fatal(1,"Mismatch sample_blue_8");
if(candidate_sample_valid !== reference_sample_valid) $fatal(1,"Mismatch sample_valid");
    cycles=cycles+1;
end endtask
task idle; begin
    read_index_write=0; write_index_write=0; data_write=0;
    read_index_read=0; write_index_read=0; data_read=0;
end endtask
initial begin
    reset=1; tick(); reset=0; load_defaults=1; tick(); load_defaults=0;
    for(i=0;i<256;i=i+1) begin
        idle(); write_index_write=1; io_data_in=i[7:0]; sample_index=i[7:0]; tick();
        for(component=0;component<3;component=component+1) begin
            idle(); data_write=1; io_data_in=(i[7:0] ^ 8'(component*21)); tick();
            idle(); tick();
        end
    end
    for(i=0;i<256;i=i+1) begin
        idle(); read_index_write=1; io_data_in=i[7:0]; sample_index=i[7:0]^8'h5a; tick();
        for(component=0;component<3;component=component+1) begin
            idle(); data_read=1; tick(); tick(); idle(); tick();
        end
    end
    for(i=0;i<768;i=i+1) begin
        {load_defaults,invalidate,palette_64_mode,read_index_write,write_index_write,data_write,
         read_index_read,write_index_read,data_read}=9'(i ^ (i>>3));
        io_data_in=i[7:0]^8'hc5; sample_index=i[7:0]^8'h53;
        reset=(i%101==0); tick();
    end
    idle(); reset=1; tick(); reset=0; tick();
    $display("PALETTE_IO_EQUIVALENCE_PASS %0d cycles",cycles); $finish;
end
endmodule
