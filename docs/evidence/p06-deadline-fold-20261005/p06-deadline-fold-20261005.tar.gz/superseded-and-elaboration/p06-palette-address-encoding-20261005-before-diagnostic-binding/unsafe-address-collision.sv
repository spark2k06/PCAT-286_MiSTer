module miter (
    input [7:0] logical_write, logical_sample, logical_port, watched_index,
    input [2:0] enables,
    input [17:0] old_row, write_data
);
    function [7:0] palette_ram_address;
        input [7:0] logical_index;
        begin
            palette_ram_address[6:0] = logical_index[6:0] ^ logical_index[7:1];
            palette_ram_address[7] = 1'b0;
        end
    endfunction
    wire [7:0] physical_write = palette_ram_address(logical_write);
    wire [7:0] physical_sample = palette_ram_address(logical_sample);
    wire [7:0] physical_port = palette_ram_address(logical_port);
    wire [7:0] physical_watched = palette_ram_address(watched_index);
    // An arbitrary logical row is related to its encoded physical row.
    // Identical write-decoder decisions preserve that relation at each edge
    // for every row/data/enable; identical read decisions preserve both ports.
    wire [17:0] legacy_next, encoded_next;
    genvar colour;
    generate for (colour = 0; colour < 3; colour = colour + 1) begin : g_row
        assign legacy_next[colour*6 +: 6] = enables[colour] && logical_write == watched_index ?
                                            write_data[colour*6 +: 6] : old_row[colour*6 +: 6];
        assign encoded_next[colour*6 +: 6] = enables[colour] && physical_write == physical_watched ?
                                             write_data[colour*6 +: 6] : old_row[colour*6 +: 6];
    end endgenerate
    always @* begin
        assert((logical_write == watched_index) == (physical_write == physical_watched));
        assert((logical_sample == watched_index) == (physical_sample == physical_watched));
        assert((logical_port == watched_index) == (physical_port == physical_watched));
        assert(legacy_next == encoded_next);
    end
endmodule
