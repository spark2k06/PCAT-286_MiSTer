module miter (
    input [7:0] operation,
    input raw_allowed, permission,
    input [15:0] protected_msw, architectural_flags,
    input check_pop2, segment_pop_opcode, pop_operation,
    input stack_cursor_valid_q, stack_write_sp
);

    wire allowed = raw_allowed && permission;
    wire implementation_allowed = raw_allowed;
    always @* assume(operation == 8'd121 || operation == 8'd128 || permission);

    wire legacy_begin_return_cursor, candidate_begin_return_cursor;
    wire legacy_stack_arch_write, candidate_stack_arch_write;
    assign legacy_begin_return_cursor = protected_msw[0] && (check_pop2 ||
                                 (allowed && operation == 8'd170 && !architectural_flags[14]) ||
                                 (segment_pop_opcode && pop_operation && !stack_cursor_valid_q));
    assign legacy_stack_arch_write = stack_write_sp && !(stack_cursor_valid_q || legacy_begin_return_cursor);
    assign candidate_begin_return_cursor = protected_msw[0] && (check_pop2 ||
                                 (implementation_allowed && operation == 8'd170 && !architectural_flags[14]) ||
                                 (segment_pop_opcode && pop_operation && !stack_cursor_valid_q));
    assign candidate_stack_arch_write = stack_write_sp && !(stack_cursor_valid_q || candidate_begin_return_cursor);
    always @* begin
        assert(legacy_begin_return_cursor == candidate_begin_return_cursor);
        assert(legacy_stack_arch_write == candidate_stack_arch_write);
    end
endmodule
