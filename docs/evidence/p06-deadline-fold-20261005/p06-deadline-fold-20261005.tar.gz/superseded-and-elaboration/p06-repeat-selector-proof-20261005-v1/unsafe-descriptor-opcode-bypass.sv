module miter (
    input [7:0] operation,
    input raw_allowed, permission,
    input [15:0] protected_msw,
    input call_gate_candidate_valid_q, event_gate_candidate_valid_q,
    input task_gate_target_active_q,
    input [15:0] task_gate_target_selector_q, tmp1_q, iret_outer_ss_q,
    input [15:0] call_stack_ss_q, tmp0_q
);

    wire allowed = raw_allowed && permission;
    wire implementation_allowed = raw_allowed;
    always @* assume(operation == 8'd121 || operation == 8'd128 || permission);
    wire legacy_jmp_gate_cs_validation_operation;
    wire legacy_cs_validation_operation;
    wire legacy_call_gate_validation_operation;
    wire legacy_call_gate_cs_validation_operation;
    wire legacy_iret_cs_validation_operation;
    wire legacy_iret_ss_validation_operation;
    wire legacy_call_ss_validation_operation;
    wire [15:0] legacy_descriptor_selector_value;
    wire candidate_jmp_gate_cs_validation_operation;
    wire candidate_cs_validation_operation;
    wire candidate_call_gate_validation_operation;
    wire candidate_call_gate_cs_validation_operation;
    wire candidate_iret_cs_validation_operation;
    wire candidate_iret_ss_validation_operation;
    wire candidate_call_ss_validation_operation;
    wire [15:0] candidate_descriptor_selector_value;
    assign legacy_jmp_gate_cs_validation_operation = implementation_allowed && protected_msw[0] &&
                                              operation == 8'd150 &&
                                              call_gate_candidate_valid_q && !event_gate_candidate_valid_q;
    assign legacy_cs_validation_operation = implementation_allowed && protected_msw[0] &&
                                     ((operation == 8'd150 &&
                                       !legacy_jmp_gate_cs_validation_operation) ||
                                      (operation == 8'd160 &&
                                       !call_gate_candidate_valid_q));
    assign legacy_call_gate_validation_operation = implementation_allowed && operation == 8'd159 && protected_msw[0];
    assign legacy_call_gate_cs_validation_operation = legacy_jmp_gate_cs_validation_operation ||
                                               (allowed && operation == 8'd160 &&
                                                protected_msw[0] && call_gate_candidate_valid_q);
    assign legacy_iret_cs_validation_operation = implementation_allowed && operation == 8'd156 && protected_msw[0];
    assign legacy_iret_ss_validation_operation = implementation_allowed && operation == 8'd158 && protected_msw[0];
    assign legacy_call_ss_validation_operation = implementation_allowed && operation == 8'd162 && protected_msw[0];
    assign legacy_descriptor_selector_value = (legacy_cs_validation_operation || legacy_call_gate_validation_operation ||
                                        legacy_call_gate_cs_validation_operation || legacy_iret_cs_validation_operation) ?
                                       (task_gate_target_active_q ? task_gate_target_selector_q : tmp1_q) :
                                       legacy_iret_ss_validation_operation ? iret_outer_ss_q :
                                       legacy_call_ss_validation_operation ? call_stack_ss_q : tmp0_q;
    assign candidate_jmp_gate_cs_validation_operation = implementation_allowed && protected_msw[0] &&
                                              operation == 8'd150 &&
                                              call_gate_candidate_valid_q && !event_gate_candidate_valid_q;
    assign candidate_cs_validation_operation = implementation_allowed && protected_msw[0] &&
                                     ((operation == 8'd150 &&
                                       !candidate_jmp_gate_cs_validation_operation) ||
                                      (operation == 8'd160 &&
                                       !call_gate_candidate_valid_q));
    assign candidate_call_gate_validation_operation = implementation_allowed && operation == 8'd159 && protected_msw[0];
    assign candidate_call_gate_cs_validation_operation = candidate_jmp_gate_cs_validation_operation ||
                                               (implementation_allowed && 1'b1 &&
                                                protected_msw[0] && call_gate_candidate_valid_q);
    assign candidate_iret_cs_validation_operation = implementation_allowed && operation == 8'd156 && protected_msw[0];
    assign candidate_iret_ss_validation_operation = implementation_allowed && operation == 8'd158 && protected_msw[0];
    assign candidate_call_ss_validation_operation = implementation_allowed && operation == 8'd162 && protected_msw[0];
    assign candidate_descriptor_selector_value = (candidate_cs_validation_operation || candidate_call_gate_validation_operation ||
                                        candidate_call_gate_cs_validation_operation || candidate_iret_cs_validation_operation) ?
                                       (task_gate_target_active_q ? task_gate_target_selector_q : tmp1_q) :
                                       candidate_iret_ss_validation_operation ? iret_outer_ss_q :
                                       candidate_call_ss_validation_operation ? call_stack_ss_q : tmp0_q;
    always @* begin
        assert(legacy_jmp_gate_cs_validation_operation == candidate_jmp_gate_cs_validation_operation);
        assert(legacy_cs_validation_operation == candidate_cs_validation_operation);
        assert(legacy_call_gate_validation_operation == candidate_call_gate_validation_operation);
        assert(legacy_call_gate_cs_validation_operation == candidate_call_gate_cs_validation_operation);
        assert(legacy_iret_cs_validation_operation == candidate_iret_cs_validation_operation);
        assert(legacy_iret_ss_validation_operation == candidate_iret_ss_validation_operation);
        assert(legacy_call_ss_validation_operation == candidate_call_ss_validation_operation);
        assert(legacy_descriptor_selector_value == candidate_descriptor_selector_value);
    end
endmodule
