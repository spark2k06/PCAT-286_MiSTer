`timescale 1ns/1ps
module spk286_preview_cost #(parameter bit HISTORICAL = 1'b1) (
    input logic clk, reset, cancel, start, enable, byte_valid, abort_fetch, consume,
    input logic [7:0] byte_data,
    output logic byte_ready, complete, valid_length, invalid_opcode, unsupported,
    output logic overlength, fetch_fault, replay_valid,
    output logic [3:0] length, replay_count,
    output logic [7:0] replay_data
);
    generate if (HISTORICAL) begin : historical
        spk286_encoding_preview preview (.clk(clk), .reset(reset), .cancel(cancel),
            .start(start), .enable(enable), .byte_valid(byte_valid), .byte_data(byte_data),
            .abort_fetch(abort_fetch), .byte_ready(byte_ready), .complete(complete),
            .valid_length(valid_length), .invalid_opcode(invalid_opcode), .unsupported(unsupported),
            .overlength(overlength), .fetch_fault(fetch_fault), .length(length));
        spk286_target_replay replay (.clk(clk), .reset(reset), .cancel(cancel), .start(start),
            .capture(byte_ready && byte_valid), .capture_data(byte_data), .consume(consume),
            .valid(replay_valid), .data(replay_data), .count(replay_count));
    end else begin : max_disabled
        assign {byte_ready, complete, valid_length, invalid_opcode, unsupported,
                overlength, fetch_fault, replay_valid, length, replay_count, replay_data} = '0;
    end endgenerate
endmodule
