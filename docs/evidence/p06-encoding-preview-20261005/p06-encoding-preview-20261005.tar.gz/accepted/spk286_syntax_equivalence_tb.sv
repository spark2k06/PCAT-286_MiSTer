`timescale 1ns/1ps
module spk286_syntax_equivalence_tb;
    localparam integer WIDTH = spk286_microcode_pkg::MC_ADDR_WIDTH;
    logic [7:0] opcode;
    logic extended_opcode, condition_taken, zero;
    logic [2:0] group_extension;
    logic [15:0] count;
    integer checks = 0;
    wire [1-1:0] decoder_gold_supported;
    wire [1-1:0] decoder_gold_invalid_opcode;
    wire [3-1:0] decoder_gold_destination;
    wire [3-1:0] decoder_gold_source_index;
    wire [WIDTH-1:0] decoder_gold_entry;
    spk286_decoder_baseline decoder_gold (.opcode(opcode), .extended_opcode(extended_opcode), .supported(decoder_gold_supported), .invalid_opcode(decoder_gold_invalid_opcode), .destination(decoder_gold_destination), .source_index(decoder_gold_source_index), .entry(decoder_gold_entry));
    wire [1-1:0] decoder_normal_supported;
    wire [1-1:0] decoder_normal_invalid_opcode;
    wire [3-1:0] decoder_normal_destination;
    wire [3-1:0] decoder_normal_source_index;
    wire [WIDTH-1:0] decoder_normal_entry;
    spk286_decoder decoder_normal (.opcode(opcode), .extended_opcode(extended_opcode), .supported(decoder_normal_supported), .invalid_opcode(decoder_normal_invalid_opcode), .destination(decoder_normal_destination), .source_index(decoder_normal_source_index), .entry(decoder_normal_entry));
    wire [1-1:0] decoder_syntax_supported;
    wire [1-1:0] decoder_syntax_invalid_opcode;
    wire [3-1:0] decoder_syntax_destination;
    wire [3-1:0] decoder_syntax_source_index;
    wire [WIDTH-1:0] decoder_syntax_entry;
    spk286_decoder #(.SYNTAX_ONLY(1'b1)) decoder_syntax (.opcode(opcode), .extended_opcode(extended_opcode), .supported(decoder_syntax_supported), .invalid_opcode(decoder_syntax_invalid_opcode), .destination(decoder_syntax_destination), .source_index(decoder_syntax_source_index), .entry(decoder_syntax_entry));
    wire [6:0] decoder_expected_shape = spk286_microcode_pkg::micro_instruction_syntax(decoder_gold_entry);
    wire [WIDTH-1:0] decoder_expected_entry = {{(WIDTH-7){1'b0}}, decoder_expected_shape};
    wire [1-1:0] control_decode_gold_push_enabled;
    wire [1-1:0] control_decode_gold_push_return_ip;
    wire [1-1:0] control_decode_gold_branch_taken;
    wire [1-1:0] control_decode_gold_decrement_count;
    wire [1-1:0] control_decode_gold_form_supported;
    wire [WIDTH-1:0] control_decode_gold_dispatch_entry;
    wire [3-1:0] control_decode_gold_adjust_kind;
    wire [2-1:0] control_decode_gold_muldiv_kind;
    wire [2-1:0] control_decode_gold_segment_index;
    wire [1-1:0] control_decode_gold_string_byte;
    wire [1-1:0] control_decode_gold_string_compare;
    wire [1-1:0] control_decode_gold_dispatch_valid;
    spk286_control_decode_baseline control_decode_gold (.opcode(opcode), .extended_opcode(extended_opcode), .condition_taken(condition_taken), .zero(zero), .group_extension(group_extension), .count(count), .push_enabled(control_decode_gold_push_enabled), .push_return_ip(control_decode_gold_push_return_ip), .branch_taken(control_decode_gold_branch_taken), .decrement_count(control_decode_gold_decrement_count), .form_supported(control_decode_gold_form_supported), .dispatch_entry(control_decode_gold_dispatch_entry), .adjust_kind(control_decode_gold_adjust_kind), .muldiv_kind(control_decode_gold_muldiv_kind), .segment_index(control_decode_gold_segment_index), .string_byte(control_decode_gold_string_byte), .string_compare(control_decode_gold_string_compare), .dispatch_valid(control_decode_gold_dispatch_valid));
    wire [1-1:0] control_decode_normal_push_enabled;
    wire [1-1:0] control_decode_normal_push_return_ip;
    wire [1-1:0] control_decode_normal_branch_taken;
    wire [1-1:0] control_decode_normal_decrement_count;
    wire [1-1:0] control_decode_normal_form_supported;
    wire [WIDTH-1:0] control_decode_normal_dispatch_entry;
    wire [3-1:0] control_decode_normal_adjust_kind;
    wire [2-1:0] control_decode_normal_muldiv_kind;
    wire [2-1:0] control_decode_normal_segment_index;
    wire [1-1:0] control_decode_normal_string_byte;
    wire [1-1:0] control_decode_normal_string_compare;
    wire [1-1:0] control_decode_normal_dispatch_valid;
    spk286_control_decode control_decode_normal (.opcode(opcode), .extended_opcode(extended_opcode), .condition_taken(condition_taken), .zero(zero), .group_extension(group_extension), .count(count), .push_enabled(control_decode_normal_push_enabled), .push_return_ip(control_decode_normal_push_return_ip), .branch_taken(control_decode_normal_branch_taken), .decrement_count(control_decode_normal_decrement_count), .form_supported(control_decode_normal_form_supported), .dispatch_entry(control_decode_normal_dispatch_entry), .adjust_kind(control_decode_normal_adjust_kind), .muldiv_kind(control_decode_normal_muldiv_kind), .segment_index(control_decode_normal_segment_index), .string_byte(control_decode_normal_string_byte), .string_compare(control_decode_normal_string_compare), .dispatch_valid(control_decode_normal_dispatch_valid));
    wire [1-1:0] control_decode_syntax_push_enabled;
    wire [1-1:0] control_decode_syntax_push_return_ip;
    wire [1-1:0] control_decode_syntax_branch_taken;
    wire [1-1:0] control_decode_syntax_decrement_count;
    wire [1-1:0] control_decode_syntax_form_supported;
    wire [WIDTH-1:0] control_decode_syntax_dispatch_entry;
    wire [3-1:0] control_decode_syntax_adjust_kind;
    wire [2-1:0] control_decode_syntax_muldiv_kind;
    wire [2-1:0] control_decode_syntax_segment_index;
    wire [1-1:0] control_decode_syntax_string_byte;
    wire [1-1:0] control_decode_syntax_string_compare;
    wire [1-1:0] control_decode_syntax_dispatch_valid;
    spk286_control_decode #(.SYNTAX_ONLY(1'b1)) control_decode_syntax (.opcode(opcode), .extended_opcode(extended_opcode), .condition_taken(condition_taken), .zero(zero), .group_extension(group_extension), .count(count), .push_enabled(control_decode_syntax_push_enabled), .push_return_ip(control_decode_syntax_push_return_ip), .branch_taken(control_decode_syntax_branch_taken), .decrement_count(control_decode_syntax_decrement_count), .form_supported(control_decode_syntax_form_supported), .dispatch_entry(control_decode_syntax_dispatch_entry), .adjust_kind(control_decode_syntax_adjust_kind), .muldiv_kind(control_decode_syntax_muldiv_kind), .segment_index(control_decode_syntax_segment_index), .string_byte(control_decode_syntax_string_byte), .string_compare(control_decode_syntax_string_compare), .dispatch_valid(control_decode_syntax_dispatch_valid));
    wire [6:0] control_decode_expected_shape = spk286_microcode_pkg::micro_instruction_syntax(control_decode_gold_dispatch_entry);
    wire [WIDTH-1:0] control_decode_expected_entry = {{(WIDTH-7){1'b0}}, control_decode_expected_shape};
    initial begin
        for (integer op = 0; op < 512; op = op + 1) begin
            opcode = 8'(op); extended_opcode = op >= 256;
            for (integer group_id = 0; group_id < 8; group_id = group_id + 1) begin
                group_extension = 3'(group_id);
                for (integer flags_id = 0; flags_id < 4; flags_id = flags_id + 1) begin
                    condition_taken = flags_id[0]; zero = flags_id[1];
                    for (integer count_id = 0; count_id < 3; count_id = count_id + 1) begin
                        count = count_id == 0 ? 16'd0 : count_id == 1 ? 16'd1 : 16'hFFFF;
                        #1;
                        if (decoder_normal_supported !== decoder_gold_supported) $fatal(1, "default functional decoder.supported differs op%h group%0d", opcode, group_id);
                        if (decoder_syntax_supported !== decoder_gold_supported) $fatal(1, "syntax functional decoder.supported differs");
                        if (decoder_normal_invalid_opcode !== decoder_gold_invalid_opcode) $fatal(1, "default functional decoder.invalid_opcode differs op%h group%0d", opcode, group_id);
                        if (decoder_syntax_invalid_opcode !== decoder_gold_invalid_opcode) $fatal(1, "syntax functional decoder.invalid_opcode differs");
                        if (decoder_normal_destination !== decoder_gold_destination) $fatal(1, "default functional decoder.destination differs op%h group%0d", opcode, group_id);
                        if (decoder_syntax_destination !== decoder_gold_destination) $fatal(1, "syntax functional decoder.destination differs");
                        if (decoder_normal_source_index !== decoder_gold_source_index) $fatal(1, "default functional decoder.source_index differs op%h group%0d", opcode, group_id);
                        if (decoder_syntax_source_index !== decoder_gold_source_index) $fatal(1, "syntax functional decoder.source_index differs");
                        if (decoder_normal_entry !== decoder_gold_entry) $fatal(1, "default functional decoder.entry differs op%h group%0d", opcode, group_id);
                        if (1'b1 && decoder_syntax_entry !== decoder_expected_entry) $fatal(1, "syntax leaf decoder.entry differs");
                        if (control_decode_normal_push_enabled !== control_decode_gold_push_enabled) $fatal(1, "default functional control_decode.push_enabled differs op%h group%0d", opcode, group_id);
                        if (control_decode_syntax_push_enabled !== control_decode_gold_push_enabled) $fatal(1, "syntax functional control_decode.push_enabled differs");
                        if (control_decode_normal_push_return_ip !== control_decode_gold_push_return_ip) $fatal(1, "default functional control_decode.push_return_ip differs op%h group%0d", opcode, group_id);
                        if (control_decode_syntax_push_return_ip !== control_decode_gold_push_return_ip) $fatal(1, "syntax functional control_decode.push_return_ip differs");
                        if (control_decode_normal_branch_taken !== control_decode_gold_branch_taken) $fatal(1, "default functional control_decode.branch_taken differs op%h group%0d", opcode, group_id);
                        if (control_decode_syntax_branch_taken !== control_decode_gold_branch_taken) $fatal(1, "syntax functional control_decode.branch_taken differs");
                        if (control_decode_normal_decrement_count !== control_decode_gold_decrement_count) $fatal(1, "default functional control_decode.decrement_count differs op%h group%0d", opcode, group_id);
                        if (control_decode_syntax_decrement_count !== control_decode_gold_decrement_count) $fatal(1, "syntax functional control_decode.decrement_count differs");
                        if (control_decode_normal_form_supported !== control_decode_gold_form_supported) $fatal(1, "default functional control_decode.form_supported differs op%h group%0d", opcode, group_id);
                        if (control_decode_syntax_form_supported !== control_decode_gold_form_supported) $fatal(1, "syntax functional control_decode.form_supported differs");
                        if (control_decode_normal_dispatch_entry !== control_decode_gold_dispatch_entry) $fatal(1, "default functional control_decode.dispatch_entry differs op%h group%0d", opcode, group_id);
                        if (control_decode_normal_adjust_kind !== control_decode_gold_adjust_kind) $fatal(1, "default functional control_decode.adjust_kind differs op%h group%0d", opcode, group_id);
                        if (control_decode_syntax_adjust_kind !== control_decode_gold_adjust_kind) $fatal(1, "syntax functional control_decode.adjust_kind differs");
                        if (control_decode_normal_muldiv_kind !== control_decode_gold_muldiv_kind) $fatal(1, "default functional control_decode.muldiv_kind differs op%h group%0d", opcode, group_id);
                        if (control_decode_syntax_muldiv_kind !== control_decode_gold_muldiv_kind) $fatal(1, "syntax functional control_decode.muldiv_kind differs");
                        if (control_decode_normal_segment_index !== control_decode_gold_segment_index) $fatal(1, "default functional control_decode.segment_index differs op%h group%0d", opcode, group_id);
                        if (control_decode_syntax_segment_index !== control_decode_gold_segment_index) $fatal(1, "syntax functional control_decode.segment_index differs");
                        if (control_decode_normal_string_byte !== control_decode_gold_string_byte) $fatal(1, "default functional control_decode.string_byte differs op%h group%0d", opcode, group_id);
                        if (control_decode_syntax_string_byte !== control_decode_gold_string_byte) $fatal(1, "syntax functional control_decode.string_byte differs");
                        if (control_decode_normal_string_compare !== control_decode_gold_string_compare) $fatal(1, "default functional control_decode.string_compare differs op%h group%0d", opcode, group_id);
                        if (control_decode_syntax_string_compare !== control_decode_gold_string_compare) $fatal(1, "syntax functional control_decode.string_compare differs");
                        if (control_decode_normal_dispatch_valid !== control_decode_gold_dispatch_valid) $fatal(1, "default functional control_decode.dispatch_valid differs op%h group%0d", opcode, group_id);
                        if (control_decode_syntax_dispatch_valid !== control_decode_gold_dispatch_valid) $fatal(1, "syntax functional control_decode.dispatch_valid differs");
                        if (control_decode_gold_dispatch_valid && control_decode_syntax_dispatch_entry !== control_decode_expected_entry) $fatal(1, "syntax leaf control_decode.dispatch_entry differs");
                        checks = checks + 1;
                    end
                end
            end
        end
        $display("SYNTAX DEFAULT EQUIVALENCE PASS checks=%0d", checks);
        $finish;
    end
endmodule
