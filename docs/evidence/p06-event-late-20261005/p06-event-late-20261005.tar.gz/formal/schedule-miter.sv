module schedule_miter (
    input clk, reset, historical_enable, cpu_boundary, cancel, preserve_cancel,
    input start_interval, start_body, metadata_valid, metadata_freeze,
    input execution_metadata_valid, execution_read_wait_event,
    input [9:0] metadata_clocks, execution_metadata_clocks,
    input target_length_ready, read_wait_event, alignment_event,
    input [3:0] target_length_clocks,
    input functional_retired, repeat_checkpoint,
    input [9:0] repeat_next_clocks
);
wire [0:0] a_active, b_active;
wire [0:0] a_body_active, b_body_active;
wire [0:0] a_retire_pending, b_retire_pending;
wire [0:0] a_head_permit, b_head_permit;
wire [0:0] a_deadline_ready, b_deadline_ready;
wire [0:0] a_retire_fire, b_retire_fire;
wire [9:0] a_elapsed_clocks, b_elapsed_clocks;
wire [9:0] a_scheduled_clocks, b_scheduled_clocks;
wire [0:0] a_implementation_extension, b_implementation_extension;
wire [36:0] a_proof_state, b_proof_state;
spk286_instruction_schedule a(.active(a_active),.body_active(a_body_active),.retire_pending(a_retire_pending),.head_permit(a_head_permit),.deadline_ready(a_deadline_ready),.retire_fire(a_retire_fire),.elapsed_clocks(a_elapsed_clocks),.scheduled_clocks(a_scheduled_clocks),.implementation_extension(a_implementation_extension),.proof_state(a_proof_state),.*);
reference_schedule b(.active(b_active),.body_active(b_body_active),.retire_pending(b_retire_pending),.head_permit(b_head_permit),.deadline_ready(b_deadline_ready),.retire_fire(b_retire_fire),.elapsed_clocks(b_elapsed_clocks),.scheduled_clocks(b_scheduled_clocks),.implementation_extension(b_implementation_extension),.proof_state(b_proof_state),.*);
always @* begin
    if (a_body_active) begin
        assume(execution_metadata_valid == metadata_valid);
        assume(execution_metadata_clocks == metadata_clocks);
        assume(execution_read_wait_event == read_wait_event);
    end
assert(a_active == b_active);
assert(a_body_active == b_body_active);
assert(a_retire_pending == b_retire_pending);
assert(a_head_permit == b_head_permit);
assert(a_deadline_ready == b_deadline_ready);
assert(a_retire_fire == b_retire_fire);
assert(a_elapsed_clocks == b_elapsed_clocks);
assert(a_scheduled_clocks == b_scheduled_clocks);
assert(a_implementation_extension == b_implementation_extension);
assert(a_proof_state == b_proof_state);
end
endmodule
