import hashlib,io,json,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'docs/evidence/p06-execution-deadline-20261005';OUT.mkdir(exist_ok=False)
directories={
    'unit':ROOT/'build/p06-deadline-lane-unit-20261005-v1',
    'formal-v1':ROOT/'build/p06-deadline-lane-formal-20261005-v1',
    'formal-v2':ROOT/'build/p06-deadline-lane-formal-20261005-v2',
    'integration':ROOT/'build/p06-deadline-lane-integration-20261005-v1',
    'compatibility':ROOT/'build/p06-deadline-lane-compatibility-20261005-v1'}
files={};inputs={};receipts={}
for label,base in directories.items():
    for p in sorted(base.rglob('*')):
        relative=p.relative_to(base)
        if p.is_file() and 'obj' not in relative.parts and p.suffix!='.vvp':
            files[label+'/'+relative.as_posix()]=p.read_bytes()
    if (base/'receipt.json').exists():
        receipt=json.loads((base/'receipt.json').read_text());receipts[label]=receipt
        assert receipt['status'] in ('PASS','EXECUTION_DEADLINE_EQUIVALENCE_PASS')
        for name,expected in receipt.get('source_sha256',receipt.get('sources_sha256',{})).items():
            if name in inputs:assert inputs[name]==expected,name
            inputs[name]=expected
for name,expected in inputs.items():
    data=(ROOT/name).read_bytes();assert hashlib.sha256(data).hexdigest()==expected,name
    files['source/'+name]=data
for name in ['vendor/spk286/rtl/timed/generation.json','vendor/spk286/rtl/timed/spk286_profiled.sv']:
    files['source/'+name]=(ROOT/name).read_bytes()
files['collector.py']=Path(__file__).read_bytes()
member_manifest={n:{'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()} for n,d in sorted(files.items())}
files['members.json']=(json.dumps(member_manifest,indent=2)+'\n').encode()
archive=OUT/'p06-execution-deadline-20261005.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
    for name,data in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    assert {m.name:tar.extractfile(m).read() for m in tar.getmembers()}==files
record={'status':'SEALED_DIRECTED_EQUIVALENCE_PASS','archive':archive.name,
    'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'members':len(files),
    'verification':'Every archived member matched its original byte string',
    'cpu_handoff_cases_each_simulator':777,'compatibility_records':30,'max_raw_pairs':5,
    'formal':'Execution-context lane equality plus inductive scheduler state/public-output equality',
    'negative':'Wrong execution opcode rejected; five existing controller mutations rejected',
    'scope':'Directed qualification, full regression user deferred; fitted cost/timing pending',
    'failed_adapter_attempt':'formal-v1 omitted Yosys -set-assumes: unconstrained lane values can differ; formal-v2 applies the separately proved contract',
    'objects_excluded':True}
(OUT/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
for label,receipt in receipts.items():(OUT/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
(OUT/'baseline-comparison.json').write_bytes((directories['integration']/'baseline-comparison.json').read_bytes())
print(json.dumps(record,indent=2))
