import hashlib, io, json, re, tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'build/p06-execution-deadline-allfeatures-20261005-v1'
OLD = ROOT / 'build/p06-replay-head-allfeatures-20261005-v1'
OUT = ROOT / 'docs/evidence/p06-execution-deadline-fit-20261005'
OUT.mkdir(exist_ok=False)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    return json.loads(path.read_text())

frozen = read(RUN/'manifest.json')
old_frozen = read(OLD/'manifest.json')
timing = read(RUN/'summary.json')
old_timing = read(OLD/'summary.json')
hierarchy = read(RUN/'hierarchy-resources.json')
old_hierarchy = read(OLD/'hierarchy-resources.json')
files = {}; effective = {}; generated = []
for name, expected in frozen['source_sha256'].items():
    normal = name.replace('\\','/')
    data = (RUN/'work'/normal).read_bytes()
    actual = digest(data)
    if actual != expected:
        assert normal == 'build_id.v' and data.strip() == b'`define BUILD_DATE "261005"', normal
        generated.append({'path':normal,'before_sha256':expected,'after_sha256':actual,
                          'rule':'Standard sys/build_id.tcl compile preflow regenerates only BUILD_DATE'})
    effective[normal] = actual
    files['source/'+normal] = data
assert len(generated) == 1
proof = read(ROOT/'docs/evidence/p06-execution-deadline-20261005/integration.json')
for name, expected in proof['sources_sha256'].items():
    assert effective[name] == expected, name
for name, expected in proof['generated_sha256'].items():
    assert effective['vendor/spk286/rtl/timed/'+name] == expected, name
old_inputs = {n.replace('\\','/'):h for n,h in old_frozen['source_sha256'].items()}
changes = {n:{'before':old_inputs.get(n),'after':h} for n,h in
           ((n.replace('\\','/'),h) for n,h in frozen['source_sha256'].items()) if old_inputs.get(n)!=h}
for n,h in old_inputs.items():
    if Path(n).suffix.lower() in ('.sdc','.qsf','.qip','.qpf','.tcl'):
        assert frozen['source_sha256'].get(n, frozen['source_sha256'].get(n.replace('/','\\'))) == h, n

def resources(directory, rows):
    text = (directory/'work/output_files/PCAT-286.fit.summary').read_text()
    cpu = next(r for r in rows['entities'] if r['entity']=='spk286_machine_cpu')
    top = next(r for r in rows['entities'] if r['path']=='|sys_top')
    report = (directory/'work/output_files/PCAT-286.fit.rpt').read_text()
    placed = int(re.search(r'ALMs used in final placement \[=a\+b\+c\+d\]\s*;\s*([\d,]+)',report)[1].replace(',',''))
    return {'equivalent_alms':int(re.search(r'Logic utilization \(in ALMs\)\s*:\s*([\d,]+)',text)[1].replace(',','')),
            'placed_alms':placed,
            'hierarchy_placed_alm_attribution':top['alm_placed']['inclusive'],
            'placed_percent_device':placed/41910*100,
            'registers':int(re.search(r'Total registers\s*:\s*(\d+)',text)[1]),
            'memory_bits':int(re.search(r'Total block memory bits\s*:\s*([\d,]+)',text)[1].replace(',','')),
            'm10k':top['m10k']['inclusive'],'dsp':top['dsp']['inclusive'],
            'pll':int(re.search(r'Total PLLs\s*:\s*(\d+)',text)[1]),
            'cpu':{key:cpu[key]['inclusive'] for key in ('alm_needed','alm_placed','registers','memory_bits','m10k')}}

def margins(summary):
    return {kind:min((d[kind]['global']['tool_worst_slack_ns'],corner) for corner,d in summary['corners'].items())
            for kind in ('setup','hold','recovery','removal')}

current = resources(RUN,hierarchy); previous = resources(OLD,old_hierarchy)
worst = min((d['setup']['cpu']['tool_worst_slack_ns'],corner,d['setup']['cpu']) for corner,d in timing['corners'].items())
rbf = RUN/'work/output_files/PCAT-286.rbf'
comparison = {'status':'COMPILE_COMPLETE_TIMING_OPEN',
              'baseline':OLD.relative_to(ROOT).as_posix(), 'candidate':RUN.relative_to(ROOT).as_posix(),
              'resource_baseline':previous,'resource_candidate':current,
              'margins_baseline_ns':margins(old_timing),'margins_candidate_ns':margins(timing),
              'setup_improvement_ns':round(margins(timing)['setup'][0]-margins(old_timing)['setup'][0],3),
              'worst_cpu_path':{'corner':worst[1],'path':worst[2]['top_paths'][0],'logic_levels':worst[2]['logic_levels']},
              'rbf':{'path':rbf.relative_to(ROOT).as_posix(),'bytes':rbf.stat().st_size,'sha256':digest(rbf.read_bytes())},
              'sources':{'count':len(effective),'controlled_generated':generated,'baseline_snapshot_deltas':changes,
                         'directed_cpu_source_binding':'All integration proof and generated CPU/event input hashes matched fitted sources',
                         'constraint_configuration_binding':'Every baseline SDC, QSF, QIP, QPF and TCL source hash unchanged'},
              'timing_scope':'Four-corner constrained paths; bounded top-N per selector, inherited platform limitations retained',
              'hardware':'NOT_RUN','full_regression':'USER_DEFERRED','compile_duration':'00:28:05','detailed_sta_duration':'00:03:35'}
(RUN/'result.json').write_text(json.dumps(comparison,indent=2)+'\n')
for p in sorted(RUN.iterdir()):
    if p.is_file(): files['run/'+p.name] = p.read_bytes()
for p in sorted((RUN/'timing').rglob('*')):
    if p.is_file(): files['run/timing/'+p.relative_to(RUN/'timing').as_posix()] = p.read_bytes()
for p in sorted((RUN/'work/output_files').iterdir()):
    if p.is_file() and p.suffix.lower() in ('.rpt','.summary','.smsg'):
        files['run/output_files/'+p.name] = p.read_bytes()
files['collector.py'] = Path(__file__).read_bytes()
files['effective-source-sha256.json'] = (json.dumps(effective,indent=2)+'\n').encode()
member_manifest = {n:{'bytes':len(d),'sha256':digest(d)} for n,d in sorted(files.items())}
files['members.json'] = (json.dumps(member_manifest,indent=2)+'\n').encode()
archive = OUT/'p06-execution-deadline-fit-20261005.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
    for name,data in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
        tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    verified = {m.name:tar.extractfile(m).read() for m in tar.getmembers()}
assert verified == files
record = {'status':'SEALED_FITTED_RESULT_TIMING_OPEN','archive':archive.name,
          'sha256':digest(archive.read_bytes()),'bytes':archive.stat().st_size,'members':len(files),
          'verification':'Every archived member matched its original byte string',
          'rbf':comparison['rbf'],'excluded':'RBF/SOF remain in output_files; compiler databases and simulator objects excluded',
          'frozen_head':frozen['head'],'fitted_source_count':len(effective)}
(OUT/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
(OUT/'result.json').write_bytes((RUN/'result.json').read_bytes())
print(json.dumps(comparison,indent=2));print(json.dumps(record,indent=2))
