#!/usr/bin/env python3
"""Replay only frozen CPU functional boundary proof, no current production RTL."""
import argparse, json, sys
from pathlib import Path
p=Path(__file__).resolve().parent
sys.path.insert(0,str(p/'source/scripts'))
import test_p06_length_fault_boundary as boundary
parser=argparse.ArgumentParser()
parser.add_argument('--output',type=Path,required=True)
a=parser.parse_args(); out=a.output.resolve(); out.mkdir(parents=True,exist_ok=False)
packages=['spk286_microcode_pkg.sv','spk286_microcode_rom.sv','spk286_microcode_sync_rom.sv','spk286_protected_pkg.sv','spk286_tss_pkg.sv']
sources=[p/'frozen'/name for name in packages]
sources += [path for path in sorted((p/'frozen').glob('*.sv')) if path.name not in packages]
shared=[p/'source/rtl/spk286_integration/spk286_at_cpu_profile.sv',p/'source/sim/spk286_timing/spk286_length_fault_boundary_tb.sv']
includes=['-I'+str(p/'source/vendor/spk286/sim/unit')]
for label in ('old','corrected'):
    selected=[p/'frozen_old_spk286.sv' if label=='old' and path.name=='spk286.sv' else path for path in sources]
    boundary.run(['iverilog','-g2012','-DHANDOFF_GOLDEN_FUNCTIONAL','-s',boundary.TOP,*includes,'-o',out/(label+'.vvp'),*selected,*shared],out/(label+'-build.log'))
old=boundary.execute_old(['vvp',out/'old.vvp','+profile=0','+trace=1','+debug=1'],out/'old.log',out/'old.csv.gz')
corrected=boundary.execute(['vvp',out/'corrected.vvp','+profile=0','+trace=1','+debug=1'],out/'corrected.log',out/'corrected.csv.gz')
original=json.loads((p/'receipt.json').read_text())
assert old==original['old']
assert corrected==original['corrected']
assert boundary.compare_prefix(out/'old.csv.gz',out/'corrected.csv.gz')==original['pair']
(out/'verification.json').write_text(json.dumps({'status':'PASS','scope':'Frozen Icarus raw source-bound proof replay'},indent=2)+'\n')
print('P06_LENGTH_BOUNDARY_FROZEN_REPLAY_PASS')
