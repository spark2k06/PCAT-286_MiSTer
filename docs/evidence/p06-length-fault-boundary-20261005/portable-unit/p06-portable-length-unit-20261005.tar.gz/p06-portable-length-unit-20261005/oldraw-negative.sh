#!/usr/bin/env bash
set -euo pipefail
root=/mnt/d/GitHub/PCAT-286_MiSTer
out="$root/build/p06-portable-length-unit-20261005-v2/oldraw-negative"
mkdir -p "$out"
cd "$root/vendor/spk286"
source scripts/rtl_sources.sh
old="$root/build/p06-raw10-review-20261005/p06-length-fault-boundary-20261005/frozen_old_spk286.sv"
for i in "${!rtl_sources[@]}"; do
    if [[ "${rtl_sources[$i]}" == rtl/spk286.sv ]]; then rtl_sources[$i]="$old"; fi
done
iverilog -g2012 -Irtl -Isim/unit -s spk286_length_boundary_tb -o "$out/oldraw.vvp" "${rtl_sources[@]}" sim/unit/spk286_length_boundary_tb.sv > "$out/compile.log" 2>&1
set +e
vvp "$out/oldraw.vvp" > "$out/runtime.log" 2>&1
rc=$?
set -e
cat "$out/runtime.log"
[[ $rc -ne 0 ]]
grep -q "legal ten-byte completion must not raise a following #GP" "$out/runtime.log"
printf 'OLDRAW_NEGATIVE_PASS exit=%s\n' "$rc"
