import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[1]
packet = ROOT / 'docs/evidence/p06-live-speed-20261005'
packet.mkdir(parents=True, exist_ok=False)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
outputs = {
    'live': 'p06-live-speed-directed-20261005-v3',
    'selector-static': 'p06-live-speed-static-selector-20261005-v1',
    'components': 'p06-live-speed-components-20261005-v2',
    'integration': 'p06-live-speed-static-handoff-20261005-v1',
    'affected': 'p06-live-speed-static-affected-20261005-v1',
    'formal': 'p06-live-speed-repeat-proof-20261005-v1',
    'top': 'p06-live-speed-top-elab-20261005-v3',
}
receipts, source_hashes = {}, {}
for label, directory in outputs.items():
    folder = ROOT / 'build' / directory
    path = folder / ('components.json' if label == 'components' else 'receipt.json')
    if label == 'top':
        assert 'AT_CONFIG_NO_DEBUG_PASS bytes=1870' in (folder / 'config.log').read_text()
        continue
    data = json.loads(path.read_text())
    assert data['status'] in ('PASS', 'PROFILE_COMPONENT_PREPARATION_PASS_NOT_FULL_ACCEPTANCE',
                             'REPEAT_LOCAL_STROBES_EQUIVALENCE_PASS')
    receipts[label] = data
    for key in ('sources_sha256', 'source_sha256'):
        for name, expected in data.get(key, {}).items():
            p = ROOT / name
            assert sha(p) == expected, name
            assert source_hashes.get(name, expected) == expected, name
            source_hashes[name] = expected
    (packet / (label + '.json')).write_text(json.dumps(data, indent=2) + '\n')
comparisons = {}
for label in ('integration', 'affected'):
    baseline = ROOT / 'docs/evidence/p06-repeat-decoder-20261005' / (label + '.json')
    assert receipts[label]['results'] == json.loads(baseline.read_text())['results']
    comparisons[label] = {'baseline': baseline.relative_to(ROOT).as_posix(),
                          'sha256': sha(baseline), 'complete_results_equal': True,
                          'entries': len(receipts[label]['results'])}
(packet / 'baseline-comparison.json').write_text(json.dumps(comparisons, indent=2) + '\n')
files = {}
for name in source_hashes:
    files['source/' + name] = ROOT / name
for directory in ('rtl', 'sys', 'sim'):
    for p in (ROOT / directory).rglob('*'):
        if p.is_file() and p.suffix.lower() in ('.sv', '.v', '.vh', '.svh', '.qip'):
            files['source/' + p.relative_to(ROOT).as_posix()] = p
for p in ROOT.iterdir():
    if p.is_file() and p.suffix.lower() in ('.sv', '.v', '.qsf', '.qpf', '.qip', '.tcl', '.sdc'):
        files['source/' + p.name] = p
for name in ('scripts/test_at_profile_elab.sh', 'scripts/check_pcat_project.py',
             'vendor/spk286/rtl/timed/generation.json', 'vendor/spk286/rtl/timed/spk286_profiled.sv',
             'vendor/spk286/rtl/timed/spk286_profiled_events.sv',
             'vendor/spk286/rtl/timed/spk286_profiled_micro_executor.sv',
             'vendor/spk286/rtl/timed/repeat-local-contract.json',
             'docs/optimization/P06_LIVE_SPEED_20261005.md'):
    files['source/' + name] = ROOT / name
for label, directory in outputs.items():
    folder = ROOT / 'build' / directory
    for p in folder.rglob('*'):
        if not p.is_file() or p.suffix == '.vvp' or any(
                part == 'obj' or part.endswith('-obj') or part.endswith('-verilator')
                for part in p.relative_to(folder).parts):
            continue
        files['tests/' + label + '/' + p.relative_to(folder).as_posix()] = p
files['collector.py'] = Path(__file__)
archive = packet / 'p06-live-speed-20261005.tar.gz'
bindings = {name: {'sha256': sha(p), 'bytes': p.stat().st_size} for name, p in sorted(files.items())}
with tarfile.open(archive, 'w:gz') as tar:
    for name, p in sorted(files.items()):
        data = p.read_bytes(); entry = tarfile.TarInfo(name); entry.size = len(data)
        tar.addfile(entry, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(bindings)
    for entry in tar.getmembers():
        data = tar.extractfile(entry).read()
        assert hashlib.sha256(data).hexdigest() == bindings[entry.name]['sha256']
        assert data == files[entry.name].read_bytes()
manifest = {'status': 'SEALED_LIVE_SPEED_DIRECTED_PASS_NOT_FITTED',
            'archive': archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size,
            'members': len(bindings), 'verification': 'Every archived member read back equal to original bytes',
            'source_sha256': source_hashes, 'members_sha256': bindings,
            'full_regression': 'USER_DEFERRED', 'hardware': 'NOT_RUN'}
(packet / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
cleanup_names = list(outputs.values()) + ['p06-live-speed-components-20261005-v1',
    'p06-live-speed-top-elab-20261005-v1', 'p06-live-speed-top-elab-20261005-v2',
    'p06-live-speed-directed-20261005-v1', 'p06-live-speed-directed-20261005-v2'] + [
    'p06-live-speed-cpu-debug-20261005-v' + str(i) for i in range(1, 6)]
cleanup = {'status': 'PENDING', 'archive_sha256': sha(archive),
           'targets': ['build/' + name for name in cleanup_names if (ROOT / 'build' / name).exists()]}
(packet / 'cleanup.json').write_text(json.dumps(cleanup, indent=2) + '\n')
print('SEALED_LIVE_SPEED', archive.stat().st_size, len(bindings), flush=True)
