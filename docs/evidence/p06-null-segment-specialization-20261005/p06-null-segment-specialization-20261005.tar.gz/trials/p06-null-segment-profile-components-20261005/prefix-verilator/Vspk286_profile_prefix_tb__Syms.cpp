// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Symbol table implementation internals

#include "Vspk286_profile_prefix_tb__pch.h"
#include "Vspk286_profile_prefix_tb.h"
#include "Vspk286_profile_prefix_tb___024root.h"

// FUNCTIONS
Vspk286_profile_prefix_tb__Syms::~Vspk286_profile_prefix_tb__Syms()
{
}

Vspk286_profile_prefix_tb__Syms::Vspk286_profile_prefix_tb__Syms(VerilatedContext* contextp, const char* namep, Vspk286_profile_prefix_tb* modelp)
    : VerilatedSyms{contextp}
    // Setup internal state of the Syms class
    , __Vm_modelp{modelp}
    // Setup module instances
    , TOP{this, namep}
{
    // Configure time unit / time precision
    _vm_contextp__->timeunit(-9);
    _vm_contextp__->timeprecision(-12);
    // Setup each module's pointers to their submodules
    // Setup each module's pointer back to symbol table (for public functions)
    TOP.__Vconfigure(true);
    // Setup scopes
    __Vscope_spk286_profile_prefix_tb.configure(this, name(), "spk286_profile_prefix_tb", "spk286_profile_prefix_tb", -9, VerilatedScope::SCOPE_OTHER);
    __Vscope_spk286_profile_prefix_tb__check.configure(this, name(), "spk286_profile_prefix_tb.check", "check", -9, VerilatedScope::SCOPE_OTHER);
}
