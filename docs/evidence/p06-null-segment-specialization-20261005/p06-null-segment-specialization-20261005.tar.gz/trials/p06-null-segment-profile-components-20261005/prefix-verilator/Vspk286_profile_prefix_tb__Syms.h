// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Symbol table internal header
//
// Internal details; most calling programs do not need this header,
// unless using verilator public meta comments.

#ifndef VERILATED_VSPK286_PROFILE_PREFIX_TB__SYMS_H_
#define VERILATED_VSPK286_PROFILE_PREFIX_TB__SYMS_H_  // guard

#include "verilated.h"

// INCLUDE MODEL CLASS

#include "Vspk286_profile_prefix_tb.h"

// INCLUDE MODULE CLASSES
#include "Vspk286_profile_prefix_tb___024root.h"

// SYMS CLASS (contains all model state)
class alignas(VL_CACHE_LINE_BYTES)Vspk286_profile_prefix_tb__Syms final : public VerilatedSyms {
  public:
    // INTERNAL STATE
    Vspk286_profile_prefix_tb* const __Vm_modelp;
    VlDeleter __Vm_deleter;
    bool __Vm_didInit = false;

    // MODULE INSTANCE STATE
    Vspk286_profile_prefix_tb___024root TOP;

    // SCOPE NAMES
    VerilatedScope __Vscope_spk286_profile_prefix_tb;
    VerilatedScope __Vscope_spk286_profile_prefix_tb__check;

    // CONSTRUCTORS
    Vspk286_profile_prefix_tb__Syms(VerilatedContext* contextp, const char* namep, Vspk286_profile_prefix_tb* modelp);
    ~Vspk286_profile_prefix_tb__Syms();

    // METHODS
    const char* name() { return TOP.name(); }
};

#endif  // guard
