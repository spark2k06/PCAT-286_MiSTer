// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vspk286_profile_prefix_tb.h for the primary calling header

#include "Vspk286_profile_prefix_tb__pch.h"
#include "Vspk286_profile_prefix_tb__Syms.h"
#include "Vspk286_profile_prefix_tb___024root.h"

VlCoroutine Vspk286_profile_prefix_tb___024root___eval_initial__TOP__Vtiming__0__0(Vspk286_profile_prefix_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_profile_prefix_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_profile_prefix_tb___024root___eval_initial__TOP__Vtiming__0__0\n"); );
    // Init
    IData/*31:0*/ spk286_profile_prefix_tb__DOT__timeout_count;
    spk286_profile_prefix_tb__DOT__timeout_count = 0;
    QData/*63:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__0__code;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__0__code = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__0__length;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__0__length = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__0__unnamedblk1__DOT__i;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__0__unnamedblk1__DOT__i = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__0__unnamedblk2__DOT__i;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__0__unnamedblk2__DOT__i = 0;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__2__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__2__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__2__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__3__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__3__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__3__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__4__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__4__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__4__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__5__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__5__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__5__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__6__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__6__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__6__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__8__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__8__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__8__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__9__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__9__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__9__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__10__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__10__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__10__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__11__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__11__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__11__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__12__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__12__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__12__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__14__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__14__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__14__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__15__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__15__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__15__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__16__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__16__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__16__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__17__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__17__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__17__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__18__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__18__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__18__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__20__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__20__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__20__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__21__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__21__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__21__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__22__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__22__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__22__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__23__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__23__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__23__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__24__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__24__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__24__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__25__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__25__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__25__message;
    QData/*63:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__26__code;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__26__code = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__26__length;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__26__length = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__26__prefix_count;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__26__prefix_count = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__26__budget;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__26__budget = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__26__estimated;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__26__estimated = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__26__unnamedblk1__DOT__i;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__26__unnamedblk1__DOT__i = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__26__unnamedblk2__DOT__i;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__26__unnamedblk2__DOT__i = 0;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__28__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__28__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__28__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__29__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__29__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__29__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__30__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__30__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__30__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__31__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__31__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__31__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__32__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__32__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__32__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__34__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__34__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__34__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__35__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__35__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__35__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__36__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__36__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__36__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__37__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__37__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__37__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__38__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__38__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__38__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__40__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__40__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__40__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__41__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__41__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__41__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__42__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__42__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__42__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__43__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__43__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__43__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__44__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__44__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__44__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__46__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__46__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__46__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__47__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__47__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__47__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__48__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__48__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__48__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__49__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__49__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__49__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__50__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__50__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__50__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__51__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__51__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__51__message;
    QData/*63:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__52__code;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__52__code = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__52__length;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__52__length = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__52__prefix_count;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__52__prefix_count = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__52__budget;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__52__budget = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__52__estimated;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__52__estimated = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__52__unnamedblk1__DOT__i;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__52__unnamedblk1__DOT__i = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__52__unnamedblk2__DOT__i;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__52__unnamedblk2__DOT__i = 0;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__54__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__54__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__54__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__55__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__55__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__55__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__56__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__56__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__56__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__57__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__57__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__57__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__58__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__58__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__58__message;
    // Body
    __Vtask_spk286_profile_prefix_tb__DOT__setup__0__length = 2U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__0__code = 0xd801ULL;
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__reset = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__flags_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__checked = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__expected_count = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__expected_budget = 2U;
    vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated = 0U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__0__unnamedblk1__DOT__i = 0U;
    while (VL_GTS_III(32, 0x1000U, __Vtask_spk286_profile_prefix_tb__DOT__setup__0__unnamedblk1__DOT__i)) {
        vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                       & __Vtask_spk286_profile_prefix_tb__DOT__setup__0__unnamedblk1__DOT__i)] = 0xf4U;
        __Vtask_spk286_profile_prefix_tb__DOT__setup__0__unnamedblk1__DOT__i 
            = ((IData)(1U) + __Vtask_spk286_profile_prefix_tb__DOT__setup__0__unnamedblk1__DOT__i);
    }
    __Vtask_spk286_profile_prefix_tb__DOT__setup__0__unnamedblk2__DOT__i = 0U;
    while (VL_LTS_III(32, __Vtask_spk286_profile_prefix_tb__DOT__setup__0__unnamedblk2__DOT__i, __Vtask_spk286_profile_prefix_tb__DOT__setup__0__length)) {
        vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                       & ((IData)(0x100U) 
                                                          + __Vtask_spk286_profile_prefix_tb__DOT__setup__0__unnamedblk2__DOT__i))] 
            = (0xffU & (IData)((__Vtask_spk286_profile_prefix_tb__DOT__setup__0__code 
                                >> (0x3fU & VL_MULS_III(32, (IData)(8U), __Vtask_spk286_profile_prefix_tb__DOT__setup__0__unnamedblk2__DOT__i)))));
        __Vtask_spk286_profile_prefix_tb__DOT__setup__0__unnamedblk2__DOT__i 
            = ((IData)(1U) + __Vtask_spk286_profile_prefix_tb__DOT__setup__0__unnamedblk2__DOT__i);
    }
    vlSelf->spk286_profile_prefix_tb__DOT__memory[0x300U] = 0x5aU;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__2__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__2__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__2__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__2__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__3__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__3__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__3__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__3__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__4__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__4__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__4__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__4__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__5__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__5__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__5__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__5__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__6__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__6__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__6__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__6__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__reset = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__8__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__8__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__8__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__8__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__9__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__9__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__9__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__9__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__10__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__10__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__10__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__10__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__11__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__11__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__11__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__11__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__12__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__12__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__12__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__12__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__8__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__8__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__8__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__8__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__9__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__9__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__9__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__9__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__10__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__10__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__10__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__10__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__11__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__11__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__11__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__11__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__12__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__12__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__12__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__12__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 2U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__8__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__8__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__8__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__8__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__9__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__9__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__9__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__9__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__10__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__10__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__10__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__10__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__11__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__11__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__11__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__11__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__12__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__12__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__12__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__12__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 3U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__8__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__8__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__8__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__8__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__9__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__9__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__9__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__9__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__10__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__10__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__10__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__10__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__11__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__11__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__11__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__11__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__12__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__12__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__12__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__12__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 4U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__8__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__8__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__8__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__8__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__9__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__9__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__9__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__9__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__10__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__10__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__10__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__10__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__11__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__11__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__11__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__11__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__12__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__12__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__12__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__12__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 5U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__8__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__8__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__8__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__8__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__9__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__9__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__9__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__9__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__10__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__10__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__10__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__10__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__11__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__11__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__11__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__11__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__12__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__12__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__12__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__12__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 6U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0x300U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__8__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__8__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__8__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__8__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__9__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__9__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__9__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__9__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__10__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__10__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__10__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__10__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__11__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__11__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__11__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__11__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__12__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__12__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__12__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__12__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 7U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0x400U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__8__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__8__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__8__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__8__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__9__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__9__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__9__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__9__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__10__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__10__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__10__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__10__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__11__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__11__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__11__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__11__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__12__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__12__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__12__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__12__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__14__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__14__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__14__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__14__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__15__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__15__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__15__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__15__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__16__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__16__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__16__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__16__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__17__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__17__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__17__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__17__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__18__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__18__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__18__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__18__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__14__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__14__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__14__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__14__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__15__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__15__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__15__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__15__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__16__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__16__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__16__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__16__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__17__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__17__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__17__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__17__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__18__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__18__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__18__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__18__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 2U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__14__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__14__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__14__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__14__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__15__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__15__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__15__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__15__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__16__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__16__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__16__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__16__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__17__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__17__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__17__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__17__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__18__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__18__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__18__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__18__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 3U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__14__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__14__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__14__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__14__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__15__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__15__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__15__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__15__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__16__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__16__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__16__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__16__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__17__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__17__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__17__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__17__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__18__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__18__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__18__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__18__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = 1U;
    spk286_profile_prefix_tb__DOT__timeout_count = 0U;
    while (((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_normal_retired_q) 
                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_software) 
                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__event_completed)))) 
            & VL_GTS_III(32, 0x1388U, spk286_profile_prefix_tb__DOT__timeout_count))) {
        vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
            = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
        vlSelf->spk286_profile_prefix_tb__DOT__ready 
            = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
        vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__data_in 
                = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                    [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                       ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                 | (2U 
                                                    == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                           ? 0U : (
                                                   (1U 
                                                    == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                    : 
                                                   ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                     : 0U)))
                                       : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                           ? 2U : 0U))))] 
                    << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
                   [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                          | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                    ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                             : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                 ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                 : 0U)))
                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                    ? 2U : 0U)))]);
        }
        co_await vlSelf->__VdlySched.delay(0xfa0ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                           28);
        if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
            if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
                 & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                    & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
            }
            if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
                 & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
                __Vtask_spk286_profile_prefix_tb__DOT__check__20__message = 
                    std::string{"actual prefix aggregation count"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__20__condition 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__20__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__20__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                __Vtask_spk286_profile_prefix_tb__DOT__check__21__message = 
                    std::string{"accepted prefix count oracle"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__21__condition 
                    = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__21__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__21__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                __Vtask_spk286_profile_prefix_tb__DOT__check__22__message = 
                    std::string{"LOCK/REP/override aggregate instruction budget"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__22__condition 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__22__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__22__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                __Vtask_spk286_profile_prefix_tb__DOT__check__23__message = 
                    std::string{"extra native fallback marked estimated"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__23__condition 
                    = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                        | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                             & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                            & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                           | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                              & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                                 & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                        & ((((0xa4U 
                                              <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                             & (0xa7U 
                                                >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                            | (((0xaaU 
                                                 <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                                & (0xafU 
                                                   >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                               | ((0x6cU 
                                                   <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                                  & (0x6fU 
                                                     >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                           & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                    | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__23__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__23__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
            }
            if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
                 & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                          | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                    ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                             : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                 ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                 : 0U)))
                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                    ? 2U : 0U))))) {
                if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                               ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                         | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                   ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                : 0U)))
                               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                   ? 2U : 0U))))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                                   & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                       ? 
                                                                      ((1U 
                                                                        & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                           | (2U 
                                                                              == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                        ? 0U
                                                                        : 
                                                                       ((1U 
                                                                         == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                         : 
                                                                        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                          ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                          : 0U)))
                                                                       : 
                                                                      ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                        ? 2U
                                                                        : 0U)))] 
                        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                            ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                         ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                             ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                             : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                 ? 
                                                (0xffU 
                                                 & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                 : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                            : 0U);
                }
                if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                               | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                              | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                  ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                      ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                      : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                                  : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                     | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                                   | (0xffeU 
                                                                      & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                          ? 
                                                                         ((1U 
                                                                           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                              | (2U 
                                                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                           ? 0U
                                                                           : 
                                                                          ((1U 
                                                                            == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                            : 
                                                                           ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                             : 0U)))
                                                                          : 
                                                                         ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                           ? 2U
                                                                           : 0U))))] 
                        = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                      ? (0xffffU & 
                                         ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                           ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                               ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                      : 0U) >> 8U));
                }
            }
        }
        vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
        co_await vlSelf->__VdlySched.delay(0x1388ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                           46);
        vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                           46);
        vlSelf->spk286_profile_prefix_tb__DOT__edges 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
        if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__24__message = 
                std::string{"original functional engine accepts probe"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__24__condition 
                = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                           & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                          & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                         & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__24__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__24__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
        }
        spk286_profile_prefix_tb__DOT__timeout_count 
            = ((IData)(1U) + spk286_profile_prefix_tb__DOT__timeout_count);
    }
    __Vtask_spk286_profile_prefix_tb__DOT__check__25__message = 
        std::string{"probe retirement and passive budget coverage"};
    __Vtask_spk286_profile_prefix_tb__DOT__check__25__condition 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_normal_retired_q) 
            | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_software) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__event_completed))) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked));
    vlSelf->spk286_profile_prefix_tb__DOT__checks = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__25__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__25__message),
                  32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                  4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                  32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                  10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                  32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                  8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
    }
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = 0U;
    VL_WRITEF("PROFILE_PREFIX_CASE case%0d prefix%0d budget%0d estimated%0d\n",
              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
    vlSelf->spk286_profile_prefix_tb__DOT__case_id 
        = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__case_id);
    __Vtask_spk286_profile_prefix_tb__DOT__setup__26__estimated = 0U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__26__budget = 2U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__26__prefix_count = 0U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__26__length = 3U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__26__code = 0xd801f0ULL;
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__reset = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__flags_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__checked = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__expected_count 
        = __Vtask_spk286_profile_prefix_tb__DOT__setup__26__prefix_count;
    vlSelf->spk286_profile_prefix_tb__DOT__expected_budget 
        = __Vtask_spk286_profile_prefix_tb__DOT__setup__26__budget;
    vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated 
        = __Vtask_spk286_profile_prefix_tb__DOT__setup__26__estimated;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__26__unnamedblk1__DOT__i = 0U;
    while (VL_GTS_III(32, 0x1000U, __Vtask_spk286_profile_prefix_tb__DOT__setup__26__unnamedblk1__DOT__i)) {
        vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                       & __Vtask_spk286_profile_prefix_tb__DOT__setup__26__unnamedblk1__DOT__i)] = 0xf4U;
        __Vtask_spk286_profile_prefix_tb__DOT__setup__26__unnamedblk1__DOT__i 
            = ((IData)(1U) + __Vtask_spk286_profile_prefix_tb__DOT__setup__26__unnamedblk1__DOT__i);
    }
    __Vtask_spk286_profile_prefix_tb__DOT__setup__26__unnamedblk2__DOT__i = 0U;
    while (VL_LTS_III(32, __Vtask_spk286_profile_prefix_tb__DOT__setup__26__unnamedblk2__DOT__i, __Vtask_spk286_profile_prefix_tb__DOT__setup__26__length)) {
        vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                       & ((IData)(0x100U) 
                                                          + __Vtask_spk286_profile_prefix_tb__DOT__setup__26__unnamedblk2__DOT__i))] 
            = (0xffU & (IData)((__Vtask_spk286_profile_prefix_tb__DOT__setup__26__code 
                                >> (0x3fU & VL_MULS_III(32, (IData)(8U), __Vtask_spk286_profile_prefix_tb__DOT__setup__26__unnamedblk2__DOT__i)))));
        __Vtask_spk286_profile_prefix_tb__DOT__setup__26__unnamedblk2__DOT__i 
            = ((IData)(1U) + __Vtask_spk286_profile_prefix_tb__DOT__setup__26__unnamedblk2__DOT__i);
    }
    vlSelf->spk286_profile_prefix_tb__DOT__memory[0x300U] = 0x5aU;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__28__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__28__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__28__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__28__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__29__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__29__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__29__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__29__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__30__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__30__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__30__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__30__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__31__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__31__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__31__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__31__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__32__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__32__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__32__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__32__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__reset = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__34__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__34__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__34__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__34__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__35__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__35__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__35__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__35__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__36__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__36__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__36__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__36__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__37__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__37__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__37__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__37__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__38__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__38__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__38__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__38__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__34__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__34__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__34__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__34__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__35__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__35__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__35__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__35__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__36__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__36__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__36__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__36__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__37__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__37__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__37__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__37__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__38__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__38__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__38__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__38__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 2U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__34__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__34__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__34__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__34__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__35__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__35__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__35__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__35__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__36__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__36__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__36__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__36__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__37__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__37__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__37__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__37__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__38__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__38__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__38__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__38__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 3U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__34__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__34__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__34__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__34__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__35__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__35__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__35__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__35__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__36__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__36__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__36__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__36__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__37__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__37__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__37__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__37__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__38__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__38__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__38__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__38__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 4U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__34__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__34__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__34__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__34__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__35__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__35__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__35__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__35__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__36__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__36__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__36__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__36__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__37__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__37__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__37__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__37__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__38__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__38__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__38__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__38__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 5U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__34__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__34__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__34__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__34__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__35__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__35__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__35__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__35__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__36__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__36__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__36__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__36__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__37__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__37__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__37__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__37__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__38__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__38__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__38__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__38__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 6U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0x300U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__34__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__34__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__34__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__34__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__35__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__35__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__35__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__35__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__36__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__36__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__36__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__36__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__37__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__37__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__37__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__37__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__38__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__38__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__38__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__38__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 7U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0x400U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__34__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__34__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__34__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__34__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__35__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__35__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__35__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__35__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__36__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__36__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__36__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__36__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__37__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__37__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__37__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__37__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__38__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__38__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__38__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__38__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__40__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__40__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__40__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__40__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__41__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__41__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__41__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__41__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__42__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__42__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__42__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__42__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__43__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__43__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__43__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__43__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__44__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__44__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__44__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__44__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__40__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__40__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__40__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__40__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__41__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__41__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__41__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__41__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__42__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__42__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__42__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__42__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__43__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__43__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__43__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__43__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__44__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__44__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__44__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__44__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 2U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__40__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__40__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__40__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__40__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__41__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__41__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__41__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__41__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__42__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__42__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__42__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__42__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__43__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__43__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__43__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__43__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__44__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__44__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__44__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__44__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 3U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__40__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__40__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__40__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__40__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__41__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__41__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__41__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__41__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__42__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__42__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__42__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__42__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__43__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__43__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__43__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__43__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__44__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__44__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__44__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__44__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = 1U;
    spk286_profile_prefix_tb__DOT__timeout_count = 0U;
    while (((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_normal_retired_q) 
                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_software) 
                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__event_completed)))) 
            & VL_GTS_III(32, 0x1388U, spk286_profile_prefix_tb__DOT__timeout_count))) {
        vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
            = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
        vlSelf->spk286_profile_prefix_tb__DOT__ready 
            = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
        vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__data_in 
                = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                    [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                       ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                 | (2U 
                                                    == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                           ? 0U : (
                                                   (1U 
                                                    == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                    : 
                                                   ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                     : 0U)))
                                       : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                           ? 2U : 0U))))] 
                    << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
                   [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                          | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                    ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                             : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                 ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                 : 0U)))
                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                    ? 2U : 0U)))]);
        }
        co_await vlSelf->__VdlySched.delay(0xfa0ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                           28);
        if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
            if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
                 & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                    & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
            }
            if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
                 & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
                __Vtask_spk286_profile_prefix_tb__DOT__check__46__message = 
                    std::string{"actual prefix aggregation count"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__46__condition 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__46__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__46__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                __Vtask_spk286_profile_prefix_tb__DOT__check__47__message = 
                    std::string{"accepted prefix count oracle"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__47__condition 
                    = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__47__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__47__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                __Vtask_spk286_profile_prefix_tb__DOT__check__48__message = 
                    std::string{"LOCK/REP/override aggregate instruction budget"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__48__condition 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__48__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__48__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                __Vtask_spk286_profile_prefix_tb__DOT__check__49__message = 
                    std::string{"extra native fallback marked estimated"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__49__condition 
                    = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                        | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                             & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                            & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                           | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                              & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                                 & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                        & ((((0xa4U 
                                              <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                             & (0xa7U 
                                                >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                            | (((0xaaU 
                                                 <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                                & (0xafU 
                                                   >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                               | ((0x6cU 
                                                   <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                                  & (0x6fU 
                                                     >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                           & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                    | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__49__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__49__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
            }
            if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
                 & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                          | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                    ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                             : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                 ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                 : 0U)))
                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                    ? 2U : 0U))))) {
                if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                               ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                         | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                   ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                : 0U)))
                               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                   ? 2U : 0U))))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                                   & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                       ? 
                                                                      ((1U 
                                                                        & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                           | (2U 
                                                                              == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                        ? 0U
                                                                        : 
                                                                       ((1U 
                                                                         == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                         : 
                                                                        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                          ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                          : 0U)))
                                                                       : 
                                                                      ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                        ? 2U
                                                                        : 0U)))] 
                        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                            ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                         ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                             ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                             : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                 ? 
                                                (0xffU 
                                                 & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                 : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                            : 0U);
                }
                if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                               | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                              | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                  ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                      ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                      : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                                  : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                     | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                                   | (0xffeU 
                                                                      & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                          ? 
                                                                         ((1U 
                                                                           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                              | (2U 
                                                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                           ? 0U
                                                                           : 
                                                                          ((1U 
                                                                            == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                            : 
                                                                           ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                             : 0U)))
                                                                          : 
                                                                         ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                           ? 2U
                                                                           : 0U))))] 
                        = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                      ? (0xffffU & 
                                         ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                           ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                               ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                      : 0U) >> 8U));
                }
            }
        }
        vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
        co_await vlSelf->__VdlySched.delay(0x1388ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                           46);
        vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                           46);
        vlSelf->spk286_profile_prefix_tb__DOT__edges 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
        if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__50__message = 
                std::string{"original functional engine accepts probe"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__50__condition 
                = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                           & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                          & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                         & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__50__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__50__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
        }
        spk286_profile_prefix_tb__DOT__timeout_count 
            = ((IData)(1U) + spk286_profile_prefix_tb__DOT__timeout_count);
    }
    __Vtask_spk286_profile_prefix_tb__DOT__check__51__message = 
        std::string{"probe retirement and passive budget coverage"};
    __Vtask_spk286_profile_prefix_tb__DOT__check__51__condition 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_normal_retired_q) 
            | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_software) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__event_completed))) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked));
    vlSelf->spk286_profile_prefix_tb__DOT__checks = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__51__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__51__message),
                  32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                  4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                  32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                  10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                  32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                  8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
    }
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = 0U;
    VL_WRITEF("PROFILE_PREFIX_CASE case%0d prefix%0d budget%0d estimated%0d\n",
              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
    vlSelf->spk286_profile_prefix_tb__DOT__case_id 
        = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__case_id);
    __Vtask_spk286_profile_prefix_tb__DOT__setup__52__estimated = 1U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__52__budget = 4U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__52__prefix_count = 1U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__52__length = 3U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__52__code = 0xd8012eULL;
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__reset = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__flags_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__checked = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__expected_count 
        = __Vtask_spk286_profile_prefix_tb__DOT__setup__52__prefix_count;
    vlSelf->spk286_profile_prefix_tb__DOT__expected_budget 
        = __Vtask_spk286_profile_prefix_tb__DOT__setup__52__budget;
    vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated 
        = __Vtask_spk286_profile_prefix_tb__DOT__setup__52__estimated;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__52__unnamedblk1__DOT__i = 0U;
    while (VL_GTS_III(32, 0x1000U, __Vtask_spk286_profile_prefix_tb__DOT__setup__52__unnamedblk1__DOT__i)) {
        vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                       & __Vtask_spk286_profile_prefix_tb__DOT__setup__52__unnamedblk1__DOT__i)] = 0xf4U;
        __Vtask_spk286_profile_prefix_tb__DOT__setup__52__unnamedblk1__DOT__i 
            = ((IData)(1U) + __Vtask_spk286_profile_prefix_tb__DOT__setup__52__unnamedblk1__DOT__i);
    }
    __Vtask_spk286_profile_prefix_tb__DOT__setup__52__unnamedblk2__DOT__i = 0U;
    while (VL_LTS_III(32, __Vtask_spk286_profile_prefix_tb__DOT__setup__52__unnamedblk2__DOT__i, __Vtask_spk286_profile_prefix_tb__DOT__setup__52__length)) {
        vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                       & ((IData)(0x100U) 
                                                          + __Vtask_spk286_profile_prefix_tb__DOT__setup__52__unnamedblk2__DOT__i))] 
            = (0xffU & (IData)((__Vtask_spk286_profile_prefix_tb__DOT__setup__52__code 
                                >> (0x3fU & VL_MULS_III(32, (IData)(8U), __Vtask_spk286_profile_prefix_tb__DOT__setup__52__unnamedblk2__DOT__i)))));
        __Vtask_spk286_profile_prefix_tb__DOT__setup__52__unnamedblk2__DOT__i 
            = ((IData)(1U) + __Vtask_spk286_profile_prefix_tb__DOT__setup__52__unnamedblk2__DOT__i);
    }
    vlSelf->spk286_profile_prefix_tb__DOT__memory[0x300U] = 0x5aU;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__54__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__54__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__54__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__54__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__55__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__55__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__55__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__55__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__56__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__56__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__56__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__56__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__57__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__57__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__57__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__57__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__58__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__58__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__58__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__58__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__reset = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__message = 
                std::string{"actual prefix aggregation count"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__message = 
                std::string{"accepted prefix count oracle"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__message = 
                std::string{"extra native fallback marked estimated"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__message = 
            std::string{"original functional engine accepts probe"};
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__message = 
                std::string{"actual prefix aggregation count"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__message = 
                std::string{"accepted prefix count oracle"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__message = 
                std::string{"extra native fallback marked estimated"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__message = 
            std::string{"original functional engine accepts probe"};
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 2U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
}
