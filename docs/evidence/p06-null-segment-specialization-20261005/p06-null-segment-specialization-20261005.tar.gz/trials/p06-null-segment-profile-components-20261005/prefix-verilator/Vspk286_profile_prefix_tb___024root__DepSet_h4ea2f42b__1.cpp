// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vspk286_profile_prefix_tb.h for the primary calling header

#include "Vspk286_profile_prefix_tb__pch.h"
#include "Vspk286_profile_prefix_tb__Syms.h"
#include "Vspk286_profile_prefix_tb___024root.h"

VlCoroutine Vspk286_profile_prefix_tb___024root___eval_initial__TOP__Vtiming__0__1(Vspk286_profile_prefix_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_profile_prefix_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_profile_prefix_tb___024root___eval_initial__TOP__Vtiming__0__1\n"); );
    // Init
    IData/*31:0*/ spk286_profile_prefix_tb__DOT__timeout_count;
    spk286_profile_prefix_tb__DOT__timeout_count = 0;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__66__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__66__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__66__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__67__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__67__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__67__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__68__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__68__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__68__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__69__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__69__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__69__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__70__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__70__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__70__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__72__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__72__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__72__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__73__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__73__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__73__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__74__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__74__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__74__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__75__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__75__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__75__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__76__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__76__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__76__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__77__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__77__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__77__message;
    QData/*63:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__78__code;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__78__code = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__78__length;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__78__length = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__78__prefix_count;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__78__prefix_count = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__78__budget;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__78__budget = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__78__estimated;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__78__estimated = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__78__unnamedblk1__DOT__i;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__78__unnamedblk1__DOT__i = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__78__unnamedblk2__DOT__i;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__78__unnamedblk2__DOT__i = 0;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__80__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__80__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__80__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__81__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__81__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__81__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__82__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__82__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__82__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__83__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__83__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__83__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__84__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__84__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__84__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__86__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__86__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__86__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__87__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__87__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__87__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__88__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__88__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__88__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__89__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__89__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__89__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__90__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__90__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__90__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__92__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__92__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__92__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__93__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__93__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__93__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__94__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__94__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__94__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__95__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__95__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__95__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__96__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__96__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__96__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__98__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__98__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__98__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__99__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__99__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__99__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__100__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__100__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__100__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__101__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__101__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__101__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__102__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__102__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__102__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__103__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__103__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__103__message;
    QData/*63:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__104__code;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__104__code = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__104__length;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__104__length = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__104__prefix_count;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__104__prefix_count = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__104__budget;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__104__budget = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__104__estimated;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__104__estimated = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__104__unnamedblk1__DOT__i;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__104__unnamedblk1__DOT__i = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__104__unnamedblk2__DOT__i;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__104__unnamedblk2__DOT__i = 0;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__106__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__106__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__106__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__107__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__107__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__107__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__108__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__108__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__108__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__109__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__109__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__109__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__110__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__110__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__110__message;
    // Body
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__message = 
                std::string{"actual prefix aggregation count"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__message = 
                std::string{"accepted prefix count oracle"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__message = 
                std::string{"extra native fallback marked estimated"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__message = 
            std::string{"original functional engine accepts probe"};
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 3U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__message = 
                std::string{"actual prefix aggregation count"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__message = 
                std::string{"accepted prefix count oracle"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__message = 
                std::string{"extra native fallback marked estimated"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__message = 
            std::string{"original functional engine accepts probe"};
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 4U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__message = 
                std::string{"actual prefix aggregation count"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__message = 
                std::string{"accepted prefix count oracle"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__message = 
                std::string{"extra native fallback marked estimated"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__message = 
            std::string{"original functional engine accepts probe"};
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 5U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__message = 
                std::string{"actual prefix aggregation count"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__message = 
                std::string{"accepted prefix count oracle"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__message = 
                std::string{"extra native fallback marked estimated"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__message = 
            std::string{"original functional engine accepts probe"};
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 6U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0x300U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__message = 
                std::string{"actual prefix aggregation count"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__message = 
                std::string{"accepted prefix count oracle"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__message = 
                std::string{"extra native fallback marked estimated"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__message = 
            std::string{"original functional engine accepts probe"};
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 7U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0x400U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__message = 
                std::string{"actual prefix aggregation count"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__message = 
                std::string{"accepted prefix count oracle"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__message = 
                std::string{"extra native fallback marked estimated"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__message = 
            std::string{"original functional engine accepts probe"};
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__66__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__66__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__66__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__66__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__67__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__67__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__67__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__67__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__68__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__68__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__68__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__68__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__69__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__69__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__69__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__69__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__70__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__70__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__70__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__70__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__66__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__66__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__66__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__66__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__67__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__67__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__67__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__67__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__68__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__68__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__68__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__68__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__69__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__69__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__69__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__69__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__70__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__70__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__70__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__70__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 2U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__66__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__66__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__66__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__66__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__67__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__67__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__67__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__67__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__68__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__68__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__68__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__68__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__69__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__69__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__69__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__69__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__70__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__70__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__70__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__70__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 3U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__66__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__66__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__66__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__66__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__67__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__67__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__67__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__67__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__68__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__68__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__68__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__68__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__69__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__69__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__69__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__69__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__70__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__70__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__70__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__70__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = 1U;
    spk286_profile_prefix_tb__DOT__timeout_count = 0U;
    while (((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_normal_retired_q) 
                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_software) 
                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__event_completed)))) 
            & VL_GTS_III(32, 0x1388U, spk286_profile_prefix_tb__DOT__timeout_count))) {
        vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
            = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
        vlSelf->spk286_profile_prefix_tb__DOT__ready 
            = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
        vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__data_in 
                = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                    [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                       ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                 | (2U 
                                                    == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                           ? 0U : (
                                                   (1U 
                                                    == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                    : 
                                                   ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                     : 0U)))
                                       : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                           ? 2U : 0U))))] 
                    << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
                   [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                          | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                    ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                             : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                 ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                 : 0U)))
                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                    ? 2U : 0U)))]);
        }
        co_await vlSelf->__VdlySched.delay(0xfa0ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                           28);
        if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
            if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
                 & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                    & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
            }
            if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
                 & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
                __Vtask_spk286_profile_prefix_tb__DOT__check__72__message = 
                    std::string{"actual prefix aggregation count"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__72__condition 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__72__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__72__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                __Vtask_spk286_profile_prefix_tb__DOT__check__73__message = 
                    std::string{"accepted prefix count oracle"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__73__condition 
                    = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__73__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__73__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                __Vtask_spk286_profile_prefix_tb__DOT__check__74__message = 
                    std::string{"LOCK/REP/override aggregate instruction budget"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__74__condition 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__74__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__74__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                __Vtask_spk286_profile_prefix_tb__DOT__check__75__message = 
                    std::string{"extra native fallback marked estimated"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__75__condition 
                    = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                        | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                             & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                            & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                           | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                              & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                                 & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                        & ((((0xa4U 
                                              <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                             & (0xa7U 
                                                >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                            | (((0xaaU 
                                                 <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                                & (0xafU 
                                                   >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                               | ((0x6cU 
                                                   <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                                  & (0x6fU 
                                                     >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                           & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                    | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__75__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__75__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
            }
            if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
                 & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                          | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                    ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                             : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                 ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                 : 0U)))
                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                    ? 2U : 0U))))) {
                if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                               ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                         | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                   ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                : 0U)))
                               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                   ? 2U : 0U))))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                                   & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                       ? 
                                                                      ((1U 
                                                                        & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                           | (2U 
                                                                              == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                        ? 0U
                                                                        : 
                                                                       ((1U 
                                                                         == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                         : 
                                                                        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                          ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                          : 0U)))
                                                                       : 
                                                                      ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                        ? 2U
                                                                        : 0U)))] 
                        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                            ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                         ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                             ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                             : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                 ? 
                                                (0xffU 
                                                 & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                 : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                            : 0U);
                }
                if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                               | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                              | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                  ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                      ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                      : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                                  : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                     | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                                   | (0xffeU 
                                                                      & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                          ? 
                                                                         ((1U 
                                                                           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                              | (2U 
                                                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                           ? 0U
                                                                           : 
                                                                          ((1U 
                                                                            == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                            : 
                                                                           ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                             : 0U)))
                                                                          : 
                                                                         ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                           ? 2U
                                                                           : 0U))))] 
                        = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                      ? (0xffffU & 
                                         ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                           ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                               ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                      : 0U) >> 8U));
                }
            }
        }
        vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
        co_await vlSelf->__VdlySched.delay(0x1388ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                           46);
        vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                           46);
        vlSelf->spk286_profile_prefix_tb__DOT__edges 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
        if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__76__message = 
                std::string{"original functional engine accepts probe"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__76__condition 
                = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                           & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                          & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                         & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__76__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__76__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
        }
        spk286_profile_prefix_tb__DOT__timeout_count 
            = ((IData)(1U) + spk286_profile_prefix_tb__DOT__timeout_count);
    }
    __Vtask_spk286_profile_prefix_tb__DOT__check__77__message = 
        std::string{"probe retirement and passive budget coverage"};
    __Vtask_spk286_profile_prefix_tb__DOT__check__77__condition 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_normal_retired_q) 
            | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_software) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__event_completed))) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked));
    vlSelf->spk286_profile_prefix_tb__DOT__checks = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__77__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__77__message),
                  32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                  4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                  32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                  10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                  32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                  8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
    }
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = 0U;
    VL_WRITEF("PROFILE_PREFIX_CASE case%0d prefix%0d budget%0d estimated%0d\n",
              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
    vlSelf->spk286_profile_prefix_tb__DOT__case_id 
        = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__case_id);
    __Vtask_spk286_profile_prefix_tb__DOT__setup__78__estimated = 0U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__78__budget = 9U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__78__prefix_count = 1U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__78__length = 2U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__78__code = 0xa4f3ULL;
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__reset = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__flags_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__checked = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__expected_count 
        = __Vtask_spk286_profile_prefix_tb__DOT__setup__78__prefix_count;
    vlSelf->spk286_profile_prefix_tb__DOT__expected_budget 
        = __Vtask_spk286_profile_prefix_tb__DOT__setup__78__budget;
    vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated 
        = __Vtask_spk286_profile_prefix_tb__DOT__setup__78__estimated;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__78__unnamedblk1__DOT__i = 0U;
    while (VL_GTS_III(32, 0x1000U, __Vtask_spk286_profile_prefix_tb__DOT__setup__78__unnamedblk1__DOT__i)) {
        vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                       & __Vtask_spk286_profile_prefix_tb__DOT__setup__78__unnamedblk1__DOT__i)] = 0xf4U;
        __Vtask_spk286_profile_prefix_tb__DOT__setup__78__unnamedblk1__DOT__i 
            = ((IData)(1U) + __Vtask_spk286_profile_prefix_tb__DOT__setup__78__unnamedblk1__DOT__i);
    }
    __Vtask_spk286_profile_prefix_tb__DOT__setup__78__unnamedblk2__DOT__i = 0U;
    while (VL_LTS_III(32, __Vtask_spk286_profile_prefix_tb__DOT__setup__78__unnamedblk2__DOT__i, __Vtask_spk286_profile_prefix_tb__DOT__setup__78__length)) {
        vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                       & ((IData)(0x100U) 
                                                          + __Vtask_spk286_profile_prefix_tb__DOT__setup__78__unnamedblk2__DOT__i))] 
            = (0xffU & (IData)((__Vtask_spk286_profile_prefix_tb__DOT__setup__78__code 
                                >> (0x3fU & VL_MULS_III(32, (IData)(8U), __Vtask_spk286_profile_prefix_tb__DOT__setup__78__unnamedblk2__DOT__i)))));
        __Vtask_spk286_profile_prefix_tb__DOT__setup__78__unnamedblk2__DOT__i 
            = ((IData)(1U) + __Vtask_spk286_profile_prefix_tb__DOT__setup__78__unnamedblk2__DOT__i);
    }
    vlSelf->spk286_profile_prefix_tb__DOT__memory[0x300U] = 0x5aU;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__80__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__80__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__80__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__80__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__81__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__81__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__81__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__81__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__82__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__82__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__82__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__82__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__83__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__83__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__83__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__83__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__84__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__84__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__84__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__84__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__reset = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__86__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__86__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__86__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__86__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__87__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__87__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__87__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__87__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__88__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__88__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__88__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__88__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__89__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__89__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__89__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__89__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__90__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__90__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__90__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__90__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__86__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__86__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__86__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__86__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__87__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__87__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__87__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__87__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__88__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__88__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__88__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__88__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__89__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__89__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__89__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__89__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__90__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__90__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__90__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__90__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 2U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__86__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__86__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__86__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__86__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__87__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__87__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__87__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__87__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__88__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__88__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__88__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__88__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__89__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__89__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__89__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__89__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__90__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__90__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__90__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__90__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 3U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__86__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__86__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__86__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__86__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__87__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__87__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__87__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__87__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__88__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__88__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__88__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__88__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__89__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__89__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__89__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__89__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__90__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__90__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__90__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__90__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 4U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__86__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__86__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__86__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__86__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__87__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__87__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__87__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__87__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__88__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__88__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__88__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__88__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__89__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__89__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__89__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__89__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__90__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__90__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__90__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__90__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 5U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__86__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__86__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__86__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__86__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__87__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__87__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__87__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__87__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__88__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__88__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__88__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__88__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__89__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__89__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__89__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__89__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__90__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__90__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__90__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__90__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 6U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0x300U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__86__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__86__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__86__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__86__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__87__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__87__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__87__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__87__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__88__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__88__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__88__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__88__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__89__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__89__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__89__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__89__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__90__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__90__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__90__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__90__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 7U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0x400U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__86__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__86__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__86__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__86__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__87__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__87__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__87__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__87__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__88__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__88__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__88__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__88__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__89__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__89__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__89__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__89__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__90__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__90__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__90__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__90__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__92__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__92__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__92__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__92__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__93__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__93__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__93__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__93__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__94__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__94__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__94__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__94__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__95__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__95__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__95__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__95__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__96__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__96__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__96__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__96__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__92__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__92__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__92__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__92__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__93__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__93__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__93__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__93__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__94__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__94__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__94__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__94__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__95__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__95__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__95__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__95__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__96__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__96__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__96__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__96__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 2U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__92__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__92__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__92__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__92__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__93__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__93__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__93__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__93__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__94__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__94__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__94__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__94__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__95__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__95__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__95__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__95__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__96__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__96__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__96__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__96__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 3U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__92__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__92__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__92__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__92__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__93__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__93__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__93__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__93__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__94__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__94__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__94__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__94__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__95__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__95__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__95__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__95__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__96__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__96__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__96__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__96__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = 1U;
    spk286_profile_prefix_tb__DOT__timeout_count = 0U;
    while (((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_normal_retired_q) 
                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_software) 
                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__event_completed)))) 
            & VL_GTS_III(32, 0x1388U, spk286_profile_prefix_tb__DOT__timeout_count))) {
        vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
            = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
        vlSelf->spk286_profile_prefix_tb__DOT__ready 
            = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
        vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__data_in 
                = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                    [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                       ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                 | (2U 
                                                    == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                           ? 0U : (
                                                   (1U 
                                                    == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                    : 
                                                   ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                     : 0U)))
                                       : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                           ? 2U : 0U))))] 
                    << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
                   [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                          | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                    ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                             : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                 ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                 : 0U)))
                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                    ? 2U : 0U)))]);
        }
        co_await vlSelf->__VdlySched.delay(0xfa0ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                           28);
        if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
            if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
                 & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                    & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
            }
            if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
                 & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
                __Vtask_spk286_profile_prefix_tb__DOT__check__98__message = 
                    std::string{"actual prefix aggregation count"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__98__condition 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__98__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__98__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                __Vtask_spk286_profile_prefix_tb__DOT__check__99__message = 
                    std::string{"accepted prefix count oracle"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__99__condition 
                    = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__99__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__99__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                __Vtask_spk286_profile_prefix_tb__DOT__check__100__message = 
                    std::string{"LOCK/REP/override aggregate instruction budget"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__100__condition 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__100__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__100__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                __Vtask_spk286_profile_prefix_tb__DOT__check__101__message = 
                    std::string{"extra native fallback marked estimated"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__101__condition 
                    = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                        | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                             & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                            & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                           | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                              & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                                 & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                        & ((((0xa4U 
                                              <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                             & (0xa7U 
                                                >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                            | (((0xaaU 
                                                 <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                                & (0xafU 
                                                   >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                               | ((0x6cU 
                                                   <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                                  & (0x6fU 
                                                     >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                           & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                    | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__101__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__101__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
            }
            if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
                 & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                          | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                    ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                             : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                 ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                 : 0U)))
                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                    ? 2U : 0U))))) {
                if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                               ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                         | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                   ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                : 0U)))
                               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                   ? 2U : 0U))))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                                   & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                       ? 
                                                                      ((1U 
                                                                        & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                           | (2U 
                                                                              == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                        ? 0U
                                                                        : 
                                                                       ((1U 
                                                                         == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                         : 
                                                                        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                          ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                          : 0U)))
                                                                       : 
                                                                      ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                        ? 2U
                                                                        : 0U)))] 
                        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                            ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                         ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                             ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                             : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                 ? 
                                                (0xffU 
                                                 & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                 : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                            : 0U);
                }
                if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                               | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                              | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                  ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                      ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                      : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                                  : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                     | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                                   | (0xffeU 
                                                                      & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                          ? 
                                                                         ((1U 
                                                                           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                              | (2U 
                                                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                           ? 0U
                                                                           : 
                                                                          ((1U 
                                                                            == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                            : 
                                                                           ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                             : 0U)))
                                                                          : 
                                                                         ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                           ? 2U
                                                                           : 0U))))] 
                        = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                      ? (0xffffU & 
                                         ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                           ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                               ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                      : 0U) >> 8U));
                }
            }
        }
        vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
        co_await vlSelf->__VdlySched.delay(0x1388ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                           46);
        vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                           46);
        vlSelf->spk286_profile_prefix_tb__DOT__edges 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
        if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__102__message = 
                std::string{"original functional engine accepts probe"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__102__condition 
                = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                           & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                          & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                         & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__102__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__102__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
        }
        spk286_profile_prefix_tb__DOT__timeout_count 
            = ((IData)(1U) + spk286_profile_prefix_tb__DOT__timeout_count);
    }
    __Vtask_spk286_profile_prefix_tb__DOT__check__103__message = 
        std::string{"probe retirement and passive budget coverage"};
    __Vtask_spk286_profile_prefix_tb__DOT__check__103__condition 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_normal_retired_q) 
            | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_software) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__event_completed))) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked));
    vlSelf->spk286_profile_prefix_tb__DOT__checks = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__103__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__103__message),
                  32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                  4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                  32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                  10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                  32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                  8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
    }
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = 0U;
    VL_WRITEF("PROFILE_PREFIX_CASE case%0d prefix%0d budget%0d estimated%0d\n",
              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
    vlSelf->spk286_profile_prefix_tb__DOT__case_id 
        = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__case_id);
    __Vtask_spk286_profile_prefix_tb__DOT__setup__104__estimated = 1U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__104__budget = 0xbU;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__104__prefix_count = 2U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__104__length = 3U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__104__code = 0xa4f32eULL;
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__reset = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__flags_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__checked = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__expected_count 
        = __Vtask_spk286_profile_prefix_tb__DOT__setup__104__prefix_count;
    vlSelf->spk286_profile_prefix_tb__DOT__expected_budget 
        = __Vtask_spk286_profile_prefix_tb__DOT__setup__104__budget;
    vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated 
        = __Vtask_spk286_profile_prefix_tb__DOT__setup__104__estimated;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__104__unnamedblk1__DOT__i = 0U;
    while (VL_GTS_III(32, 0x1000U, __Vtask_spk286_profile_prefix_tb__DOT__setup__104__unnamedblk1__DOT__i)) {
        vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                       & __Vtask_spk286_profile_prefix_tb__DOT__setup__104__unnamedblk1__DOT__i)] = 0xf4U;
        __Vtask_spk286_profile_prefix_tb__DOT__setup__104__unnamedblk1__DOT__i 
            = ((IData)(1U) + __Vtask_spk286_profile_prefix_tb__DOT__setup__104__unnamedblk1__DOT__i);
    }
    __Vtask_spk286_profile_prefix_tb__DOT__setup__104__unnamedblk2__DOT__i = 0U;
    while (VL_LTS_III(32, __Vtask_spk286_profile_prefix_tb__DOT__setup__104__unnamedblk2__DOT__i, __Vtask_spk286_profile_prefix_tb__DOT__setup__104__length)) {
        vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                       & ((IData)(0x100U) 
                                                          + __Vtask_spk286_profile_prefix_tb__DOT__setup__104__unnamedblk2__DOT__i))] 
            = (0xffU & (IData)((__Vtask_spk286_profile_prefix_tb__DOT__setup__104__code 
                                >> (0x3fU & VL_MULS_III(32, (IData)(8U), __Vtask_spk286_profile_prefix_tb__DOT__setup__104__unnamedblk2__DOT__i)))));
        __Vtask_spk286_profile_prefix_tb__DOT__setup__104__unnamedblk2__DOT__i 
            = ((IData)(1U) + __Vtask_spk286_profile_prefix_tb__DOT__setup__104__unnamedblk2__DOT__i);
    }
    vlSelf->spk286_profile_prefix_tb__DOT__memory[0x300U] = 0x5aU;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__106__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__106__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__106__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__106__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__107__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__107__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__107__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__107__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__108__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__108__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__108__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__108__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__109__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__109__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__109__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__109__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__110__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__110__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__110__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__110__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__reset = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__message = 
                std::string{"actual prefix aggregation count"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__message = 
                std::string{"accepted prefix count oracle"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__message = 
                std::string{"extra native fallback marked estimated"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__message = 
            std::string{"original functional engine accepts probe"};
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__message = 
                std::string{"actual prefix aggregation count"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__message = 
                std::string{"accepted prefix count oracle"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__message = 
                std::string{"extra native fallback marked estimated"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__message = 
            std::string{"original functional engine accepts probe"};
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 2U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__message = 
                std::string{"actual prefix aggregation count"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__message = 
                std::string{"accepted prefix count oracle"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__message = 
                std::string{"extra native fallback marked estimated"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__message = 
            std::string{"original functional engine accepts probe"};
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 3U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__message = 
                std::string{"actual prefix aggregation count"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__message = 
                std::string{"accepted prefix count oracle"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__message = 
                std::string{"extra native fallback marked estimated"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__message = 
            std::string{"original functional engine accepts probe"};
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 4U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__message = 
                std::string{"actual prefix aggregation count"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__message = 
                std::string{"accepted prefix count oracle"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__message = 
                std::string{"extra native fallback marked estimated"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__message = 
            std::string{"original functional engine accepts probe"};
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 5U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
}
