// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vspk286_profile_prefix_tb.h for the primary calling header

#include "Vspk286_profile_prefix_tb__pch.h"
#include "Vspk286_profile_prefix_tb__Syms.h"
#include "Vspk286_profile_prefix_tb___024root.h"

VlCoroutine Vspk286_profile_prefix_tb___024root___eval_initial__TOP__Vtiming__0__2(Vspk286_profile_prefix_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_profile_prefix_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_profile_prefix_tb___024root___eval_initial__TOP__Vtiming__0__2\n"); );
    // Init
    IData/*31:0*/ spk286_profile_prefix_tb__DOT__timeout_count;
    spk286_profile_prefix_tb__DOT__timeout_count = 0;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__118__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__118__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__118__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__119__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__119__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__119__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__120__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__120__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__120__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__121__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__121__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__121__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__122__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__122__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__122__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__124__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__124__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__124__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__125__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__125__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__125__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__126__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__126__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__126__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__127__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__127__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__127__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__128__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__128__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__128__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__129__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__129__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__129__message;
    QData/*63:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__130__code;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__130__code = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__130__length;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__130__length = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__130__prefix_count;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__130__prefix_count = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__130__budget;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__130__budget = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__130__estimated;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__130__estimated = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__130__unnamedblk1__DOT__i;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__130__unnamedblk1__DOT__i = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__130__unnamedblk2__DOT__i;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__130__unnamedblk2__DOT__i = 0;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__132__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__132__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__132__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__133__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__133__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__133__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__134__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__134__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__134__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__135__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__135__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__135__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__136__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__136__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__136__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__138__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__138__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__138__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__139__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__139__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__139__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__140__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__140__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__140__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__141__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__141__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__141__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__142__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__142__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__142__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__144__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__144__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__144__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__145__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__145__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__145__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__146__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__146__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__146__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__147__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__147__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__147__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__148__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__148__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__148__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__150__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__150__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__150__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__151__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__151__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__151__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__152__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__152__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__152__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__153__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__153__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__153__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__154__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__154__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__154__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__155__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__155__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__155__message;
    QData/*63:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__156__code;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__156__code = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__156__length;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__156__length = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__156__prefix_count;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__156__prefix_count = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__156__budget;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__156__budget = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__156__estimated;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__156__estimated = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__156__unnamedblk1__DOT__i;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__156__unnamedblk1__DOT__i = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__156__unnamedblk2__DOT__i;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__156__unnamedblk2__DOT__i = 0;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__158__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__158__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__158__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__159__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__159__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__159__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__160__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__160__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__160__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__161__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__161__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__161__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__162__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__162__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__162__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__164__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__164__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__164__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__165__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__165__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__165__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__166__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__166__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__166__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__167__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__167__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__167__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__168__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__168__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__168__message;
    // Body
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__message = 
                std::string{"actual prefix aggregation count"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__message = 
                std::string{"accepted prefix count oracle"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__message = 
                std::string{"extra native fallback marked estimated"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__message = 
            std::string{"original functional engine accepts probe"};
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 6U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0x300U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__message = 
                std::string{"actual prefix aggregation count"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__message = 
                std::string{"accepted prefix count oracle"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__message = 
                std::string{"extra native fallback marked estimated"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__message = 
            std::string{"original functional engine accepts probe"};
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 7U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0x400U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__message = 
                std::string{"actual prefix aggregation count"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__message = 
                std::string{"accepted prefix count oracle"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__message = 
                std::string{"extra native fallback marked estimated"};
            vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__message = 
            std::string{"original functional engine accepts probe"};
        vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__118__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__118__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__118__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__118__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__119__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__119__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__119__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__119__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__120__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__120__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__120__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__120__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__121__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__121__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__121__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__121__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__122__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__122__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__122__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__122__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__118__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__118__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__118__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__118__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__119__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__119__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__119__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__119__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__120__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__120__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__120__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__120__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__121__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__121__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__121__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__121__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__122__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__122__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__122__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__122__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 2U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__118__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__118__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__118__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__118__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__119__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__119__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__119__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__119__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__120__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__120__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__120__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__120__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__121__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__121__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__121__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__121__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__122__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__122__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__122__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__122__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 3U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__118__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__118__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__118__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__118__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__119__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__119__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__119__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__119__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__120__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__120__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__120__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__120__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__121__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__121__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__121__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__121__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__122__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__122__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__122__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__122__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = 1U;
    spk286_profile_prefix_tb__DOT__timeout_count = 0U;
    while (((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_normal_retired_q) 
                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_software) 
                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__event_completed)))) 
            & VL_GTS_III(32, 0x1388U, spk286_profile_prefix_tb__DOT__timeout_count))) {
        vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
            = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
        vlSelf->spk286_profile_prefix_tb__DOT__ready 
            = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
        vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__data_in 
                = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                    [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                       ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                 | (2U 
                                                    == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                           ? 0U : (
                                                   (1U 
                                                    == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                    : 
                                                   ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                     : 0U)))
                                       : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                           ? 2U : 0U))))] 
                    << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
                   [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                          | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                    ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                             : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                 ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                 : 0U)))
                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                    ? 2U : 0U)))]);
        }
        co_await vlSelf->__VdlySched.delay(0xfa0ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                           28);
        if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
            if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
                 & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                    & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
            }
            if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
                 & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
                __Vtask_spk286_profile_prefix_tb__DOT__check__124__message = 
                    std::string{"actual prefix aggregation count"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__124__condition 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__124__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__124__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                __Vtask_spk286_profile_prefix_tb__DOT__check__125__message = 
                    std::string{"accepted prefix count oracle"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__125__condition 
                    = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__125__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__125__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                __Vtask_spk286_profile_prefix_tb__DOT__check__126__message = 
                    std::string{"LOCK/REP/override aggregate instruction budget"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__126__condition 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__126__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__126__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                __Vtask_spk286_profile_prefix_tb__DOT__check__127__message = 
                    std::string{"extra native fallback marked estimated"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__127__condition 
                    = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                        | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                             & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                            & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                           | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                              & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                                 & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                        & ((((0xa4U 
                                              <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                             & (0xa7U 
                                                >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                            | (((0xaaU 
                                                 <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                                & (0xafU 
                                                   >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                               | ((0x6cU 
                                                   <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                                  & (0x6fU 
                                                     >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                           & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                    | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__127__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__127__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
            }
            if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
                 & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                          | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                    ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                             : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                 ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                 : 0U)))
                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                    ? 2U : 0U))))) {
                if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                               ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                         | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                   ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                : 0U)))
                               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                   ? 2U : 0U))))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                                   & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                       ? 
                                                                      ((1U 
                                                                        & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                           | (2U 
                                                                              == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                        ? 0U
                                                                        : 
                                                                       ((1U 
                                                                         == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                         : 
                                                                        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                          ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                          : 0U)))
                                                                       : 
                                                                      ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                        ? 2U
                                                                        : 0U)))] 
                        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                            ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                         ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                             ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                             : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                 ? 
                                                (0xffU 
                                                 & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                 : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                            : 0U);
                }
                if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                               | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                              | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                  ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                      ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                      : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                                  : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                     | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                                   | (0xffeU 
                                                                      & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                          ? 
                                                                         ((1U 
                                                                           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                              | (2U 
                                                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                           ? 0U
                                                                           : 
                                                                          ((1U 
                                                                            == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                            : 
                                                                           ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                             : 0U)))
                                                                          : 
                                                                         ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                           ? 2U
                                                                           : 0U))))] 
                        = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                      ? (0xffffU & 
                                         ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                           ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                               ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                      : 0U) >> 8U));
                }
            }
        }
        vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
        co_await vlSelf->__VdlySched.delay(0x1388ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                           46);
        vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                           46);
        vlSelf->spk286_profile_prefix_tb__DOT__edges 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
        if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__128__message = 
                std::string{"original functional engine accepts probe"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__128__condition 
                = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                           & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                          & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                         & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__128__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__128__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
        }
        spk286_profile_prefix_tb__DOT__timeout_count 
            = ((IData)(1U) + spk286_profile_prefix_tb__DOT__timeout_count);
    }
    __Vtask_spk286_profile_prefix_tb__DOT__check__129__message = 
        std::string{"probe retirement and passive budget coverage"};
    __Vtask_spk286_profile_prefix_tb__DOT__check__129__condition 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_normal_retired_q) 
            | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_software) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__event_completed))) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked));
    vlSelf->spk286_profile_prefix_tb__DOT__checks = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__129__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__129__message),
                  32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                  4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                  32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                  10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                  32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                  8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
    }
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = 0U;
    VL_WRITEF("PROFILE_PREFIX_CASE case%0d prefix%0d budget%0d estimated%0d\n",
              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
    vlSelf->spk286_profile_prefix_tb__DOT__case_id 
        = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__case_id);
    __Vtask_spk286_profile_prefix_tb__DOT__setup__130__estimated = 1U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__130__budget = 0xbU;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__130__prefix_count = 2U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__130__length = 4U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__130__code = 0xa4f32ef0ULL;
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__reset = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__flags_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__checked = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__expected_count 
        = __Vtask_spk286_profile_prefix_tb__DOT__setup__130__prefix_count;
    vlSelf->spk286_profile_prefix_tb__DOT__expected_budget 
        = __Vtask_spk286_profile_prefix_tb__DOT__setup__130__budget;
    vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated 
        = __Vtask_spk286_profile_prefix_tb__DOT__setup__130__estimated;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__130__unnamedblk1__DOT__i = 0U;
    while (VL_GTS_III(32, 0x1000U, __Vtask_spk286_profile_prefix_tb__DOT__setup__130__unnamedblk1__DOT__i)) {
        vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                       & __Vtask_spk286_profile_prefix_tb__DOT__setup__130__unnamedblk1__DOT__i)] = 0xf4U;
        __Vtask_spk286_profile_prefix_tb__DOT__setup__130__unnamedblk1__DOT__i 
            = ((IData)(1U) + __Vtask_spk286_profile_prefix_tb__DOT__setup__130__unnamedblk1__DOT__i);
    }
    __Vtask_spk286_profile_prefix_tb__DOT__setup__130__unnamedblk2__DOT__i = 0U;
    while (VL_LTS_III(32, __Vtask_spk286_profile_prefix_tb__DOT__setup__130__unnamedblk2__DOT__i, __Vtask_spk286_profile_prefix_tb__DOT__setup__130__length)) {
        vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                       & ((IData)(0x100U) 
                                                          + __Vtask_spk286_profile_prefix_tb__DOT__setup__130__unnamedblk2__DOT__i))] 
            = (0xffU & (IData)((__Vtask_spk286_profile_prefix_tb__DOT__setup__130__code 
                                >> (0x3fU & VL_MULS_III(32, (IData)(8U), __Vtask_spk286_profile_prefix_tb__DOT__setup__130__unnamedblk2__DOT__i)))));
        __Vtask_spk286_profile_prefix_tb__DOT__setup__130__unnamedblk2__DOT__i 
            = ((IData)(1U) + __Vtask_spk286_profile_prefix_tb__DOT__setup__130__unnamedblk2__DOT__i);
    }
    vlSelf->spk286_profile_prefix_tb__DOT__memory[0x300U] = 0x5aU;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__132__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__132__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__132__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__132__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__133__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__133__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__133__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__133__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__134__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__134__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__134__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__134__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__135__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__135__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__135__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__135__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__136__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__136__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__136__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__136__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__reset = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__138__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__138__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__138__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__138__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__139__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__139__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__139__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__139__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__140__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__140__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__140__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__140__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__141__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__141__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__141__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__141__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__142__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__142__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__142__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__142__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__138__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__138__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__138__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__138__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__139__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__139__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__139__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__139__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__140__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__140__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__140__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__140__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__141__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__141__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__141__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__141__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__142__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__142__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__142__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__142__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 2U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__138__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__138__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__138__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__138__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__139__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__139__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__139__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__139__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__140__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__140__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__140__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__140__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__141__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__141__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__141__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__141__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__142__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__142__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__142__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__142__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 3U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__138__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__138__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__138__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__138__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__139__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__139__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__139__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__139__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__140__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__140__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__140__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__140__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__141__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__141__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__141__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__141__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__142__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__142__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__142__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__142__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 4U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__138__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__138__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__138__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__138__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__139__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__139__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__139__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__139__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__140__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__140__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__140__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__140__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__141__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__141__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__141__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__141__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__142__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__142__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__142__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__142__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 5U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__138__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__138__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__138__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__138__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__139__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__139__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__139__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__139__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__140__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__140__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__140__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__140__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__141__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__141__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__141__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__141__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__142__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__142__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__142__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__142__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 6U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0x300U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__138__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__138__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__138__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__138__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__139__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__139__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__139__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__139__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__140__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__140__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__140__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__140__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__141__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__141__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__141__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__141__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__142__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__142__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__142__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__142__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 7U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0x400U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__138__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__138__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__138__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__138__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__139__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__139__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__139__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__139__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__140__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__140__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__140__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__140__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__141__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__141__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__141__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__141__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__142__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__142__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__142__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__142__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__144__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__144__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__144__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__144__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__145__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__145__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__145__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__145__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__146__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__146__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__146__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__146__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__147__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__147__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__147__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__147__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__148__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__148__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__148__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__148__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__144__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__144__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__144__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__144__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__145__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__145__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__145__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__145__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__146__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__146__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__146__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__146__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__147__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__147__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__147__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__147__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__148__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__148__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__148__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__148__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 2U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__144__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__144__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__144__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__144__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__145__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__145__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__145__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__145__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__146__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__146__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__146__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__146__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__147__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__147__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__147__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__147__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__148__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__148__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__148__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__148__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 3U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__144__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__144__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__144__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__144__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__145__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__145__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__145__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__145__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__146__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__146__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__146__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__146__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__147__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__147__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__147__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__147__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__148__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__148__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__148__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__148__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = 1U;
    spk286_profile_prefix_tb__DOT__timeout_count = 0U;
    while (((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_normal_retired_q) 
                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_software) 
                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__event_completed)))) 
            & VL_GTS_III(32, 0x1388U, spk286_profile_prefix_tb__DOT__timeout_count))) {
        vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
            = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
        vlSelf->spk286_profile_prefix_tb__DOT__ready 
            = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
        vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__data_in 
                = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                    [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                       ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                 | (2U 
                                                    == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                           ? 0U : (
                                                   (1U 
                                                    == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                    : 
                                                   ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                     : 0U)))
                                       : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                           ? 2U : 0U))))] 
                    << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
                   [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                          | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                    ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                             : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                 ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                 : 0U)))
                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                    ? 2U : 0U)))]);
        }
        co_await vlSelf->__VdlySched.delay(0xfa0ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                           28);
        if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
            if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
                 & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                    & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
            }
            if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
                 & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
                __Vtask_spk286_profile_prefix_tb__DOT__check__150__message = 
                    std::string{"actual prefix aggregation count"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__150__condition 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__150__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__150__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                __Vtask_spk286_profile_prefix_tb__DOT__check__151__message = 
                    std::string{"accepted prefix count oracle"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__151__condition 
                    = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__151__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__151__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                __Vtask_spk286_profile_prefix_tb__DOT__check__152__message = 
                    std::string{"LOCK/REP/override aggregate instruction budget"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__152__condition 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__152__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__152__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                __Vtask_spk286_profile_prefix_tb__DOT__check__153__message = 
                    std::string{"extra native fallback marked estimated"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__153__condition 
                    = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                        | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                             & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                            & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                           | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                              & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                                 & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                        & ((((0xa4U 
                                              <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                             & (0xa7U 
                                                >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                            | (((0xaaU 
                                                 <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                                & (0xafU 
                                                   >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                               | ((0x6cU 
                                                   <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                                  & (0x6fU 
                                                     >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                           & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                    | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__153__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__153__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
            }
            if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
                 & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                          | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                    ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                             : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                 ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                 : 0U)))
                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                    ? 2U : 0U))))) {
                if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                               ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                         | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                   ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                : 0U)))
                               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                   ? 2U : 0U))))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                                   & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                       ? 
                                                                      ((1U 
                                                                        & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                           | (2U 
                                                                              == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                        ? 0U
                                                                        : 
                                                                       ((1U 
                                                                         == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                         : 
                                                                        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                          ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                          : 0U)))
                                                                       : 
                                                                      ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                        ? 2U
                                                                        : 0U)))] 
                        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                            ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                         ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                             ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                             : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                 ? 
                                                (0xffU 
                                                 & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                 : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                            : 0U);
                }
                if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                               | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                              | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                  ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                      ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                      : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                                  : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                     | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                                   | (0xffeU 
                                                                      & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                          ? 
                                                                         ((1U 
                                                                           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                              | (2U 
                                                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                           ? 0U
                                                                           : 
                                                                          ((1U 
                                                                            == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                            : 
                                                                           ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                             : 0U)))
                                                                          : 
                                                                         ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                           ? 2U
                                                                           : 0U))))] 
                        = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                      ? (0xffffU & 
                                         ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                           ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                               ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                      : 0U) >> 8U));
                }
            }
        }
        vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
        co_await vlSelf->__VdlySched.delay(0x1388ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                           46);
        vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                           46);
        vlSelf->spk286_profile_prefix_tb__DOT__edges 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
        if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__154__message = 
                std::string{"original functional engine accepts probe"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__154__condition 
                = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                           & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                          & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                         & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__154__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__154__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
        }
        spk286_profile_prefix_tb__DOT__timeout_count 
            = ((IData)(1U) + spk286_profile_prefix_tb__DOT__timeout_count);
    }
    __Vtask_spk286_profile_prefix_tb__DOT__check__155__message = 
        std::string{"probe retirement and passive budget coverage"};
    __Vtask_spk286_profile_prefix_tb__DOT__check__155__condition 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_normal_retired_q) 
            | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_software) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__event_completed))) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked));
    vlSelf->spk286_profile_prefix_tb__DOT__checks = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__155__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__155__message),
                  32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                  4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                  32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                  10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                  32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                  8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
    }
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = 0U;
    VL_WRITEF("PROFILE_PREFIX_CASE case%0d prefix%0d budget%0d estimated%0d\n",
              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
    vlSelf->spk286_profile_prefix_tb__DOT__case_id 
        = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__case_id);
    __Vtask_spk286_profile_prefix_tb__DOT__setup__156__estimated = 1U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__156__budget = 0xbU;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__156__prefix_count = 2U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__156__length = 3U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__156__code = 0xa4f3f3ULL;
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__reset = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__flags_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__checked = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__expected_count 
        = __Vtask_spk286_profile_prefix_tb__DOT__setup__156__prefix_count;
    vlSelf->spk286_profile_prefix_tb__DOT__expected_budget 
        = __Vtask_spk286_profile_prefix_tb__DOT__setup__156__budget;
    vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated 
        = __Vtask_spk286_profile_prefix_tb__DOT__setup__156__estimated;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__156__unnamedblk1__DOT__i = 0U;
    while (VL_GTS_III(32, 0x1000U, __Vtask_spk286_profile_prefix_tb__DOT__setup__156__unnamedblk1__DOT__i)) {
        vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                       & __Vtask_spk286_profile_prefix_tb__DOT__setup__156__unnamedblk1__DOT__i)] = 0xf4U;
        __Vtask_spk286_profile_prefix_tb__DOT__setup__156__unnamedblk1__DOT__i 
            = ((IData)(1U) + __Vtask_spk286_profile_prefix_tb__DOT__setup__156__unnamedblk1__DOT__i);
    }
    __Vtask_spk286_profile_prefix_tb__DOT__setup__156__unnamedblk2__DOT__i = 0U;
    while (VL_LTS_III(32, __Vtask_spk286_profile_prefix_tb__DOT__setup__156__unnamedblk2__DOT__i, __Vtask_spk286_profile_prefix_tb__DOT__setup__156__length)) {
        vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                       & ((IData)(0x100U) 
                                                          + __Vtask_spk286_profile_prefix_tb__DOT__setup__156__unnamedblk2__DOT__i))] 
            = (0xffU & (IData)((__Vtask_spk286_profile_prefix_tb__DOT__setup__156__code 
                                >> (0x3fU & VL_MULS_III(32, (IData)(8U), __Vtask_spk286_profile_prefix_tb__DOT__setup__156__unnamedblk2__DOT__i)))));
        __Vtask_spk286_profile_prefix_tb__DOT__setup__156__unnamedblk2__DOT__i 
            = ((IData)(1U) + __Vtask_spk286_profile_prefix_tb__DOT__setup__156__unnamedblk2__DOT__i);
    }
    vlSelf->spk286_profile_prefix_tb__DOT__memory[0x300U] = 0x5aU;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__158__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__158__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__158__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__158__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__159__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__159__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__159__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__159__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__160__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__160__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__160__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__160__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__161__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__161__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__161__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__161__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__162__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__162__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__162__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__162__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__reset = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__164__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__164__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__164__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__164__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__165__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__165__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__165__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__165__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__166__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__166__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__166__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__166__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__167__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__167__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__167__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__167__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__168__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__168__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__168__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__168__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__164__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__164__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__164__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__164__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__165__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__165__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__165__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__165__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__166__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__166__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__166__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__166__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__167__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__167__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__167__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__167__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__168__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__168__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__168__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__168__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 2U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__164__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__164__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__164__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__164__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__165__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__165__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__165__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__165__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__166__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__166__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__166__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__166__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__167__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__167__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__167__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__167__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__168__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__168__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__168__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__168__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 3U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__164__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__164__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__164__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__164__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__165__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__165__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__165__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__165__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__166__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__166__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__166__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__166__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__167__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__167__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__167__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__167__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__168__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__168__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__168__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__168__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 4U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__164__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__164__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__164__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__164__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__165__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__165__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__165__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__165__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__166__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__166__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__166__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__166__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__167__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__167__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__167__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__167__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__168__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__168__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__168__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__168__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 5U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__164__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__164__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__164__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__164__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__165__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__165__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__165__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__165__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__166__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__166__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__166__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__166__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__167__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__167__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__167__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__167__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__168__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__168__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__168__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__168__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 6U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0x300U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__164__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__164__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__164__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__164__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__165__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__165__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__165__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__165__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__166__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__166__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__166__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__166__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__167__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__167__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__167__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__167__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__168__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__168__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__168__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__168__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 7U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0x400U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__164__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__164__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__164__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__164__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__165__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__165__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__165__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__165__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__166__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__166__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__166__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__166__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__167__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__167__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__167__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__167__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__168__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__168__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__168__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__168__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
}
