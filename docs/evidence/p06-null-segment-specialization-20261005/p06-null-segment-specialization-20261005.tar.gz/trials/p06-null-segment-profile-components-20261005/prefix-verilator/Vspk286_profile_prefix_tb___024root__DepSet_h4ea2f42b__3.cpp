// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vspk286_profile_prefix_tb.h for the primary calling header

#include "Vspk286_profile_prefix_tb__pch.h"
#include "Vspk286_profile_prefix_tb__Syms.h"
#include "Vspk286_profile_prefix_tb___024root.h"

VlCoroutine Vspk286_profile_prefix_tb___024root___eval_initial__TOP__Vtiming__0__3(Vspk286_profile_prefix_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_profile_prefix_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_profile_prefix_tb___024root___eval_initial__TOP__Vtiming__0__3\n"); );
    // Init
    IData/*31:0*/ spk286_profile_prefix_tb__DOT__timeout_count;
    spk286_profile_prefix_tb__DOT__timeout_count = 0;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__170__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__170__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__170__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__171__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__171__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__171__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__172__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__172__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__172__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__173__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__173__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__173__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__174__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__174__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__174__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__176__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__176__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__176__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__177__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__177__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__177__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__178__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__178__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__178__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__179__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__179__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__179__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__180__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__180__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__180__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__181__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__181__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__181__message;
    QData/*63:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__182__code;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__182__code = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__182__length;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__182__length = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__182__prefix_count;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__182__prefix_count = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__182__budget;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__182__budget = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__182__estimated;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__182__estimated = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__182__unnamedblk1__DOT__i;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__182__unnamedblk1__DOT__i = 0;
    IData/*31:0*/ __Vtask_spk286_profile_prefix_tb__DOT__setup__182__unnamedblk2__DOT__i;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__182__unnamedblk2__DOT__i = 0;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__184__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__184__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__184__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__185__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__185__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__185__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__186__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__186__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__186__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__187__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__187__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__187__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__188__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__188__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__188__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__190__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__190__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__190__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__191__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__191__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__191__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__192__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__192__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__192__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__193__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__193__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__193__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__194__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__194__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__194__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__196__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__196__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__196__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__197__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__197__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__197__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__198__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__198__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__198__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__199__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__199__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__199__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__200__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__200__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__200__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__202__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__202__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__202__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__203__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__203__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__203__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__204__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__204__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__204__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__205__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__205__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__205__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__206__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__206__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__206__message;
    CData/*0:0*/ __Vtask_spk286_profile_prefix_tb__DOT__check__207__condition;
    __Vtask_spk286_profile_prefix_tb__DOT__check__207__condition = 0;
    std::string __Vtask_spk286_profile_prefix_tb__DOT__check__207__message;
    // Body
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__170__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__170__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__170__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__170__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__171__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__171__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__171__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__171__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__172__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__172__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__172__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__172__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__173__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__173__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__173__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__173__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__174__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__174__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__174__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__174__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__170__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__170__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__170__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__170__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__171__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__171__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__171__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__171__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__172__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__172__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__172__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__172__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__173__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__173__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__173__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__173__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__174__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__174__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__174__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__174__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 2U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__170__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__170__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__170__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__170__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__171__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__171__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__171__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__171__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__172__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__172__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__172__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__172__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__173__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__173__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__173__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__173__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__174__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__174__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__174__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__174__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 3U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__170__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__170__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__170__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__170__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__171__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__171__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__171__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__171__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__172__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__172__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__172__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__172__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__173__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__173__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__173__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__173__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__174__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__174__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__174__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__174__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = 1U;
    spk286_profile_prefix_tb__DOT__timeout_count = 0U;
    while (((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_normal_retired_q) 
                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_software) 
                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__event_completed)))) 
            & VL_GTS_III(32, 0x1388U, spk286_profile_prefix_tb__DOT__timeout_count))) {
        vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
            = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
        vlSelf->spk286_profile_prefix_tb__DOT__ready 
            = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
        vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__data_in 
                = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                    [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                       ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                 | (2U 
                                                    == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                           ? 0U : (
                                                   (1U 
                                                    == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                    : 
                                                   ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                     : 0U)))
                                       : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                           ? 2U : 0U))))] 
                    << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
                   [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                          | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                    ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                             : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                 ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                 : 0U)))
                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                    ? 2U : 0U)))]);
        }
        co_await vlSelf->__VdlySched.delay(0xfa0ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                           28);
        if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
            if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
                 & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                    & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
            }
            if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
                 & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
                __Vtask_spk286_profile_prefix_tb__DOT__check__176__message = 
                    std::string{"actual prefix aggregation count"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__176__condition 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__176__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__176__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                __Vtask_spk286_profile_prefix_tb__DOT__check__177__message = 
                    std::string{"accepted prefix count oracle"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__177__condition 
                    = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__177__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__177__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                __Vtask_spk286_profile_prefix_tb__DOT__check__178__message = 
                    std::string{"LOCK/REP/override aggregate instruction budget"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__178__condition 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__178__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__178__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                __Vtask_spk286_profile_prefix_tb__DOT__check__179__message = 
                    std::string{"extra native fallback marked estimated"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__179__condition 
                    = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                        | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                             & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                            & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                           | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                              & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                                 & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                        & ((((0xa4U 
                                              <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                             & (0xa7U 
                                                >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                            | (((0xaaU 
                                                 <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                                & (0xafU 
                                                   >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                               | ((0x6cU 
                                                   <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                                  & (0x6fU 
                                                     >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                           & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                    | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__179__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__179__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
            }
            if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
                 & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                          | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                    ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                             : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                 ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                 : 0U)))
                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                    ? 2U : 0U))))) {
                if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                               ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                         | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                   ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                : 0U)))
                               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                   ? 2U : 0U))))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                                   & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                       ? 
                                                                      ((1U 
                                                                        & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                           | (2U 
                                                                              == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                        ? 0U
                                                                        : 
                                                                       ((1U 
                                                                         == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                         : 
                                                                        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                          ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                          : 0U)))
                                                                       : 
                                                                      ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                        ? 2U
                                                                        : 0U)))] 
                        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                            ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                         ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                             ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                             : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                 ? 
                                                (0xffU 
                                                 & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                 : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                            : 0U);
                }
                if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                               | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                              | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                  ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                      ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                      : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                                  : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                     | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                                   | (0xffeU 
                                                                      & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                          ? 
                                                                         ((1U 
                                                                           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                              | (2U 
                                                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                           ? 0U
                                                                           : 
                                                                          ((1U 
                                                                            == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                            : 
                                                                           ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                             : 0U)))
                                                                          : 
                                                                         ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                           ? 2U
                                                                           : 0U))))] 
                        = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                      ? (0xffffU & 
                                         ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                           ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                               ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                      : 0U) >> 8U));
                }
            }
        }
        vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
        co_await vlSelf->__VdlySched.delay(0x1388ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                           46);
        vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                           46);
        vlSelf->spk286_profile_prefix_tb__DOT__edges 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
        if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__180__message = 
                std::string{"original functional engine accepts probe"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__180__condition 
                = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                           & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                          & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                         & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__180__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__180__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
        }
        spk286_profile_prefix_tb__DOT__timeout_count 
            = ((IData)(1U) + spk286_profile_prefix_tb__DOT__timeout_count);
    }
    __Vtask_spk286_profile_prefix_tb__DOT__check__181__message = 
        std::string{"probe retirement and passive budget coverage"};
    __Vtask_spk286_profile_prefix_tb__DOT__check__181__condition 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_normal_retired_q) 
            | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_software) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__event_completed))) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked));
    vlSelf->spk286_profile_prefix_tb__DOT__checks = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__181__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__181__message),
                  32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                  4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                  32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                  10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                  32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                  8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
    }
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = 0U;
    VL_WRITEF("PROFILE_PREFIX_CASE case%0d prefix%0d budget%0d estimated%0d\n",
              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
    vlSelf->spk286_profile_prefix_tb__DOT__case_id 
        = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__case_id);
    __Vtask_spk286_profile_prefix_tb__DOT__setup__182__estimated = 0U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__182__budget = 2U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__182__prefix_count = 0U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__182__length = 4U;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__182__code = 0xd801f0f0ULL;
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__reset = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__flags_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__checked = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__expected_count 
        = __Vtask_spk286_profile_prefix_tb__DOT__setup__182__prefix_count;
    vlSelf->spk286_profile_prefix_tb__DOT__expected_budget 
        = __Vtask_spk286_profile_prefix_tb__DOT__setup__182__budget;
    vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated 
        = __Vtask_spk286_profile_prefix_tb__DOT__setup__182__estimated;
    __Vtask_spk286_profile_prefix_tb__DOT__setup__182__unnamedblk1__DOT__i = 0U;
    while (VL_GTS_III(32, 0x1000U, __Vtask_spk286_profile_prefix_tb__DOT__setup__182__unnamedblk1__DOT__i)) {
        vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                       & __Vtask_spk286_profile_prefix_tb__DOT__setup__182__unnamedblk1__DOT__i)] = 0xf4U;
        __Vtask_spk286_profile_prefix_tb__DOT__setup__182__unnamedblk1__DOT__i 
            = ((IData)(1U) + __Vtask_spk286_profile_prefix_tb__DOT__setup__182__unnamedblk1__DOT__i);
    }
    __Vtask_spk286_profile_prefix_tb__DOT__setup__182__unnamedblk2__DOT__i = 0U;
    while (VL_LTS_III(32, __Vtask_spk286_profile_prefix_tb__DOT__setup__182__unnamedblk2__DOT__i, __Vtask_spk286_profile_prefix_tb__DOT__setup__182__length)) {
        vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                       & ((IData)(0x100U) 
                                                          + __Vtask_spk286_profile_prefix_tb__DOT__setup__182__unnamedblk2__DOT__i))] 
            = (0xffU & (IData)((__Vtask_spk286_profile_prefix_tb__DOT__setup__182__code 
                                >> (0x3fU & VL_MULS_III(32, (IData)(8U), __Vtask_spk286_profile_prefix_tb__DOT__setup__182__unnamedblk2__DOT__i)))));
        __Vtask_spk286_profile_prefix_tb__DOT__setup__182__unnamedblk2__DOT__i 
            = ((IData)(1U) + __Vtask_spk286_profile_prefix_tb__DOT__setup__182__unnamedblk2__DOT__i);
    }
    vlSelf->spk286_profile_prefix_tb__DOT__memory[0x300U] = 0x5aU;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__184__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__184__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__184__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__184__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__185__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__185__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__185__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__185__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__186__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__186__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__186__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__186__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__187__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__187__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__187__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__187__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__188__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__188__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__188__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__188__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__reset = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__190__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__190__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__190__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__190__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__191__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__191__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__191__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__191__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__192__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__192__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__192__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__192__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__193__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__193__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__193__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__193__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__194__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__194__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__194__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__194__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__190__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__190__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__190__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__190__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__191__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__191__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__191__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__191__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__192__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__192__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__192__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__192__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__193__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__193__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__193__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__193__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__194__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__194__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__194__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__194__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 2U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__190__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__190__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__190__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__190__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__191__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__191__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__191__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__191__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__192__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__192__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__192__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__192__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__193__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__193__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__193__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__193__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__194__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__194__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__194__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__194__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 3U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__190__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__190__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__190__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__190__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__191__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__191__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__191__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__191__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__192__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__192__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__192__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__192__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__193__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__193__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__193__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__193__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__194__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__194__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__194__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__194__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 4U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__190__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__190__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__190__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__190__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__191__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__191__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__191__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__191__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__192__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__192__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__192__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__192__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__193__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__193__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__193__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__193__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__194__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__194__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__194__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__194__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 5U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__190__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__190__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__190__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__190__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__191__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__191__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__191__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__191__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__192__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__192__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__192__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__192__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__193__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__193__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__193__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__193__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__194__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__194__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__194__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__194__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 6U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0x300U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__190__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__190__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__190__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__190__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__191__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__191__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__191__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__191__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__192__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__192__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__192__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__192__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__193__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__193__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__193__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__193__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__194__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__194__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__194__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__194__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = 7U;
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = 0x400U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__190__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__190__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__190__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__190__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__191__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__191__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__191__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__191__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__192__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__192__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__192__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__192__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__193__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__193__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__193__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__193__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__194__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__194__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__194__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__194__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__196__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__196__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__196__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__196__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__197__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__197__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__197__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__197__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__198__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__198__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__198__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__198__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__199__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__199__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__199__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__199__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__200__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__200__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__200__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__200__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__196__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__196__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__196__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__196__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__197__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__197__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__197__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__197__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__198__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__198__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__198__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__198__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__199__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__199__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__199__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__199__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__200__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__200__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__200__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__200__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 2U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__196__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__196__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__196__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__196__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__197__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__197__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__197__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__197__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__198__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__198__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__198__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__198__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__199__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__199__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__199__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__199__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__200__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__200__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__200__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__200__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 1U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = 3U;
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = 0x100U;
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
        = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
    vlSelf->spk286_profile_prefix_tb__DOT__ready = 
        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
         & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                        ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                  | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                            ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                         : 0U))) : 
                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                         ? 2U : 0U))))) {
        vlSelf->spk286_profile_prefix_tb__DOT__data_in 
            = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                   ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                             | (2U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                       ? 0U : ((1U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                    : 0U)))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                       ? 2U : 0U))))] 
                << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
               [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U)))]);
    }
    co_await vlSelf->__VdlySched.delay(0xfa0ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       28);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
             & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
        }
        if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__196__message = 
                std::string{"actual prefix aggregation count"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__196__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__196__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__196__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__197__message = 
                std::string{"accepted prefix count oracle"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__197__condition 
                = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__197__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__197__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__198__message = 
                std::string{"LOCK/REP/override aggregate instruction budget"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__198__condition 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__198__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__198__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            __Vtask_spk286_profile_prefix_tb__DOT__check__199__message = 
                std::string{"extra native fallback marked estimated"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__199__condition 
                = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                    | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                       | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                          & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                             & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                    & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                        | (((0xaaU 
                                             <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                            & (0xafU 
                                               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                           | ((0x6cU 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                              & (0x6fU 
                                                 >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                       & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                   == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__199__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__199__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
            vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
        }
        if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                           ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                     | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                               ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                        : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                            : 0U)))
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                               ? 2U : 0U))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                   ? 
                                                                  ((1U 
                                                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                       | (2U 
                                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                    ? 0U
                                                                    : 
                                                                   ((1U 
                                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                     : 
                                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                      ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                      : 0U)))
                                                                   : 
                                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                    ? 2U
                                                                    : 0U)))] 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                        ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                     ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                         ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                             ? (0xffU 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                        : 0U);
            }
            if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                           | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                          | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                              ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                  ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                              : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                               | (0xffeU 
                                                                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                      ? 
                                                                     ((1U 
                                                                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                          | (2U 
                                                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                       ? 0U
                                                                       : 
                                                                      ((1U 
                                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                        : 
                                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                         : 0U)))
                                                                      : 
                                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                       ? 2U
                                                                       : 0U))))] 
                    = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                  ? (0xffffU & ((1U 
                                                 & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                                 ? 
                                                VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                 : 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                                  ? 
                                                 VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                  : 0U) >> 8U));
            }
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
    co_await vlSelf->__VdlySched.delay(0x1388ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                       46);
    vlSelf->spk286_profile_prefix_tb__DOT__edges = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        __Vtask_spk286_profile_prefix_tb__DOT__check__200__message = 
            std::string{"original functional engine accepts probe"};
        __Vtask_spk286_profile_prefix_tb__DOT__check__200__condition 
            = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                     & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
        vlSelf->spk286_profile_prefix_tb__DOT__checks 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
        if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__200__condition))))) {
            VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                      64,VL_TIME_UNITED_Q(1000),-9,
                      vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__200__message),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                      4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                      10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                      32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                      8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
            VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = 1U;
    spk286_profile_prefix_tb__DOT__timeout_count = 0U;
    while (((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_normal_retired_q) 
                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_software) 
                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__event_completed)))) 
            & VL_GTS_III(32, 0x1388U, spk286_profile_prefix_tb__DOT__timeout_count))) {
        vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary 
            = (0U == VL_MODDIVS_III(32, vlSelf->spk286_profile_prefix_tb__DOT__edges, (IData)(8U)));
        vlSelf->spk286_profile_prefix_tb__DOT__ready 
            = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid));
        vlSelf->spk286_profile_prefix_tb__DOT__data_in = 0xf4f4U;
        if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
             & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                            ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                      | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                             : 0U)))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                ? 2U : 0U))))) {
            vlSelf->spk286_profile_prefix_tb__DOT__data_in 
                = ((vlSelf->spk286_profile_prefix_tb__DOT__memory
                    [(1U | (0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                       ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                 | (2U 
                                                    == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                           ? 0U : (
                                                   (1U 
                                                    == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                    ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                    : 
                                                   ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                     : 0U)))
                                       : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                           ? 2U : 0U))))] 
                    << 8U) | vlSelf->spk286_profile_prefix_tb__DOT__memory
                   [(0xffeU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                          | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                    ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                             : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                 ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                 : 0U)))
                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                    ? 2U : 0U)))]);
        }
        co_await vlSelf->__VdlySched.delay(0xfa0ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                           28);
        if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
            if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
                 & ((0xfU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                    & (0xf0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes);
            }
            if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid)) 
                 & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked)))) {
                __Vtask_spk286_profile_prefix_tb__DOT__check__202__message = 
                    std::string{"actual prefix aggregation count"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__202__condition 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q) 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__202__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__202__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                __Vtask_spk286_profile_prefix_tb__DOT__check__203__message = 
                    std::string{"accepted prefix count oracle"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__203__condition 
                    = (vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_count);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__203__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__203__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                __Vtask_spk286_profile_prefix_tb__DOT__check__204__message = 
                    std::string{"LOCK/REP/override aggregate instruction budget"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__204__condition 
                    = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks) 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_budget);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__204__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__204__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                __Vtask_spk286_profile_prefix_tb__DOT__check__205__message = 
                    std::string{"extra native fallback marked estimated"};
                __Vtask_spk286_profile_prefix_tb__DOT__check__205__condition 
                    = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated) 
                        | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q) 
                             & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                            & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q)) 
                           | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)) 
                              & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q)) 
                                 & ((~ ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
                                        & ((((0xa4U 
                                              <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                             & (0xa7U 
                                                >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                            | (((0xaaU 
                                                 <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                                & (0xafU 
                                                   >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                                               | ((0x6cU 
                                                   <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                                  & (0x6fU 
                                                     >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
                                           & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) 
                                    | (1U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q))))))) 
                       == vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
                vlSelf->spk286_profile_prefix_tb__DOT__checks 
                    = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
                if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__205__condition))))) {
                    VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                              64,VL_TIME_UNITED_Q(1000),
                              -9,vlSymsp->name(),-1,
                              &(__Vtask_spk286_profile_prefix_tb__DOT__check__205__message),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                              4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                              10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                              8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                    VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
                }
                vlSelf->spk286_profile_prefix_tb__DOT__checked = 1U;
            }
            if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready)) 
                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)) 
                 & (0x1000U > ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                          | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                    ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                             : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                 ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                 : 0U)))
                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                    ? 2U : 0U))))) {
                if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                               ? ((1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                         | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                   ? 0U : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                : 0U)))
                               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                   ? 2U : 0U))))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__memory[(0xfffU 
                                                                   & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                       ? 
                                                                      ((1U 
                                                                        & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                           | (2U 
                                                                              == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                        ? 0U
                                                                        : 
                                                                       ((1U 
                                                                         == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                         ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                         : 
                                                                        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                          ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                          : 0U)))
                                                                       : 
                                                                      ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                        ? 2U
                                                                        : 0U)))] 
                        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                            ? (0xffU & ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                         ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                             ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                             : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                 ? 
                                                (0xffU 
                                                 & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                 : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                            : 0U);
                }
                if ((1U & (~ (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                               | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))) 
                              | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                  ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                      ? (~ vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                      : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q))
                                  : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                     | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q))))))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__memory[(1U 
                                                                   | (0xffeU 
                                                                      & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)
                                                                          ? 
                                                                         ((1U 
                                                                           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid)) 
                                                                              | (2U 
                                                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))))
                                                                           ? 0U
                                                                           : 
                                                                          ((1U 
                                                                            == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                                                                            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q
                                                                            : 
                                                                           ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                                             ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q
                                                                             : 0U)))
                                                                          : 
                                                                         ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)
                                                                           ? 2U
                                                                           : 0U))))] 
                        = (0xffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__data_oe)
                                      ? (0xffffU & 
                                         ((1U & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q)
                                           ? VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q)
                                               ? VL_SHIFTR_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q), 8U)
                                               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q)
                                                   ? 
                                                  (0xffU 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q)))))
                                      : 0U) >> 8U));
                }
            }
        }
        vlSelf->spk286_profile_prefix_tb__DOT__clk = 1U;
        co_await vlSelf->__VdlySched.delay(0x1388ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                           46);
        vlSelf->spk286_profile_prefix_tb__DOT__clk = 0U;
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 
                                           46);
        vlSelf->spk286_profile_prefix_tb__DOT__edges 
            = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__edges);
        if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
            __Vtask_spk286_profile_prefix_tb__DOT__check__206__message = 
                std::string{"original functional engine accepts probe"};
            __Vtask_spk286_profile_prefix_tb__DOT__check__206__condition 
                = (1U & ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                           & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))) 
                          & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown))) 
                         & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error))));
            vlSelf->spk286_profile_prefix_tb__DOT__checks 
                = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
            if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__206__condition))))) {
                VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                          64,VL_TIME_UNITED_Q(1000),
                          -9,vlSymsp->name(),-1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__206__message),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                          4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                          10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                          32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                          8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
                VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
            }
        }
        spk286_profile_prefix_tb__DOT__timeout_count 
            = ((IData)(1U) + spk286_profile_prefix_tb__DOT__timeout_count);
    }
    __Vtask_spk286_profile_prefix_tb__DOT__check__207__message = 
        std::string{"probe retirement and passive budget coverage"};
    __Vtask_spk286_profile_prefix_tb__DOT__check__207__condition 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_normal_retired_q) 
            | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_software) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__event_completed))) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__checked));
    vlSelf->spk286_profile_prefix_tb__DOT__checks = 
        ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__checks);
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_profile_prefix_tb__DOT__check__207__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_profile_prefix_tb.sv:17: Assertion failed in %Nspk286_profile_prefix_tb.check: %@ case%0d count%0#/%0d budget%0#/%0d opcode%x\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_profile_prefix_tb__DOT__check__207__message),
                  32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
                  4,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q),
                  32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
                  10,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks),
                  32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
                  8,(IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 17, "");
    }
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = 0U;
    VL_WRITEF("PROFILE_PREFIX_CASE case%0d prefix%0d budget%0d estimated%0d\n",
              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_count,
              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_budget,
              32,vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated);
    vlSelf->spk286_profile_prefix_tb__DOT__case_id 
        = ((IData)(1U) + vlSelf->spk286_profile_prefix_tb__DOT__case_id);
    VL_WRITEF("PROFILE_PREFIX_PASS cases%0d checks%0d\n",
              32,vlSelf->spk286_profile_prefix_tb__DOT__case_id,
              32,vlSelf->spk286_profile_prefix_tb__DOT__checks);
    VL_FINISH_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 95, "");
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vspk286_profile_prefix_tb___024root___dump_triggers__act(Vspk286_profile_prefix_tb___024root* vlSelf);
#endif  // VL_DEBUG

void Vspk286_profile_prefix_tb___024root___eval_triggers__act(Vspk286_profile_prefix_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_profile_prefix_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_profile_prefix_tb___024root___eval_triggers__act\n"); );
    // Body
    vlSelf->__VactTriggered.set(0U, ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__clk) 
                                     & (~ (IData)(vlSelf->__Vtrigprevexpr___TOP__spk286_profile_prefix_tb__DOT__clk__0))));
    vlSelf->__VactTriggered.set(1U, vlSelf->__VdlySched.awaitingCurrentTime());
    vlSelf->__Vtrigprevexpr___TOP__spk286_profile_prefix_tb__DOT__clk__0 
        = vlSelf->spk286_profile_prefix_tb__DOT__clk;
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vspk286_profile_prefix_tb___024root___dump_triggers__act(vlSelf);
    }
#endif
}
