// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vspk286_profile_prefix_tb.h for the primary calling header

#include "Vspk286_profile_prefix_tb__pch.h"
#include "Vspk286_profile_prefix_tb___024root.h"

VL_ATTR_COLD void Vspk286_profile_prefix_tb___024root___stl_sequent__TOP__2(Vspk286_profile_prefix_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_profile_prefix_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_profile_prefix_tb___024root___stl_sequent__TOP__2\n"); );
    // Init
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_ready;
    spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_ready = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__fault_request;
    spk286_profile_prefix_tb__DOT__dut__DOT__fault_request = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__system_fault;
    spk286_profile_prefix_tb__DOT__dut__DOT__system_fault = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_ha5f0a04c__0;
    spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_ha5f0a04c__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_he61ed21f__0;
    spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_he61ed21f__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_pop_sp_commit;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_pop_sp_commit = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_post_fault;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_post_fault = 0;
    SData/*15:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__sequential_gpr_write_data;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__sequential_gpr_write_data = 0;
    IData/*19:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_onehot;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_onehot = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h2f04017f__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h2f04017f__0 = 0;
    IData/*17:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hfe63c0ca__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hfe63c0ca__0 = 0;
    IData/*16:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0cf40e08__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0cf40e08__0 = 0;
    SData/*15:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h1b07fba1__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h1b07fba1__0 = 0;
    SData/*14:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h11b3bff1__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h11b3bff1__0 = 0;
    SData/*13:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_haaf0e5de__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_haaf0e5de__0 = 0;
    SData/*12:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_ha69722db__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_ha69722db__0 = 0;
    SData/*11:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h52d684e9__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h52d684e9__0 = 0;
    SData/*10:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h9a87bc1e__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h9a87bc1e__0 = 0;
    SData/*9:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h02b1df34__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h02b1df34__0 = 0;
    SData/*8:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h21dc821c__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h21dc821c__0 = 0;
    CData/*7:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h13130501__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h13130501__0 = 0;
    CData/*6:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he78197c4__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he78197c4__0 = 0;
    CData/*5:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h87dd1c31__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h87dd1c31__0 = 0;
    SData/*15:0*/ __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout = 0;
    IData/*19:0*/ __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables = 0;
    VlWide<10>/*319:0*/ __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values;
    VL_ZERO_W(320, __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values);
    // Body
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_post_fault 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h81ee59e2__0) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_validation_operation)
               ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_target_active_q)
                   ? (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_success_live))
                   : ((6U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_class))
                       ? (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_gate_success_live))
                       : ((7U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_class))
                           ? (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_success_live))
                           : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_class))
                               ? (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_success_live))
                               : (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_success_live))))))
               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_cs_validation_operation)
                   ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0c8da3c8__0)
                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_validation_operation)
                       ? (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_ss_success_live))
                       : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_cs_validation_operation)
                           ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hc92b0026__0)
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_validation_operation)
                               ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h9ac33813__0)
                                   ? (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_gate_success_live))
                                   : ((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_success_live) 
                                          | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_target_begin))) 
                                      & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h720a7911__0)))
                               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_ss_validation_operation)
                                   ? (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_iret_ss_success_live))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_reload_operation)
                                       ? (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_segment_success_live))
                                       : (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_verify_operation) 
                                             | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_inspect_operation) 
                                                | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_success_live))))))))))));
    if (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_en) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segment_state_commit_index 
            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_index;
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segment_state_commit_selector 
            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_selector;
    } else {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segment_state_commit_index 
            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__load_index;
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segment_state_commit_selector 
            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__load_selector;
    }
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segment_state_commit_en 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_en) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_en2) 
              | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q)) 
                 & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error)) 
                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h19ebc0b4__0)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_outer_return_commit 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__context_commit) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q) 
              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_en) 
                 & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_en2) 
                    & ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_index)) 
                       & ((2U == ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_segment_write)
                                   ? 1U : 2U)) & ((3U 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_selector)) 
                                                  > (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__current_cpl))))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_pop_sp_commit 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__protected_return_cursor_q) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__micro_executor__segment_pop_opcode) 
              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_reload_operation) 
                 & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_en))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operation_done 
        = ((3U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_done) 
              | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_service__DOT__state_q))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_validation_success_event 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hedc9faf1__0) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_pre_fault)) 
              & ((~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_post_fault)) 
                 & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h81ee59e2__0) 
                     & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_candidate_success_live) 
                        & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp0_q) 
                            <= (0xffffU & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor))) 
                           & (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                                      >> 0x28U))))) 
                    | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbc8e52c8__0) 
                       & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_success_q))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__system_fault 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__npx_fault) 
           | ((0xbU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__state_q)) 
              | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_mode_fault) 
                 | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_privilege_fault) 
                    | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__io_privilege_fault) 
                       | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__halt_privilege_fault) 
                          | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_fault) 
                             | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_fault) 
                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_tss_pre_fault) 
                                   | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h4e941736__0) 
                                      | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_pre_fault) 
                                         | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_post_fault) 
                                            | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h748f4ecd__0)))))))))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h2f04017f__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_sp_commit) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__retf_outer_sp_commit) 
              | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__return_same_sp_commit) 
                 | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_sp_commit) 
                    | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_pop_sp_commit)))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h87dd1c31__0 
        = (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_pop_sp_commit) 
            << 5U) | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h03543a5a__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fault_error_valid 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h564427fd__0)) 
              & ((3U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_service__DOT__state_q)) 
                 || (1U & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__system_fault)
                            ? ((8U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__system_fault_vector)) 
                               | ((0xaU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__system_fault_vector)) 
                                  | ((0xbU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__system_fault_vector)) 
                                     | ((0xcU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__system_fault_vector)) 
                                        | (0xdU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__system_fault_vector))))))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_hced645af__0) 
                               | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_access_fault) 
                                  | ((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__arithmetic_fault) 
                                         | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__bounds_fault))) 
                                     | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_fetch_fault)))))))));
    vlSelf->spk286_profile_prefix_tb__DOT__debug_fault_error_code 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__system_fault)
            ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__npx_fault)
                ? 0U : ((0xbU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__state_q))
                         ? ((0xfffcU & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__fault_error_code_q)) 
                            | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active) 
                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_external))
                                ? 1U : 0U)) : (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_mode_fault) 
                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_privilege_fault) 
                                                   | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__io_privilege_fault)))
                                                ? 0U
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_tss_pre_fault)
                                                    ? 
                                                   ((0xfffcU 
                                                     & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__tr_selector_q)) 
                                                    | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active) 
                                                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_external))
                                                        ? 1U
                                                        : 0U))
                                                    : 
                                                   ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h4e941736__0)
                                                     ? 0U
                                                     : 
                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h748f4ecd__0)
                                                      ? 
                                                     (2U 
                                                      | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__debug_event_vector) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active) 
                                                             & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_external))
                                                             ? 1U
                                                             : 0U)))
                                                      : 
                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_offset_fault)
                                                       ? 0U
                                                       : 
                                                      (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_pre_fault) 
                                                        | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_post_fault))
                                                        ? 
                                                       ((0xfffcU 
                                                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_value)) 
                                                        | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active) 
                                                            & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_external))
                                                            ? 1U
                                                            : 0U))
                                                        : 0U))))))))
            : 0U);
    vlSelf->spk286_profile_prefix_tb__DOT__debug_fault_vector 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h564427fd__0)
            ? 6U : ((3U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_service__DOT__state_q))
                     ? 0xdU : ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__system_fault)
                                ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__system_fault_vector)
                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_hced645af__0)
                                    ? 0xcU : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_access_fault)
                                               ? 0xdU
                                               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_fetch_fault)
                                                   ? 0xdU
                                                   : 
                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__bounds_fault)
                                                    ? 5U
                                                    : 
                                                   ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__arithmetic_fault)
                                                     ? 0U
                                                     : 0xdU))))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__fault_request 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__range_fault) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__bounds_fault) 
              | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__arithmetic_fault) 
                 | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__operand_blocked) 
                    | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__invalid_form) 
                       | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__invalid_opcode_fault) 
                          | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__system_limit_fault) 
                             | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__system_fault) 
                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_access_fault) 
                                   | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_fetch_fault) 
                                      | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__execution_allowed) 
                                          & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active)) 
                                             & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__raw_retired)) 
                                                & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__event_completed)) 
                                                   & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_active) 
                                                       | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_head_permit)) 
                                                      & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_valid)) 
                                                         & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_response_valid)) 
                                                            & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__fetch_blocked) 
                                                                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h8e0b9e29__0)))))))))) 
                                         | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__length_fault) 
                                            | (3U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_service__DOT__state_q))))))))))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h94cbb048__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_gpr_write) 
           | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h2f04017f__0));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he78197c4__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_result_write) 
            << 6U) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h87dd1c31__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_vector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__entry_failure 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__events__enable) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_cancel)) 
                 & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__fault_request))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_kind = 0U;
    if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__events__enable) 
          & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active))) 
         & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_cancel)))) {
        if ((((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__fault_request) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__events__instruction_active)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown)))) {
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_vector 
                = vlSelf->spk286_profile_prefix_tb__DOT__debug_fault_vector;
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_kind = 1U;
        } else if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__software_taken) 
                    & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown)))) {
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_vector 
                = (0xffU & ((0xcdU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q))
                             ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp0_q)
                             : ((0xccU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q))
                                 ? 3U : 4U)));
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_kind = 5U;
        } else if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__boundary) 
                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_async_enable))) {
            if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__trap_due) 
                   & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unused_ss_shadow))) 
                  & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_boundary) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__repeat_ss_inhibit_q)))) 
                 & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown)))) {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_vector = 1U;
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_kind = 2U;
            } else if ((((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__debug_nmi_pending) 
                           & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__debug_nmi_blocked))) 
                          & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__shutdown_reset_only_q))) 
                         & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unused_ss_shadow))) 
                        & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_boundary) 
                              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__repeat_ss_inhibit_q))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_vector = 2U;
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_kind = 3U;
            } else if (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__fault_request) 
                        & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown)))) {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_vector 
                    = vlSelf->spk286_profile_prefix_tb__DOT__debug_fault_vector;
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_kind = 1U;
            }
        }
    }
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h13130501__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fixed_result_write) 
            << 7U) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he78197c4__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_request 
        = ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_kind)) 
           | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__entry_shutdown)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__entry_failure)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h21dc821c__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_index_write) 
            << 8U) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h13130501__0));
    spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_he61ed21f__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h41f92d96__0) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_request)) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__event_completed)) 
                 & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__raw_retired)) 
                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_valid))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h02b1df34__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_count_write) 
            << 9U) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h21dc821c__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_he61ed21f__0) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__length_fault)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__is_prefix)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_start 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_he61ed21f__0) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__decode_supported) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__is_prefix)) 
                 & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__length_fault)))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h9a87bc1e__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_write_acc) 
            << 0xaU) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h02b1df34__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_start_body 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_start) 
           | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h45d69300__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_start 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_start) 
           | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_dispatch));
    spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_ha5f0a04c__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
           | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_start));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h52d684e9__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__add_allocation_arch) 
            << 0xbU) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h9a87bc1e__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__next_micro_pc 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_pc;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__reset) 
         | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__semantic_cancel))) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__next_micro_pc = 0U;
    } else if (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__execution_allowed) {
        if (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_active) {
            if ((((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_valid) 
                    & (0x2e7U > (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_pc))) 
                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operation_done)) 
                  & (3U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word))) 
                 & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operation_retire)))) {
                if (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__microsequencer__branch_request) {
                    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__microsequencer__branch_target_valid) 
                         & (0x2e7U > (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__microsequencer__branch_target)))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__next_micro_pc 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__microsequencer__branch_target;
                    }
                } else if ((0x2e7U > (0x7ffU & ((IData)(1U) 
                                                + (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_pc))))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__next_micro_pc 
                        = (0x3ffU & ((IData)(1U) + (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_pc)));
                }
            }
        } else if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_start) 
                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_decode_ready))) {
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__next_micro_pc 
                = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__microsequencer__start_entry;
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__events__instruction_start 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__context_active)) 
           & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_ha5f0a04c__0));
    spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_ready 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__length_fault)) 
           & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_ha5f0a04c__0) 
              | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_byte_ready)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_ha69722db__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__frame_write_gpr) 
            << 0xcU) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h52d684e9__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_start_interval 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__events__instruction_start) 
           | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h45d69300__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_replay__DOT__take_consume 
        = (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q)) 
            & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_valid) 
               & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_ready) 
                  & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_replay__DOT__count_q))))) 
           & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_replay__DOT__count_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefetch_queue__DOT__do_consume 
        = ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefetch_queue__DOT__count_q)) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q)
               ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_byte_ready)
               : ((0U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_replay__DOT__count_q)) 
                  & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_ready))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__timing_queue_consume 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_valid) 
           & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_ready));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_haaf0e5de__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allocate_stack) 
            << 0xdU) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_ha69722db__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__instruction_context__consume 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active)) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__timing_queue_consume));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h11b3bff1__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__move_source) 
            << 0xeU) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_haaf0e5de__0));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h1b07fba1__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_arch_write) 
            << 0xfU) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h11b3bff1__0));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0cf40e08__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__count_operation) 
            << 0x10U) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h1b07fba1__0));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hfe63c0ca__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__result_to_dst) 
            << 0x11U) | spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0cf40e08__0);
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_onehot 
        = ((0x80000U & ((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__move_word) 
                            | (0U != spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hfe63c0ca__0))) 
                        << 0x13U)) | ((((~ (IData)(
                                                   (0U 
                                                    != spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hfe63c0ca__0))) 
                                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__move_word)) 
                                       << 0x12U) | 
                                      ((((~ (IData)(
                                                    (0U 
                                                     != spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0cf40e08__0))) 
                                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__result_to_dst)) 
                                        << 0x11U) | 
                                       ((((~ (IData)(
                                                     (0U 
                                                      != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h1b07fba1__0)))) 
                                          & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__count_operation)) 
                                         << 0x10U) 
                                        | ((((~ (IData)(
                                                        (0U 
                                                         != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h11b3bff1__0)))) 
                                             & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_arch_write)) 
                                            << 0xfU) 
                                           | ((((~ (IData)(
                                                           (0U 
                                                            != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_haaf0e5de__0)))) 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__move_source)) 
                                               << 0xeU) 
                                              | ((((~ (IData)(
                                                              (0U 
                                                               != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_ha69722db__0)))) 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allocate_stack)) 
                                                  << 0xdU) 
                                                 | ((((~ (IData)(
                                                                 (0U 
                                                                  != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h52d684e9__0)))) 
                                                      & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__frame_write_gpr)) 
                                                     << 0xcU) 
                                                    | ((((~ (IData)(
                                                                    (0U 
                                                                     != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h9a87bc1e__0)))) 
                                                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__add_allocation_arch)) 
                                                        << 0xbU) 
                                                       | ((((~ (IData)(
                                                                       (0U 
                                                                        != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h02b1df34__0)))) 
                                                            & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_write_acc)) 
                                                           << 0xaU) 
                                                          | ((((~ (IData)(
                                                                          (0U 
                                                                           != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h21dc821c__0)))) 
                                                               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_count_write)) 
                                                              << 9U) 
                                                             | ((((~ (IData)(
                                                                             (0U 
                                                                              != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h13130501__0)))) 
                                                                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_index_write)) 
                                                                 << 8U) 
                                                                | ((((~ (IData)(
                                                                                (0U 
                                                                                != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he78197c4__0)))) 
                                                                     & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fixed_result_write)) 
                                                                    << 7U) 
                                                                   | ((((~ (IData)(
                                                                                (0U 
                                                                                != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h87dd1c31__0)))) 
                                                                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_result_write)) 
                                                                       << 6U) 
                                                                      | ((((~ (IData)(
                                                                                (0U 
                                                                                != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h03543a5a__0)))) 
                                                                           & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_pop_sp_commit)) 
                                                                          << 5U) 
                                                                         | ((((~ (IData)(
                                                                                (0U 
                                                                                != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_ha17f98de__0)))) 
                                                                              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_sp_commit)) 
                                                                             << 4U) 
                                                                            | ((((~ (IData)(
                                                                                (0U 
                                                                                != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hcd1e1639__0)))) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__return_same_sp_commit)) 
                                                                                << 3U) 
                                                                               | ((((~ (IData)(
                                                                                (0U 
                                                                                != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h1b5291b6__0)))) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__retf_outer_sp_commit)) 
                                                                                << 2U) 
                                                                                | ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_gpr_write)) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_sp_commit)) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_gpr_write))))))))))))))))))));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[0U] 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[0U];
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[1U] 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[1U];
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[2U] 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[2U];
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[3U] 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[3U];
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[4U] 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[4U];
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[5U] 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[5U];
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[6U] 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[6U];
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[7U] 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[7U];
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[8U] 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[8U];
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[9U] 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[9U];
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
        = spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_onehot;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((- (IData)((1U & __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables))) 
                      & __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[0U]));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 1U)))) 
                         & ((__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[0U] 
                             << 0x10U) | (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[0U] 
                                          >> 0x10U)))));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 2U)))) 
                         & __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[1U])));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 3U)))) 
                         & ((__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[1U] 
                             << 0x10U) | (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[1U] 
                                          >> 0x10U)))));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 4U)))) 
                         & __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[2U])));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 5U)))) 
                         & ((__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[2U] 
                             << 0x10U) | (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[2U] 
                                          >> 0x10U)))));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 6U)))) 
                         & __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[3U])));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 7U)))) 
                         & ((__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[3U] 
                             << 0x10U) | (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[3U] 
                                          >> 0x10U)))));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 8U)))) 
                         & __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[4U])));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 9U)))) 
                         & ((__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[4U] 
                             << 0x10U) | (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[4U] 
                                          >> 0x10U)))));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 0xaU)))) 
                         & __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[5U])));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 0xbU)))) 
                         & ((__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[5U] 
                             << 0x10U) | (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[5U] 
                                          >> 0x10U)))));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 0xcU)))) 
                         & __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[6U])));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 0xdU)))) 
                         & ((__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[6U] 
                             << 0x10U) | (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[6U] 
                                          >> 0x10U)))));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 0xeU)))) 
                         & __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[7U])));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 0xfU)))) 
                         & ((__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[7U] 
                             << 0x10U) | (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[7U] 
                                          >> 0x10U)))));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 0x10U)))) 
                         & __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[8U])));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 0x11U)))) 
                         & ((__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[8U] 
                             << 0x10U) | (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[8U] 
                                          >> 0x10U)))));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 0x12U)))) 
                         & __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[9U])));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 0x13U)))) 
                         & ((__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[9U] 
                             << 0x10U) | (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[9U] 
                                          >> 0x10U)))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__sequential_gpr_write_data 
        = __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout;
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_write) {
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__effective_gpr_write_index 
                = (7U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_destination_q));
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__effective_gpr_write_data 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_alu)
                    ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__alu_result)
                    : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp1_q));
        } else {
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__effective_gpr_write_index 
                = (7U & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_gpr_write)
                          ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_phase_q)
                          : ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h2f04017f__0)
                              ? 4U : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_result_write)
                                       ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg)
                                       : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fixed_result_write)
                                           ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__write_result_dx)
                                               ? 2U
                                               : 0U)
                                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_index_write)
                                               ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_step_source)
                                                   ? 6U
                                                   : 7U)
                                               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_count_write)
                                                   ? 1U
                                                   : 
                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_write_acc)
                                                    ? 0U
                                                    : 
                                                   ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__add_allocation_arch)
                                                     ? 4U
                                                     : 
                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__frame_write_gpr)
                                                      ? 
                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word) 
                                                      - (IData)(6U))
                                                      : 
                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allocate_stack)
                                                       ? 4U
                                                       : 
                                                      ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__move_source)
                                                        ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__source_index_q)
                                                        : 
                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_arch_write)
                                                         ? 4U
                                                         : 
                                                        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__count_operation)
                                                          ? 1U
                                                          : 
                                                         (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__move_word) 
                                                           | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__result_to_dst))
                                                           ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__destination_q)
                                                           : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_gpr_write_index))))))))))))))));
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__effective_gpr_write_data 
                = spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__sequential_gpr_write_data;
        }
    } else {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__effective_gpr_write_index 
            = (7U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index));
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__effective_gpr_write_data 
            = vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data;
    }
}

VL_ATTR_COLD void Vspk286_profile_prefix_tb___024root___stl_sequent__TOP__0(Vspk286_profile_prefix_tb___024root* vlSelf);
VL_ATTR_COLD void Vspk286_profile_prefix_tb___024root___stl_sequent__TOP__1(Vspk286_profile_prefix_tb___024root* vlSelf);

VL_ATTR_COLD void Vspk286_profile_prefix_tb___024root___eval_stl(Vspk286_profile_prefix_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_profile_prefix_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_profile_prefix_tb___024root___eval_stl\n"); );
    // Body
    if ((1ULL & vlSelf->__VstlTriggered.word(0U))) {
        Vspk286_profile_prefix_tb___024root___stl_sequent__TOP__0(vlSelf);
        Vspk286_profile_prefix_tb___024root___stl_sequent__TOP__1(vlSelf);
        Vspk286_profile_prefix_tb___024root___stl_sequent__TOP__2(vlSelf);
    }
}

VL_ATTR_COLD void Vspk286_profile_prefix_tb___024root___eval_triggers__stl(Vspk286_profile_prefix_tb___024root* vlSelf);

VL_ATTR_COLD bool Vspk286_profile_prefix_tb___024root___eval_phase__stl(Vspk286_profile_prefix_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_profile_prefix_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_profile_prefix_tb___024root___eval_phase__stl\n"); );
    // Init
    CData/*0:0*/ __VstlExecute;
    // Body
    Vspk286_profile_prefix_tb___024root___eval_triggers__stl(vlSelf);
    __VstlExecute = vlSelf->__VstlTriggered.any();
    if (__VstlExecute) {
        Vspk286_profile_prefix_tb___024root___eval_stl(vlSelf);
    }
    return (__VstlExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vspk286_profile_prefix_tb___024root___dump_triggers__act(Vspk286_profile_prefix_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_profile_prefix_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_profile_prefix_tb___024root___dump_triggers__act\n"); );
    // Body
    if ((1U & (~ (IData)(vlSelf->__VactTriggered.any())))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelf->__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 0 is active: @(posedge spk286_profile_prefix_tb.clk)\n");
    }
    if ((2ULL & vlSelf->__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 1 is active: @([true] __VdlySched.awaitingCurrentTime())\n");
    }
}
#endif  // VL_DEBUG

#ifdef VL_DEBUG
VL_ATTR_COLD void Vspk286_profile_prefix_tb___024root___dump_triggers__nba(Vspk286_profile_prefix_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_profile_prefix_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_profile_prefix_tb___024root___dump_triggers__nba\n"); );
    // Body
    if ((1U & (~ (IData)(vlSelf->__VnbaTriggered.any())))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelf->__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 0 is active: @(posedge spk286_profile_prefix_tb.clk)\n");
    }
    if ((2ULL & vlSelf->__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 1 is active: @([true] __VdlySched.awaitingCurrentTime())\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vspk286_profile_prefix_tb___024root___ctor_var_reset(Vspk286_profile_prefix_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_profile_prefix_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_profile_prefix_tb___024root___ctor_var_reset\n"); );
    // Body
    vlSelf->spk286_profile_prefix_tb__DOT__clk = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__reset = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__ready = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__execute_enable = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__halted = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__shutdown = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__event_completed = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__debug_event_vector = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__debug_fault_vector = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__debug_fault_error_code = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__debug_instruction_ip = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__debug_nmi_pending = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__debug_nmi_blocked = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__data_in = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_en = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__flags_write_en = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__redirect = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__control_error = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__fetch_blocked = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__data_oe = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__bus_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__hlda = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__operand_blocked = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__debug_segment_selectors = VL_RAND_RESET_Q(64);
    vlSelf->spk286_profile_prefix_tb__DOT__debug_segment_limits = VL_RAND_RESET_Q(64);
    vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary = VL_RAND_RESET_I(1);
    for (int __Vi0 = 0; __Vi0 < 4096; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__memory[__Vi0] = VL_RAND_RESET_I(8);
    }
    vlSelf->spk286_profile_prefix_tb__DOT__edges = VL_RAND_RESET_I(32);
    vlSelf->spk286_profile_prefix_tb__DOT__case_id = VL_RAND_RESET_I(32);
    vlSelf->spk286_profile_prefix_tb__DOT__checks = VL_RAND_RESET_I(32);
    vlSelf->spk286_profile_prefix_tb__DOT__counted_prefixes = VL_RAND_RESET_I(32);
    vlSelf->spk286_profile_prefix_tb__DOT__expected_count = VL_RAND_RESET_I(32);
    vlSelf->spk286_profile_prefix_tb__DOT__expected_budget = VL_RAND_RESET_I(32);
    vlSelf->spk286_profile_prefix_tb__DOT__expected_estimated = VL_RAND_RESET_I(32);
    vlSelf->spk286_profile_prefix_tb__DOT__checked = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__restart = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__stream_restart = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__internal_redirect = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__internal_target = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_check = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__condition_taken = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__branch_taken = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__form_supported = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_ready = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_response_ready = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_response_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_response_data = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_response_count = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_fill_ready = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__destination_q = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__source_index_q = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__direct_flags_data = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__direct_flags_mask = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__is_prefix = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__context_active = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segment_override = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__lock_prefix = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__length_fault = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__override_segment = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__io_transfer = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__string_destination = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_boundary = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_bytes = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__execution_allowed = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__decode_supported = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__decode_ready = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_start = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__decode_destination = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__decode_entry = VL_RAND_RESET_I(10);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_pc = VL_RAND_RESET_I(10);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_entry = VL_RAND_RESET_I(10);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__dispatch_request = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__dispatch_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__reverse_operands = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__arithmetic_fault = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__adjust_kind = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__range_fault = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__bounds_fault = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__counter_branch_target = VL_RAND_RESET_I(11);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__dispatch_entry = VL_RAND_RESET_I(10);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_active = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operation_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operation_done = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operation_retire = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_done = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_byte_ready = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__effective_gpr_write_index = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__effective_gpr_write_data = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__effective_ip_write_data = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte_ready = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_segment = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_rm = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_register_direct = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_displacement = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_offset = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__address_override = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__address_offset = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_write = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_done = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_operand_done = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_write_data = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_operand_read_data = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_gpr_write_index = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__memory_request = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__memory_request_ready = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__memory_byte = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__memory_address = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__memory_read_data = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__memory_response_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_memory_request = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_memory_response_ready = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_memory_request = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_memory_done = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_service_busy = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_memory_done = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_msw = VL_RAND_RESET_I(16);
    VL_RAND_RESET_W(128, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_gpr);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_gdtr_base = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_idtr_base = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_ldtr_base = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_tr_base = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_tr_access = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_ldtr_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_ldtr_present = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_tr_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_tr_present = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_segment_selectors = VL_RAND_RESET_Q(64);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_segment_limits = VL_RAND_RESET_Q(64);
    VL_RAND_RESET_W(96, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_segment_bases);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_segment_access = VL_RAND_RESET_I(32);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_segment_valid = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_segment_present = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_segment_protected = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_segment_dpl = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_start = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__alu_operation = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__result_write_allowed = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__alu_byte = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__decoded_flags_mask = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_cancel = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_dispatch = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_request = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_software = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_needs_ack = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_external = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_kind = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_ip = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_cs = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_flags = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_error_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_error_code = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_start = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__service_start = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__raw_retired = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__context_commit = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__software_taken = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__invalid_form = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__invalid_opcode_fault = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__ack_request = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__ack_request_ready = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__ack_response_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__ack_response_ready = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__ack_pending_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__ack_done = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__ack_vector = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__internal_segment_write = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unused_ss_shadow = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__decoded_segment_index = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__semantic_cancel = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__timing_queue_consume = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_gdtr_load_en = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_idtr_load_en = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_msw_load_data = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_msw_load_mask = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_gdtr_load_base = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_ldtr_commit_en = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_tr_commit_en = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_ldtr_commit_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_return_task = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_nested_call = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_tss_address = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_event_address = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__system_limit_fault = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__system_fault_vector = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fault_error_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_outer_return_commit = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__current_cpl = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_en = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_index = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_selector = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_en2 = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segment_state_commit_en = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segment_state_commit_index = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segment_state_commit_selector = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_access_fault = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_fetch_fault = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_fetch_invalid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_task_load = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_state_loaded = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_decode_ready = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_head_permit = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_retire_fire = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_normal_retired_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_async_enable = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_preserve_cancel = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_checkpoint = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_branch_known_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_branch_taken_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_count_known_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_count_q = VL_RAND_RESET_I(5);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_nonempty_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_iteration = VL_RAND_RESET_I(10);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_start_interval = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_start_body = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks = VL_RAND_RESET_I(10);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_execution_base = VL_RAND_RESET_I(10);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_execution_repeat_setup = VL_RAND_RESET_I(10);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_execution_repeat_iteration = VL_RAND_RESET_I(10);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_execution_ea = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_instruction_metadata_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_event_metadata_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_event_base = VL_RAND_RESET_I(10);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_native_queue_data = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview_start = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_started_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview_active = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_byte_ready = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_complete = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_valid_length = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_abort_fetch = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_length = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_length_clocks = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__profile_target_handoff__cancel = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_candidate_body = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_modrm_current = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_execution_repeated = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellout__profile_execution_metadata__requires_count = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellout__profile_execution_metadata__requires_outcome = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellout__profile_execution_metadata__requires_modrm = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_io_ranges = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_address_ranges = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_stack_ranges = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_regular_ranges = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_vector_ranges = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__load_selector = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__load_index = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__load_en = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__fetch__suspend = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__fetch__request = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__biu__lock_request = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__next_micro_pc = VL_RAND_RESET_I(10);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__instruction_context__consume = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__instruction_context__complete = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__microsequencer__branch_target_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__microsequencer__branch_target = VL_RAND_RESET_I(10);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__microsequencer__branch_request = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__microsequencer__start_entry = VL_RAND_RESET_I(10);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__micro_executor__push_enabled = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__micro_executor__segment_pop_opcode = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__operand_decode__byte_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__events__fault_new_task = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__events__instruction_active = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__events__instruction_start = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__events__enable = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__0__KET____DOT__cache_limit = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__0__KET____DOT__cache_expand_down = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__1__KET____DOT__cache_limit = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__1__KET____DOT__cache_expand_down = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__2__KET____DOT__cache_limit = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__2__KET____DOT__cache_expand_down = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__3__KET____DOT__cache_limit = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__3__KET____DOT__cache_expand_down = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h564427fd__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_hced645af__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h45d69300__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h19ebc0b4__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h8e0b9e29__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h41f92d96__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__fault_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__length_q = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__new_redirect = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT__state_q = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT__active_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT__accept_byte = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT__is_prefix = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT__byte_count = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT__opcode_q = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT__extended_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT__dispatch_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT__tail_q = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT__remaining_q = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT__decode_invalid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT__entry = VL_RAND_RESET_I(10);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT__dispatch_entry = VL_RAND_RESET_I(10);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT__form_supported = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT__dispatch_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT__opcode_tail = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT__modrm_tail = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT____Vcellinp__instruction_context__prefix_accept = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT____Vcellinp__instruction_context__cancel = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT__instruction_context__DOT__extended_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT__decoder__DOT____VdfgTmp_h0f0db5a7__0 = 0;
    for (int __Vi0 = 0; __Vi0 < 10; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_replay__DOT__bytes_q[__Vi0] = VL_RAND_RESET_I(8);
    }
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_replay__DOT__write_q = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_replay__DOT__count_q = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_replay__DOT__take_capture = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_replay__DOT__take_consume = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_replay__DOT____Vlvbound_h9c8021b4__0 = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_replay__DOT____Vlvbound_h763c5a5b__0 = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__active_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__pending_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__qualified_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__frozen_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__admission_window_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__elapsed_q = VL_RAND_RESET_I(10);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__base_q = VL_RAND_RESET_I(10);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__extra_q = VL_RAND_RESET_I(10);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__elapsed_next = VL_RAND_RESET_I(11);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__extra_next = VL_RAND_RESET_I(11);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_productive_boundary = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_elapsed_saturated = VL_RAND_RESET_I(1);
    VL_RAND_RESET_W(128, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__gpr_q);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__ip_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__flags_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__effective_flags_mask = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__gdtr_limit_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__idtr_limit_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__gdtr_base_q = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__idtr_base_q = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__ldtr_selector_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__tr_selector_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__ldtr_base_q = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__tr_base_q = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__ldtr_limit_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__tr_limit_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__tr_access_q = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__ldtr_valid_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__ldtr_present_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__tr_valid_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__tr_present_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_selector_q = VL_RAND_RESET_Q(64);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_limit_q = VL_RAND_RESET_Q(64);
    VL_RAND_RESET_W(96, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_base_q);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_access_q = VL_RAND_RESET_I(32);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_valid_q = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_present_q = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_protected_q = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_dpl_q = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__outer_return_clear = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT____Vlvbound_hc376928a__0 = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT____Vlvbound_h7d338dd3__0 = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__state_q = VL_RAND_RESET_I(5);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__target_selector_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__target_limit_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__current_selector_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__current_limit_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__target_base_q = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__current_base_q = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__target_access_q = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__current_access_q = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__target_descriptor_address_q = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__current_descriptor_address_q = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__current_ip_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__current_flags_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__current_ldtr_q = VL_RAND_RESET_I(16);
    VL_RAND_RESET_W(128, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__current_gpr_q);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__current_segments_q = VL_RAND_RESET_Q(64);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__nested_call_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__jump_task_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__return_task_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__incoming_ldtr_selector_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__incoming_ldtr_word0_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__incoming_ldtr_word1_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__incoming_ldtr_word2_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__incoming_ldtr_descriptor_address_q = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__incoming_ldtr_limit_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__incoming_ldtr_base_q = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__incoming_ldtr_valid_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__incoming_ldtr_present_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__return_target_resolved_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__return_selector_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__return_descriptor_word0_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__return_descriptor_word1_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__return_descriptor_word2_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__return_descriptor_address = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__return_descriptor_class = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__return_descriptor_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__return_descriptor_reserved_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_memory_request = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_memory_request = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_memory_address = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_memory_write_data = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_fault_vector = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_fault_error_code = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_loaded_segments = VL_RAND_RESET_Q(64);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__incoming_ldtr_class = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__incoming_ldtr_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__incoming_ldtr_reserved_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT____Vcellinp__return_descriptor_parser__raw_descriptor = VL_RAND_RESET_Q(64);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT____Vcellinp__incoming_ldtr_parser__raw_descriptor = VL_RAND_RESET_Q(64);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT____Vcellinp__segment_service__memory_done = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__fault_vector_q = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__fault_error_code_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__state_q = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__segment_index_q = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__word_index_q = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__task_segments_q = VL_RAND_RESET_Q(64);
    for (int __Vi0 = 0; __Vi0 < 4; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__descriptor_raw_q[__Vi0] = VL_RAND_RESET_Q(64);
    }
    for (int __Vi0 = 0; __Vi0 < 4; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__descriptor_address_q[__Vi0] = VL_RAND_RESET_I(24);
    }
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__cache_selectors_q = VL_RAND_RESET_Q(64);
    VL_RAND_RESET_W(96, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__cache_bases_q);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__cache_limits_q = VL_RAND_RESET_Q(64);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__cache_access_q = VL_RAND_RESET_I(32);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__cache_present_q = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__cache_protected_q = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__cache_dpl_q = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__precheck_fault_q = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__segment_required = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__segment_invalid = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__segment_missing = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__selected_fault_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__selected_fault_vector = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__selected_selector = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__selector_null = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__selector_carry = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__selector_limit_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__descriptor_address_calc = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__write_needed = VL_RAND_RESET_I(1);
    for (int __Vi0 = 0; __Vi0 < 4; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__descriptor_accessed[__Vi0] = VL_RAND_RESET_I(1);
    }
    for (int __Vi0 = 0; __Vi0 < 4; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__descriptor_present[__Vi0] = VL_RAND_RESET_I(1);
    }
    for (int __Vi0 = 0; __Vi0 < 4; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__descriptor_valid[__Vi0] = VL_RAND_RESET_I(1);
    }
    for (int __Vi0 = 0; __Vi0 < 4; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__descriptor_reserved_valid[__Vi0] = VL_RAND_RESET_I(1);
    }
    for (int __Vi0 = 0; __Vi0 < 4; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__descriptor_segment[__Vi0] = VL_RAND_RESET_I(1);
    }
    for (int __Vi0 = 0; __Vi0 < 4; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__descriptor_executable[__Vi0] = VL_RAND_RESET_I(1);
    }
    for (int __Vi0 = 0; __Vi0 < 4; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__descriptor_conforming[__Vi0] = VL_RAND_RESET_I(1);
    }
    for (int __Vi0 = 0; __Vi0 < 4; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__descriptor_readable[__Vi0] = VL_RAND_RESET_I(1);
    }
    for (int __Vi0 = 0; __Vi0 < 4; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__descriptor_writable[__Vi0] = VL_RAND_RESET_I(1);
    }
    for (int __Vi0 = 0; __Vi0 < 4; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__descriptor_limit[__Vi0] = VL_RAND_RESET_I(16);
    }
    for (int __Vi0 = 0; __Vi0 < 4; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__descriptor_base[__Vi0] = VL_RAND_RESET_I(24);
    }
    for (int __Vi0 = 0; __Vi0 < 4; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__descriptor_access[__Vi0] = VL_RAND_RESET_I(8);
    }
    for (int __Vi0 = 0; __Vi0 < 4; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__descriptor_class[__Vi0] = VL_RAND_RESET_I(4);
    }
    for (int __Vi0 = 0; __Vi0 < 4; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__descriptor_dpl[__Vi0] = VL_RAND_RESET_I(2);
    }
    for (int __Vi0 = 0; __Vi0 < 4; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__segment_type_valid[__Vi0] = VL_RAND_RESET_I(1);
    }
    for (int __Vi0 = 0; __Vi0 < 4; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__segment_privilege_valid[__Vi0] = VL_RAND_RESET_I(1);
    }
    for (int __Vi0 = 0; __Vi0 < 4; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__segment_present_valid[__Vi0] = VL_RAND_RESET_I(1);
    }
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT____Vlvbound_h05e19184__0 = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT____Vlvbound_h0fd656e5__0 = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT____VdfgTmp_he1491d44__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__state_q = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__index_q = VL_RAND_RESET_I(5);
    for (int __Vi0 = 0; __Vi0 < 15; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__load_words_q[__Vi0] = VL_RAND_RESET_I(16);
    }
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__current_selector_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__target_base_q = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__target_selector_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__target_limit_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__target_access_q = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__target_descriptor_address_q = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__current_descriptor_address_q = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__nested_call_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__jump_task_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__return_task_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT____Vlvbound_h5b724e2d__0 = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_service__DOT__state_q = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_service__DOT__word_index_q = VL_RAND_RESET_I(6);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_service__DOT__current_protected_q = VL_RAND_RESET_I(1);
    for (int __Vi0 = 0; __Vi0 < 51; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_service__DOT__image_q[__Vi0] = VL_RAND_RESET_I(16);
    }
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_service__DOT____Vlvbound_h14cd17b3__0 = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segments__DOT__selector_q = VL_RAND_RESET_Q(64);
    VL_RAND_RESET_W(96, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segments__DOT__base_q);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segments__DOT__limit_q = VL_RAND_RESET_Q(64);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segments__DOT__access_q = VL_RAND_RESET_I(32);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segments__DOT____Vlvbound_h1ff389eb__0 = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__active_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__canceled_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__restart_pending_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__cursor_q = VL_RAND_RESET_I(17);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__address_q = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__request_ip_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__request_count_q = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__bhe_n_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__next_address = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__completed_cursor = VL_RAND_RESET_I(17);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__next_cursor = VL_RAND_RESET_I(17);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__single_byte = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__response_fire = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__response_slot_available = VL_RAND_RESET_I(1);
    for (int __Vi0 = 0; __Vi0 < 6; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefetch_queue__DOT__storage_q[__Vi0] = VL_RAND_RESET_I(8);
    }
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefetch_queue__DOT__head_q = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefetch_queue__DOT__tail_q = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefetch_queue__DOT__count_q = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefetch_queue__DOT__do_fill = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefetch_queue__DOT__do_consume = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefetch_queue__DOT__tail_after_first = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefetch_queue__DOT__tail_after_second = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefetch_queue__DOT____Vlvbound_h2612bec2__0 = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefetch_queue__DOT____Vlvbound_hffbd228e__0 = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__data_active_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__second_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__canceled_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__byte_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__io_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_data_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__low_byte_q = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__owner_valid_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__data_complete = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__owner_q = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__ack_active_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__ack_second_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__lock_chain_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__ack_canceled_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__decoder__DOT____VdfgTmp_h0f0db5a7__0 = 0;
    for (int __Vi0 = 0; __Vi0 < 1024; ++__Vi0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__microcode_rom__DOT__contents[__Vi0] = VL_RAND_RESET_I(9);
    }
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fetch_port = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__io_privilege_fault = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_step_source = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_step_dest = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_read_acc = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_write_acc = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_continue = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_count_write = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_index_write = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_index = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__copy_call_parameters = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__auxiliary_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allocation_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__frame_address_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__auxiliary_valid_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allocation_valid_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__frame_address_valid_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__counter_valid_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__counter_q = VL_RAND_RESET_I(5);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__frame_read_gpr = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__frame_write_gpr = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__save_auxiliary = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__restore_auxiliary = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__save_allocation = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__load_counter = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__decrement_counter = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__begin_stack_cursor = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_stack_cursor = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__set_frame_address = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__decrement_frame_address = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allocate_stack = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__set_ea_plus2 = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_cursor_valid_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_arch_write = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__begin_return_cursor = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__protected_return_cursor_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__return_same_sp_commit = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__add_allocation_arch = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_cursor_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__return_stack_pointer = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_parameter_bytes = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp0_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp1_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp2_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__flags_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__flags_mask_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_active_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_index_q = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_limit_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_base_q = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_table_operation = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_table_load = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_msw_load = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_privilege_fault = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_mode_fault = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__halt_privilege_fault = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_adjust = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_commit = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_fault = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_commit = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_fault = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__npx_fault = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_operand_done = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_begin = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_is_gdtr = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_selected_base = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_request = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_complete = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_write = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_fault = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__unused_muldiv_ready = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__result_high_pending_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__write_result_ax = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__write_result_dx = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fixed_result_write = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_low = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_high = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_flags = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_mask = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__muldiv_service__dividend = VL_RAND_RESET_I(32);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__muldiv_service__kind = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_request = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_complete = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_write = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_fault = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__unused_adjust_ready = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arithmetic_fault_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_result = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_flags = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_mask = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_segment = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_active_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_phase_q = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_word0_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_word1_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_word2_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_word3_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_tr = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_verify_read = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_verify_write = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_verify_operation = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_inspect_operation = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_reload_operation = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_validation_operation = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_validation_operation = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_segment_null_commit = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_segment_success_live = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_success_live = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_begin = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_operand_done = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_null_commit = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_success_live = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_success_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_verify_negative = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_inspect_negative = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_inspect_success_live = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_verify_flags_write = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_inspect_flags_write = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_result_write = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_pre_fault = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_low_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_low_reserved_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_class = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_unused_segment = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_unused_conforming = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_unused_readable = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_unused_writable = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_null = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_value = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_address = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_offset_fault = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_validation_success_event = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_validation_operation = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_cs_validation_operation = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__jmp_gate_target_begin = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_stack_validation_operation = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_switch_begin = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_switch_active_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_write_done = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_switch_phase_q = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_data_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_active_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_read = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_read_done = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_write_done = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_phase_q = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_remaining_q = VL_RAND_RESET_I(5);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_source_sp_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_data_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_outer_required = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_tss_active_state_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_tss_operand_done = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_tss_pre_fault = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_stack_ready_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_tss_phase_q = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_stack_sp_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_stack_ss_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_target_dpl_q = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_parameter_count_q = VL_RAND_RESET_I(5);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_candidate_valid_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_selector_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_limit_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_base_q = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_access_q = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_dpl_q = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_present_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_frame_bytes = VL_RAND_RESET_I(17);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_last_byte = VL_RAND_RESET_I(17);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_cs_validation_operation = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_ss_validation_operation = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_frame_operation = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_required = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_pop_done = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_ready_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_ss_candidate_valid_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_phase_q = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_sp_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_ss_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_ss_selector_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_ss_limit_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_ss_base_q = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_ss_access_q = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_ss_dpl_q = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_ss_present_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_iret_cs_success_live = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_iret_ss_success_live = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_ss_success_live = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_gate_success_live = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_gate_cs_success_live = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_candidate_success_live = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_success_live = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_target_begin = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_target_active_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_nested_call_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_target_selector_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_active_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_phase_q = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_word0_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_word1_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_word2_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_word3_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_ip_operation = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_cs_operation = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_begin = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_operand_done = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_success_live = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_candidate_valid_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_target_selector_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_target_offset_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_class_q = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_low_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_low_reserved_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_class = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_unused_segment = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_vector_ip = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_vector_cs = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clear_event_flags = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_candidate_valid_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_candidate_selector_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_candidate_limit_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_candidate_base_q = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_candidate_access_q = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_candidate_class_q = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_candidate_dpl_q = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_candidate_present_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_candidate_valid_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_candidate_valid_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_selector_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_limit_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_base_q = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_address_q = VL_RAND_RESET_I(24);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_access_q = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_switch_skip = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_return_skip = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_return_finish = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_return_started_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_success_live = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_active_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_event_switch_done_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_event_switch_skip = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_phase_q = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_gpr_write = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_flags_write = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_redirect = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_segment_write = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_ldtr_write = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_done = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_done_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_service_complete_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor = VL_RAND_RESET_Q(64);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__event_gate_parser__raw_descriptor = VL_RAND_RESET_Q(64);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__constant_zero = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__constant_ones = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_ea = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_target = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__move_source = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__write_reg_tmp1 = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__set_address = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__add_base = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__high_byte_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__flags_valid_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__result_disposed_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fetch_word = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fetch_signed_byte = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__move_word = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_operand = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_tmp1 = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_destination = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__compute_alu = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__result_operation = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__result_to_dst = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__commit_result = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__commit_flags = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__alu_result = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__alu_flags = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_request = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_complete = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_write = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__result_suppress_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allow_result_write = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__unused_shift_ready = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__count_low = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_result = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_flags = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_mask = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_ip = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__target_relative = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__target_absolute = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__redirect_operation = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__count_operation = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_write_sp = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__target_valid_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__target_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_next_sp = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fetch_byte = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fetch_byte_tmp1 = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_flags = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__restore_flags = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__set_if = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clear_if_tf = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__direct_flags = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__sign_extend_byte = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__sign_fill_word = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__constant_one = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__carry_fill_byte = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_event_flags = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_event_cs = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_event_ip = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__vector_cs = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__halt_operation = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_commit = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_sp_commit = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__retf_outer_sp_commit = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_sp_commit = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__stack_service__sp = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_last_byte = VL_RAND_RESET_I(17);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__adjust_service__cancel = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_decode = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_alu = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_byte = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_destination_rm = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__unary_register = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__unary_direct = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_capture = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__direct_register_capture = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_pending_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_write = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_destination_q = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_a_index = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_b_index = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__immediate_operation = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__immediate_alu = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__immediate_rm = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__immediate_word = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__immediate_signed = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__immediate_register = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__immediate_fetch = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__immediate_last = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__immediate_capture = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__immediate_value = VL_RAND_RESET_I(16);
    VL_RAND_RESET_W(320, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_flags_write_mask = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h81ee59e2__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbc8e52c8__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0c8da3c8__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h720a7911__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hc92b0026__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h676cdf20__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h4b82a8ba__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h94cbb048__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h431e1356__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h34e1cf13__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbc272fa5__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hb5d3750f__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h72e9be9b__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hfed63a1d__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h6f1b5359__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h669f3c1e__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h46e8c854__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h47070c4b__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h123c7c30__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h4e941736__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h748f4ecd__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h9ac33813__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h124121e1__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hd208890c__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hda2f34dc__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h9b33c892__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h1f6c94ab__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h1c5fbef9__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hedc9faf1__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hf949133e__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h960f7d4f__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h27251fb3__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h03543a5a__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_ha17f98de__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hcd1e1639__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h1b5291b6__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__busy_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__divide_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__signed_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__byte_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__negative_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__remainder_negative_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__zero_divisor_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__remaining_q = VL_RAND_RESET_I(6);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__factor_q = VL_RAND_RESET_I(32);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__product_q = VL_RAND_RESET_I(32);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__quotient_q = VL_RAND_RESET_I(32);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__multiplier_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__divisor_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__remainder_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__normalized_dividend = VL_RAND_RESET_I(32);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__absolute_dividend = VL_RAND_RESET_I(32);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__next_product = VL_RAND_RESET_I(32);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__signed_product = VL_RAND_RESET_I(32);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__normalized_source = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__absolute_source = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__dividend_negative = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__source_negative = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__shifted_remainder = VL_RAND_RESET_I(17);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__reduced_remainder = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__next_quotient = VL_RAND_RESET_I(32);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__signed_quotient = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__signed_remainder = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__high_product = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__subtract_divisor = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__overflow = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__byte_step = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__byte_remainder = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__byte_corrected_quotient = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__byte_remainder_wrap = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__byte_overflow_accept = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT____VdfgTmp_h702cc853__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_service__DOT__busy_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_service__DOT__byte_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_service__DOT__carry_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_service__DOT__single_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_service__DOT__original_sign_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_service__DOT__kind_q = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_service__DOT__remaining_q = VL_RAND_RESET_I(5);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_service__DOT__value_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_service__DOT__next_value = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_service__DOT__next_carry = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_service__DOT__next_sign = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_service__DOT__busy_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_service__DOT__divide_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_service__DOT__remaining_q = VL_RAND_RESET_I(4);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_service__DOT__factor_q = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_service__DOT__multiplier_q = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_service__DOT__accumulator_q = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_service__DOT__divisor_q = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_service__DOT__quotient_q = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_service__DOT__remainder_q = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_service__DOT__shifted_remainder = VL_RAND_RESET_I(9);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_service__DOT__next_remainder = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_service__DOT__next_quotient = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_service__DOT__next_accumulator = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_service__DOT__low_adjust = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_service__DOT__high_adjust = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_service__DOT__correction = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_service__DOT__decimal_result = VL_RAND_RESET_I(8);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_service__DOT____VdfgTmp_h70299a46__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_service__DOT____VdfgTmp_hf66deb71__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__alu_decode__DOT__string_compare = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__alu_decode__DOT__inc_dec = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__alu_decode__DOT____VdfgTmp_h53b4da03__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode__DOT__state_q = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode__DOT__decoded_size = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode__DOT__size_q = VL_RAND_RESET_I(2);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode__DOT__ea_memory = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode__DOT__ea_offset = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode__DOT__allowed = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode__DOT__reuse_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode__DOT__ea__DOT__uses_bp = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__pending_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__is_memory = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__allowed = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__within_limit = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT____VdfgTmp_h314da18c__0 = 0;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__repeat_ss_inhibit_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__trap_sample_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__trap_pending_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__dispatch_pending_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__delivery_context_live_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__shutdown_nmi_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__shutdown_reset_only_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__instruction_cs_q = VL_RAND_RESET_I(16);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__boundary = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__trap_due = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__entry_failure = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__entry_double_fault = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__entry_shutdown = VL_RAND_RESET_I(1);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_kind = VL_RAND_RESET_I(3);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_vector = VL_RAND_RESET_I(8);
    vlSelf->__VdfgTmp_hc8706df8__0 = 0;
    vlSelf->__VdfgTmp_h1c2f81f0__0 = 0;
    vlSelf->__VdfgTmp_hd94b9d92__0 = 0;
    vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__60__condition = VL_RAND_RESET_I(1);
    vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__61__condition = VL_RAND_RESET_I(1);
    vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__62__condition = VL_RAND_RESET_I(1);
    vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__63__condition = VL_RAND_RESET_I(1);
    vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__64__condition = VL_RAND_RESET_I(1);
    vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__112__condition = VL_RAND_RESET_I(1);
    vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__113__condition = VL_RAND_RESET_I(1);
    vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__114__condition = VL_RAND_RESET_I(1);
    vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__115__condition = VL_RAND_RESET_I(1);
    vlSelf->__Vtask_spk286_profile_prefix_tb__DOT__check__116__condition = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__Vfuncout = VL_RAND_RESET_I(24);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__base = VL_RAND_RESET_I(10);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__setup_clocks = VL_RAND_RESET_I(10);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__iteration_clocks = VL_RAND_RESET_I(10);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__ea = VL_RAND_RESET_I(3);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__repeated = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__nonempty = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__prefixes = VL_RAND_RESET_I(4);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__remaining_prefixes = VL_RAND_RESET_I(4);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__first = VL_RAND_RESET_I(12);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__second = VL_RAND_RESET_I(12);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__prefix_clocks = VL_RAND_RESET_I(12);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__sum_bits = VL_RAND_RESET_I(12);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__carry_bits = VL_RAND_RESET_I(12);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__212__Vfuncout = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__212__limit_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__212__expand_down = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__212__is_byte = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__213__Vfuncout = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__213__offset_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__213__limit_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__213__expand_down = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__213__is_byte = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__214__Vfuncout = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__214__offset_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__214__limit_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__214__expand_down = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__214__is_byte = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__215__Vfuncout = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__215__offset_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__215__limit_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__215__expand_down = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__215__is_byte = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__216__Vfuncout = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__216__offset_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__216__expand_down = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__216__is_byte = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__217__Vfuncout = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__217__limit_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__217__expand_down = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__217__is_byte = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__218__Vfuncout = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__218__offset_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__218__limit_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__218__expand_down = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__218__is_byte = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__219__Vfuncout = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__219__offset_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__219__limit_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__219__expand_down = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__219__is_byte = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__220__Vfuncout = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__220__offset_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__220__limit_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__220__expand_down = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__220__is_byte = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__221__Vfuncout = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__221__offset_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__221__expand_down = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__221__is_byte = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__222__Vfuncout = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__222__limit_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__222__expand_down = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__222__is_byte = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__223__Vfuncout = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__223__offset_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__223__limit_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__223__expand_down = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__223__is_byte = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__224__Vfuncout = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__224__offset_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__224__limit_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__224__expand_down = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__224__is_byte = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__225__Vfuncout = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__225__offset_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__225__limit_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__225__expand_down = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__225__is_byte = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__226__Vfuncout = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__226__offset_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__226__expand_down = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__226__is_byte = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__227__Vfuncout = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__227__limit_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__227__expand_down = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__227__is_byte = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__228__Vfuncout = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__228__offset_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__228__limit_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__228__expand_down = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__228__is_byte = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__229__Vfuncout = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__229__offset_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__229__limit_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__229__expand_down = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__229__is_byte = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__230__Vfuncout = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__230__offset_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__230__limit_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__230__expand_down = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__230__is_byte = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__231__Vfuncout = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__231__offset_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__231__expand_down = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__231__is_byte = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__232__Vfuncout = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__232__offset_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__232__limit_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__232__expand_down = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__232__is_byte = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__233__Vfuncout = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__233__offset_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__233__limit_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__233__expand_down = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__233__is_byte = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__234__Vfuncout = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__234__offset_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__234__limit_value = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__234__expand_down = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__234__is_byte = VL_RAND_RESET_I(1);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__save_offset__501__Vfuncout = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__save_offset__501__index = VL_RAND_RESET_I(5);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__save_data__502__Vfuncout = VL_RAND_RESET_I(16);
    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__save_data__502__index = VL_RAND_RESET_I(5);
    vlSelf->__Vdly__spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q = VL_RAND_RESET_I(1);
    vlSelf->__Vdly__spk286_profile_prefix_tb__DOT__dut__DOT__ack_pending_q = VL_RAND_RESET_I(1);
    vlSelf->__Vdly__spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__flags_q = VL_RAND_RESET_I(16);
    vlSelf->__Vdly__spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__state_q = VL_RAND_RESET_I(4);
    vlSelf->__Vdly__spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__state_q = VL_RAND_RESET_I(4);
    vlSelf->__Vdly__spk286_profile_prefix_tb__DOT__dut__DOT__loadall_service__DOT__state_q = VL_RAND_RESET_I(2);
    vlSelf->__Vdlyvset__spk286_profile_prefix_tb__DOT__dut__DOT__loadall_service__DOT__image_q__v0 = 0;
    vlSelf->__Vdlyvdim0__spk286_profile_prefix_tb__DOT__dut__DOT__loadall_service__DOT__image_q__v51 = 0;
    vlSelf->__Vdlyvval__spk286_profile_prefix_tb__DOT__dut__DOT__loadall_service__DOT__image_q__v51 = VL_RAND_RESET_I(16);
    vlSelf->__Vdlyvset__spk286_profile_prefix_tb__DOT__dut__DOT__loadall_service__DOT__image_q__v51 = 0;
    vlSelf->__Vdly__spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__ack_active_q = VL_RAND_RESET_I(1);
    vlSelf->__Vdly__spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__ack_second_q = VL_RAND_RESET_I(1);
    vlSelf->__Vdly__spk286_profile_prefix_tb__DOT__dut__DOT__ack_response_valid = VL_RAND_RESET_I(1);
    vlSelf->__Vdly__spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__ack_canceled_q = VL_RAND_RESET_I(1);
    vlSelf->__Vdly__spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__address_q = VL_RAND_RESET_I(24);
    vlSelf->__Vdly__spk286_profile_prefix_tb__DOT__dut__DOT__micro_active = VL_RAND_RESET_I(1);
    vlSelf->__Vdly__spk286_profile_prefix_tb__DOT__dut__DOT__micro_pc = VL_RAND_RESET_I(10);
    vlSelf->__Vdly__spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode__DOT__state_q = VL_RAND_RESET_I(3);
    vlSelf->__Vdly__spk286_profile_prefix_tb__DOT__dut__DOT__event_active = VL_RAND_RESET_I(1);
    vlSelf->__Vdly__spk286_profile_prefix_tb__DOT__dut__DOT__event_cancel = VL_RAND_RESET_I(1);
    vlSelf->__Vdly__spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__trap_sample_q = VL_RAND_RESET_I(1);
    vlSelf->__Vtrigprevexpr___TOP__spk286_profile_prefix_tb__DOT__clk__0 = VL_RAND_RESET_I(1);
}
