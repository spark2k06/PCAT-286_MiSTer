// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vspk286_profile_prefix_tb.h for the primary calling header

#include "Vspk286_profile_prefix_tb__pch.h"
#include "Vspk286_profile_prefix_tb___024root.h"

VL_INLINE_OPT void Vspk286_profile_prefix_tb___024root___nba_comb__TOP__0(Vspk286_profile_prefix_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_profile_prefix_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_profile_prefix_tb___024root___nba_comb__TOP__0\n"); );
    // Init
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT____VdfgTmp_h23c5909b__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT____VdfgTmp_h23c5909b__0 = 0;
    // Body
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__elapsed_next 
        = (0x7ffU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__elapsed_q) 
                     + (IData)(vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary)));
    if ((0x3ffU < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__elapsed_next))) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__elapsed_next = 0x3ffU;
    }
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_productive_boundary 
        = vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_elapsed_saturated 
        = ((0x3ffU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__elapsed_q)) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_productive_boundary) 
              & (0x3feU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__elapsed_q))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_head_permit 
        = ((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__pending_q) 
               | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__active_q) 
                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q)))) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary) 
              | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__admission_window_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefetch_queue__DOT__do_fill 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_response_valid) 
            & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable)) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_fill_ready));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_response_ready 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
           && (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_fill_ready));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__response_fire 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_response_ready) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_response_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__response_slot_available 
        = (1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_response_valid)) 
                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__response_fire)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__active_q) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__reset)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch__DOT__response_slot_available)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_abort_fetch 
        = ((0U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefetch_queue__DOT__count_q)) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_response_valid)) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                 & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__fetch_blocked) 
                    | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_fetch_invalid)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__fetch__request 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
           && ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
               & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active)) 
                  & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)) 
                     & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown)) 
                        & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault)) 
                              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__operand_blocked)) 
                                 & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_fetch_invalid)) 
                                    & (4U >= (0x1fU 
                                              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefetch_queue__DOT__count_q) 
                                                 + 
                                                 (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_response_valid)
                                                    ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_response_count)
                                                    : 0U) 
                                                  + 
                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)
                                                    ? 2U
                                                    : 0U))))))))))))));
    vlSelf->spk286_profile_prefix_tb__DOT__bus_valid 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__reset)) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__hlda)) 
              & ((2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                  ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__ack_active_q)
                  : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner))
                      ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__data_active_q)
                      : ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__lock_chain_q)) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_ready 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
           & ((1U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner)) 
              & ((2U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner)) 
                 & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready))));
    spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT____VdfgTmp_h23c5909b__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__bus_valid) 
           & (1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__selected_owner)));
    vlSelf->spk286_profile_prefix_tb__DOT__data_oe 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT____VdfgTmp_h23c5909b__0) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__write_q));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__data_complete 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT____VdfgTmp_h23c5909b__0) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ready));
}

VL_INLINE_OPT void Vspk286_profile_prefix_tb___024root___nba_sequent__TOP__2(Vspk286_profile_prefix_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_profile_prefix_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_profile_prefix_tb___024root___nba_sequent__TOP__2\n"); );
    // Body
    vlSelf->spk286_profile_prefix_tb__DOT__control_error 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__reset)) 
           & (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ip_write_en)) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__redirect)) 
              | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en) 
                 & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__redirect)) 
                    & (1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__restart 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error)) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__redirect));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__events__enable 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error)) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__reset)) 
                 & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__restart)))));
}

VL_INLINE_OPT void Vspk286_profile_prefix_tb___024root___nba_comb__TOP__1(Vspk286_profile_prefix_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_profile_prefix_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_profile_prefix_tb___024root___nba_comb__TOP__1\n"); );
    // Init
    CData/*7:0*/ spk286_profile_prefix_tb__DOT__segment_access;
    spk286_profile_prefix_tb__DOT__segment_access = 0;
    SData/*15:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__stack_offset;
    spk286_profile_prefix_tb__DOT__dut__DOT__stack_offset = 0;
    CData/*1:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__service_segment;
    spk286_profile_prefix_tb__DOT__dut__DOT__service_segment = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__stack_request;
    spk286_profile_prefix_tb__DOT__dut__DOT__stack_request = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_ready;
    spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_ready = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__string_request;
    spk286_profile_prefix_tb__DOT__dut__DOT__string_request = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__repeat_stepped;
    spk286_profile_prefix_tb__DOT__dut__DOT__repeat_stepped = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__counter_branch_request;
    spk286_profile_prefix_tb__DOT__dut__DOT__counter_branch_request = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode_enable;
    spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode_enable = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode_done;
    spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode_done = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__operand_request;
    spk286_profile_prefix_tb__DOT__dut__DOT__operand_request = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__operand_select_rm;
    spk286_profile_prefix_tb__DOT__dut__DOT__operand_select_rm = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__vector_request;
    spk286_profile_prefix_tb__DOT__dut__DOT__vector_request = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__software_request;
    spk286_profile_prefix_tb__DOT__dut__DOT__software_request = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__fault_request;
    spk286_profile_prefix_tb__DOT__dut__DOT__fault_request = 0;
    SData/*15:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__vector_offset;
    spk286_profile_prefix_tb__DOT__dut__DOT__vector_offset = 0;
    IData/*23:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__protected_descriptor_address;
    spk286_profile_prefix_tb__DOT__dut__DOT__protected_descriptor_address = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__protected_call_stack_access;
    spk286_profile_prefix_tb__DOT__dut__DOT__protected_call_stack_access = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__system_fault;
    spk286_profile_prefix_tb__DOT__dut__DOT__system_fault = 0;
    IData/*23:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__real_segment_base;
    spk286_profile_prefix_tb__DOT__dut__DOT__real_segment_base = 0;
    IData/*23:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__operand_physical_address;
    spk286_profile_prefix_tb__DOT__dut__DOT__operand_physical_address = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__profile_raw_operation_valid;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_raw_operation_valid = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__profile_deadline_ready;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_deadline_ready = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_continue;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_continue = 0;
    SData/*9:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks = 0;
    SData/*9:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_setup;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_setup = 0;
    CData/*2:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__profile_ea_clocks;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_ea_clocks = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__profile_execution_metadata_valid;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_execution_metadata_valid = 0;
    IData/*23:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__profile_execution_metadata_carry_save;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_execution_metadata_carry_save = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_outcome;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_outcome = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_count;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_count = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_target_length;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_target_length = 0;
    SData/*9:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__protected_call_range_fault;
    spk286_profile_prefix_tb__DOT__dut__DOT__protected_call_range_fault = 0;
    SData/*15:0*/ spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__registers__flags_write_mask;
    spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__registers__flags_write_mask = 0;
    SData/*15:0*/ spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__offset;
    spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__offset = 0;
    CData/*1:0*/ spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__read_index;
    spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__read_index = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_ha5f0a04c__0;
    spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_ha5f0a04c__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_he61ed21f__0;
    spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_he61ed21f__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_hc6c48371__0;
    spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_hc6c48371__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_hd259eb91__0;
    spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_hd259eb91__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata__DOT__string_form;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata__DOT__string_form = 0;
    SData/*12:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_budget_sum;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_budget_sum = 0;
    SData/*12:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_budget_carry;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_budget_carry = 0;
    SData/*12:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_adjustment_sum;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_adjustment_sum = 0;
    SData/*12:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_adjustment_carry;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_adjustment_carry = 0;
    SData/*12:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_adjustment;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_adjustment = 0;
    SData/*12:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_compare_sum;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_compare_sum = 0;
    SData/*12:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_compare_carry;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_compare_carry = 0;
    SData/*12:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_difference;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_difference = 0;
    SData/*15:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__selector;
    spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__selector = 0;
    CData/*3:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__access;
    spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__access = 0;
    CData/*1:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__dpl;
    spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__dpl = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__table_ok;
    spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__table_ok = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__type_ok;
    spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__type_ok = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__privilege_ok;
    spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__privilege_ok = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT____VdfgTmp_h761c2f8c__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT____VdfgTmp_h761c2f8c__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__microsequencer__DOT____VdfgTmp_h4bc99f05__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__microsequencer__DOT____VdfgTmp_h4bc99f05__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__io_write;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__io_write = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__io_privilege_check;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__io_privilege_check = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__if_control_operation;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__if_control_operation = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_count;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_count = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_read1;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_read1 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_store;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_store = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_empty;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_empty = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_range_fault;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_range_fault = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_push2;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_push2 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_pop2;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_pop2 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_call_frame;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_call_frame = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__add_allocation_sp;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__add_allocation_sp = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__counter_branch;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__counter_branch = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_push8;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_push8 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_pop8;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_pop8 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_stack_word;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_stack_word = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_rm32;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_rm32 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_bounds;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_bounds = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_frame_address;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_frame_address = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_pop_sp_commit;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_pop_sp_commit = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_range_fault;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_range_fault = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_operation;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_operation = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_table_store;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_table_store = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_msw_store;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_msw_store = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_ldtr_store;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_ldtr_store = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_tr_store;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_tr_store = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_protected_check;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_protected_check = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_privilege_check;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_privilege_check = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_check_operation;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_check_operation = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_operation;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_operation = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_operation;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_operation = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_privilege_fault;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_privilege_fault = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_lock_fault;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_lock_fault = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__npx_esc_check;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__npx_esc_check = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__npx_wait_check;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__npx_wait_check = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_selector_store;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_selector_store = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_operand_request;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_operand_request = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_operand_write;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_operand_write = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_arithmetic;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_arithmetic = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_ldtr;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_ldtr = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_access;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_access = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_limit;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_limit = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_access_valid;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_access_valid = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_write;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_write = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_post_fault;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_post_fault = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_high_word_valid;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_high_word_valid = 0;
    IData/*20:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_unused_end;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_unused_end = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_limit_valid;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_limit_valid = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_carry;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_carry = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__jmp_gate_probe_operation;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__jmp_gate_probe_operation = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__jmp_gate_cs_validation_operation;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__jmp_gate_cs_validation_operation = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_gate_access_valid;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_gate_access_valid = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_gate_cs_access_valid;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_gate_cs_access_valid = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_switch_operation;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_switch_operation = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_write;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_write = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_write;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_write = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_pop;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_pop = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_operation;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_operation = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_pre_fault;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_pre_fault = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_post_fault;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_post_fault = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_high_word_valid;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_high_word_valid = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_switch_operation;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_switch_operation = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_system_access_valid;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_system_access_valid = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_access_valid;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_access_valid = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_iret_cs_access_valid;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_iret_cs_access_valid = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_access_valid;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_access_valid = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_iret_ss_access_valid;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_iret_ss_access_valid = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_ss_access_valid;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_ss_access_valid = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_segment_access_valid;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_segment_access_valid = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_access_valid;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_access_valid = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allowed;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allowed = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__push_operation;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__push_operation = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__push_event_error;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__push_event_error = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__pop_operation;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__pop_operation = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__push_transfer;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__push_transfer = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__push_event_error_transfer;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__push_event_error_transfer = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_stack;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_stack = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__commit_context;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__commit_context = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__ack_operation;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__ack_operation = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__stack_service__push;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__stack_service__push = 0;
    SData/*15:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__sequential_gpr_write_data;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__sequential_gpr_write_data = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed = 0;
    IData/*19:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_onehot;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_onehot = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he95c168d__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he95c168d__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbb636733__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbb636733__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h82b5883d__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h82b5883d__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h8e881c59__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h8e881c59__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h9213fbb4__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h9213fbb4__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h6a853812__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h6a853812__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hc0c4091d__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hc0c4091d__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hfe54633e__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hfe54633e__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h09139821__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h09139821__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h657a4724__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h657a4724__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hb678200d__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hb678200d__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbabeeb40__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbabeeb40__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h2f04017f__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h2f04017f__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h4a6318ec__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h4a6318ec__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h273d8170__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h273d8170__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0c79368c__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0c79368c__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h8a02c0df__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h8a02c0df__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he66532ef__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he66532ef__0 = 0;
    CData/*7:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h503ab7d7__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h503ab7d7__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hb6f57119__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hb6f57119__0 = 0;
    CData/*7:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he0669a8c__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he0669a8c__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbdda3170__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbdda3170__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h63cacb15__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h63cacb15__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hac56e6d2__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hac56e6d2__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hf67482c1__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hf67482c1__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h07c77af6__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h07c77af6__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hd7d48636__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hd7d48636__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h2c23db46__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h2c23db46__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h7d92a0be__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h7d92a0be__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hd335f353__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hd335f353__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0cf4309e__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0cf4309e__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hd7564ff8__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hd7564ff8__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hc5701f43__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hc5701f43__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h4aae6acf__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h4aae6acf__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_heda1dc20__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_heda1dc20__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h827d400a__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h827d400a__0 = 0;
    IData/*17:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hfe63c0ca__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hfe63c0ca__0 = 0;
    IData/*16:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0cf40e08__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0cf40e08__0 = 0;
    SData/*15:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h1b07fba1__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h1b07fba1__0 = 0;
    SData/*14:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h11b3bff1__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h11b3bff1__0 = 0;
    SData/*13:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_haaf0e5de__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_haaf0e5de__0 = 0;
    SData/*12:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_ha69722db__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_ha69722db__0 = 0;
    SData/*11:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h52d684e9__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h52d684e9__0 = 0;
    SData/*10:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h9a87bc1e__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h9a87bc1e__0 = 0;
    SData/*9:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h02b1df34__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h02b1df34__0 = 0;
    SData/*8:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h21dc821c__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h21dc821c__0 = 0;
    CData/*7:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h13130501__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h13130501__0 = 0;
    CData/*6:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he78197c4__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he78197c4__0 = 0;
    CData/*5:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h87dd1c31__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h87dd1c31__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hac507719__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hac507719__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hd5c514d2__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hd5c514d2__0 = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he4d05fbc__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he4d05fbc__0 = 0;
    IData/*19:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector__DOT__descriptor_offset;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector__DOT__descriptor_offset = 0;
    IData/*24:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector__DOT__address_sum;
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector__DOT__address_sum = 0;
    SData/*15:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__register_word;
    spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__register_word = 0;
    CData/*0:0*/ spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT____VdfgTmp_h73c33177__0;
    spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT____VdfgTmp_h73c33177__0 = 0;
    SData/*9:0*/ __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__Vfuncout;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__Vfuncout = 0;
    SData/*9:0*/ __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__base;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__base = 0;
    SData/*9:0*/ __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__setup_clocks;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__setup_clocks = 0;
    SData/*9:0*/ __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__iteration_clocks;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__iteration_clocks = 0;
    CData/*2:0*/ __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__ea;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__ea = 0;
    CData/*0:0*/ __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__repeated;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__repeated = 0;
    CData/*0:0*/ __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__nonempty;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__nonempty = 0;
    CData/*0:0*/ __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__delivery;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__delivery = 0;
    CData/*3:0*/ __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__prefixes;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__prefixes = 0;
    CData/*3:0*/ __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__remaining_prefixes;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__remaining_prefixes = 0;
    SData/*11:0*/ __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__first;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__first = 0;
    SData/*11:0*/ __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__second;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__second = 0;
    SData/*11:0*/ __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__prefix_clocks;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__prefix_clocks = 0;
    SData/*11:0*/ __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__sum_bits;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__sum_bits = 0;
    SData/*11:0*/ __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__carry_bits;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__carry_bits = 0;
    SData/*11:0*/ __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__full_sum;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__full_sum = 0;
    SData/*15:0*/ __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout = 0;
    IData/*19:0*/ __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables = 0;
    VlWide<10>/*319:0*/ __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values;
    VL_ZERO_W(320, __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values);
    VlWide<4>/*127:0*/ __Vtemp_8;
    CData/*31:0*/ __Vdeeptemp_h4ad99da3__0;
    // Body
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_preserve_cancel 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__restart)) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_cancel) 
              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active) 
                 & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_software))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__execution_allowed 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error)) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__reset)) 
                 & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__restart)) 
                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__operand_blocked)) 
                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                          & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown)) 
                             & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__halted)) 
                                | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_active)))))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__semantic_cancel 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__restart) 
           | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_cancel));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_fetch_fault 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_fetch_invalid) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__execution_allowed) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active)) 
                 & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_active)) 
                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_head_permit)))));
    spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT____VdfgTmp_h761c2f8c__0 
        = (1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__reset)) 
                 & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__semantic_cancel) 
                       | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__data_active_q) 
                          | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT__ack_active_q) 
                             | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__memory_response_valid)))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__microsequencer__DOT____VdfgTmp_h4bc99f05__0 
        = ((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__semantic_cancel) 
               | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__reset))) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__execution_allowed));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__ack_request_ready 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT____VdfgTmp_h761c2f8c__0) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__ack_response_valid)) 
              & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__hlda))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__memory_request_ready 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__hlda)) 
           & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__biu__DOT____VdfgTmp_h761c2f8c__0));
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_raw_operation_valid 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__microsequencer__DOT____VdfgTmp_h4bc99f05__0) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_active) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault)) 
                 & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_valid) 
                    & ((3U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                       & (0x2e7U > (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_pc)))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_decode_ready 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__microsequencer__DOT____VdfgTmp_h4bc99f05__0) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_active)) 
              & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__microcode_fault))));
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_continue 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_raw_operation_valid) 
           & ((IData)(vlSelf->__VdfgTmp_hc8706df8__0) 
              & (0x80U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__decode_ready 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_decode_ready) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active) 
              | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_head_permit)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_dispatch 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__dispatch_pending_q) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_decode_ready) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__events__enable)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h41f92d96__0 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active)) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__decode_ready));
    if (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_dispatch) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h45d69300__0 
            = (1U & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_software)));
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__microsequencer__start_entry 
            = ((1U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
                ? 0x89U : 0x78U);
    } else {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h45d69300__0 = 0U;
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__microsequencer__start_entry 
            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__decode_entry;
    }
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_dispatch) 
           | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_software)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__service_start 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_dispatch) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h41f92d96__0) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__raw_retired)) 
                 & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__event_completed)) 
                    & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_valid) 
                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__is_prefix)) 
                          & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__decode_supported)))))));
    if (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata) {
        spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry 
            = ((1U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
                ? 0x89U : 0x78U);
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode = 0U;
    } else if (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_candidate_body) {
        spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry 
            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__decode_entry;
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode 
            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data;
    } else {
        spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry 
            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_entry;
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode 
            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q;
    }
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_execution_metadata_carry_save 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)
            ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_event_base) 
               << 0xcU) : ([&]() {
                vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__prefixes 
                    = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q;
                vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__nonempty 
                    = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_nonempty_q;
                vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__repeated 
                    = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_execution_repeated;
                vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__ea 
                    = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_execution_ea;
                vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__iteration_clocks 
                    = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_execution_repeat_iteration;
                vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__setup_clocks 
                    = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_execution_repeat_setup;
                vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__base 
                    = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_execution_base;
                vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__remaining_prefixes 
                    = ((0U == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__prefixes))
                        ? 0U : (0xfU & ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__prefixes) 
                                        - (IData)(1U))));
                vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__first 
                    = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__repeated)
                        ? (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__setup_clocks)
                        : (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__base));
                vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__second 
                    = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__repeated)
                        ? ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__nonempty)
                            ? (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__iteration_clocks)
                            : 0U) : (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__ea));
                vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__prefix_clocks 
                    = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__repeated)
                        ? ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__remaining_prefixes) 
                           << 1U) : ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__prefixes) 
                                     << 1U));
                vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__sum_bits 
                    = (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__first) 
                        ^ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__second)) 
                       ^ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__prefix_clocks));
                vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__carry_bits 
                    = (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__first) 
                        & ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__second) 
                           | (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__prefix_clocks))) 
                       | ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__second) 
                          & (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__prefix_clocks)));
                vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__Vfuncout 
                    = (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__sum_bits) 
                        << 0xcU) | (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__carry_bits));
            }(), vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget_carry_save__210__Vfuncout));
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_execution_metadata_valid 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata)
            ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_event_metadata_valid)
            : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_instruction_metadata_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__adjust_service__cancel 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__semantic_cancel) 
           | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__service_start));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbdda3170__0 
        = (1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__reset)) 
                 & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__semantic_cancel)) 
                    & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__service_start) 
                          | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_switch_skip) 
                             | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_return_skip) 
                                | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_event_switch_skip))))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_target_length = 0U;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 0U;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_outcome = 0U;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_count = 0U;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_ea_clocks = 0U;
    if ((0x200U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
        if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                      >> 8U)))) {
            if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                          >> 7U)))) {
                if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                              >> 6U)))) {
                    if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                  >> 5U)))) {
                        if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                          >> 2U)))) {
                                if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                              >> 1U)))) {
                                    if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_target_length = 1U;
                                    }
                                }
                            }
                        } else if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                             >> 3U)))) {
                            if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                    if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_target_length 
                                            = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_modrm_current) 
                                               & (3U 
                                                  != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode)));
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if ((0x80U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((0x40U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                  >> 5U)))) {
                        if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                              >> 2U)))) {
                                    if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                                  >> 1U)))) {
                                        if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                        }
                                    }
                                }
                            } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                              >> 1U)))) {
                                    if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                    }
                                }
                            }
                        } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                }
                            }
                        } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                }
                            }
                        } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                            }
                        }
                    }
                } else if ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                    if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                    }
                                } else if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                }
                            } else if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                                 >> 1U)))) {
                                if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                }
                            }
                        } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                }
                            } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                            }
                        } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                            }
                        } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                        }
                    } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                }
                            } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                            }
                        } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                            }
                        } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                        }
                    } else if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                         >> 2U)))) {
                        if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                            }
                        }
                    }
                }
            } else if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                 >> 6U)))) {
                if ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                          >> 2U)))) {
                                if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                              >> 1U)))) {
                                    if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                    }
                                }
                            }
                        } else if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                             >> 2U)))) {
                            if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                }
                            }
                        }
                    } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                      >> 2U)))) {
                            if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                }
                            }
                        }
                    } else if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                         >> 2U)))) {
                        if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                            }
                        }
                    }
                } else if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                     >> 4U)))) {
                    if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                  >> 3U)))) {
                        if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                }
                            }
                        }
                    }
                }
            }
        }
        spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
            = (0x3ffU & ((0x100U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                          ? 2U : ((0x80U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                   ? ((0x40U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                       ? ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                           ? ((0x10U 
                                               & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? 2U
                                               : ((8U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 2U
                                                   : 
                                                  ((4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 2U
                                                     : 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 0xc3U
                                                      : 2U)))))
                                           : ((0x10U 
                                               & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? ((8U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 
                                                  ((4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 2U
                                                     : 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 
                                                     ((3U 
                                                       != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                       ? 0xbU
                                                       : 0xaU)
                                                      : 2U)))
                                                   : 
                                                  ((4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 2U
                                                     : 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 2U
                                                      : 
                                                     ((3U 
                                                       != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                       ? 0x10U
                                                       : 0xeU)))
                                                    : 2U))
                                               : ((8U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 
                                                  ((2U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 
                                                    ((3U 
                                                      != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                      ? 0x10U
                                                      : 0xeU)
                                                     : 2U)
                                                    : 2U)
                                                   : 
                                                  ((4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 
                                                     ((3U 
                                                       != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                       ? 0x10U
                                                       : 0xeU)
                                                      : 2U)
                                                     : 2U)
                                                    : 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 
                                                     ((3U 
                                                       != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                       ? 0x13U
                                                       : 0x11U)
                                                      : 2U)
                                                     : 2U)))))
                                       : ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                           ? ((0x10U 
                                               & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? ((8U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 
                                                  ((4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 
                                                     ((3U 
                                                       != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                       ? 0x13U
                                                       : 0x11U)
                                                      : 2U)
                                                     : 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 2U
                                                      : 
                                                     ((3U 
                                                       != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                       ? 3U
                                                       : 2U)))
                                                    : 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 2U
                                                     : 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 
                                                     ((3U 
                                                       != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                       ? 3U
                                                       : 2U)
                                                      : 2U)))
                                                   : 
                                                  ((4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 
                                                     ((4U 
                                                       & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                       ? 
                                                      ((2U 
                                                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                        ? 2U
                                                        : 
                                                       ((3U 
                                                         != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                         ? 0x10U
                                                         : 0xeU))
                                                       : 
                                                      ((2U 
                                                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                        ? 
                                                       ((3U 
                                                         != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                         ? 0x13U
                                                         : 0x11U)
                                                        : 
                                                       ((3U 
                                                         != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                         ? 3U
                                                         : 2U)))
                                                      : 2U)
                                                     : 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 
                                                     ((3U 
                                                       != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                       ? 6U
                                                       : 3U)
                                                      : 2U))
                                                    : 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 
                                                     ((3U 
                                                       != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                       ? 3U
                                                       : 2U)
                                                      : 2U)
                                                     : 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 0xcU
                                                      : 2U))))
                                               : ((8U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 
                                                  ((4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 0xbU
                                                      : 2U)
                                                     : 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 0xcU
                                                      : 2U))
                                                    : 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 0xbU
                                                      : 2U)
                                                     : 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 
                                                     ((4U 
                                                       & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                       ? 
                                                      ((2U 
                                                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                        ? 
                                                       ((1U 
                                                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                         ? 2U
                                                         : 
                                                        ((3U 
                                                          != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                          ? 6U
                                                          : 3U))
                                                        : 
                                                       ((1U 
                                                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                         ? 2U
                                                         : 
                                                        ((3U 
                                                          != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                          ? 3U
                                                          : 2U)))
                                                       : 
                                                      ((1U 
                                                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                        ? 0xcU
                                                        : 0xbU))
                                                      : 2U)))
                                                   : 
                                                  ((4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 3U
                                                      : 2U)
                                                     : 2U)
                                                    : 2U)))
                                           : ((0x10U 
                                               & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? ((8U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 
                                                  ((4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 2U
                                                      : 5U)
                                                     : 2U))
                                                   : 
                                                  ((4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 2U
                                                     : 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 5U
                                                      : 2U))))
                                               : ((8U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 
                                                  ((4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 2U
                                                     : 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 2U
                                                      : 5U)))
                                                   : 2U))))
                                   : ((0x40U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                       ? ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                           ? ((0x10U 
                                               & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? ((8U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 
                                                  ((4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 5U
                                                      : 2U)
                                                     : 2U)
                                                    : 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 2U
                                                      : 3U)
                                                     : 2U))
                                                   : 
                                                  ((4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 2U
                                                     : 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 3U
                                                      : 2U))
                                                    : 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 2U
                                                     : 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 2U
                                                      : 5U))))
                                               : ((8U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 
                                                  ((4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 5U
                                                      : 2U)
                                                     : 2U))
                                                   : 
                                                  ((4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 2U
                                                     : 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 7U
                                                      : 2U)))))
                                           : ((0x10U 
                                               & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? ((8U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 
                                                  ((4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 2U
                                                      : 5U)
                                                     : 2U))
                                                   : 
                                                  ((4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 3U
                                                      : 2U)
                                                     : 2U)))
                                               : ((8U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 
                                                  ((4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 2U
                                                     : 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 2U
                                                      : 8U)))
                                                   : 
                                                  ((4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 2U
                                                     : 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 2U
                                                      : 5U))))))
                                       : ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                           ? ((0x10U 
                                               & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? ((8U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 
                                                  ((4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 2U
                                                     : 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 
                                                     ((3U 
                                                       != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                       ? 0x18U
                                                       : 0x15U)
                                                      : 2U)))
                                                   : 
                                                  ((4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 2U
                                                      : 
                                                     ((3U 
                                                       != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                       ? 0x18U
                                                       : 0x15U))
                                                     : 2U)))
                                               : ((8U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 
                                                  ((4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 2U
                                                      : 
                                                     ((4U 
                                                       & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                       ? 
                                                      ((2U 
                                                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                        ? 
                                                       ((1U 
                                                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                         ? 
                                                        (((1U 
                                                           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))
                                                           ? 0x19U
                                                           : 0x11U) 
                                                         + 
                                                         ((3U 
                                                           != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                           ? 3U
                                                           : 0U))
                                                         : 
                                                        (((1U 
                                                           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))
                                                           ? 0x16U
                                                           : 0xeU) 
                                                         + 
                                                         ((3U 
                                                           != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                           ? 3U
                                                           : 0U)))
                                                        : 
                                                       (((1U 
                                                          & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))
                                                          ? 0x15U
                                                          : 0xdU) 
                                                        + 
                                                        ((3U 
                                                          != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                          ? 3U
                                                          : 0U)))
                                                       : 
                                                      ((2U 
                                                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                        ? 
                                                       ((3U 
                                                         != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                         ? 7U
                                                         : 2U)
                                                        : 
                                                       ((1U 
                                                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                         ? 2U
                                                         : 
                                                        ((3U 
                                                          != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                          ? 6U
                                                          : 3U)))))
                                                     : 2U))
                                                   : 
                                                  ((4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 
                                                     ((4U 
                                                       & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                       ? 
                                                      ((2U 
                                                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                        ? 
                                                       ((1U 
                                                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                         ? 
                                                        (((1U 
                                                           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))
                                                           ? 0x19U
                                                           : 0x11U) 
                                                         + 
                                                         ((3U 
                                                           != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                           ? 3U
                                                           : 0U))
                                                         : 
                                                        (((1U 
                                                           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))
                                                           ? 0x16U
                                                           : 0xeU) 
                                                         + 
                                                         ((3U 
                                                           != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                           ? 3U
                                                           : 0U)))
                                                        : 
                                                       (((1U 
                                                          & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))
                                                          ? 0x15U
                                                          : 0xdU) 
                                                        + 
                                                        ((3U 
                                                          != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                          ? 3U
                                                          : 0U)))
                                                       : 
                                                      ((2U 
                                                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                        ? 
                                                       ((3U 
                                                         != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                         ? 7U
                                                         : 2U)
                                                        : 
                                                       ((1U 
                                                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                         ? 2U
                                                         : 
                                                        ((3U 
                                                          != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                          ? 6U
                                                          : 3U))))
                                                      : 2U)
                                                     : 2U))))
                                           : ((0x10U 
                                               & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? ((4U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 2U
                                                   : 
                                                  ((2U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 
                                                   ((1U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 2U
                                                     : 
                                                    ((1U 
                                                      & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
                                                      ? 0x19U
                                                      : 0xfU))))
                                               : ((8U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 2U
                                                   : 
                                                  ((4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
                                                       ? 0x1aU
                                                       : 0xfU)
                                                      : 2U)
                                                     : 2U)
                                                    : 2U))))))));
    } else if ((0x100U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
        if ((0x80U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((0x40U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                      >> 3U)))) {
                            if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                          >> 2U)))) {
                                if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                    if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_target_length 
                                            = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_modrm_current) 
                                               & (3U 
                                                  != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode)));
                                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                    }
                                }
                            }
                        }
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                            = (0x3ffU & ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                          ? 2U : ((4U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 2U
                                                   : 
                                                  ((2U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 2U
                                                     : 
                                                    ((1U 
                                                      & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
                                                      ? 0x1dU
                                                      : 0x10U))
                                                    : 2U))));
                    } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                          >> 1U)))) {
                                if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_target_length = 1U;
                                }
                            }
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                                = (0x3ffU & ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                              ? 2U : 
                                             ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? 2U
                                               : ((1U 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
                                                   ? 0x17U
                                                   : 0xbU))));
                        } else {
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                                = (0x3ffU & 2U);
                        }
                    } else {
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                            = (0x3ffU & 2U);
                    }
                } else if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                      >> 2U)))) {
                            if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_target_length = 1U;
                                }
                            }
                        }
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                            = (0x3ffU & ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                          ? 2U : ((2U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 
                                                  ((1U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 
                                                   ((1U 
                                                     & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
                                                     ? 0x1aU
                                                     : 0xdU))
                                                   : 2U)));
                    } else {
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                            = (0x3ffU & ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                          ? 2U : ((2U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 2U
                                                   : 
                                                  ((1U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 
                                                   ((1U 
                                                     & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
                                                     ? 0x15U
                                                     : 7U)))));
                    }
                    if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                  >> 3U)))) {
                        if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                      >> 2U)))) {
                            if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                          >> 1U)))) {
                                if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                }
                            }
                        }
                    }
                } else {
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                        = (0x3ffU & ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                      ? 2U : ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? ((2U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 
                                                  ((1U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 0xdU
                                                    : 2U)
                                                   : 2U)
                                               : ((2U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 2U
                                                   : 
                                                  ((1U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 5U
                                                    : 2U)))));
                    if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                  >> 3U)))) {
                        if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                }
                            }
                        } else if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                             >> 1U)))) {
                            if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm 
                                    = (0x39U == (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry));
                            }
                        }
                    }
                }
            } else if ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                    = (0x3ffU & ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                  ? 2U : ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                           ? ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? 2U
                                               : ((2U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 2U
                                                   : 
                                                  ((1U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 
                                                   ((0U 
                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_count_q))
                                                     ? 0xbU
                                                     : 
                                                    ((1U 
                                                      == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_count_q))
                                                      ? 0xfU
                                                      : 
                                                     ((IData)(0xcU) 
                                                      + 
                                                      ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_count_q) 
                                                       << 2U)))))))
                                           : 2U)));
                if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                              >> 4U)))) {
                    if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                      >> 2U)))) {
                            if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                          >> 1U)))) {
                                if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_count = 1U;
                                }
                            }
                        }
                    }
                }
            } else {
                spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                    = (0x3ffU & ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                  ? ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                      ? 2U : ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? ((2U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 
                                                  ((1U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 0x13U
                                                    : 2U)
                                                   : 2U)
                                               : 2U))
                                  : ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                      ? 2U : ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? 2U
                                               : ((2U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 
                                                  ((1U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 0x11U
                                                    : 2U)
                                                   : 
                                                  ((1U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 
                                                   ((1U 
                                                     & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
                                                     ? 0x14U
                                                     : 5U)))))));
            }
        } else {
            if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                          >> 6U)))) {
                if ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                          >> 2U)))) {
                                if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                    if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                        if ((4U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))) {
                                            if ((1U 
                                                 & (~ 
                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg) 
                                                     >> 1U)))) {
                                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_target_length 
                                                    = 
                                                    ((1U 
                                                      & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                      ? 
                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_modrm_current) 
                                                      & (3U 
                                                         != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode)))
                                                      : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_modrm_current));
                                            }
                                        } else if (
                                                   (2U 
                                                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))) {
                                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_target_length 
                                                = (
                                                   (1U 
                                                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                    ? 
                                                   ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_modrm_current) 
                                                    & (3U 
                                                       != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode)))
                                                    : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_modrm_current));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if ((0x40U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                                = (0x3ffU & ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                              ? ((2U 
                                                  & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                  ? 2U
                                                  : 
                                                 ((1U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 3U
                                                   : 2U))
                                              : ((2U 
                                                  & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                  ? 2U
                                                  : 
                                                 ((1U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 
                                                  ((1U 
                                                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
                                                    ? 
                                                   ((3U 
                                                     != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                     ? 0x13U
                                                     : 0x11U)
                                                    : 
                                                   ((3U 
                                                     != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                     ? 5U
                                                     : 2U))
                                                   : 2U))));
                            if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                          >> 2U)))) {
                                if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                              >> 1U)))) {
                                    if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                    }
                                }
                            }
                        } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                                = (0x3ffU & ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                              ? 2U : 
                                             ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? ((3U 
                                                   != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                   ? 3U
                                                   : 2U)
                                               : 2U)));
                            if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                          >> 1U)))) {
                                if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                }
                            }
                        } else {
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                                = (0x3ffU & 2U);
                        }
                    } else {
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                            = (0x3ffU & ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                          ? ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                              ? ((2U 
                                                  & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                  ? 
                                                 ((1U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 2U
                                                   : 
                                                  ((0xd4U 
                                                    == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))
                                                    ? 0x10U
                                                    : 0xeU))
                                                  : 2U)
                                              : 2U)
                                          : ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                              ? ((2U 
                                                  & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                  ? 
                                                 ((1U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 3U
                                                   : 2U)
                                                  : 2U)
                                              : ((2U 
                                                  & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                  ? 2U
                                                  : 
                                                 ((1U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 2U
                                                   : 
                                                  ((3U 
                                                    != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                    ? 7U
                                                    : 2U))))));
                        if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                      >> 3U)))) {
                            if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                          >> 2U)))) {
                                if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                              >> 1U)))) {
                                    if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                    }
                                }
                            }
                        }
                    }
                } else if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                            = (0x3ffU & ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                          ? 2U : ((2U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 2U
                                                   : 
                                                  ((1U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 
                                                   ((3U 
                                                     != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                     ? 7U
                                                     : 2U)
                                                    : 2U))));
                        if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                      >> 2U)))) {
                            if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                          >> 1U)))) {
                                if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                }
                            }
                        }
                    } else {
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                            = (0x3ffU & ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                          ? 2U : ((2U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 
                                                  ((1U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 
                                                   ((3U 
                                                     != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                     ? 7U
                                                     : 2U))
                                                   : 2U)));
                        if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                      >> 2U)))) {
                            if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                }
                            }
                        }
                    }
                } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                        = (0x3ffU & ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                      ? 2U : ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? ((1U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 
                                                  ((3U 
                                                    != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                    ? 7U
                                                    : 2U)
                                                   : 2U)
                                               : 2U)));
                    if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                  >> 2U)))) {
                        if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                            }
                        }
                    }
                } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                        = (0x3ffU & ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                      ? 2U : ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? 2U
                                               : ((3U 
                                                   != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                   ? 7U
                                                   : 2U))));
                    if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                  >> 1U)))) {
                        if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                        }
                    }
                } else {
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                        = (0x3ffU & 2U);
                }
            } else if ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                                = (0x3ffU & ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                              ? 2U : 
                                             ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? ((3U 
                                                   != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                   ? 7U
                                                   : 2U)
                                               : 2U)));
                            if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                          >> 1U)))) {
                                if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                }
                            }
                        } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                                    = (0x3ffU & ((4U 
                                                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                  ? 
                                                 ((2U 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                   ? 
                                                  ((1U 
                                                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                    ? 2U
                                                    : 
                                                   ((3U 
                                                     != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                     ? 5U
                                                     : 3U))
                                                   : 
                                                  ((1U 
                                                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
                                                     ? 0x1aU
                                                     : 0xfU)
                                                    : 
                                                   ((3U 
                                                     != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                     ? 0xbU
                                                     : 7U)))
                                                  : 
                                                 ((2U 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                   ? 
                                                  ((1U 
                                                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
                                                     ? 0x1dU
                                                     : 0x10U)
                                                    : 
                                                   ((3U 
                                                     != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                     ? 0xbU
                                                     : 7U))
                                                   : 
                                                  ((3U 
                                                    != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                    ? 7U
                                                    : 2U))));
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                            } else {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                                    = (0x3ffU & 2U);
                            }
                        } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                                = (0x3ffU & ((4U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                              ? ((2U 
                                                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                  ? 
                                                 ((1U 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                   ? 
                                                  (((1U 
                                                     & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))
                                                     ? 0x19U
                                                     : 0x11U) 
                                                   + 
                                                   ((3U 
                                                     != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                     ? 3U
                                                     : 0U))
                                                   : 
                                                  (((1U 
                                                     & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))
                                                     ? 0x16U
                                                     : 0xeU) 
                                                   + 
                                                   ((3U 
                                                     != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                     ? 3U
                                                     : 0U)))
                                                  : 
                                                 (((1U 
                                                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))
                                                    ? 0x15U
                                                    : 0xdU) 
                                                  + 
                                                  ((3U 
                                                    != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                    ? 3U
                                                    : 0U)))
                                              : ((2U 
                                                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                  ? 
                                                 ((3U 
                                                   != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                   ? 7U
                                                   : 2U)
                                                  : 
                                                 ((1U 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                   ? 2U
                                                   : 
                                                  ((3U 
                                                    != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                    ? 6U
                                                    : 3U)))));
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                        } else {
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                                = (0x3ffU & 2U);
                        }
                    } else {
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                            = (0x3ffU & ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                          ? 2U : ((2U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 
                                                  ((1U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 5U
                                                    : 2U)
                                                   : 2U)));
                    }
                } else {
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                        = (0x3ffU & ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                      ? ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                          ? ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                              ? ((1U 
                                                  & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                  ? 2U
                                                  : 3U)
                                              : 2U)
                                          : ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                              ? 2U : 
                                             ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? 3U
                                               : 2U)))
                                      : ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                          ? ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                              ? 2U : 
                                             ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? 2U
                                               : 5U))
                                          : 2U)));
                }
            } else if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                    = (0x3ffU & ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                  ? ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                      ? ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                          ? ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                              ? 5U : 2U)
                                          : 2U) : (
                                                   (2U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 2U
                                                     : 3U)
                                                    : 2U))
                                  : ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                      ? ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                          ? 2U : ((1U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 2U
                                                   : 
                                                  ((3U 
                                                    != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                    ? 5U
                                                    : 3U)))
                                      : 2U)));
                if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                              >> 3U)))) {
                    if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                      >> 1U)))) {
                            if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                            }
                        }
                    }
                }
            } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                            = (0x3ffU & ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                          ? 2U : ((3U 
                                                   != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                   ? 5U
                                                   : 3U)));
                        if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                        }
                    } else {
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                            = (0x3ffU & 2U);
                    }
                } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                        = (0x3ffU & ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                      ? 2U : 3U));
                    if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                    }
                } else {
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                        = (0x3ffU & 2U);
                }
            } else {
                spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                    = (0x3ffU & ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                  ? 2U : ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                           ? ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? ((
                                                   (3U 
                                                    != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                    ? 8U
                                                    : 5U) 
                                                  + (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_count_q))
                                               : 2U)
                                           : 2U)));
                if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                              >> 2U)))) {
                    if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_count = 1U;
                        }
                    }
                }
            }
        }
    } else {
        if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                      >> 7U)))) {
            if ((0x40U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                              >> 5U)))) {
                    if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                          >> 2U)))) {
                                if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                    if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_target_length = 1U;
                                    }
                                }
                            }
                        } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_target_length = 1U;
                                }
                            }
                        } else if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                             >> 1U)))) {
                            if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_target_length 
                                    = (0xe3U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode));
                            }
                        }
                    } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                          >> 1U)))) {
                                if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_target_length = 1U;
                                }
                            }
                        } else if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                             >> 1U)))) {
                            if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_target_length = 1U;
                            }
                        }
                    } else if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                         >> 2U)))) {
                        if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_target_length = 1U;
                            }
                        }
                    }
                }
            } else if ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                          >> 1U)))) {
                                if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                    if ((4U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))) {
                                        if ((1U & (~ 
                                                   ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg) 
                                                    >> 1U)))) {
                                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_target_length 
                                                = (
                                                   (1U 
                                                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                    ? 
                                                   ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_modrm_current) 
                                                    & (3U 
                                                       != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode)))
                                                    : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_modrm_current));
                                        }
                                    } else if ((2U 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))) {
                                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_target_length 
                                            = ((1U 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_modrm_current) 
                                                   & (3U 
                                                      != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode)))
                                                : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_modrm_current));
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if ((0x80U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((0x40U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                                    = (0x3ffU & ((2U 
                                                  & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                  ? 2U
                                                  : 
                                                 ((1U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 2U
                                                   : 
                                                  (((3U 
                                                     != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                     ? 8U
                                                     : 5U) 
                                                   + (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_count_q)))));
                                if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                              >> 1U)))) {
                                    if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_count = 1U;
                                    }
                                }
                            } else {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                                    = (0x3ffU & 2U);
                            }
                        } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                                = (0x3ffU & ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                              ? 2U : 
                                             ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? ((3U 
                                                   != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                   ? 7U
                                                   : 2U)
                                               : 2U)));
                            if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                          >> 1U)))) {
                                if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                }
                            }
                        } else {
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                                = (0x3ffU & 2U);
                        }
                    } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                                    = (0x3ffU & ((1U 
                                                  & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                  ? 2U
                                                  : 
                                                 (((3U 
                                                    != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                    ? 8U
                                                    : 5U) 
                                                  + (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_count_q))));
                                if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_count = 1U;
                                }
                            } else {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                                    = (0x3ffU & 2U);
                            }
                        } else {
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                                = (0x3ffU & 2U);
                        }
                    } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                                    = (0x3ffU & (((3U 
                                                   != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                   ? 8U
                                                   : 5U) 
                                                 + (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_count_q)));
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_count = 1U;
                            } else {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                                    = (0x3ffU & 2U);
                            }
                        } else {
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                                = (0x3ffU & 2U);
                        }
                    } else {
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                            = (0x3ffU & ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                          ? 2U : ((1U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 2U
                                                   : 
                                                  ((3U 
                                                    != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                    ? 7U
                                                    : 2U))));
                        if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                      >> 1U)))) {
                            if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                            }
                        }
                    }
                } else {
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                        = (0x3ffU & ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                      ? 2U : ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? 2U
                                               : ((4U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 
                                                  ((2U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 2U
                                                     : 
                                                    ((3U 
                                                      != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                      ? 
                                                     ((7U 
                                                       == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                       ? 6U
                                                       : 7U)
                                                      : 3U))
                                                    : 2U)
                                                   : 
                                                  ((2U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 
                                                   ((1U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 2U
                                                     : 3U))))));
                    if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                  >> 4U)))) {
                        if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                      >> 3U)))) {
                            if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                    if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                    }
                                }
                            }
                        }
                    }
                }
            } else if ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                            = (0x3ffU & ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                          ? 2U : ((2U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 2U
                                                   : 
                                                  ((1U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 
                                                   ((3U 
                                                     != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                     ? 
                                                    ((7U 
                                                      == 
                                                      (7U 
                                                       & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode) 
                                                          >> 3U)))
                                                      ? 6U
                                                      : 7U)
                                                     : 2U)
                                                    : 2U))));
                        if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                      >> 2U)))) {
                            if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                          >> 1U)))) {
                                if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                }
                            }
                        }
                    } else {
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                            = (0x3ffU & ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                          ? 2U : ((2U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 
                                                  ((1U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 
                                                   ((3U 
                                                     != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                     ? 
                                                    (((0x84U 
                                                       == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                                      | (0x85U 
                                                         == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)))
                                                      ? 6U
                                                      : 7U)
                                                     : 2U))
                                                   : 2U)));
                        if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                      >> 2U)))) {
                            if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                                }
                            }
                        }
                    }
                } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                            = (0x3ffU & ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                          ? 2U : ((3U 
                                                   != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                   ? 3U
                                                   : 2U)));
                        if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                        }
                    } else {
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                            = (0x3ffU & 2U);
                    }
                } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                            = (0x3ffU & ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                          ? 2U : ((3U 
                                                   != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                   ? 5U
                                                   : 2U)));
                        if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                        }
                    } else {
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                            = (0x3ffU & 2U);
                    }
                } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                        = (0x3ffU & ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                      ? 2U : ((3U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                               ? 3U
                                               : 2U)));
                    if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                    }
                } else {
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                        = (0x3ffU & 2U);
                }
            } else {
                spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                    = (0x3ffU & ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                  ? 2U : ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                           ? ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? 2U
                                               : ((2U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 2U
                                                   : 
                                                  ((1U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 0x28U
                                                    : 2U)))
                                           : 2U)));
            }
        } else if ((0x40U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                    = (0x3ffU & ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                  ? ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                      ? ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                          ? 2U : ((2U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 2U
                                                   : 
                                                  ((1U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 0x17U)))
                                      : 2U) : ((8U 
                                                & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                ? (
                                                   (4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
                                                       ? 0x1fU
                                                       : 0x11U)
                                                      : 2U)
                                                     : 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 2U
                                                      : 
                                                     (((0xceU 
                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_branch_taken_q)))
                                                       ? 3U
                                                       : 
                                                      ((1U 
                                                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
                                                        ? 0x28U
                                                        : 
                                                       ((0xceU 
                                                         == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))
                                                         ? 0x18U
                                                         : 0x17U)))))
                                                    : 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 2U
                                                      : 
                                                     (((0xceU 
                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                                       & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_branch_taken_q)))
                                                       ? 3U
                                                       : 
                                                      ((1U 
                                                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
                                                        ? 0x28U
                                                        : 
                                                       ((0xceU 
                                                         == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))
                                                         ? 0x18U
                                                         : 0x17U))))
                                                     : 2U))
                                                : (
                                                   (4U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 2U
                                                      : 
                                                     ((0xfaU 
                                                       == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))
                                                       ? 3U
                                                       : 2U))
                                                     : 2U)
                                                    : 
                                                   ((2U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 5U
                                                      : 2U)
                                                     : 
                                                    ((1U 
                                                      & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                      ? 2U
                                                      : 3U))))));
                if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                              >> 4U)))) {
                    if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                          >> 1U)))) {
                                if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_outcome 
                                        = (0xceU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode));
                                }
                            }
                        } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_outcome 
                                    = (0xceU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode));
                            }
                        }
                    } else if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                         >> 2U)))) {
                        if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm 
                                    = (0x39U == (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry));
                            }
                        }
                    }
                }
            } else if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                    = (0x3ffU & ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                  ? ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                      ? 2U : ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? ((1U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 2U
                                                   : 0xbU)
                                               : 2U))
                                  : ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                      ? ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                          ? ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                              ? 2U : 0xbU)
                                          : 2U) : (
                                                   (2U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 2U
                                                    : 
                                                   ((1U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 
                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_branch_taken_q)
                                                      ? 
                                                     ((0xe3U 
                                                       == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))
                                                       ? 7U
                                                       : 8U)
                                                      : 4U)
                                                     : 2U)))));
                if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                              >> 3U)))) {
                    if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                  >> 2U)))) {
                        if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                      >> 1U)))) {
                            if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_outcome = 1U;
                            }
                        }
                    }
                }
            } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                        = (0x3ffU & ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                      ? 2U : ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? ((
                                                   (0xebU 
                                                    == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                                   | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_branch_taken_q))
                                                   ? 7U
                                                   : 3U)
                                               : 2U)));
                    if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                  >> 1U)))) {
                        if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_outcome 
                                = (0xebU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode));
                        }
                    }
                } else {
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                        = (0x3ffU & ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                      ? 2U : ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? 7U
                                               : 2U)));
                }
            } else {
                spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                    = (0x3ffU & ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                  ? 2U : ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                           ? ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? 7U
                                               : 2U)
                                           : 2U)));
            }
        } else if ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                            = (0x3ffU & ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                          ? 2U : ((1U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 
                                                  ((4U 
                                                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                    ? 
                                                   ((2U 
                                                     & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                     ? 
                                                    ((1U 
                                                      & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                      ? 2U
                                                      : 
                                                     ((3U 
                                                       != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                       ? 5U
                                                       : 3U))
                                                     : 
                                                    ((1U 
                                                      & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
                                                       ? 0x1aU
                                                       : 0xfU)
                                                      : 
                                                     ((3U 
                                                       != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                       ? 0xbU
                                                       : 7U)))
                                                    : 
                                                   ((2U 
                                                     & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                     ? 
                                                    ((1U 
                                                      & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
                                                       ? 0x1dU
                                                       : 0x10U)
                                                      : 
                                                     ((3U 
                                                       != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                       ? 0xbU
                                                       : 7U))
                                                     : 
                                                    ((3U 
                                                      != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                      ? 7U
                                                      : 2U)))
                                                   : 2U)));
                        if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                      >> 1U)))) {
                            if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                            }
                        }
                    } else {
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                            = (0x3ffU & ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                          ? 2U : ((1U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 5U
                                                   : 2U)));
                        if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                      >> 1U)))) {
                            if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm 
                                    = (0x39U == (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry));
                            }
                        }
                    }
                } else {
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                        = (0x3ffU & ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                      ? ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                          ? ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                              ? 2U : 3U)
                                          : 2U) : (
                                                   (2U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 3U
                                                     : 2U)
                                                    : 
                                                   ((1U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 2U
                                                     : 5U))));
                    if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                  >> 2U)))) {
                        if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                      >> 1U)))) {
                            if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm 
                                    = (0x39U == (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry));
                            }
                        }
                    }
                }
            } else {
                spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                    = (0x3ffU & ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                  ? ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                      ? ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                          ? 2U : ((1U 
                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                   ? 3U
                                                   : 2U))
                                      : 2U) : ((4U 
                                                & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                ? (
                                                   (2U 
                                                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                                     ? 2U
                                                     : 
                                                    ((3U 
                                                      != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                      ? 
                                                     ((7U 
                                                       == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                       ? 6U
                                                       : 7U)
                                                      : 3U))
                                                    : 2U)
                                                : 2U)));
                if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                              >> 3U)))) {
                    if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                            }
                        }
                    }
                }
            }
        } else if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                                = (0x3ffU & ((3U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                              ? ((7U 
                                                  == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))
                                                  ? 6U
                                                  : 7U)
                                              : 3U));
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                        } else {
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                                = (0x3ffU & 2U);
                        }
                    } else {
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                            = (0x3ffU & 2U);
                    }
                } else {
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                        = (0x3ffU & ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                      ? 2U : ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? 3U
                                               : 2U)));
                }
            } else {
                spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                    = (0x3ffU & ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                  ? 2U : ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                           ? ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                               ? 2U
                                               : ((3U 
                                                   != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                                   ? 
                                                  ((7U 
                                                    == 
                                                    (7U 
                                                     & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode) 
                                                        >> 3U)))
                                                    ? 6U
                                                    : 7U)
                                                   : 2U))
                                           : 2U)));
                if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                              >> 2U)))) {
                    if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                        }
                    }
                }
            }
        } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                = (0x3ffU & ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                              ? 2U : ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                       ? ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                                           ? ((3U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                               ? ((
                                                   (0x84U 
                                                    == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                                   | (0x85U 
                                                      == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)))
                                                   ? 6U
                                                   : 7U)
                                               : 2U)
                                           : 2U) : 2U)));
            if ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                          >> 2U)))) {
                if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                    }
                }
            }
        } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                        = (0x3ffU & ((3U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                      ? 5U : 2U));
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
                } else {
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                        = (0x3ffU & 2U);
                }
            } else {
                spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                    = (0x3ffU & 2U);
            }
        } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                    = (0x3ffU & ((3U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))
                                  ? 3U : 2U));
                spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm = 1U;
            } else {
                spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                    = (0x3ffU & 2U);
            }
        } else {
            spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks 
                = (0x3ffU & 2U);
        }
    }
    if ((((((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm) 
            & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_modrm_current)) 
           & (3U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode))) 
          & ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode)) 
             | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_mode)))) 
         & (3U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_rm)))) {
        spk286_profile_prefix_tb__DOT__dut__DOT__profile_ea_clocks = 1U;
    }
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_valid 
        = (1U & ((((~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_modrm)) 
                   | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_modrm_current)) 
                  & ((~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_outcome)) 
                     | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_branch_known_q))) 
                 & ((~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_count)) 
                    | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_count_known_q))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 0U;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_setup = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_iteration = 0U;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata__DOT__string_form = 0U;
    if ((0x200U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
        if ((0x100U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
        } else if ((0x80U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((0x40U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                                }
                            } else {
                                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                            }
                        } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        } else if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                                }
                            } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                            }
                        } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        } else if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                if ((4U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))) {
                                    if ((2U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))) {
                                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                                    }
                                }
                            } else {
                                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                            }
                        } else if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                            }
                        } else if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((4U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))) {
                            if ((2U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))) {
                                if ((1U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))) {
                                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                                }
                            } else if ((1U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))) {
                                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                            }
                        }
                    } else {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        } else {
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata__DOT__string_form = 1U;
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_setup = 5U;
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_iteration = 4U;
                        }
                    } else {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata__DOT__string_form = 1U;
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_setup = 5U;
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_iteration = 4U;
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else {
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata__DOT__string_form = 1U;
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_setup = 5U;
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_iteration = 4U;
                }
            } else {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            }
        } else if ((0x40U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata__DOT__string_form = 1U;
                                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_setup = 5U;
                                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_iteration = 4U;
                                } else {
                                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                                }
                            } else {
                                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                            }
                        } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                            }
                        } else {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        } else if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata__DOT__string_form = 1U;
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_setup = 5U;
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_iteration = 5U;
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        } else {
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata__DOT__string_form = 1U;
                            spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_setup = 5U;
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_iteration = 5U;
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated 
                                = (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind));
                        }
                    } else {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata__DOT__string_form = 1U;
                        spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_setup = 4U;
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_iteration = 3U;
                    } else {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else {
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata__DOT__string_form = 1U;
                    spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_setup = 5U;
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_iteration = 9U;
                }
            } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            } else {
                spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata__DOT__string_form = 1U;
                spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_setup = 5U;
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_iteration = 4U;
            }
        } else if ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    } else if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    } else if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg) 
                                         >> 2U)))) {
                        if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg) 
                                      >> 1U)))) {
                            if ((1U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))) {
                                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                            }
                        }
                    }
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg) 
                                  >> 2U)))) {
                        if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg) 
                                      >> 1U)))) {
                            if ((1U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))) {
                                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                            }
                        }
                    }
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            }
        } else {
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
        }
    } else if ((0x100U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
        if ((0x80U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((0x40U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            }
        } else if ((0x40U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                            } else if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                            }
                        } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        } else if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        } else if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                            }
                        } else {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    } else if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            }
        } else if ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        } else if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((4U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))) {
                                if ((2U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))) {
                                    if ((1U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))) {
                                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                                    }
                                } else {
                                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                                }
                            } else if ((2U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))) {
                                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                            }
                        } else {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg) 
                                      >> 2U)))) {
                            if ((1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg) 
                                          >> 1U)))) {
                                if ((1U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))) {
                                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                                }
                            }
                        }
                    } else {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            }
        } else if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            }
        } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            }
        } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
        } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            }
        } else {
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
        }
    } else if ((0x80U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
        if ((0x40U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                            } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                            }
                        } else {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        } else if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                            }
                        } else {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            }
        } else if ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    } else if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            }
        } else if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            }
        } else {
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
        }
    } else if ((0x40U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
        if ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated 
                        = ((1U & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                  >> 1U)) || ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)) 
                                              || (1U 
                                                  & (~ 
                                                     (((0xceU 
                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                                       & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_branch_known_q)) 
                                                      & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_branch_taken_q)))))));
                } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated 
                        = ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)) 
                           || (1U & (~ (((0xceU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_branch_known_q)) 
                                        & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_branch_taken_q))))));
                } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            }
        } else {
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated 
                = ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))
                    ? ((1U & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                              >> 3U)) || ((1U & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                                 >> 2U)) 
                                          || ((1U & 
                                               ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                                >> 1U)) 
                                              || ((1U 
                                                   & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) 
                                                  || ((0xe3U 
                                                       == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                                      & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_branch_known_q)) 
                                                         | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_branch_taken_q)))))))
                    : ((1U & (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                 >> 3U))) || ((1U & 
                                               (~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                                   >> 2U))) 
                                              || ((1U 
                                                   & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry) 
                                                      >> 1U)) 
                                                  || ((1U 
                                                       & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) 
                                                      || (1U 
                                                          & (((0xebU 
                                                               == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                                                              | (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_branch_known_q))) 
                                                             | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_branch_taken_q))))))));
        }
    } else if ((0x20U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
        if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        if ((4U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))) {
                            if ((2U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))) {
                                if ((1U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))) {
                                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                                }
                            } else {
                                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                            }
                        } else if ((2U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg))) {
                            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                        }
                    } else {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            }
        } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                } else if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            }
        } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            }
        } else {
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
        }
    } else if ((0x10U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
        if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                    if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                    }
                } else {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
                }
            } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            } else if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            }
        } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
        } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            }
        } else {
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
        }
    } else if ((8U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
        if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
        } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            }
        } else {
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
        }
    } else if ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
        if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
            if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
            }
        } else {
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
        }
    } else if ((2U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
        if ((1U & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
        }
    } else if ((1U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
    }
    if ((1U & ((~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata__DOT__string_form)) 
               | (0U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))))) {
        spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_setup = 0U;
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_iteration = 0U;
        if (((~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata__DOT__string_form)) 
             & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind)))) {
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
        }
    } else if ((((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind)) 
                 & (0x248U != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry))) 
                & (0x261U != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_entry)))) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_family_estimated = 1U;
    }
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_budget_sum 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__base_q;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_budget_carry = 0U;
    if (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__frozen_q)) 
         & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_execution_metadata_valid))) {
        spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_budget_sum 
            = (0xfffU & (spk286_profile_prefix_tb__DOT__dut__DOT__profile_execution_metadata_carry_save 
                         >> 0xcU));
        spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_budget_carry 
            = (0x1ffeU & (spk286_profile_prefix_tb__DOT__dut__DOT__profile_execution_metadata_carry_save 
                          << 1U));
    }
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_adjustment_sum 
        = (0x1fffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__extra_q) 
                       ^ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_length_clocks)) 
                      ^ (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__elapsed_q))));
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_adjustment_carry 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__extra_q) 
            & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_length_clocks) 
               | (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__elapsed_q)))) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_length_clocks) 
              & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__elapsed_q))));
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_adjustment 
        = (0x1fffU & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_adjustment_sum) 
                      + VL_SHIFTL_III(13,13,32, (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_adjustment_carry), 1U)));
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_compare_sum 
        = (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_budget_sum) 
            ^ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_budget_carry)) 
           ^ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_adjustment));
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_compare_carry 
        = (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_budget_sum) 
            & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_budget_carry) 
               | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_adjustment))) 
           | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_budget_carry) 
              & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_adjustment)));
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_difference 
        = (0x1fffU & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_compare_sum) 
                      + VL_SHIFTL_III(13,13,32, (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_compare_carry), 1U)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__unused_shift_ready 
        = (1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__reset) 
                    | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__adjust_service__cancel) 
                       | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_service__DOT__busy_q) 
                          | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_valid))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_raw_operation_valid) 
           & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbdda3170__0));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__prefixes 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_prefix_count_q;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__delivery 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_delivery_metadata;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__nonempty 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_candidate_body)
            ? (0U != (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__gpr_q[0U] 
                      >> 0x10U)) : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_nonempty_q));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__repeated 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)) 
           & ((((0xa4U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                & (0xa7U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
               | (((0xaaU <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                   & (0xafU >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))) 
                  | ((0x6cU <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode)) 
                     & (0x6fU >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_opcode))))) 
              & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind))));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__ea 
        = spk286_profile_prefix_tb__DOT__dut__DOT__profile_ea_clocks;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__iteration_clocks 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_iteration;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__setup_clocks 
        = spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_setup;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__base 
        = spk286_profile_prefix_tb__DOT__dut__DOT__profile_base_clocks;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__remaining_prefixes 
        = ((0U == (IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__prefixes))
            ? 0U : (0xfU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__prefixes) 
                            - (IData)(1U))));
    if (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__repeated) {
        __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__first 
            = __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__setup_clocks;
        __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__second 
            = ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__nonempty)
                ? (IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__iteration_clocks)
                : 0U);
        __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__prefix_clocks 
            = ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__remaining_prefixes) 
               << 1U);
    } else {
        __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__first 
            = __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__base;
        __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__second 
            = __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__ea;
        __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__prefix_clocks 
            = ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__delivery)
                ? 0U : ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__prefixes) 
                        << 1U));
    }
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__sum_bits 
        = (((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__first) 
            ^ (IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__second)) 
           ^ (IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__prefix_clocks));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__carry_bits 
        = (((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__first) 
            & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__second) 
               | (IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__prefix_clocks))) 
           | ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__second) 
              & (IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__prefix_clocks)));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__full_sum 
        = (0xfffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__sum_bits) 
                     + VL_SHIFTL_III(12,12,32, (IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__carry_bits), 1U)));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__Vfuncout 
        = ((0U != (3U & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__full_sum) 
                         >> 0xaU))) ? 0x3ffU : (0x3ffU 
                                                & (IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__full_sum)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_clocks 
        = __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__profile_metadata_budget__211__Vfuncout;
    spk286_profile_prefix_tb__DOT__dut__DOT__profile_deadline_ready 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__active_q) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__body_q) 
              & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__qualified_q) 
                  | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__frozen_q)) 
                     & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_execution_metadata_valid))) 
                 & (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q)) 
                     | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q)) 
                    & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_elapsed_saturated) 
                       | (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_difference) 
                           >> 0xcU) | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_productive_boundary) 
                                       & (0U == (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__execution_difference)))))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__direct_register_capture 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_pending_q)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__unary_direct)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_read_acc 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x81U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__begin_stack_cursor 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x67U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__frame_read_gpr 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x4eU <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (0x55U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__set_ea_plus2 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x6eU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_segment 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x4cU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_ea 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x40U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_target 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x43U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__constant_one 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x3dU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__constant_zero 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x48U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__constant_ones 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x49U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__count_low 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x3fU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_flags 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x1eU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_event_flags 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x24U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_event_cs 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x25U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_event_ip 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x26U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_ip 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x17U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_destination 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0xdU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              | (0x35U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_stack_cursor 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x70U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_cursor_valid_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__save_auxiliary 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x5eU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__restore_auxiliary 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x5fU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__auxiliary_valid_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__save_allocation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x60U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__load_counter 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x61U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q) 
                 >> 1U)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__set_frame_address 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x69U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__decrement_frame_address 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x6bU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__frame_address_valid_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__add_base 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x46U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__set_address 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x45U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q) 
                 >> 1U)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__sign_extend_byte 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x3bU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__carry_fill_byte 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0xacU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__sign_fill_word 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x3cU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__target_relative 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x18U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q) 
                 >> 1U)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__target_absolute 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x19U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__decrement_counter 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x62U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__counter_valid_q) 
                 & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__counter_q)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__compute_alu 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0xeU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q) 
                 & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__flags_valid_q)) 
                    & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q) 
                       >> 1U)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__commit_flags 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x12U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__flags_valid_q) 
                 & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__result_disposed_q))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_request 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x4aU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hda2f34dc__0)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_request 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x3eU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hda2f34dc__0)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_request 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (((0x74U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
               | ((0x76U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                  | (0x75U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)))) 
              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q) 
                 & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__flags_valid_q)) 
                    & ((0x76U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                       | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q) 
                          >> 1U))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_switch_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0xa9U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__dispatch_request 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x47U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__direct_flags 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x3aU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clear_if_tf 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x27U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clear_event_flags 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x9aU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__restore_flags 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x1fU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__counter_branch 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__counter_valid_q) 
              & ((0x63U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                 | (0x64U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he66532ef__0 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0xaaU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__move_word 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (((2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
               | (0x36U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word))) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__redirect_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x1aU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__target_valid_q)));
    spk286_profile_prefix_tb__DOT__dut__DOT__software_request 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x22U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__count_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x1cU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__ack_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x23U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_stack 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x1bU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q) 
                 >> 1U)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__move_source 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x44U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q) 
                 >> 1U)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_arithmetic 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x4bU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allocate_stack 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x6cU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allocation_valid_q) 
                 & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_cursor_valid_q))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__frame_write_gpr 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x56U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & ((0x5dU >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                 & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__halt_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x21U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_stack_validation_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0xa1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__add_allocation_sp 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x73U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_required)) 
                 & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allocation_valid_q))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_write_acc 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x82U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_bounds 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x6fU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__auxiliary_valid_q) 
                 & (3U == (3U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_count 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x7cU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_step_dest 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x7bU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_check_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0xa6U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__npx_esc_check 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0xc4U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__npx_wait_check 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0xc5U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x97U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__write_result_ax 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x77U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q) 
                 >> 2U)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_step_source 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x7aU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__write_result_dx 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x78U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__auxiliary_valid_q) 
                 & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__result_high_pending_q))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fetch_port 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x87U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fetch_word 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              | (0xbU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fetch_signed_byte 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0xcU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              | (0x14U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fetch_byte_tmp1 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x32U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fetch_byte 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x1dU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__immediate_fetch 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__immediate_operation) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_pending_q)) 
                 & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__immediate_rm)) 
                    | (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode__DOT__state_q))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0xa8U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode_enable 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((4U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__unary_direct)) 
                 & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_decode))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_verify_read 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x92U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_verify_write 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x93U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_limit 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x95U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_access 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x94U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_commit 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x2dU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (7U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__commit_context 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x2aU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (3U == (3U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_validation_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x9fU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__commit_result 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__result_operation) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__result_disposed_q)) 
                 & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q) 
                    >> 2U))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_protected_check 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0xc1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_ldtr 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x90U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_privilege_check 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0xc2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_check 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x13U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_msw_store 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x8cU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0xa7U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (3U == (3U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_msw_load 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x8dU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_ip_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x98U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_ldtr_store 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x8eU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_tr_store 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x8fU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_table_store 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x88U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              | (0x89U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__vector_cs 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x29U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_cs_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x99U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_rm32 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x6dU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_push2 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x71U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_push8 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x65U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_pop8 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x66U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_call_frame 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0xa4U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_stack_word 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x68U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_pop2 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x72U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__push_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x15U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__push_event_error 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x9bU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_switch_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0xa3U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__io_privilege_check 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0xc3U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__if_control_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x20U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_frame_address 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x6aU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__frame_address_valid_q)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h273d8170__0 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x4dU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_validation_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0xa2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_ss_validation_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x9eU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_cs_validation_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x9cU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_tr 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x91U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_table_load 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x8aU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              | (0x8bU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_read1 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x7eU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__address_override)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_frame_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0x9dU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__copy_call_parameters 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (0xa5U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hd7d48636__0 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_store 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x7fU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__address_override) 
                 & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_retire_fire 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__reset)) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__semantic_cancel)) 
              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary) 
                 & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_deadline_ready) 
                    & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__pending_q) 
                       | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__raw_retired))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operation_valid 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_raw_operation_valid) 
           & ((~ (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_raw_operation_valid) 
                   & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind)) 
                      & ((0x79U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                         & (0U != (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__gpr_q[0U] 
                                   >> 0x10U))))) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_continue))) 
              | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary) 
                 & ((~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_continue)) 
                    | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_deadline_ready)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_complete 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_request) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_complete 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_request) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_complete 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_request) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_nested_call 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_switch_operation) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h47070c4b__0) 
              | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_nested_call_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_return_task 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he66532ef__0) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q) 
              & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__flags_q) 
                  >> 0xeU) & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_return_started_q)) 
                              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h123c7c30__0)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__software_taken 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__software_request) 
           & ((0xceU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q)) 
              | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__flags_q) 
                 >> 0xbU)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__ack_request 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__ack_operation) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_needs_ack));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__arithmetic_fault 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_arithmetic) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arithmetic_fault_q));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__halt_privilege_fault 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__halt_operation) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h9b33c892__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_tss_pre_fault 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_stack_validation_operation) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_outer_required) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_stack_ready_q)) 
                 & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__tr_valid_q)) 
                    | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__tr_present_q)) 
                       | ((2U < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_target_dpl_q)) 
                          | ((0x1ffffU & ((IData)(3U) 
                                          + (0xffffU 
                                             & ((IData)(2U) 
                                                + VL_SHIFTL_III(16,16,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_target_dpl_q), 2U))))) 
                             > (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__tr_limit_q))))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__add_allocation_arch 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__protected_return_cursor_q)) 
           & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__add_allocation_sp));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__bounds_fault 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_bounds) 
           & (VL_LTS_III(16, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp1_q), (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__auxiliary_q)) 
              | VL_GTS_III(16, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp1_q), (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp0_q))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_fault 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_check_operation) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q)) 
              | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__lock_prefix)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__npx_fault 
        = (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__npx_esc_check) 
            & (IData)((0U != (0xcU & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))))) 
           | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__npx_wait_check) 
              & (IData)((0xaU == (0xaU & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_begin 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_operation) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_active_q)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_index 
        = (0xffffU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_step_source)
                       ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__gpr_q[3U]
                       : ((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__gpr_q[3U] 
                           << 0x10U) | (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__gpr_q[3U] 
                                        >> 0x10U))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_index_write 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_step_source) 
           | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_step_dest));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fixed_result_write 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__result_suppress_q)) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__write_result_ax) 
              | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__write_result_dx)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_lock_fault 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_operation) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__lock_prefix));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_privilege_fault 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_operation) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__lock_prefix)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h9b33c892__0)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode__DOT__allowed 
        = ((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__reset) 
               | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__adjust_service__cancel))) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__invalid_form)) 
              & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode_enable)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_verify_operation 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_verify_read) 
           | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_verify_write));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_inspect_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_access) 
           | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_limit));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__context_commit 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_commit) 
            & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q)) 
               | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_candidate_valid_q) 
                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h431e1356__0)))) 
           | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__commit_context) 
              & (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q)) 
                  | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active) 
                     | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_candidate_valid_q))) 
                 & (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_outer_required)) 
                     | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_candidate_valid_q)) 
                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h431e1356__0)))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hb678200d__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__commit_result) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allow_result_write));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_adjust 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_operation) 
           & ((3U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp0_q)) 
              < (3U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp1_q))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_vector_ip 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_ip_operation) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h960f7d4f__0));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_selector_store 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_ldtr_store) 
           | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_tr_store));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_vector_cs 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_cs_operation) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h960f7d4f__0));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__push_transfer 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__push_operation) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__micro_executor__push_enabled));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__push_event_error_transfer 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__push_event_error) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_error_valid) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__micro_executor__push_enabled)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_switch_begin 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_switch_operation) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_switch_active_q)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_outer_required)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_write 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_switch_operation) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_switch_active_q) 
              & (2U > (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_switch_phase_q))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__io_privilege_fault 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q) 
           & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__current_cpl) 
               > (3U & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__flags_q) 
                        >> 0xcU))) & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__if_control_operation) 
                                      | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__io_privilege_check) 
                                         | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
                                            & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h676cdf20__0) 
                                               | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h124121e1__0)))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__internal_segment_write 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q)) 
           & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h273d8170__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_reload_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h273d8170__0) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hf67482c1__0 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_ldtr) 
           | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_tr));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_table_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_table_store) 
           | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_table_load));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_tmp1 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_read1) 
           | ((9U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              | ((0xaU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                 | ((0x33U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                    | (0x34U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h63cacb15__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_frame_operation) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_required));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hac56e6d2__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__copy_call_parameters) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_outer_required) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_active_q)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__jmp_gate_cs_validation_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hd7d48636__0) 
           & ((0x96U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_candidate_valid_q)) 
                 & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_candidate_valid_q))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_range_fault 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_store) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q) 
              & (0xffffU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__address_offset))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__instruction_context__complete 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__event_completed) 
           | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_retire_fire));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_return_finish 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_return_started_q) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operation_valid) 
              & (3U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__unused_muldiv_ready 
        = ((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__reset) 
               | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__adjust_service__cancel) 
                  | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_service__DOT__busy_q) 
                     | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_valid))))) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operation_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__unused_adjust_ready 
        = ((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__reset) 
               | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__adjust_service__cancel) 
                  | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_service__DOT__busy_q) 
                     | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_valid))))) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operation_valid));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allowed 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operation_valid) 
           & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbdda3170__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_start 
        = (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_switch_operation) 
            & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_candidate_valid_q) 
               & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_service_busy)) 
                  & ((0xaU != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__state_q)) 
                     & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_active_q)) 
                        & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_done_q))))))) 
           | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_return_task));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__ack_response_ready 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__ack_pending_q) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__ack_request));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_pre_fault 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_begin) 
           & ((0x1ffffU & ((IData)(7U) + ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__debug_event_vector) 
                                          << 3U))) 
              > (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__idtr_limit_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_fault 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_lock_fault) 
           | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_privilege_fault));
    spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode_done 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode__DOT__allowed) 
           & ((3U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode__DOT__state_q)) 
              | ((4U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode__DOT__state_q)) 
                 & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode__DOT__reuse_q))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte_ready 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode__DOT__allowed) 
           & ((0U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode__DOT__state_q)) 
              | ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode__DOT__state_q)) 
                 | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode__DOT__state_q)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__internal_target 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_redirect)
            ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__load_words_q
           [0U] : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__context_commit)
                    ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp0_q)
                    : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__target_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__internal_redirect 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__redirect_operation) 
            & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__branch_taken)) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__context_commit) 
              | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_redirect)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__return_same_sp_commit 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__context_commit) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_required)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__protected_return_cursor_q)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0c79368c__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__context_commit) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_sp_commit 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__context_commit) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_commit) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_required)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h827d400a__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__context_commit) 
           & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__commit_context));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__result_to_dst 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hb678200d__0) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h27251fb3__0));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h657a4724__0 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_operation) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_adjust));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_mode_fault 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q)) 
           & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_protected_check) 
              | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_privilege_check) 
                 | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_selector_store))));
    spk286_profile_prefix_tb__DOT__dut__DOT__vector_offset 
        = (0xffffU & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__debug_event_vector) 
                       << 2U) + (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__vector_cs) 
                                  | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_vector_cs))
                                  ? 2U : 0U)));
    spk286_profile_prefix_tb__DOT__dut__DOT__vector_request 
        = (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
            & (0x28U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word))) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__vector_cs) 
              | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_vector_ip) 
                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_vector_cs))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_heda1dc20__0 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__push_transfer) 
           | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__push_event_error_transfer));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__set_if 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__io_privilege_fault)) 
           & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__if_control_operation));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h09139821__0 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__io_privilege_fault)) 
           & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed));
    if (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__context_commit) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__load_index = 1U;
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__load_selector 
            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp1_q;
    } else if (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__internal_segment_write) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__load_index 
            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__decoded_segment_index;
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__load_selector 
            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp0_q;
    } else {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__load_index 
            = vlSelf->spk286_profile_prefix_tb__DOT__segment_load_index;
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__load_selector 
            = vlSelf->spk286_profile_prefix_tb__DOT__segment_load_selector;
    }
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h19ebc0b4__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__segment_load_en) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__context_commit) 
              | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__internal_segment_write)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_segment_null_commit 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_active_q)) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_reload_operation) 
              & (IData)(((0U == (0xfffcU & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp0_q))) 
                         & (2U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__decoded_segment_index))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_privilege_fault 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q) 
           & ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__current_cpl)) 
              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_table_load) 
                 | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_msw_load) 
                    | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_privilege_check) 
                       | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hf67482c1__0))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_operation 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_table_operation) 
           | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_msw_store) 
              | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_msw_load) 
                 | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_selector_store))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_range_fault 
        = (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_push2) 
            & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hd208890c__0)) 
           | (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_pop2) 
               & (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__gpr_q[2U] 
                  & (0xfffdU <= (0xffffU & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__gpr_q[2U])))) 
              | (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_push8) 
                  & (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__gpr_q[2U] 
                     & (0x10U > (0xffffU & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__gpr_q[2U])))) 
                 | (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_pop8) 
                     & (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__gpr_q[2U] 
                        & (0xfff1U <= (0xffffU & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__gpr_q[2U])))) 
                    | (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_stack_word) 
                        & (0xffffU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp0_q))) 
                       | (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h63cacb15__0) 
                           & ((0U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_phase_q)) 
                              & ((0x40000U & ((1U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
                                               ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_access_q
                                               : vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segments__DOT__access_q))
                                  ? (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__return_stack_pointer) 
                                      <= (0xffffU & (IData)(
                                                            (vlSelf->spk286_profile_prefix_tb__DOT__debug_segment_limits 
                                                             >> 0x20U)))) 
                                     | (0xffffU < vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_last_byte))
                                  : (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_last_byte 
                                     > (0xffffU & (IData)(
                                                          (vlSelf->spk286_profile_prefix_tb__DOT__debug_segment_limits 
                                                           >> 0x20U))))))) 
                          | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_call_frame) 
                             & (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active)) 
                                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q)) 
                                & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_outer_required)
                                    ? ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_stack_ready_q)) 
                                       | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_stack_sp_q) 
                                           < vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_frame_bytes) 
                                          | (((4U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_access_q))
                                               ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_stack_sp_q) 
                                                  <= 
                                                  (0x1ffffU 
                                                   & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_limit_q) 
                                                      + vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_frame_bytes)))
                                               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_stack_sp_q) 
                                                  > 
                                                  (0x1ffffU 
                                                   & ((IData)(2U) 
                                                      + (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_limit_q))))) 
                                             | ((0U 
                                                 != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_parameter_count_q)) 
                                                & ((0x40000U 
                                                    & ((1U 
                                                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
                                                        ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_access_q
                                                        : vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segments__DOT__access_q))
                                                    ? 
                                                   (((0xffffU 
                                                      & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__gpr_q[2U]) 
                                                     <= 
                                                     (0xffffU 
                                                      & (IData)(
                                                                (vlSelf->spk286_profile_prefix_tb__DOT__debug_segment_limits 
                                                                 >> 0x20U)))) 
                                                    | (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_last_byte 
                                                       >> 0x10U))
                                                    : 
                                                   (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_last_byte 
                                                    > 
                                                    (0xffffU 
                                                     & (IData)(
                                                               (vlSelf->spk286_profile_prefix_tb__DOT__debug_segment_limits 
                                                                >> 0x20U)))))))))
                                    : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hd208890c__0))))))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_pop 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h63cacb15__0) 
           & (2U > (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_phase_q)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_write 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hac56e6d2__0) 
           & (1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_phase_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_read 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hac56e6d2__0) 
           & (0U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_phase_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_cs_validation_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__jmp_gate_cs_validation_operation) 
           | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
              & ((0xa0U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                 & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q) 
                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_candidate_valid_q)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_validation_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hd7d48636__0) 
           & (((~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__jmp_gate_cs_validation_operation)) 
               & (0x96U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word))) 
              | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_candidate_valid_q)) 
                 & (0xa0U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_count_write 
        = ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind)) 
           & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_count) 
              | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_range_fault)));
    spk286_profile_prefix_tb__DOT__dut__DOT__string_request 
        = (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
            & ((0x7dU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__address_override))) 
           | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_read1) 
              | ((~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_range_fault)) 
                 & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_store))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_empty 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allowed) 
           & (0x79U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_continue 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allowed) 
           & (0x80U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__ack_done 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__ack_response_ready) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__ack_response_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_commit 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_fault)) 
           & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_operation));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operation_retire 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_pending_q) 
              & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_decode) 
                  & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode_done) 
                     & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_register_direct))) 
                 | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__immediate_operation) 
                     & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__immediate_register)) 
                    | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__unary_direct)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_byte_ready 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__immediate_fetch) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fetch_word) 
              | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fetch_signed_byte) 
                 | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fetch_byte) 
                    | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fetch_byte_tmp1) 
                       | (((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q) 
                               >> 3U)) & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fetch_port)) 
                          | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte_ready)))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__new_redirect 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__internal_redirect) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active)) 
              & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_target_length)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__effective_ip_write_data 
        = (0xffffU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__restart)
                       ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data)
                       : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable)
                           ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__internal_redirect)
                               ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__internal_target)
                               : ((IData)(1U) + (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__ip_q)))
                           : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__ip_write_data))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__stream_restart 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__restart) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__internal_redirect) 
              | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_cancel) 
                 | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_service__DOT__state_q)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__profile_target_handoff__cancel 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__semantic_cancel) 
           | ((2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_service__DOT__state_q)) 
              | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__internal_redirect) 
                 & ((~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__profile_requires_target_length)) 
                    | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_en2 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_segment_write)) 
           & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0c79368c__0) 
              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_candidate_valid_q) 
                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_ss_candidate_valid_q))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h34e1cf13__0 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0c79368c__0) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_candidate_valid_q));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h1b5291b6__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_sp_commit) 
            << 1U) | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_gpr_write));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_sp_commit 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h827d400a__0) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_outer_required));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__retf_outer_sp_commit 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h827d400a__0) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_required));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__stack_service__push 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_heda1dc20__0) 
           | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_write));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__io_write 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h09139821__0) 
           & ((3U == (3U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q))) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h124121e1__0)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__load_en 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h19ebc0b4__0) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error)) 
              & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h4e941736__0 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_range_fault) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__range_fault 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_range_fault) 
           | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_range_fault) 
              | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_rm32) 
                 & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_offset) 
                    & (0xfffcU < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_offset))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__pop_operation 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((0x16U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
              | ((0x2bU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                 | ((0x2cU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                    | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_pop)))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hac507719__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_cs_validation_operation) 
           | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_cs_validation_operation));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h7d92a0be__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_cs_validation_operation) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_validation_operation) 
              | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_cs_validation_operation) 
                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_ss_validation_operation))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hb6f57119__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_validation_operation) 
           | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_validation_operation));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__jmp_gate_probe_operation 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_validation_operation) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_candidate_valid_q)) 
              & (0x96U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h4a6318ec__0 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_empty) 
           & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_kind)));
    spk286_profile_prefix_tb__DOT__dut__DOT__repeat_stepped 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_continue) 
           & (IData)(vlSelf->__VdfgTmp_hc8706df8__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hb5d3750f__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operation_retire) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_alu));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_write 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operation_retire) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_alu)) 
              | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__result_write_allowed)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h8e0b9e29__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_active)
            ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_byte_ready)
            : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__decode_ready));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT____Vcellinp__instruction_context__cancel 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__stream_restart) 
           | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview_start));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview_active 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_started_q) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_active)) 
              & ((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__profile_target_handoff__cancel) 
                     | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__known_q))) 
                 & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q))));
    if (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_segment_write) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_index 
            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__segment_index_q;
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_selector 
            = (0xffffU & (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__cache_selectors_q 
                                  >> (0x3fU & VL_SHIFTL_III(6,6,32, (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__segment_index_q), 4U)))));
    } else if (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h34e1cf13__0) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_index = 1U;
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_selector 
            = (0xffffU & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_candidate_selector_q));
    } else {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_index 
            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__decoded_segment_index;
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_selector 
            = (0xffffU & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp0_q));
    }
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hcd1e1639__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__retf_outer_sp_commit) 
            << 2U) | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h1b5291b6__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_next_sp 
        = (0xffffU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__stack_service__sp) 
                      + ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_stack)
                          ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp1_q)
                          : ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__stack_service__push)
                              ? 0xfffeU : 2U))));
    spk286_profile_prefix_tb__DOT__dut__DOT__stack_offset 
        = (0xffffU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_read)
                       ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_source_sp_q)
                       : ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_write)
                           ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_cursor_q) 
                              - (IData)(2U)) : ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_pop)
                                                 ? 
                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__return_stack_pointer) 
                                                 + (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_parameter_bytes))
                                                 : 
                                                ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_frame_address)
                                                  ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__frame_address_q)
                                                  : 
                                                 ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__stack_service__push)
                                                   ? 
                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__stack_service__sp) 
                                                   - (IData)(2U))
                                                   : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__stack_service__sp)))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__io_transfer 
        = (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h09139821__0) 
            & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q) 
                >> 1U) & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h676cdf20__0))) 
           | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__io_write));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__begin_return_cursor 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q) 
           & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_pop2) 
              | (((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__flags_q) 
                      >> 0xeU)) & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he66532ef__0)) 
                 | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__micro_executor__segment_pop_opcode) 
                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_cursor_valid_q)) 
                       & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__pop_operation))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbabeeb40__0 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_heda1dc20__0) 
           | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__pop_operation));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hedc9faf1__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_validation_operation) 
           | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hac507719__0));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h2c23db46__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_validation_operation) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_validation_operation) 
              | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hac507719__0)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_write 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_active_q) 
           & ((4U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_phase_q)) 
              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_tr) 
                 | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_reload_operation) 
                     | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_validation_operation) 
                        | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h7d92a0be__0))) 
                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_success_q)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h9ac33813__0 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__jmp_gate_probe_operation) 
           & (6U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_class)));
    spk286_profile_prefix_tb__DOT__dut__DOT__counter_branch_request 
        = (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__counter_branch) 
            & ((0x63U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
               == (0U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__counter_q)))) 
           | (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h4a6318ec__0) 
               & (0U == (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__gpr_q[0U] 
                         >> 0x10U))) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__repeat_stepped)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__trap_due 
        = (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__repeat_stepped) 
            & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__trap_sample_q)) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__trap_pending_q) 
              | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_retire_fire) 
                 & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active)) 
                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__trap_sample_q)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_boundary 
        = (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h4a6318ec__0) 
            & (0U != (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__gpr_q[0U] 
                      >> 0x10U))) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__repeat_stepped));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__length_fault 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active)) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__raw_retired)) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__event_completed)) 
                 & ((0xaU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_bytes)) 
                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h8e0b9e29__0)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_byte_ready 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview_active) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT__active_q) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_complete)) 
                 & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__reset)) 
                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__stream_restart)) 
                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview_start)) 
                          & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_abort_fetch)) 
                             & (0xaU > (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT__byte_count)))))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__outer_return_clear = 0U;
    spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__selector 
        = (0xffffU & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_selector_q));
    spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__access 
        = (0xfU & (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_access_q 
                   >> 1U));
    spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__dpl 
        = (3U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_dpl_q));
    spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__type_ok 
        = (IData)((((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__access) 
                    >> 3U) & (4U != (5U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__access)))));
    spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__privilege_ok 
        = (1U & ((IData)((6U == (6U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__access)))) 
                 | (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__dpl) 
                     >= (3U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_selector))) 
                    & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__dpl) 
                       >= (3U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__selector))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__table_ok 
        = ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__selector))
            ? (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__ldtr_valid_q) 
                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__ldtr_present_q)) 
               & ((0x1ffffU & ((IData)(7U) + (0xfff8U 
                                              & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__selector)))) 
                  <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__ldtr_limit_q)))
            : ((0x1ffffU & ((IData)(7U) + (0xfff8U 
                                           & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__selector)))) 
               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__gdtr_limit_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__outer_return_clear 
        = ((0xeU & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__outer_return_clear)) 
           | ((0U != (0x3fffU & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__selector) 
                                 >> 2U))) & (((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_valid_q)) 
                                                | (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_present_q))) 
                                               | (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__table_ok))) 
                                              | (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__type_ok))) 
                                             | (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__privilege_ok)))));
    spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__selector 
        = (0xffffU & (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_selector_q 
                              >> 0x30U)));
    spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__table_ok 
        = ((4U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__selector))
            ? (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__ldtr_valid_q) 
                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__ldtr_present_q)) 
               & ((0x1ffffU & ((IData)(7U) + (0xfff8U 
                                              & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__selector)))) 
                  <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__ldtr_limit_q)))
            : ((0x1ffffU & ((IData)(7U) + (0xfff8U 
                                           & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__selector)))) 
               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__gdtr_limit_q)));
    spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__access 
        = (0xfU & (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_access_q 
                   >> 0x19U));
    spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__dpl 
        = (3U & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_dpl_q) 
                 >> 6U));
    spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__type_ok 
        = (IData)((((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__access) 
                    >> 3U) & (4U != (5U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__access)))));
    spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__privilege_ok 
        = (1U & ((IData)((6U == (6U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__access)))) 
                 | (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__dpl) 
                     >= (3U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_selector))) 
                    & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__dpl) 
                       >= (3U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__selector))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__outer_return_clear 
        = ((7U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__outer_return_clear)) 
           | (((0U != (0x3fffU & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__selector) 
                                  >> 2U))) & (((((~ 
                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_valid_q) 
                                                   >> 3U)) 
                                                 | (~ 
                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_present_q) 
                                                     >> 3U))) 
                                                | (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__table_ok))) 
                                               | (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__type_ok))) 
                                              | (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__unnamedblk1__DOT__check_outer_data__DOT__privilege_ok)))) 
              << 3U));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_ha17f98de__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__return_same_sp_commit) 
            << 3U) | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hcd1e1639__0));
    spk286_profile_prefix_tb__DOT__dut__DOT__stack_request 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__range_fault)) 
           & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbabeeb40__0) 
              | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_frame_address) 
                 | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_write) 
                    | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_read) 
                       | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_write))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_begin 
        = (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hf67482c1__0) 
            | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_verify_operation) 
               | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_inspect_operation) 
                  | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_reload_operation) 
                     | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_validation_operation) 
                        | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_validation_operation) 
                           | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h7d92a0be__0))))))) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_active_q)) 
              & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h2c23db46__0)
                  ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q) 
                     >> 1U) : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_ss_validation_operation)
                                ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_ready_q)
                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_validation_operation)
                                    ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_stack_ready_q)
                                    : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_value 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h2c23db46__0)
            ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_target_active_q)
                ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_target_selector_q)
                : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp1_q))
            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_ss_validation_operation)
                ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_ss_q)
                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_validation_operation)
                    ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_stack_ss_q)
                    : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp0_q))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_write) 
           | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_table_load) 
               & (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_index_q))) 
              | ((0x83U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                 | ((0x85U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                    | (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q)) 
                        & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__string_request)) 
                       | ((0x41U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                          | ((0x2eU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                             | ((0x2fU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                | ((0x33U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                   | ((0x34U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                      | ((0x30U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                         | ((0x31U 
                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                            | ((0x37U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                               | (0x38U 
                                                  == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)))))))))))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__microsequencer__branch_request 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__counter_branch_request) 
           | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__dispatch_request));
    if (spk286_profile_prefix_tb__DOT__dut__DOT__counter_branch_request) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__microsequencer__branch_target 
            = (0x3ffU & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__counter_branch_target));
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__microsequencer__branch_target_valid 
            = (1U & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__counter_branch_target) 
                     >> 0xaU));
    } else {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__microsequencer__branch_target 
            = (0x3ffU & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__dispatch_entry));
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__microsequencer__branch_target_valid 
            = (1U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__dispatch_valid));
    }
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_repeat_checkpoint 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_boundary) 
           & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__repeat_stepped));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_async_enable 
        = (1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__active_q)) 
                 | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__cpu_boundary) 
                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__active_q)) 
                       | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_retire_fire) 
                          | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_boundary))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__boundary 
        = (1U & (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__events__instruction_active)) 
                  | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_retire_fire) 
                     | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_boundary))) 
                 & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active)) 
                    & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_cancel)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__invalid_opcode_fault 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__execution_allowed) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__decode_ready) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active)) 
                 & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__raw_retired)) 
                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__event_completed)) 
                       & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_valid) 
                          & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__is_prefix)) 
                             & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__length_fault)) 
                                & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__instruction_context__DOT__extended_q)
                                    ? (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__decoder__DOT____VdfgTmp_h0f0db5a7__0))
                                    : ((0x64U <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data)) 
                                       & (0x67U >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))))))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__operand_decode__byte_valid 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__length_fault)) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_valid));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT__accept_byte 
        = ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefetch_queue__DOT__count_q)) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_byte_ready));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h03543a5a__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_sp_commit) 
            << 4U) | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_ha17f98de__0));
    spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_hc6c48371__0 
        = ((~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__stack_request)) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__address_override));
    spk286_profile_prefix_tb__DOT__dut__DOT__operand_select_rm 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h4b82a8ba__0) 
           | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_operation) 
              | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__io_transfer) 
                 | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__string_request) 
                    | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__vector_request) 
                       | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__stack_request) 
                          | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_check) 
                             | ((6U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                | ((0xaU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                   | ((8U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                      | ((0x10U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                         | ((0x2fU 
                                             == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                            | ((0x34U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                               | ((0x31U 
                                                   == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                                  | ((0x38U 
                                                      == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                                     | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_operation))))))))))))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__protected_call_stack_access 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_switch_active_q) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_outer_required) 
              & ((~ ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_frame_address) 
                     | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_read))) 
                 & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__stack_request))));
    spk286_profile_prefix_tb__DOT__dut__DOT__service_segment 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__string_request)
            ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__string_destination)
                ? 0U : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segment_override)
                         ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__override_segment)
                         : 3U)) : ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__stack_request)
                                    ? 2U : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segment_override)
                                             ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__override_segment)
                                             : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_segment))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h6f1b5359__0 
        = ((3U & (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                          >> 0x2dU))) >= (3U & (((3U 
                                                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_value)) 
                                                 > (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__current_cpl))
                                                 ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_value)
                                                 : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__current_cpl))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hd7564ff8__0 
        = (((3U & (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                           >> 0x2dU))) >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__current_cpl)) 
           & ((3U & (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                             >> 0x2dU))) >= (3U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_value))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector__DOT__descriptor_offset 
        = (0xfff8U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_value));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_null 
        = (0U == (0x3fffU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_value) 
                             >> 2U)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_unused_end 
        = (0x1fffffU & ((IData)(7U) + spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector__DOT__descriptor_offset));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_limit_valid 
        = (spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_unused_end 
           <= ((4U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_value))
                ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__ldtr_limit_q)
                : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__gdtr_limit_q)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector__DOT__address_sum 
        = (0x1ffffffU & (((4U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_value))
                           ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__ldtr_base_q
                           : vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__gdtr_base_q) 
                         + spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector__DOT__descriptor_offset));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_address 
        = (0xffffffU & spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector__DOT__address_sum);
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_carry 
        = (1U & (spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector__DOT__address_sum 
                 >> 0x18U));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__memory_byte 
        = ((1U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_service__DOT__state_q)) 
           && ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_memory_request)
                ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_memory_request)
                    ? (4U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__state_q))
                    : (((3U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__state_q)) 
                        | (4U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__state_q))) 
                       & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_memory_request)))
                : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_msw_load_mask 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_task_load)
            ? 8U : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_commit)
                     ? 8U : 0xfU));
    spk286_profile_prefix_tb__DOT__dut__DOT__protected_call_range_fault 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__stack_request)
            ? ([&]() {
                vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__232__is_byte 
                    = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte;
                vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__232__expand_down 
                    = (1U & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_access_q) 
                             >> 2U));
                vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__232__limit_value 
                    = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_limit_q;
                vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__232__offset_value 
                    = spk286_profile_prefix_tb__DOT__dut__DOT__stack_offset;
                vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__232__Vfuncout 
                    = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__232__expand_down)
                        ? (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__232__offset_value) 
                            <= (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__232__limit_value)) 
                           | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__232__is_byte)) 
                              & (0xffffU == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__232__offset_value))))
                        : (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__232__offset_value) 
                            > (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__232__limit_value)) 
                           | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__232__is_byte)) 
                              & ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__232__offset_value) 
                                 == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__232__limit_value)))));
            }(), (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__232__Vfuncout))
            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__address_override)
                ? ([&]() {
                    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__233__is_byte 
                        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte;
                    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__233__expand_down 
                        = (1U & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_access_q) 
                                 >> 2U));
                    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__233__limit_value 
                        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_limit_q;
                    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__233__offset_value 
                        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__address_offset;
                    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__233__Vfuncout 
                        = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__233__expand_down)
                            ? (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__233__offset_value) 
                                <= (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__233__limit_value)) 
                               | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__233__is_byte)) 
                                  & (0xffffU == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__233__offset_value))))
                            : (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__233__offset_value) 
                                > (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__233__limit_value)) 
                               | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__233__is_byte)) 
                                  & ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__233__offset_value) 
                                     == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__233__limit_value)))));
                }(), (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__233__Vfuncout))
                : ([&]() {
                    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__234__is_byte 
                        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte;
                    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__234__expand_down 
                        = (1U & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_access_q) 
                                 >> 2U));
                    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__234__limit_value 
                        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_limit_q;
                    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__234__offset_value 
                        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_offset;
                    vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__234__Vfuncout 
                        = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__234__expand_down)
                            ? (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__234__offset_value) 
                                <= (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__234__limit_value)) 
                               | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__234__is_byte)) 
                                  & (0xffffU == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__234__offset_value))))
                            : (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__234__offset_value) 
                                > (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__234__limit_value)) 
                               | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__234__is_byte)) 
                                  & ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__234__offset_value) 
                                     == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__234__limit_value)))));
                }(), (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__234__Vfuncout))));
    VL_ASSIGNBIT_II(0U, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_io_ranges, 
                    (1U & (~ ([&]() {
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__212__is_byte 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__212__expand_down 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__0__KET____DOT__cache_expand_down;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__212__limit_value 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__0__KET____DOT__cache_limit;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__212__Vfuncout 
                            = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__212__expand_down) 
                               || ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__212__is_byte)) 
                                   & (0U == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__212__limit_value))));
                    }(), (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__212__Vfuncout)))));
    VL_ASSIGNBIT_II(1U, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_io_ranges, 
                    (1U & (~ ([&]() {
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__217__is_byte 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__217__expand_down 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__1__KET____DOT__cache_expand_down;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__217__limit_value 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__1__KET____DOT__cache_limit;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__217__Vfuncout 
                            = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__217__expand_down) 
                               || ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__217__is_byte)) 
                                   & (0U == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__217__limit_value))));
                    }(), (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__217__Vfuncout)))));
    VL_ASSIGNBIT_II(2U, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_io_ranges, 
                    (1U & (~ ([&]() {
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__222__is_byte 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__222__expand_down 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__2__KET____DOT__cache_expand_down;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__222__limit_value 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__2__KET____DOT__cache_limit;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__222__Vfuncout 
                            = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__222__expand_down) 
                               || ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__222__is_byte)) 
                                   & (0U == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__222__limit_value))));
                    }(), (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__222__Vfuncout)))));
    VL_ASSIGNBIT_II(3U, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_io_ranges, 
                    (1U & (~ ([&]() {
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__227__is_byte 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__227__expand_down 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__3__KET____DOT__cache_expand_down;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__227__limit_value 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__3__KET____DOT__cache_limit;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__227__Vfuncout 
                            = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__227__expand_down) 
                               || ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__227__is_byte)) 
                                   & (0U == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__227__limit_value))));
                    }(), (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__227__Vfuncout)))));
    VL_ASSIGNBIT_II(0U, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_vector_ranges, 
                    (1U & (~ ([&]() {
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__216__is_byte 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__216__expand_down 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__0__KET____DOT__cache_expand_down;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__216__offset_value 
                            = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__io_transfer)
                                ? 0U : (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__vector_offset));
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__216__Vfuncout 
                            = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__216__expand_down) 
                               || ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__216__is_byte)) 
                                   & (0xffffU == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__216__offset_value))));
                    }(), (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__216__Vfuncout)))));
    VL_ASSIGNBIT_II(1U, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_vector_ranges, 
                    (1U & (~ ([&]() {
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__221__is_byte 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__221__expand_down 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__1__KET____DOT__cache_expand_down;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__221__offset_value 
                            = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__io_transfer)
                                ? 0U : (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__vector_offset));
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__221__Vfuncout 
                            = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__221__expand_down) 
                               || ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__221__is_byte)) 
                                   & (0xffffU == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__221__offset_value))));
                    }(), (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__221__Vfuncout)))));
    VL_ASSIGNBIT_II(2U, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_vector_ranges, 
                    (1U & (~ ([&]() {
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__226__is_byte 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__226__expand_down 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__2__KET____DOT__cache_expand_down;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__226__offset_value 
                            = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__io_transfer)
                                ? 0U : (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__vector_offset));
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__226__Vfuncout 
                            = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__226__expand_down) 
                               || ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__226__is_byte)) 
                                   & (0xffffU == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__226__offset_value))));
                    }(), (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__226__Vfuncout)))));
    VL_ASSIGNBIT_II(3U, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_vector_ranges, 
                    (1U & (~ ([&]() {
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__231__is_byte 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__231__expand_down 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__3__KET____DOT__cache_expand_down;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__231__offset_value 
                            = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__io_transfer)
                                ? 0U : (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__vector_offset));
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__231__Vfuncout 
                            = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__231__expand_down) 
                               || ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__231__is_byte)) 
                                   & (0xffffU == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__231__offset_value))));
                    }(), (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__231__Vfuncout)))));
    VL_ASSIGNBIT_II(0U, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_address_ranges, 
                    (1U & (~ ([&]() {
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__213__is_byte 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__213__expand_down 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__0__KET____DOT__cache_expand_down;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__213__limit_value 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__0__KET____DOT__cache_limit;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__213__offset_value 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__address_offset;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__213__Vfuncout 
                            = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__213__expand_down)
                                ? (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__213__offset_value) 
                                    <= (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__213__limit_value)) 
                                   | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__213__is_byte)) 
                                      & (0xffffU == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__213__offset_value))))
                                : (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__213__offset_value) 
                                    > (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__213__limit_value)) 
                                   | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__213__is_byte)) 
                                      & ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__213__offset_value) 
                                         == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__213__limit_value)))));
                    }(), (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__213__Vfuncout)))));
    VL_ASSIGNBIT_II(0U, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_stack_ranges, 
                    (1U & (~ ([&]() {
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__214__is_byte 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__214__expand_down 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__0__KET____DOT__cache_expand_down;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__214__limit_value 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__0__KET____DOT__cache_limit;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__214__offset_value 
                            = spk286_profile_prefix_tb__DOT__dut__DOT__stack_offset;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__214__Vfuncout 
                            = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__214__expand_down)
                                ? (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__214__offset_value) 
                                    <= (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__214__limit_value)) 
                                   | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__214__is_byte)) 
                                      & (0xffffU == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__214__offset_value))))
                                : (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__214__offset_value) 
                                    > (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__214__limit_value)) 
                                   | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__214__is_byte)) 
                                      & ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__214__offset_value) 
                                         == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__214__limit_value)))));
                    }(), (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__214__Vfuncout)))));
    VL_ASSIGNBIT_II(0U, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_regular_ranges, 
                    (1U & (~ ([&]() {
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__215__is_byte 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__215__expand_down 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__0__KET____DOT__cache_expand_down;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__215__limit_value 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__0__KET____DOT__cache_limit;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__215__offset_value 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_offset;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__215__Vfuncout 
                            = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__215__expand_down)
                                ? (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__215__offset_value) 
                                    <= (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__215__limit_value)) 
                                   | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__215__is_byte)) 
                                      & (0xffffU == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__215__offset_value))))
                                : (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__215__offset_value) 
                                    > (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__215__limit_value)) 
                                   | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__215__is_byte)) 
                                      & ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__215__offset_value) 
                                         == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__215__limit_value)))));
                    }(), (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__215__Vfuncout)))));
    VL_ASSIGNBIT_II(1U, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_address_ranges, 
                    (1U & (~ ([&]() {
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__218__is_byte 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__218__expand_down 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__1__KET____DOT__cache_expand_down;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__218__limit_value 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__1__KET____DOT__cache_limit;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__218__offset_value 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__address_offset;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__218__Vfuncout 
                            = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__218__expand_down)
                                ? (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__218__offset_value) 
                                    <= (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__218__limit_value)) 
                                   | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__218__is_byte)) 
                                      & (0xffffU == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__218__offset_value))))
                                : (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__218__offset_value) 
                                    > (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__218__limit_value)) 
                                   | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__218__is_byte)) 
                                      & ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__218__offset_value) 
                                         == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__218__limit_value)))));
                    }(), (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__218__Vfuncout)))));
    VL_ASSIGNBIT_II(1U, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_stack_ranges, 
                    (1U & (~ ([&]() {
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__219__is_byte 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__219__expand_down 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__1__KET____DOT__cache_expand_down;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__219__limit_value 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__1__KET____DOT__cache_limit;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__219__offset_value 
                            = spk286_profile_prefix_tb__DOT__dut__DOT__stack_offset;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__219__Vfuncout 
                            = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__219__expand_down)
                                ? (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__219__offset_value) 
                                    <= (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__219__limit_value)) 
                                   | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__219__is_byte)) 
                                      & (0xffffU == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__219__offset_value))))
                                : (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__219__offset_value) 
                                    > (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__219__limit_value)) 
                                   | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__219__is_byte)) 
                                      & ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__219__offset_value) 
                                         == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__219__limit_value)))));
                    }(), (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__219__Vfuncout)))));
    VL_ASSIGNBIT_II(1U, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_regular_ranges, 
                    (1U & (~ ([&]() {
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__220__is_byte 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__220__expand_down 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__1__KET____DOT__cache_expand_down;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__220__limit_value 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__1__KET____DOT__cache_limit;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__220__offset_value 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_offset;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__220__Vfuncout 
                            = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__220__expand_down)
                                ? (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__220__offset_value) 
                                    <= (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__220__limit_value)) 
                                   | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__220__is_byte)) 
                                      & (0xffffU == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__220__offset_value))))
                                : (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__220__offset_value) 
                                    > (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__220__limit_value)) 
                                   | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__220__is_byte)) 
                                      & ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__220__offset_value) 
                                         == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__220__limit_value)))));
                    }(), (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__220__Vfuncout)))));
    VL_ASSIGNBIT_II(2U, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_address_ranges, 
                    (1U & (~ ([&]() {
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__223__is_byte 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__223__expand_down 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__2__KET____DOT__cache_expand_down;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__223__limit_value 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__2__KET____DOT__cache_limit;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__223__offset_value 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__address_offset;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__223__Vfuncout 
                            = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__223__expand_down)
                                ? (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__223__offset_value) 
                                    <= (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__223__limit_value)) 
                                   | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__223__is_byte)) 
                                      & (0xffffU == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__223__offset_value))))
                                : (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__223__offset_value) 
                                    > (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__223__limit_value)) 
                                   | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__223__is_byte)) 
                                      & ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__223__offset_value) 
                                         == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__223__limit_value)))));
                    }(), (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__223__Vfuncout)))));
    VL_ASSIGNBIT_II(2U, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_stack_ranges, 
                    (1U & (~ ([&]() {
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__224__is_byte 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__224__expand_down 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__2__KET____DOT__cache_expand_down;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__224__limit_value 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__2__KET____DOT__cache_limit;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__224__offset_value 
                            = spk286_profile_prefix_tb__DOT__dut__DOT__stack_offset;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__224__Vfuncout 
                            = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__224__expand_down)
                                ? (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__224__offset_value) 
                                    <= (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__224__limit_value)) 
                                   | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__224__is_byte)) 
                                      & (0xffffU == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__224__offset_value))))
                                : (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__224__offset_value) 
                                    > (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__224__limit_value)) 
                                   | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__224__is_byte)) 
                                      & ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__224__offset_value) 
                                         == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__224__limit_value)))));
                    }(), (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__224__Vfuncout)))));
    VL_ASSIGNBIT_II(2U, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_regular_ranges, 
                    (1U & (~ ([&]() {
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__225__is_byte 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__225__expand_down 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__2__KET____DOT__cache_expand_down;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__225__limit_value 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__2__KET____DOT__cache_limit;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__225__offset_value 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_offset;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__225__Vfuncout 
                            = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__225__expand_down)
                                ? (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__225__offset_value) 
                                    <= (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__225__limit_value)) 
                                   | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__225__is_byte)) 
                                      & (0xffffU == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__225__offset_value))))
                                : (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__225__offset_value) 
                                    > (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__225__limit_value)) 
                                   | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__225__is_byte)) 
                                      & ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__225__offset_value) 
                                         == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__225__limit_value)))));
                    }(), (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__225__Vfuncout)))));
    VL_ASSIGNBIT_II(3U, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_address_ranges, 
                    (1U & (~ ([&]() {
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__228__is_byte 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__228__expand_down 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__3__KET____DOT__cache_expand_down;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__228__limit_value 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__3__KET____DOT__cache_limit;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__228__offset_value 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__address_offset;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__228__Vfuncout 
                            = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__228__expand_down)
                                ? (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__228__offset_value) 
                                    <= (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__228__limit_value)) 
                                   | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__228__is_byte)) 
                                      & (0xffffU == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__228__offset_value))))
                                : (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__228__offset_value) 
                                    > (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__228__limit_value)) 
                                   | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__228__is_byte)) 
                                      & ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__228__offset_value) 
                                         == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__228__limit_value)))));
                    }(), (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__228__Vfuncout)))));
    VL_ASSIGNBIT_II(3U, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_stack_ranges, 
                    (1U & (~ ([&]() {
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__229__is_byte 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__229__expand_down 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__3__KET____DOT__cache_expand_down;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__229__limit_value 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__3__KET____DOT__cache_limit;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__229__offset_value 
                            = spk286_profile_prefix_tb__DOT__dut__DOT__stack_offset;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__229__Vfuncout 
                            = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__229__expand_down)
                                ? (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__229__offset_value) 
                                    <= (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__229__limit_value)) 
                                   | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__229__is_byte)) 
                                      & (0xffffU == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__229__offset_value))))
                                : (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__229__offset_value) 
                                    > (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__229__limit_value)) 
                                   | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__229__is_byte)) 
                                      & ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__229__offset_value) 
                                         == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__229__limit_value)))));
                    }(), (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__229__Vfuncout)))));
    VL_ASSIGNBIT_II(3U, vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_regular_ranges, 
                    (1U & (~ ([&]() {
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__230__is_byte 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__230__expand_down 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__3__KET____DOT__cache_expand_down;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__230__limit_value 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__3__KET____DOT__cache_limit;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__230__offset_value 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_offset;
                        vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__230__Vfuncout 
                            = ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__230__expand_down)
                                ? (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__230__offset_value) 
                                    <= (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__230__limit_value)) 
                                   | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__230__is_byte)) 
                                      & (0xffffU == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__230__offset_value))))
                                : (((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__230__offset_value) 
                                    > (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__230__limit_value)) 
                                   | ((~ (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__230__is_byte)) 
                                      & ((IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__230__offset_value) 
                                         == (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__230__limit_value)))));
                    }(), (IData)(vlSelf->__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__protected_range_exceeded__230__Vfuncout)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h564427fd__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__invalid_form) 
           | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__invalid_opcode_fault));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_capture 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_decode) 
              & ((0U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode__DOT__state_q)) 
                 & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte_ready) 
                    & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__operand_decode__byte_valid) 
                       & (0xc0U == (0xc0U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_data))))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__immediate_last 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__immediate_fetch) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__operand_decode__byte_valid) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__immediate_word)) 
                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__high_byte_q))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_replay__DOT__take_capture 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_preview__DOT__accept_byte) 
           & (0xaU > (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_replay__DOT__write_q)));
    if (spk286_profile_prefix_tb__DOT__dut__DOT__operand_select_rm) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_gpr_write_index 
            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_rm;
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__is_memory 
            = (1U & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_register_direct) 
                        & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_active_q)) 
                           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_tss_active_state_q)) 
                              & ((~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_call_stack_access)) 
                                 & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_active_q)) 
                                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__address_override)) 
                                       & ((~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__stack_request)) 
                                          & ((~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__vector_request)) 
                                             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__io_transfer))))))))))));
    } else {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_gpr_write_index 
            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg;
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__is_memory = 0U;
    }
    spk286_profile_prefix_tb__DOT__dut__DOT__protected_descriptor_address 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_address;
    if ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_phase_q))) {
        spk286_profile_prefix_tb__DOT__dut__DOT__protected_descriptor_address 
            = (0xffffffU & ((IData)(2U) + vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_address));
    } else if ((2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_phase_q))) {
        spk286_profile_prefix_tb__DOT__dut__DOT__protected_descriptor_address 
            = (0xffffffU & ((IData)(4U) + vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_address));
    } else if ((3U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_phase_q))) {
        spk286_profile_prefix_tb__DOT__dut__DOT__protected_descriptor_address 
            = (0xffffffU & ((IData)(6U) + vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_address));
    } else if ((4U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_phase_q))) {
        spk286_profile_prefix_tb__DOT__dut__DOT__protected_descriptor_address 
            = (0xffffffU & ((IData)(5U) + vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_address));
    }
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hd5c514d2__0 
        = (1U & ((~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_limit_valid)) 
                 | ((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__ldtr_present_q) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__ldtr_valid_q))) 
                    & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_value) 
                       >> 2U))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hd335f353__0 
        = (1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_null)) 
                 & (~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_limit_valid))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__immediate_capture 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__immediate_last) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__immediate_register));
    spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__register_word 
        = (0xffffU & (((0U == (0x1fU & VL_SHIFTL_III(7,7,32, 
                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte)
                                                       ? 
                                                      (3U 
                                                       & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_gpr_write_index))
                                                       : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_gpr_write_index)), 4U)))
                        ? 0U : (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__gpr_q[
                                (((IData)(0xfU) + (0x7fU 
                                                   & VL_SHIFTL_III(7,7,32, 
                                                                   ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte)
                                                                     ? 
                                                                    (3U 
                                                                     & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_gpr_write_index))
                                                                     : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_gpr_write_index)), 4U))) 
                                 >> 5U)] << ((IData)(0x20U) 
                                             - (0x1fU 
                                                & VL_SHIFTL_III(7,7,32, 
                                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte)
                                                                  ? 
                                                                 (3U 
                                                                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_gpr_write_index))
                                                                  : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_gpr_write_index)), 4U))))) 
                      | (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__gpr_q[
                         (3U & (VL_SHIFTL_III(7,7,32, 
                                              ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte)
                                                ? (3U 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_gpr_write_index))
                                                : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_gpr_write_index)), 4U) 
                                >> 5U))] >> (0x1fU 
                                             & VL_SHIFTL_III(7,7,32, 
                                                             ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte)
                                                               ? 
                                                              (3U 
                                                               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_gpr_write_index))
                                                               : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_gpr_write_index)), 4U)))));
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__offset 
            = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__io_transfer)
                ? 0U : (((~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__vector_request)) 
                         & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_hc6c48371__0))
                         ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__address_offset)
                         : ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__vector_request)
                             ? (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__vector_offset)
                             : ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__stack_request)
                                 ? (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__stack_offset)
                                 : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_offset)))));
        spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__read_index 
            = spk286_profile_prefix_tb__DOT__dut__DOT__service_segment;
    } else {
        spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__offset = 0U;
        spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__read_index = 0U;
    }
    spk286_profile_prefix_tb__DOT__dut__DOT__real_segment_base 
        = ((0x5fU >= (0x7fU & ((IData)(0x18U) * (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__read_index))))
            ? (0xffffffU & (((0U == (0x1fU & ((IData)(0x18U) 
                                              * (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__read_index))))
                              ? 0U : (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segments__DOT__base_q[
                                      (((IData)(0x17U) 
                                        + (0x7fU & 
                                           ((IData)(0x18U) 
                                            * (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__read_index)))) 
                                       >> 5U)] << ((IData)(0x20U) 
                                                   - 
                                                   (0x1fU 
                                                    & ((IData)(0x18U) 
                                                       * (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__read_index)))))) 
                            | (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segments__DOT__base_q[
                               (3U & (((IData)(0x18U) 
                                       * (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__read_index)) 
                                      >> 5U))] >> (0x1fU 
                                                   & ((IData)(0x18U) 
                                                      * (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__read_index))))))
            : 0U);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__within_limit 
        = (1U & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_active_q) 
                  | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_active_q) 
                     | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_call_stack_access) 
                        | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_tss_active_state_q)))) 
                 | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__vector_request)
                     ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_vector_ranges) 
                        >> (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__read_index))
                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__io_transfer)
                         ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_io_ranges) 
                            >> (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__read_index))
                         : ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_hc6c48371__0)
                             ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_address_ranges) 
                                >> (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__read_index))
                             : ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__stack_request)
                                 ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_stack_ranges) 
                                    >> (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__read_index))
                                 : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_regular_ranges) 
                                    >> (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__read_index))))))));
    spk286_profile_prefix_tb__DOT__segment_access = 
        (0xffU & ((1U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
                   ? (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_access_q 
                      >> (0x1fU & VL_SHIFTL_III(5,5,32, (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__read_index), 3U)))
                   : (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segments__DOT__access_q 
                      >> (0x1fU & VL_SHIFTL_III(5,5,32, (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__read_index), 3U)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__system_limit_fault 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_table_operation) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_register_direct)) 
              & (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__3__KET____DOT__cache_expand_down)
                     ? (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_offset) 
                         <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__3__KET____DOT__cache_limit)) 
                        | (0xfffaU < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_offset)))
                     : ((0x1ffffU & ((IData)(5U) + (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_offset))) 
                        > (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__3__KET____DOT__cache_limit))) 
                   << 3U) | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__2__KET____DOT__cache_expand_down)
                                ? (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_offset) 
                                    <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__2__KET____DOT__cache_limit)) 
                                   | (0xfffaU < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_offset)))
                                : ((0x1ffffU & ((IData)(5U) 
                                                + (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_offset))) 
                                   > (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__2__KET____DOT__cache_limit))) 
                              << 2U) | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__1__KET____DOT__cache_expand_down)
                                           ? (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_offset) 
                                               <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__1__KET____DOT__cache_limit)) 
                                              | (0xfffaU 
                                                 < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_offset)))
                                           : ((0x1ffffU 
                                               & ((IData)(5U) 
                                                  + (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_offset))) 
                                              > (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__1__KET____DOT__cache_limit))) 
                                         << 1U) | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__0__KET____DOT__cache_expand_down)
                                                    ? 
                                                   (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_offset) 
                                                     <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__0__KET____DOT__cache_limit)) 
                                                    | (0xfffaU 
                                                       < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_offset)))
                                                    : 
                                                   ((0x1ffffU 
                                                     & ((IData)(5U) 
                                                        + (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_offset))) 
                                                    > (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__g_operand_cache_range__BRA__0__KET____DOT__cache_limit)))))) 
                 >> (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__read_index))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_pre_fault 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_begin) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q)) 
              | (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hf67482c1__0) 
                  & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_value) 
                      >> 2U) | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_carry) 
                                | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hd335f353__0) 
                                   | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_tr) 
                                      & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_null)))))) 
                 | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_reload_operation) 
                     & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_carry) 
                        | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hd335f353__0) 
                           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_null) 
                              & (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__decoded_segment_index)))))) 
                    | (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h2c23db46__0) 
                        | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_validation_operation) 
                           | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_ss_validation_operation))) 
                       & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_carry) 
                          | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_null) 
                             | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hd5c514d2__0))))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_operand_read_data 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h4b82a8ba__0)
            ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__memory_read_data)
            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__is_memory)
                ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__memory_read_data)
                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_byte)
                    ? (0xffU & ((4U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_gpr_write_index))
                                 ? ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__register_word) 
                                    >> 8U) : (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__register_word)))
                    : (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__register_word))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_msw_load_data 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_task_load)
            ? (8U | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_commit)
                ? (0xfff7U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
                : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_operand_read_data)));
    spk286_profile_prefix_tb__DOT__dut__DOT__operand_physical_address 
        = (0xffffffU & (((1U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
                          ? ((0x5fU >= (0x7fU & ((IData)(0x18U) 
                                                 * (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__read_index))))
                              ? (((0U == (0x1fU & ((IData)(0x18U) 
                                                   * (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__read_index))))
                                   ? 0U : (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_base_q[
                                           (((IData)(0x17U) 
                                             + (0x7fU 
                                                & ((IData)(0x18U) 
                                                   * (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__read_index)))) 
                                            >> 5U)] 
                                           << ((IData)(0x20U) 
                                               - (0x1fU 
                                                  & ((IData)(0x18U) 
                                                     * (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__read_index)))))) 
                                 | (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_base_q[
                                    (3U & (((IData)(0x18U) 
                                            * (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__read_index)) 
                                           >> 5U))] 
                                    >> (0x1fU & ((IData)(0x18U) 
                                                 * (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__read_index)))))
                              : 0U) : spk286_profile_prefix_tb__DOT__dut__DOT__real_segment_base) 
                        + (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__offset)));
    if (spk286_profile_prefix_tb__DOT__dut__DOT__vector_request) {
        spk286_profile_prefix_tb__DOT__dut__DOT__operand_physical_address 
            = spk286_profile_prefix_tb__DOT__dut__DOT__vector_offset;
    }
    if (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__io_transfer) {
        spk286_profile_prefix_tb__DOT__dut__DOT__operand_physical_address 
            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp1_q;
    }
    if (spk286_profile_prefix_tb__DOT__dut__DOT__protected_call_stack_access) {
        spk286_profile_prefix_tb__DOT__dut__DOT__operand_physical_address 
            = (0xffffffU & (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_base_q 
                            + (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__stack_offset)));
    }
    if (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_tss_active_state_q) {
        spk286_profile_prefix_tb__DOT__dut__DOT__operand_physical_address 
            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_tss_address;
    }
    if (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_active_q) {
        spk286_profile_prefix_tb__DOT__dut__DOT__operand_physical_address 
            = spk286_profile_prefix_tb__DOT__dut__DOT__protected_descriptor_address;
    }
    if (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_active_q) {
        spk286_profile_prefix_tb__DOT__dut__DOT__operand_physical_address 
            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_event_address;
    }
    spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_hd259eb91__0 
        = (1U & (~ (IData)((2U == (0xaU & (IData)(spk286_profile_prefix_tb__DOT__segment_access))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h07c77af6__0 
        = (1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__system_limit_fault)) 
                 & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_privilege_fault)) 
                    & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_mode_fault)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_null_commit 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_begin) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_null) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_pre_fault)) 
                 & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_privilege_fault)) 
                    & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_ldtr)))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0cf4309e__0 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_pre_fault)) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_null) 
              | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_carry) 
                 | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hd5c514d2__0))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_gdtr_load_base 
        = ((0xff0000U & (((2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_index_q))
                           ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_operand_read_data)
                           : (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_base_q 
                              >> 0x10U)) << 0x10U)) 
           | (0xffffU & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_base_q));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__memory_address 
        = (0xffffffU & ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_service__DOT__state_q))
                         ? ((IData)(0x800U) + ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_service__DOT__word_index_q) 
                                               << 1U))
                         : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_memory_request)
                             ? ((2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__state_q))
                                 ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__incoming_ldtr_descriptor_address_q
                                 : ((3U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__state_q))
                                     ? ((IData)(2U) 
                                        + vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__incoming_ldtr_descriptor_address_q)
                                     : ((4U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__state_q))
                                         ? ((IData)(4U) 
                                            + vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__incoming_ldtr_descriptor_address_q)
                                         : ((5U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__state_q))
                                             ? ((IData)(6U) 
                                                + vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__incoming_ldtr_descriptor_address_q)
                                             : ((0xcU 
                                                 == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__state_q))
                                                 ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__current_base_q
                                                 : 
                                                ((0xdU 
                                                  == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__state_q))
                                                  ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__return_descriptor_address
                                                  : 
                                                 ((0xeU 
                                                   == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__state_q))
                                                   ? 
                                                  ((IData)(2U) 
                                                   + vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__return_descriptor_address)
                                                   : 
                                                  ((0xfU 
                                                    == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__state_q))
                                                    ? 
                                                   ((IData)(4U) 
                                                    + vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__return_descriptor_address)
                                                    : 
                                                   ((0x10U 
                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__state_q))
                                                     ? 
                                                    ((IData)(6U) 
                                                     + vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__return_descriptor_address)
                                                     : 
                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_memory_request)
                                                      ? 
                                                     ((2U 
                                                       == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__state_q))
                                                       ? 
                                                      (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT____VdfgTmp_he1491d44__0 
                                                       + 
                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT__word_index_q) 
                                                        << 1U))
                                                       : 
                                                      ((IData)(5U) 
                                                       + vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__segment_service__DOT____VdfgTmp_he1491d44__0))
                                                      : vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_memory_address))))))))))
                             : spk286_profile_prefix_tb__DOT__dut__DOT__operand_physical_address)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_begin 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_operation) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_active_q)) 
              & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h07c77af6__0)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_operand_request 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_active_q) 
           & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_operation) 
              & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h07c77af6__0)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_ldtr_commit_valid 
        = (1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_task_load)) 
                 & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_ldtr_write)
                     ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__incoming_ldtr_valid_q)
                     : (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_null_commit)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_verify_negative 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_begin) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_verify_operation) 
              & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0cf4309e__0)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_inspect_negative 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_begin) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_inspect_operation) 
              & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0cf4309e__0)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_operand_write 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_operand_request) 
           & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_table_store) 
              | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_msw_store) 
                 | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_selector_store))));
    spk286_profile_prefix_tb__DOT__dut__DOT__operand_request 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h4b82a8ba__0) 
           | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_operand_request) 
              | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__io_transfer) 
                 | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__string_request) 
                    | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__vector_request) 
                       | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__stack_request) 
                          | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_check) 
                             | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h657a4724__0) 
                                | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
                                   & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__write_reg_tmp1) 
                                      | ((5U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                         | ((6U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                            | ((0x2eU 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                               | ((0x2fU 
                                                   == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                                  | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_tmp1) 
                                                     | ((((7U 
                                                           == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                                          | ((8U 
                                                              == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                                             | ((0x30U 
                                                                 == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                                                | (0x31U 
                                                                   == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word))))) 
                                                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__temporary_valid_q)) 
                                                        | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hb678200d__0) 
                                                           & ((0x11U 
                                                               != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                                              & (0x39U 
                                                                 != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word))))))))))))))))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_write_data 
        = (0xffffU & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h657a4724__0)
                       ? ((0xfffcU & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp0_q)) 
                          | (3U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp1_q)))
                       : ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_write)
                           ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_data_q)
                           : ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_write)
                               ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_data_q)
                               : ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_write)
                                   ? (0xffU & ((IData)(
                                                       (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                                                        >> 0x28U)) 
                                               | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_tr)
                                                   ? 2U
                                                   : 1U)))
                                   : ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_operand_write)
                                       ? ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_ldtr_store)
                                           ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__ldtr_selector_q)
                                           : ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_tr_store)
                                               ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__tr_selector_q)
                                               : ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_msw_store)
                                                   ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q)
                                                   : 
                                                  ((0U 
                                                    == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_index_q))
                                                    ? 
                                                   ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_is_gdtr)
                                                     ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__gdtr_limit_q)
                                                     : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__idtr_limit_q))
                                                    : 
                                                   ((1U 
                                                     == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_index_q))
                                                     ? vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_selected_base
                                                     : 
                                                    (0xff00U 
                                                     | (0xffU 
                                                        & (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_selected_base 
                                                           >> 0x10U))))))))
                                       : ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__push_event_error_transfer)
                                           ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_error_code)
                                           : (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__push_transfer) 
                                               & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active)) 
                                                  & ((0xffU 
                                                      == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q)) 
                                                     & (2U 
                                                        == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg)))))
                                               ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__ip_q)
                                               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__write_reg_tmp1)
                                                   ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp1_q)
                                                   : 
                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__result_operation)
                                                    ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp2_q)
                                                    : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp0_q)))))))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_write 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_write) 
           | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_operand_write) 
              | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__io_write) 
                 | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_store) 
                    | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__write_reg_tmp1) 
                       | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__push_transfer) 
                          | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__push_event_error_transfer) 
                             | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_write) 
                                | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_write) 
                                   | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h657a4724__0) 
                                      | ((7U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                         | ((8U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                            | ((0x30U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                               | ((0x31U 
                                                   == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                                  | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__result_operation)))))))))))))));
    __Vtemp_8[0U] = ((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__load_words_q
                      [3U] << 0x10U) | vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__load_words_q
                     [2U]);
    __Vtemp_8[1U] = ((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__load_words_q
                      [5U] << 0x10U) | vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__load_words_q
                     [4U]);
    __Vtemp_8[2U] = (IData)((((QData)((IData)(((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__load_words_q
                                                [9U] 
                                                << 0x10U) 
                                               | vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__load_words_q
                                               [8U]))) 
                              << 0x20U) | (QData)((IData)(
                                                          ((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__load_words_q
                                                            [7U] 
                                                            << 0x10U) 
                                                           | vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__load_words_q
                                                           [6U])))));
    __Vtemp_8[3U] = (IData)(((((QData)((IData)(((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__load_words_q
                                                 [9U] 
                                                 << 0x10U) 
                                                | vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__load_words_q
                                                [8U]))) 
                               << 0x20U) | (QData)((IData)(
                                                           ((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__load_words_q
                                                             [7U] 
                                                             << 0x10U) 
                                                            | vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__task_service__DOT__load_words_q
                                                            [6U])))) 
                             >> 0x20U));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[0U] 
        = (IData)((((QData)((IData)((0xffffU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_cursor_q) 
                                                + (
                                                   ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__commit_context) 
                                                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allocation_valid_q))
                                                    ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allocation_q)
                                                    : 0U))))) 
                    << 0x30U) | (((QData)((IData)((
                                                   (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allocation_q) 
                                                     + (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_sp_q)) 
                                                    << 0x10U) 
                                                   | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_sp_q)))) 
                                  << 0x10U) | (QData)((IData)(
                                                              (0xffffU 
                                                               & (((0U 
                                                                    == 
                                                                    (0x1fU 
                                                                     & VL_SHIFTL_III(7,7,32, 
                                                                                (7U 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_phase_q)), 4U)))
                                                                    ? 0U
                                                                    : 
                                                                   (__Vtemp_8[
                                                                    (((IData)(0xfU) 
                                                                      + 
                                                                      (0x7fU 
                                                                       & VL_SHIFTL_III(7,7,32, 
                                                                                (7U 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_phase_q)), 4U))) 
                                                                     >> 5U)] 
                                                                    << 
                                                                    ((IData)(0x20U) 
                                                                     - 
                                                                     (0x1fU 
                                                                      & VL_SHIFTL_III(7,7,32, 
                                                                                (7U 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_phase_q)), 4U))))) 
                                                                  | (__Vtemp_8[
                                                                     (3U 
                                                                      & (VL_SHIFTL_III(7,7,32, 
                                                                                (7U 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_phase_q)), 4U) 
                                                                         >> 5U))] 
                                                                     >> 
                                                                     (0x1fU 
                                                                      & VL_SHIFTL_III(7,7,32, 
                                                                                (7U 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_phase_q)), 4U))))))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[1U] 
        = (IData)(((((QData)((IData)((0xffffU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_cursor_q) 
                                                 + 
                                                 (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__commit_context) 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allocation_valid_q))
                                                   ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allocation_q)
                                                   : 0U))))) 
                     << 0x30U) | (((QData)((IData)(
                                                   ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allocation_q) 
                                                      + (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_sp_q)) 
                                                     << 0x10U) 
                                                    | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_sp_q)))) 
                                   << 0x10U) | (QData)((IData)(
                                                               (0xffffU 
                                                                & (((0U 
                                                                     == 
                                                                     (0x1fU 
                                                                      & VL_SHIFTL_III(7,7,32, 
                                                                                (7U 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_phase_q)), 4U)))
                                                                     ? 0U
                                                                     : 
                                                                    (__Vtemp_8[
                                                                     (((IData)(0xfU) 
                                                                       + 
                                                                       (0x7fU 
                                                                        & VL_SHIFTL_III(7,7,32, 
                                                                                (7U 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_phase_q)), 4U))) 
                                                                      >> 5U)] 
                                                                     << 
                                                                     ((IData)(0x20U) 
                                                                      - 
                                                                      (0x1fU 
                                                                       & VL_SHIFTL_III(7,7,32, 
                                                                                (7U 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_phase_q)), 4U))))) 
                                                                   | (__Vtemp_8[
                                                                      (3U 
                                                                       & (VL_SHIFTL_III(7,7,32, 
                                                                                (7U 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_phase_q)), 4U) 
                                                                          >> 5U))] 
                                                                      >> 
                                                                      (0x1fU 
                                                                       & VL_SHIFTL_III(7,7,32, 
                                                                                (7U 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_phase_q)), 4U))))))))) 
                   >> 0x20U));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[2U] 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_cursor_q) 
            << 0x10U) | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_cursor_q));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[3U] 
        = ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__write_result_dx)
              ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__auxiliary_q)
              : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp2_q)) 
            << 0x10U) | (0xffffU & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_access)
                                     ? (0xff00U & ((IData)(
                                                           (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                                                            >> 0x28U)) 
                                                   << 8U))
                                     : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[4U] 
        = (((((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__gpr_q[0U] 
               << 0x10U) | (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__gpr_q[0U] 
                            >> 0x10U)) - (IData)(1U)) 
            << 0x10U) | (0xffffU & ((0x400U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__flags_q))
                                     ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_index) 
                                        - ((1U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q))
                                            ? 2U : 1U))
                                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_index) 
                                        + ((1U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q))
                                            ? 2U : 1U)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[5U] 
        = ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allocation_q) 
             + vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__gpr_q[2U]) 
            << 0x10U) | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp0_q));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[6U] 
        = ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_cursor_q) 
             - (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allocation_q)) 
            << 0x10U) | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp0_q));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[7U] 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_next_sp) 
            << 0x10U) | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp1_q));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[8U] 
        = (IData)((((QData)((IData)((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_write_data) 
                                      << 0x10U) | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp0_q)))) 
                    << 0x20U) | (QData)((IData)((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp2_q) 
                                                  << 0x10U) 
                                                 | (0xffffU 
                                                    & (((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__gpr_q[0U] 
                                                         << 0x10U) 
                                                        | (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__gpr_q[0U] 
                                                           >> 0x10U)) 
                                                       - (IData)(1U))))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[9U] 
        = (IData)(((((QData)((IData)((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_write_data) 
                                       << 0x10U) | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp0_q)))) 
                     << 0x20U) | (QData)((IData)((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp2_q) 
                                                   << 0x10U) 
                                                  | (0xffffU 
                                                     & (((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__gpr_q[0U] 
                                                          << 0x10U) 
                                                         | (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__gpr_q[0U] 
                                                            >> 0x10U)) 
                                                        - (IData)(1U))))))) 
                   >> 0x20U));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_operand 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__operand_request) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_active_q)) 
              & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_check) 
                    | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_write)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_access_fault 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__operand_request) 
           & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__operand_select_rm) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_register_direct)) 
                 & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_active_q)) 
                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_tss_active_state_q)) 
                       & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_active_q)) 
                          & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__io_transfer)) 
                             & ((~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__vector_request)) 
                                & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_call_stack_access)
                                    ? ((2U != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__service_segment)) 
                                       | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__protected_call_range_fault))
                                    : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q) 
                                       & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_protected_q) 
                                           >> (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__service_segment)) 
                                          & ((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_valid_q) 
                                                 >> (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__service_segment))) 
                                             | ((~ 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__segment_present_q) 
                                                  >> (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__service_segment))) 
                                                | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__within_limit)) 
                                                   | ((8U 
                                                       & (IData)(spk286_profile_prefix_tb__DOT__segment_access))
                                                       ? 
                                                      ((~ 
                                                        ((IData)(spk286_profile_prefix_tb__DOT__segment_access) 
                                                         >> 1U)) 
                                                       | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_write))
                                                       : 
                                                      ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__stack_request)
                                                        ? 
                                                       ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_hd259eb91__0) 
                                                        | (2U 
                                                           != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__service_segment)))
                                                        : 
                                                       ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_hd259eb91__0) 
                                                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_write))))))))))))))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_hced645af__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_access_fault) 
            & (2U == (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__service_segment))) 
           | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__range_fault) 
               | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__system_limit_fault)) 
              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q) 
                 & (2U == (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__service_segment)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__allowed 
        = (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_access_fault)) 
            & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__operand_request)) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__reset)) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__semantic_cancel)) 
                 & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__operand_blocked)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_memory_response_ready 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__allowed) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__pending_q));
    spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT____VdfgTmp_h73c33177__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__allowed) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__is_memory));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_done 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__allowed) 
           & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_check) 
               & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__pending_q)) 
                  & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__is_memory)) 
                     | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__within_limit)))) 
              | (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__is_memory)) 
                  & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__pending_q))) 
                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT____VdfgTmp_h314da18c__0))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_operand_done 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h4b82a8ba__0)
            ? ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__reset)) 
               & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__semantic_cancel)) 
                  & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__operand_blocked)) 
                     & (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__pending_q)) 
                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_check)) 
                        | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT____VdfgTmp_h314da18c__0)))))
            : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_done));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_memory_request 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT____VdfgTmp_h73c33177__0) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__pending_q)) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_check)) 
                 & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand__DOT__within_limit))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__memory_request 
        = ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_service__DOT__state_q)) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_memory_request) 
              | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_memory_request)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_pop_done 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_pop) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_operand_done));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_read_done 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_read) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_operand_done));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_tss_operand_done 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_tss_active_state_q) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_operand_done));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_write_done 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_write) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_operand_done));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_write_done 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_write) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_operand_done));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_operand_done 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_operand_request) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_operand_done));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_commit 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_operation) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__lock_prefix)) 
                 & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_adjust)) 
                    | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_operand_done)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_write_sp 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_stack) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_operand_done) 
              & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbabeeb40__0) 
                 | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_write))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_operand_done 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_active_q) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_operand_done));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_operand_done 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_active_q) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_operand_done));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__extra_next 
        = (0x7ffU & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__extra_q) 
                     + (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__memory_request) 
                         & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__memory_request_ready) 
                            & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__memory_byte)) 
                               & vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__memory_address)))
                         ? 2U : 0U)));
    if ((0x3ffU < (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__extra_next))) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_schedule__DOT__extra_next = 0x3ffU;
    }
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h8a02c0df__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_table_load) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_operand_done) 
              & (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_index_q))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_arch_write 
        = ((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_cursor_valid_q) 
               | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__begin_return_cursor))) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_write_sp));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hfe54633e__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_operand_done) 
           & (3U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_phase_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbc8e52c8__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_operand_done) 
           & (4U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_phase_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h81ee59e2__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_operand_done) 
           & (3U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_phase_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_gdtr_load_en 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h8a02c0df__0) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_is_gdtr));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_idtr_load_en 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_is_gdtr)) 
           & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h8a02c0df__0));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_high_word_valid 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_unused_segment) 
           | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hfe54633e__0)
               ? (0U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_operand_read_data))
               : (0U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_word3_q))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbb636733__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbc8e52c8__0) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_tr) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_success_q)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hc0c4091d__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbc8e52c8__0) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_reload_operation) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_success_q)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h82b5883d__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h81ee59e2__0) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_verify_operation));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h8e881c59__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h81ee59e2__0) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_inspect_operation));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h6a853812__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h81ee59e2__0) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_reload_operation));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_high_word_valid 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_unused_segment) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h81ee59e2__0)
               ? (0U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_operand_read_data))
               : (0U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_word3_q))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_access_valid 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_low_valid) 
           & (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_high_word_valid) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_low_reserved_valid)) 
              & (((8U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_class)) 
                  | ((9U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_class)) 
                     | (7U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_class)))) 
                 & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_software)) 
                    | ((3U & (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__event_gate_parser__raw_descriptor 
                                      >> 0x2dU))) >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__current_cpl))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_tr_commit_en 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_task_load) 
           | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbb636733__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_verify_flags_write 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_pre_fault)) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_verify_negative) 
              | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h82b5883d__0)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_inspect_flags_write 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_pre_fault)) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_inspect_negative) 
              | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h8e881c59__0)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h72e9be9b__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_low_valid) 
           & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_high_word_valid) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_low_reserved_valid)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_success_live 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_access_valid) 
           & (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__event_gate_parser__raw_descriptor 
                      >> 0x2fU)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_system_access_valid 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h72e9be9b__0) 
           & (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_ldtr) 
               & (0xaU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_class))) 
              | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_tr) 
                 & ((4U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_class)) 
                    & (0x2bU <= (0xffffU & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor)))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_access_valid 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h72e9be9b__0) 
           & ((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_value) 
                  >> 2U)) & ((4U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_class)) 
                             & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_target_active_q) 
                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h47070c4b__0) 
                                   | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hd7564ff8__0))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_inspect_success_live 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h72e9be9b__0) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h6f1b5359__0) 
              & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_access) 
                 | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_limit) 
                    & (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_unused_conforming)) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_unused_segment)) 
                       | ((4U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_class)) 
                          | ((5U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_class)) 
                             | (0xaU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_class)))))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_gate_access_valid 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h72e9be9b__0) 
           & ((6U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_class)) 
              & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hd7564ff8__0)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_access_valid 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h72e9be9b__0) 
           & ((7U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_class)) 
              & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hd7564ff8__0)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_segment_access_valid 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h72e9be9b__0) 
           & ((2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__decoded_segment_index))
               ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h669f3c1e__0) 
                  & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_unused_writable) 
                     & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h1c5fbef9__0) 
                        & ((3U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_value)) 
                           == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__current_cpl)))))
               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_unused_segment) 
                  & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_unused_conforming) 
                      | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h6f1b5359__0)) 
                     & ((1U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_class)) 
                        | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_unused_readable))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he4d05fbc__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h72e9be9b__0) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_unused_segment));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_post_fault 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_success_live)) 
           & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hfe54633e__0));
    spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__registers__flags_write_mask 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable)
            ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hb5d3750f__0)
                ? (((IData)(vlSelf->__VdfgTmp_h1c2f81f0__0)
                     ? 0xffefU : 0xffffU) & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__decoded_flags_mask))
                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_flags_write)
                    ? 0xffffU : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_commit)
                                  ? 0x40U : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__direct_flags)
                                              ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__direct_flags_mask)
                                              : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_verify_flags_write)
                                                  ? 0x40U
                                                  : 
                                                 ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_inspect_flags_write)
                                                   ? 0x40U
                                                   : 
                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__restore_flags)
                                                    ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_flags_write_mask)
                                                    : 
                                                   ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_commit)
                                                     ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_flags_write_mask)
                                                     : 
                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__set_if)
                                                      ? 0x200U
                                                      : 
                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clear_if_tf)
                                                       ? 0x300U
                                                       : 
                                                      ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clear_event_flags)
                                                        ? 
                                                       ((1U 
                                                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
                                                         ? 
                                                        ((8U 
                                                          == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_class_q))
                                                          ? 0x4300U
                                                          : 0x4100U)
                                                         : 0x300U)
                                                        : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__flags_mask_q))))))))))))
            : 0U);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__effective_flags_mask 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) 
            & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__reset)) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_flags_write)))
            ? (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__registers__flags_write_mask)
            : (0x7fd5U & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__registers__flags_write_mask)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_success_live 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_system_access_valid) 
           & (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                      >> 0x2fU)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_success_live 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_access_valid) 
           & (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                      >> 0x2fU)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_result_write 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_active_q) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_operand_done) 
              & ((3U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_phase_q)) 
                 & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_inspect_operation) 
                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_inspect_success_live)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_gate_success_live 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_gate_access_valid) 
           & (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                      >> 0x2fU)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_success_live 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_access_valid) 
           & (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                      >> 0x2fU)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h4aae6acf__0 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he4d05fbc__0) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h46e8c854__0));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hc5701f43__0 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he4d05fbc__0) 
           & (1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_class)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h748f4ecd__0 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_pre_fault) 
           | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_post_fault));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he95c168d__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h81ee59e2__0) 
           & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_load_ldtr) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_success_live)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__jmp_gate_target_begin 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h81ee59e2__0) 
           & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__jmp_gate_probe_operation) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_gate_success_live)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_target_begin 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h81ee59e2__0) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_target_active_q)) 
              & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hb6f57119__0) 
                 & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_success_live))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_ss_access_valid 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h4aae6acf__0) 
           & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_target_dpl_q) 
               == (3U & (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                                 >> 0x2dU)))) & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_target_dpl_q) 
                                                 == 
                                                 (3U 
                                                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_value)))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_iret_ss_access_valid 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h4aae6acf__0) 
           & (((3U & (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                              >> 0x2dU))) == (3U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp1_q))) 
              & ((3U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_value)) 
                 == (3U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp1_q)))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_gate_cs_access_valid 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hc5701f43__0) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h1f6c94ab__0) 
              & ((~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__jmp_gate_cs_validation_operation)) 
                 | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_unused_conforming) 
                    | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h1c5fbef9__0)))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_iret_cs_access_valid 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hc5701f43__0) 
           & (((3U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_value)) 
               >= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__current_cpl)) 
              & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_unused_conforming) 
                  & ((3U & (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                                    >> 0x2dU))) <= 
                     (3U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_value)))) 
                 | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_unused_conforming)) 
                    & ((3U & (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                                      >> 0x2dU))) == 
                       (3U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_value)))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_access_valid 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hc5701f43__0) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_candidate_valid_q)
               ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h1f6c94ab__0)
               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hfed63a1d__0) 
                  | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_unused_conforming)) 
                     & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h1c5fbef9__0) 
                        & ((3U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_value)) 
                           <= (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__current_cpl)))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_ldtr_commit_en 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_ldtr_write) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_null_commit) 
              | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he95c168d__0)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_ss_success_live 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_ss_access_valid) 
           & (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                      >> 0x2fU)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_iret_ss_success_live 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_iret_ss_access_valid) 
           & (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                      >> 0x2fU)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h503ab7d7__0 
        = (((~ (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                        >> 0x2fU))) & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_gate_cs_access_valid))
            ? 0xbU : 0xdU);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_gate_cs_success_live 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_gate_cs_access_valid) 
           & (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                      >> 0x2fU)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_iret_cs_success_live 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_iret_cs_access_valid) 
           & (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                      >> 0x2fU)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he0669a8c__0 
        = (((~ (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                        >> 0x2fU))) & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_target_active_q)
                                        ? (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_access_valid)
                                        : ((6U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_class))
                                            ? (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_gate_access_valid)
                                            : ((7U 
                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_class))
                                                ? (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_access_valid)
                                                : (
                                                   (1U 
                                                    == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_class))
                                                    ? (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_access_valid)
                                                    : (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_access_valid))))))
            ? 0xbU : 0xdU);
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_success_live 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_access_valid) 
           & (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                      >> 0x2fU)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hc92b0026__0 
        = (1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_iret_cs_success_live)) 
                 | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hf949133e__0) 
                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_iret_cs_success_live))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__system_fault_vector 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__npx_fault)
            ? 7U : ((0xbU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__state_q))
                     ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__fault_vector_q)
                     : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_mode_fault)
                         ? 6U : (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_privilege_fault) 
                                  | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__io_privilege_fault) 
                                     | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__halt_privilege_fault)))
                                  ? 0xdU : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_fault)
                                             ? 6U : 
                                            ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_lock_fault)
                                              ? 6U : 
                                             ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_privilege_fault)
                                               ? 0xdU
                                               : ((1U 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q))
                                                   ? 
                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_tss_pre_fault)
                                                    ? 0xaU
                                                    : 
                                                   ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_range_fault)
                                                     ? 0xcU
                                                     : 
                                                    ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_pre_fault)
                                                      ? 0xdU
                                                      : 
                                                     ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_post_fault)
                                                       ? 
                                                      (((~ (IData)(
                                                                   (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__event_gate_parser__raw_descriptor 
                                                                    >> 0x2fU))) 
                                                        & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_access_valid))
                                                        ? 0xbU
                                                        : 0xdU)
                                                       : 
                                                      ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_validation_operation)
                                                        ? 
                                                       (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_pre_fault)) 
                                                         & ((~ (IData)(
                                                                       (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                                                                        >> 0x2fU))) 
                                                            & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_ss_access_valid)))
                                                         ? 0xcU
                                                         : 0xaU)
                                                        : 
                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_pre_fault)
                                                         ? 0xdU
                                                         : 
                                                        ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__jmp_gate_cs_validation_operation)
                                                          ? (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h503ab7d7__0)
                                                          : 
                                                         ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h9ac33813__0)
                                                           ? 
                                                          (((~ (IData)(
                                                                       (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                                                                        >> 0x2fU))) 
                                                            & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_gate_access_valid))
                                                            ? 0xbU
                                                            : 0xdU)
                                                           : 
                                                          (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hb6f57119__0) 
                                                            & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_unused_segment))
                                                            ? 
                                                           (((~ (IData)(
                                                                        (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                                                                         >> 0x2fU))) 
                                                             & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_access_valid))
                                                             ? 0xbU
                                                             : 0xdU)
                                                            : 
                                                           ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_validation_operation)
                                                             ? (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he0669a8c__0)
                                                             : 
                                                            ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_cs_validation_operation)
                                                              ? (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h503ab7d7__0)
                                                              : 
                                                             ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_ss_validation_operation)
                                                               ? 
                                                              (((~ (IData)(
                                                                           (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                                                                            >> 0x2fU))) 
                                                                & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_iret_ss_access_valid))
                                                                ? 0xcU
                                                                : 0xdU)
                                                               : 
                                                              ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_cs_validation_operation)
                                                                ? 
                                                               (((~ (IData)(
                                                                            (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                                                                             >> 0x2fU))) 
                                                                 & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_iret_cs_access_valid))
                                                                 ? 0xbU
                                                                 : 0xdU)
                                                                : 
                                                               ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_validation_operation)
                                                                 ? (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he0669a8c__0)
                                                                 : 
                                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_reload_operation)
                                                                  ? 
                                                                 (((~ (IData)(
                                                                              (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                                                                               >> 0x2fU))) 
                                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_segment_access_valid))
                                                                   ? 
                                                                  ((2U 
                                                                    == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__decoded_segment_index))
                                                                    ? 0xcU
                                                                    : 0xbU)
                                                                   : 0xdU)
                                                                  : 
                                                                 (((~ (IData)(
                                                                              (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                                                                               >> 0x2fU))) 
                                                                   & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_system_access_valid))
                                                                   ? 0xbU
                                                                   : 0xdU))))))))))))))))
                                                   : 6U))))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_candidate_success_live 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_cs_validation_operation)
            ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_gate_cs_success_live)
            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_cs_validation_operation)
                ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_iret_cs_success_live)
                : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_success_live)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_segment_success_live 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_segment_null_commit) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_cs_validation_operation)
               ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_iret_cs_success_live)
               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_validation_operation)
                   ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_success_live)
                   : ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_segment_access_valid) 
                      & (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                                 >> 0x2fU))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_offset_fault 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hedc9faf1__0) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_operand_done) 
              & ((3U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_phase_q)) 
                 & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_candidate_success_live) 
                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hf949133e__0)))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h9213fbb4__0 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h6a853812__0) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_segment_success_live) 
              & (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                         >> 0x28U))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0c8da3c8__0 
        = (1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_gate_cs_success_live)) 
                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_offset_fault)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h720a7911__0 
        = (1U & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_success_live)) 
                 | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_offset_fault)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_en 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_segment_write) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h34e1cf13__0) 
              | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_segment_null_commit) 
                 | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h9213fbb4__0) 
                    | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hc0c4091d__0)))));
    __Vdeeptemp_h4ad99da3__0 = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__carry_fill_byte) 
                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__decrement_counter) 
                                   | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__counter_branch) 
                                      | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__begin_stack_cursor) 
                                         | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_stack_cursor) 
                                            | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__set_frame_address) 
                                               | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__decrement_frame_address) 
                                                  | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allocate_stack) 
                                                     | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__set_ea_plus2) 
                                                        | (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__range_fault)) 
                                                            & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_push8) 
                                                               | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_pop8) 
                                                                  | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_stack_word) 
                                                                     | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_rm32) 
                                                                        | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_call_frame)))))) 
                                                           | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_stack_validation_operation) 
                                                               & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_outer_required)) 
                                                                  | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_stack_ready_q) 
                                                                     | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_tss_operand_done) 
                                                                        & (1U 
                                                                           == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_tss_phase_q)))))) 
                                                              | (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_switch_operation) 
                                                                  & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_outer_required)) 
                                                                     | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_write_done) 
                                                                        & (1U 
                                                                           == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_switch_phase_q))))) 
                                                                 | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__copy_call_parameters) 
                                                                     & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_outer_required)) 
                                                                        | ((0U 
                                                                            == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_parameter_count_q)) 
                                                                           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_write_done) 
                                                                              & (1U 
                                                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_parameter_remaining_q)))))) 
                                                                    | (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__bounds_fault)) 
                                                                        & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_bounds)) 
                                                                       | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_segment) 
                                                                          | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__internal_segment_write) 
                                                                             | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_complete) 
                                                                                | (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arithmetic_fault_q)) 
                                                                                & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_arithmetic)) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__dispatch_request) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__constant_zero) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__constant_ones) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_ea) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_target) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__move_source) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__set_address) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__add_base) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__shift_complete) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__count_low) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__direct_flags) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__sign_extend_byte) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__sign_fill_word) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__constant_one) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_flags) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__restore_flags) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__set_if) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clear_if_tf) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_event_flags) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_event_cs) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_event_ip) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__context_commit) 
                                                                                | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__software_request) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__halt_operation) 
                                                                                | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_protected_check) 
                                                                                | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_privilege_check) 
                                                                                | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__io_privilege_check) 
                                                                                | (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__npx_fault)) 
                                                                                & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__npx_esc_check) 
                                                                                | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__npx_wait_check))) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clear_event_flags) 
                                                                                | (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__push_event_error) 
                                                                                & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_error_valid)) 
                                                                                | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__push_event_error_transfer) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_operand_done)))) 
                                                                                | (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__ack_operation) 
                                                                                & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_needs_ack)) 
                                                                                | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__ack_done))) 
                                                                                | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fetch_byte) 
                                                                                | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fetch_byte_tmp1)) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__operand_decode__byte_valid)) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_ip) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__target_relative) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__target_absolute) 
                                                                                | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__adjust_stack) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__count_operation) 
                                                                                | (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__micro_executor__push_enabled)) 
                                                                                & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__push_operation)) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__redirect_operation) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__move_word) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__read_destination) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__compute_alu) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__commit_flags) 
                                                                                | (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allow_result_write)) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__commit_result)) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__result_to_dst) 
                                                                                | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fetch_word) 
                                                                                & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__operand_decode__byte_valid) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__high_byte_q))) 
                                                                                | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fetch_signed_byte) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__operand_decode__byte_valid)) 
                                                                                | (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode_enable) 
                                                                                & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__operand_decode_done)) 
                                                                                | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_operand_done) 
                                                                                & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_table_operation)) 
                                                                                | (2U 
                                                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_index_q)))) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_verify_negative) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_inspect_negative) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_null_commit) 
                                                                                | (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_outer_required)) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_validation_operation)) 
                                                                                | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he95c168d__0) 
                                                                                | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbb636733__0) 
                                                                                | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h82b5883d__0) 
                                                                                | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h8e881c59__0) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_segment_null_commit) 
                                                                                | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h9213fbb4__0) 
                                                                                | (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_segment_success_live)) 
                                                                                & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h6a853812__0)) 
                                                                                | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hc0c4091d__0) 
                                                                                | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h81ee59e2__0) 
                                                                                & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_validation_operation) 
                                                                                & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_target_begin)) 
                                                                                & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_target_active_q)
                                                                                 ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_success_live)
                                                                                 : 
                                                                                ((6U 
                                                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_class))
                                                                                 ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_gate_success_live)
                                                                                 : 
                                                                                ((7U 
                                                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_class))
                                                                                 ? 
                                                                                (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_success_live))
                                                                                 : 
                                                                                ((1U 
                                                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_class))
                                                                                 ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_success_live)
                                                                                 : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_success_live)))))))) 
                                                                                | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h81ee59e2__0) 
                                                                                & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_validation_operation) 
                                                                                & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_ss_success_live)) 
                                                                                | (IData)(
                                                                                (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                                                                                >> 0x28U))))) 
                                                                                | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbc8e52c8__0) 
                                                                                & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_validation_operation) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_success_q))) 
                                                                                | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h81ee59e2__0) 
                                                                                & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_cs_validation_operation) 
                                                                                & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0c8da3c8__0) 
                                                                                | (IData)(
                                                                                (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                                                                                >> 0x28U))))) 
                                                                                | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbc8e52c8__0) 
                                                                                & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_cs_validation_operation) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_success_q))) 
                                                                                | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h81ee59e2__0) 
                                                                                & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_validation_operation) 
                                                                                & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_target_begin)) 
                                                                                & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__jmp_gate_target_begin)) 
                                                                                & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_success_live) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h720a7911__0) 
                                                                                | (IData)(
                                                                                (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                                                                                >> 0x28U)))))))) 
                                                                                | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbc8e52c8__0) 
                                                                                & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_validation_operation) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_success_q))) 
                                                                                | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h81ee59e2__0) 
                                                                                & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_cs_validation_operation) 
                                                                                & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hc92b0026__0) 
                                                                                | (IData)(
                                                                                (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                                                                                >> 0x28U))))) 
                                                                                | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbc8e52c8__0) 
                                                                                & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_cs_validation_operation) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_success_q))) 
                                                                                | (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_required)) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_ss_validation_operation)) 
                                                                                | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h81ee59e2__0) 
                                                                                & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_ss_validation_operation) 
                                                                                & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_iret_ss_success_live)) 
                                                                                | (IData)(
                                                                                (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                                                                                >> 0x28U))))) 
                                                                                | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbc8e52c8__0) 
                                                                                & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_ss_validation_operation) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_success_q))) 
                                                                                | (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q)) 
                                                                                & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_operation)) 
                                                                                | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_pre_fault) 
                                                                                | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_post_fault) 
                                                                                | (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hfe54633e__0) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_success_live)) 
                                                                                | ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_ip_operation) 
                                                                                | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_cs_operation)) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_candidate_valid_q)) 
                                                                                | (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_candidate_valid_q)) 
                                                                                & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_switch_operation)) 
                                                                                | (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_switch_operation) 
                                                                                & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_done_q) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_service_complete_q))) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_switch_skip) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_event_switch_skip) 
                                                                                | (((0xaaU 
                                                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                                                                & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_return_started_q)) 
                                                                                & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q)) 
                                                                                | (~ 
                                                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__registers__DOT__flags_q) 
                                                                                >> 0xeU))))) 
                                                                                | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_return_started_q) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_done)) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_return_skip) 
                                                                                | (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_check_operation) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q)) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_fault) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_commit) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_commit) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_fault) 
                                                                                | (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__implementation_allowed) 
                                                                                & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q)) 
                                                                                & ((0x96U 
                                                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                                                                | ((0x9fU 
                                                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                                                                | ((0xa0U 
                                                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                                                                | ((0xa2U 
                                                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                                                                | ((0x9cU 
                                                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                                                                | (0x9eU 
                                                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word))))))))) 
                                                                                | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_frame_operation) 
                                                                                & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_required)) 
                                                                                | ((1U 
                                                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_phase_q)) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_operand_done)))) 
                                                                                | (((0x73U 
                                                                                == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_required)) 
                                                                                | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__operand_request) 
                                                                                & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_operand_done) 
                                                                                & ((~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_operand_request)) 
                                                                                & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_active_q)) 
                                                                                & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__event_gate_active_q)) 
                                                                                & (~ 
                                                                                ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_frame_operation) 
                                                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_tss_active_state_q) 
                                                                                | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_stack_write) 
                                                                                | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__copy_call_parameters)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_done 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operation_retire) 
           | (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__immediate_register)) 
               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__immediate_last)) 
              | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__muldiv_complete) 
                 | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__write_result_ax) 
                    | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__write_result_dx) 
                       | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fetch_port) 
                           & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q) 
                               >> 3U) | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__operand_decode__byte_valid))) 
                          | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_empty) 
                             | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_continue) 
                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_index_write) 
                                   | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_count) 
                                      | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_read_acc) 
                                         | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_write_acc) 
                                            | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__add_allocation_sp) 
                                               | (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__range_fault)) 
                                                   & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_push2) 
                                                      | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__check_pop2))) 
                                                  | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__frame_read_gpr) 
                                                     | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__frame_write_gpr) 
                                                        | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__save_auxiliary) 
                                                           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__restore_auxiliary) 
                                                              | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__save_allocation) 
                                                                 | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__load_counter) 
                                                                    | __Vdeeptemp_h4ad99da3__0))))))))))))))))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_post_fault 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h81ee59e2__0) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_validation_operation)
               ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_target_active_q)
                   ? (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_success_live))
                   : ((6U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_class))
                       ? (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_gate_success_live))
                       : ((7U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_class))
                           ? (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_success_live))
                           : ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_class))
                               ? (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_success_live))
                               : (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_success_live))))))
               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_cs_validation_operation)
                   ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0c8da3c8__0)
                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_ss_validation_operation)
                       ? (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_ss_success_live))
                       : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_cs_validation_operation)
                           ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hc92b0026__0)
                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_validation_operation)
                               ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h9ac33813__0)
                                   ? (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_call_gate_success_live))
                                   : ((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_descriptor_success_live) 
                                          | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_gate_target_begin))) 
                                      & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h720a7911__0)))
                               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_ss_validation_operation)
                                   ? (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_iret_ss_success_live))
                                   : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_reload_operation)
                                       ? (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_segment_success_live))
                                       : (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_verify_operation) 
                                             | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_inspect_operation) 
                                                | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_success_live))))))))))));
    if (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_en) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segment_state_commit_index 
            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_index;
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segment_state_commit_selector 
            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_selector;
    } else {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segment_state_commit_index 
            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__load_index;
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segment_state_commit_selector 
            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__segments__load_selector;
    }
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__segment_state_commit_en 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_en) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_en2) 
              | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q)) 
                 & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__control_error)) 
                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h19ebc0b4__0)))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_outer_return_commit 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__context_commit) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q) 
              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_en) 
                 & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_en2) 
                    & ((1U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_index)) 
                       & ((2U == ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_segment_write)
                                   ? 1U : 2U)) & ((3U 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_selector)) 
                                                  > (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__current_cpl))))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_pop_sp_commit 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__protected_return_cursor_q) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__micro_executor__segment_pop_opcode) 
              & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_reload_operation) 
                 & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_segment_commit_en))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operation_done 
        = ((3U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word)) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_done) 
              | (2U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_service__DOT__state_q))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__cs_validation_success_event 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hedc9faf1__0) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_pre_fault)) 
              & ((~ (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_post_fault)) 
                 & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h81ee59e2__0) 
                     & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_candidate_success_live) 
                        & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp0_q) 
                            <= (0xffffU & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor))) 
                           & (IData)((vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____Vcellinp__descriptor_parser__raw_descriptor 
                                      >> 0x28U))))) 
                    | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hbc8e52c8__0) 
                       & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_success_q))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__system_fault 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__npx_fault) 
           | ((0xbU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__state_q)) 
              | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_mode_fault) 
                 | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_privilege_fault) 
                    | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__io_privilege_fault) 
                       | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__halt_privilege_fault) 
                          | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__arpl_fault) 
                             | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__clts_fault) 
                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_tss_pre_fault) 
                                   | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h4e941736__0) 
                                      | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_pre_fault) 
                                         | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_post_fault) 
                                            | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h748f4ecd__0)))))))))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h2f04017f__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_sp_commit) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__retf_outer_sp_commit) 
              | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__return_same_sp_commit) 
                 | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_sp_commit) 
                    | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_pop_sp_commit)))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h87dd1c31__0 
        = (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_pop_sp_commit) 
            << 5U) | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h03543a5a__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fault_error_valid 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__msw_q) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h564427fd__0)) 
              & ((3U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_service__DOT__state_q)) 
                 || (1U & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__system_fault)
                            ? ((8U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__system_fault_vector)) 
                               | ((0xaU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__system_fault_vector)) 
                                  | ((0xbU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__system_fault_vector)) 
                                     | ((0xcU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__system_fault_vector)) 
                                        | (0xdU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__system_fault_vector))))))
                            : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_hced645af__0) 
                               | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_access_fault) 
                                  | ((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__arithmetic_fault) 
                                         | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__bounds_fault))) 
                                     | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_fetch_fault)))))))));
    vlSelf->spk286_profile_prefix_tb__DOT__debug_fault_error_code 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__system_fault)
            ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__npx_fault)
                ? 0U : ((0xbU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__state_q))
                         ? ((0xfffcU & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__task_switch_service__DOT__fault_error_code_q)) 
                            | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active) 
                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_external))
                                ? 1U : 0U)) : (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_mode_fault) 
                                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__system_privilege_fault) 
                                                   | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__io_privilege_fault)))
                                                ? 0U
                                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_tss_pre_fault)
                                                    ? 
                                                   ((0xfffcU 
                                                     & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_state__DOT__tr_selector_q)) 
                                                    | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active) 
                                                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_external))
                                                        ? 1U
                                                        : 0U))
                                                    : 
                                                   ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h4e941736__0)
                                                     ? 0U
                                                     : 
                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h748f4ecd__0)
                                                      ? 
                                                     (2U 
                                                      | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__debug_event_vector) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active) 
                                                             & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_external))
                                                             ? 1U
                                                             : 0U)))
                                                      : 
                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_cs_offset_fault)
                                                       ? 0U
                                                       : 
                                                      (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_pre_fault) 
                                                        | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_post_fault))
                                                        ? 
                                                       ((0xfffcU 
                                                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_selector_value)) 
                                                        | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active) 
                                                            & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_external))
                                                            ? 1U
                                                            : 0U))
                                                        : 0U))))))))
            : 0U);
    vlSelf->spk286_profile_prefix_tb__DOT__debug_fault_vector 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h564427fd__0)
            ? 6U : ((3U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_service__DOT__state_q))
                     ? 0xdU : ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__system_fault)
                                ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__system_fault_vector)
                                : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_hced645af__0)
                                    ? 0xcU : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_access_fault)
                                               ? 0xdU
                                               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_fetch_fault)
                                                   ? 0xdU
                                                   : 
                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__bounds_fault)
                                                    ? 5U
                                                    : 
                                                   ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__arithmetic_fault)
                                                     ? 0U
                                                     : 0xdU))))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__fault_request 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__range_fault) 
           | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__bounds_fault) 
              | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__arithmetic_fault) 
                 | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__operand_blocked) 
                    | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__invalid_form) 
                       | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__invalid_opcode_fault) 
                          | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__system_limit_fault) 
                             | ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__system_fault) 
                                | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_access_fault) 
                                   | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__protected_fetch_fault) 
                                      | (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__execution_allowed) 
                                          & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active)) 
                                             & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__raw_retired)) 
                                                & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__event_completed)) 
                                                   & (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_active) 
                                                       | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_head_permit)) 
                                                      & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_valid)) 
                                                         & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_response_valid)) 
                                                            & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__fetch_bus_valid)) 
                                                               & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__fetch_blocked) 
                                                                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h8e0b9e29__0)))))))))) 
                                         | ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__length_fault) 
                                            | (3U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__loadall_service__DOT__state_q))))))))))))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h94cbb048__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_gpr_write) 
           | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h2f04017f__0));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he78197c4__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_result_write) 
            << 6U) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h87dd1c31__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_vector = 0U;
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__entry_failure 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__events__enable) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_cancel)) 
                 & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__fault_request))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_kind = 0U;
    if ((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__events__enable) 
          & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active))) 
         & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_cancel)))) {
        if ((((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__fault_request) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__events__instruction_active)) 
             & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown)))) {
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_vector 
                = vlSelf->spk286_profile_prefix_tb__DOT__debug_fault_vector;
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_kind = 1U;
        } else if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__software_taken) 
                    & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown)))) {
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_vector 
                = (0xffU & ((0xcdU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q))
                             ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp0_q)
                             : ((0xccU == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_q))
                                 ? 3U : 4U)));
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_kind = 5U;
        } else if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__boundary) 
                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_async_enable))) {
            if (((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__trap_due) 
                   & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unused_ss_shadow))) 
                  & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_boundary) 
                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__repeat_ss_inhibit_q)))) 
                 & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown)))) {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_vector = 1U;
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_kind = 2U;
            } else if ((((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__debug_nmi_pending) 
                           & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__debug_nmi_blocked))) 
                          & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__shutdown_reset_only_q))) 
                         & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unused_ss_shadow))) 
                        & (~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__repeat_boundary) 
                              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__repeat_ss_inhibit_q))))) {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_vector = 2U;
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_kind = 3U;
            } else if (((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__fault_request) 
                        & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__shutdown)))) {
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_vector 
                    = vlSelf->spk286_profile_prefix_tb__DOT__debug_fault_vector;
                vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_kind = 1U;
            }
        }
    }
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h13130501__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fixed_result_write) 
            << 7U) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he78197c4__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_request 
        = ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__selected_kind)) 
           | ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__entry_shutdown)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__events__DOT__entry_failure)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h21dc821c__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_index_write) 
            << 8U) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h13130501__0));
    spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_he61ed21f__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h41f92d96__0) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_request)) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__event_completed)) 
                 & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__raw_retired)) 
                    & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__unsupported_q)) 
                       & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_valid))))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h02b1df34__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_count_write) 
            << 9U) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h21dc821c__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_he61ed21f__0) 
           & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__length_fault)) 
              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__is_prefix)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_start 
        = ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_he61ed21f__0) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__decode_supported) 
              & ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__is_prefix)) 
                 & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__length_fault)))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h9a87bc1e__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_write_acc) 
            << 0xaU) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h02b1df34__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_start_body 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_start) 
           | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h45d69300__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_start 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_start) 
           | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_dispatch));
    spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_ha5f0a04c__0 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefix_accept) 
           | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__opcode_start));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h52d684e9__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__add_allocation_arch) 
            << 0xbU) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h9a87bc1e__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__next_micro_pc 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_pc;
    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__reset) 
         | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__semantic_cancel))) {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__next_micro_pc = 0U;
    } else if (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__execution_allowed) {
        if (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_active) {
            if ((((((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_valid) 
                    & (0x2e7U > (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_pc))) 
                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operation_done)) 
                  & (3U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word))) 
                 & (~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operation_retire)))) {
                if (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__microsequencer__branch_request) {
                    if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__microsequencer__branch_target_valid) 
                         & (0x2e7U > (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__microsequencer__branch_target)))) {
                        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__next_micro_pc 
                            = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__microsequencer__branch_target;
                    }
                } else if ((0x2e7U > (0x7ffU & ((IData)(1U) 
                                                + (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_pc))))) {
                    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__next_micro_pc 
                        = (0x3ffU & ((IData)(1U) + (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_pc)));
                }
            }
        } else if (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_start) 
                    & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_decode_ready))) {
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__next_micro_pc 
                = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__microsequencer__start_entry;
        }
    }
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__events__instruction_start 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__context_active)) 
           & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_ha5f0a04c__0));
    spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_ready 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__length_fault)) 
           & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_ha5f0a04c__0) 
              | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__executor_byte_ready)));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_ha69722db__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__frame_write_gpr) 
            << 0xcU) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h52d684e9__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_start_interval 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__events__instruction_start) 
           | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____VdfgTmp_h45d69300__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_replay__DOT__take_consume 
        = (((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q)) 
            & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_valid) 
               & ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_ready) 
                  & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_replay__DOT__count_q))))) 
           & (0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_replay__DOT__count_q)));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefetch_queue__DOT__do_consume 
        = ((0U != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__prefetch_queue__DOT__count_q)) 
           & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_handoff__DOT__pending_q)
               ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_byte_ready)
               : ((0U == (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__profile_target_replay__DOT__count_q)) 
                  & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_ready))));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__timing_queue_consume 
        = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_valid) 
           & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__queue_consume_ready));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_haaf0e5de__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allocate_stack) 
            << 0xdU) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_ha69722db__0));
    vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT____Vcellinp__instruction_context__consume 
        = ((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__event_active)) 
           & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__timing_queue_consume));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h11b3bff1__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__move_source) 
            << 0xeU) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_haaf0e5de__0));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h1b07fba1__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_arch_write) 
            << 0xfU) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h11b3bff1__0));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0cf40e08__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__count_operation) 
            << 0x10U) | (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h1b07fba1__0));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hfe63c0ca__0 
        = (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__result_to_dst) 
            << 0x11U) | spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0cf40e08__0);
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_onehot 
        = ((0x80000U & ((~ ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__move_word) 
                            | (0U != spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hfe63c0ca__0))) 
                        << 0x13U)) | ((((~ (IData)(
                                                   (0U 
                                                    != spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hfe63c0ca__0))) 
                                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__move_word)) 
                                       << 0x12U) | 
                                      ((((~ (IData)(
                                                    (0U 
                                                     != spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h0cf40e08__0))) 
                                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__result_to_dst)) 
                                        << 0x11U) | 
                                       ((((~ (IData)(
                                                     (0U 
                                                      != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h1b07fba1__0)))) 
                                          & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__count_operation)) 
                                         << 0x10U) 
                                        | ((((~ (IData)(
                                                        (0U 
                                                         != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h11b3bff1__0)))) 
                                             & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_arch_write)) 
                                            << 0xfU) 
                                           | ((((~ (IData)(
                                                           (0U 
                                                            != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_haaf0e5de__0)))) 
                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__move_source)) 
                                               << 0xeU) 
                                              | ((((~ (IData)(
                                                              (0U 
                                                               != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_ha69722db__0)))) 
                                                   & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allocate_stack)) 
                                                  << 0xdU) 
                                                 | ((((~ (IData)(
                                                                 (0U 
                                                                  != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h52d684e9__0)))) 
                                                      & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__frame_write_gpr)) 
                                                     << 0xcU) 
                                                    | ((((~ (IData)(
                                                                    (0U 
                                                                     != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h9a87bc1e__0)))) 
                                                         & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__add_allocation_arch)) 
                                                        << 0xbU) 
                                                       | ((((~ (IData)(
                                                                       (0U 
                                                                        != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h02b1df34__0)))) 
                                                            & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_write_acc)) 
                                                           << 0xaU) 
                                                          | ((((~ (IData)(
                                                                          (0U 
                                                                           != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h21dc821c__0)))) 
                                                               & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_count_write)) 
                                                              << 9U) 
                                                             | ((((~ (IData)(
                                                                             (0U 
                                                                              != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h13130501__0)))) 
                                                                  & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_index_write)) 
                                                                 << 8U) 
                                                                | ((((~ (IData)(
                                                                                (0U 
                                                                                != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_he78197c4__0)))) 
                                                                     & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fixed_result_write)) 
                                                                    << 7U) 
                                                                   | ((((~ (IData)(
                                                                                (0U 
                                                                                != (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h87dd1c31__0)))) 
                                                                        & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_result_write)) 
                                                                       << 6U) 
                                                                      | ((((~ (IData)(
                                                                                (0U 
                                                                                != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h03543a5a__0)))) 
                                                                           & (IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__segment_pop_sp_commit)) 
                                                                          << 5U) 
                                                                         | ((((~ (IData)(
                                                                                (0U 
                                                                                != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_ha17f98de__0)))) 
                                                                              & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__call_gate_sp_commit)) 
                                                                             << 4U) 
                                                                            | ((((~ (IData)(
                                                                                (0U 
                                                                                != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_hcd1e1639__0)))) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__return_same_sp_commit)) 
                                                                                << 3U) 
                                                                               | ((((~ (IData)(
                                                                                (0U 
                                                                                != (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h1b5291b6__0)))) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__retf_outer_sp_commit)) 
                                                                                << 2U) 
                                                                                | ((((~ (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_gpr_write)) 
                                                                                & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__iret_outer_sp_commit)) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_gpr_write))))))))))))))))))));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[0U] 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[0U];
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[1U] 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[1U];
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[2U] 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[2U];
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[3U] 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[3U];
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[4U] 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[4U];
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[5U] 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[5U];
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[6U] 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[6U];
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[7U] 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[7U];
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[8U] 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[8U];
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[9U] 
        = vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_values[9U];
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
        = spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__gpr_data_onehot;
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((- (IData)((1U & __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables))) 
                      & __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[0U]));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 1U)))) 
                         & ((__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[0U] 
                             << 0x10U) | (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[0U] 
                                          >> 0x10U)))));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 2U)))) 
                         & __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[1U])));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 3U)))) 
                         & ((__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[1U] 
                             << 0x10U) | (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[1U] 
                                          >> 0x10U)))));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 4U)))) 
                         & __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[2U])));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 5U)))) 
                         & ((__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[2U] 
                             << 0x10U) | (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[2U] 
                                          >> 0x10U)))));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 6U)))) 
                         & __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[3U])));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 7U)))) 
                         & ((__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[3U] 
                             << 0x10U) | (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[3U] 
                                          >> 0x10U)))));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 8U)))) 
                         & __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[4U])));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 9U)))) 
                         & ((__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[4U] 
                             << 0x10U) | (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[4U] 
                                          >> 0x10U)))));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 0xaU)))) 
                         & __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[5U])));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 0xbU)))) 
                         & ((__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[5U] 
                             << 0x10U) | (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[5U] 
                                          >> 0x10U)))));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 0xcU)))) 
                         & __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[6U])));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 0xdU)))) 
                         & ((__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[6U] 
                             << 0x10U) | (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[6U] 
                                          >> 0x10U)))));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 0xeU)))) 
                         & __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[7U])));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 0xfU)))) 
                         & ((__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[7U] 
                             << 0x10U) | (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[7U] 
                                          >> 0x10U)))));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 0x10U)))) 
                         & __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[8U])));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 0x11U)))) 
                         & ((__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[8U] 
                             << 0x10U) | (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[8U] 
                                          >> 0x10U)))));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 0x12U)))) 
                         & __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[9U])));
    __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout 
        = (0xffffU & ((IData)(__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout) 
                      | ((- (IData)((1U & (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__enables 
                                           >> 0x13U)))) 
                         & ((__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[9U] 
                             << 0x10U) | (__Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__values[9U] 
                                          >> 0x10U)))));
    spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__sequential_gpr_write_data 
        = __Vfunc_spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__reduce_gpr_data__732__Vfuncout;
    if (vlSelf->spk286_profile_prefix_tb__DOT__execute_enable) {
        if (vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_write) {
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__effective_gpr_write_index 
                = (7U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_destination_q));
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__effective_gpr_write_data 
                = ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__register_alu)
                    ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__alu_result)
                    : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__tmp1_q));
        } else {
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__effective_gpr_write_index 
                = (7U & ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_gpr_write)
                          ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__task_commit_phase_q)
                          : ((IData)(spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT____VdfgTmp_h2f04017f__0)
                              ? 4U : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__descriptor_result_write)
                                       ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_reg)
                                       : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__fixed_result_write)
                                           ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__write_result_dx)
                                               ? 2U
                                               : 0U)
                                           : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_index_write)
                                               ? ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_step_source)
                                                   ? 6U
                                                   : 7U)
                                               : ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_count_write)
                                                   ? 1U
                                                   : 
                                                  ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__string_write_acc)
                                                    ? 0U
                                                    : 
                                                   ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__add_allocation_arch)
                                                     ? 4U
                                                     : 
                                                    ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__frame_write_gpr)
                                                      ? 
                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_word) 
                                                      - (IData)(6U))
                                                      : 
                                                     ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__allocate_stack)
                                                       ? 4U
                                                       : 
                                                      ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__move_source)
                                                        ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__source_index_q)
                                                        : 
                                                       ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__stack_arch_write)
                                                         ? 4U
                                                         : 
                                                        ((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__count_operation)
                                                          ? 1U
                                                          : 
                                                         (((IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__move_word) 
                                                           | (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__result_to_dst))
                                                           ? (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__destination_q)
                                                           : (IData)(vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__operand_gpr_write_index))))))))))))))));
            vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__effective_gpr_write_data 
                = spk286_profile_prefix_tb__DOT__dut__DOT__micro_executor__DOT__sequential_gpr_write_data;
        }
    } else {
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__effective_gpr_write_index 
            = (7U & (IData)(vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_index));
        vlSelf->spk286_profile_prefix_tb__DOT__dut__DOT__effective_gpr_write_data 
            = vlSelf->spk286_profile_prefix_tb__DOT__gpr_write_data;
    }
}
