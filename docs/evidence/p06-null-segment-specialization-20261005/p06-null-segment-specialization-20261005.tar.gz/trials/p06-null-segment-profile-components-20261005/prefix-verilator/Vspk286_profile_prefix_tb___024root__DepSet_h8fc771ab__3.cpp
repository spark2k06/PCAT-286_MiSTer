// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vspk286_profile_prefix_tb.h for the primary calling header

#include "Vspk286_profile_prefix_tb__pch.h"
#include "Vspk286_profile_prefix_tb___024root.h"

void Vspk286_profile_prefix_tb___024root___nba_sequent__TOP__0(Vspk286_profile_prefix_tb___024root* vlSelf);
void Vspk286_profile_prefix_tb___024root___nba_sequent__TOP__1(Vspk286_profile_prefix_tb___024root* vlSelf);
void Vspk286_profile_prefix_tb___024root___nba_comb__TOP__0(Vspk286_profile_prefix_tb___024root* vlSelf);
void Vspk286_profile_prefix_tb___024root___nba_sequent__TOP__2(Vspk286_profile_prefix_tb___024root* vlSelf);
void Vspk286_profile_prefix_tb___024root___nba_comb__TOP__1(Vspk286_profile_prefix_tb___024root* vlSelf);

void Vspk286_profile_prefix_tb___024root___eval_nba(Vspk286_profile_prefix_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_profile_prefix_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_profile_prefix_tb___024root___eval_nba\n"); );
    // Body
    if ((1ULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vspk286_profile_prefix_tb___024root___nba_sequent__TOP__0(vlSelf);
        Vspk286_profile_prefix_tb___024root___nba_sequent__TOP__1(vlSelf);
    }
    if ((3ULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vspk286_profile_prefix_tb___024root___nba_comb__TOP__0(vlSelf);
    }
    if ((2ULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vspk286_profile_prefix_tb___024root___nba_sequent__TOP__2(vlSelf);
    }
    if ((3ULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vspk286_profile_prefix_tb___024root___nba_comb__TOP__1(vlSelf);
    }
}

void Vspk286_profile_prefix_tb___024root___timing_resume(Vspk286_profile_prefix_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_profile_prefix_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_profile_prefix_tb___024root___timing_resume\n"); );
    // Body
    if ((2ULL & vlSelf->__VactTriggered.word(0U))) {
        vlSelf->__VdlySched.resume();
    }
}

void Vspk286_profile_prefix_tb___024root___eval_triggers__act(Vspk286_profile_prefix_tb___024root* vlSelf);
void Vspk286_profile_prefix_tb___024root___eval_act(Vspk286_profile_prefix_tb___024root* vlSelf);

bool Vspk286_profile_prefix_tb___024root___eval_phase__act(Vspk286_profile_prefix_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_profile_prefix_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_profile_prefix_tb___024root___eval_phase__act\n"); );
    // Init
    VlTriggerVec<2> __VpreTriggered;
    CData/*0:0*/ __VactExecute;
    // Body
    Vspk286_profile_prefix_tb___024root___eval_triggers__act(vlSelf);
    __VactExecute = vlSelf->__VactTriggered.any();
    if (__VactExecute) {
        __VpreTriggered.andNot(vlSelf->__VactTriggered, vlSelf->__VnbaTriggered);
        vlSelf->__VnbaTriggered.thisOr(vlSelf->__VactTriggered);
        Vspk286_profile_prefix_tb___024root___timing_resume(vlSelf);
        Vspk286_profile_prefix_tb___024root___eval_act(vlSelf);
    }
    return (__VactExecute);
}

bool Vspk286_profile_prefix_tb___024root___eval_phase__nba(Vspk286_profile_prefix_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_profile_prefix_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_profile_prefix_tb___024root___eval_phase__nba\n"); );
    // Init
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = vlSelf->__VnbaTriggered.any();
    if (__VnbaExecute) {
        Vspk286_profile_prefix_tb___024root___eval_nba(vlSelf);
        vlSelf->__VnbaTriggered.clear();
    }
    return (__VnbaExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vspk286_profile_prefix_tb___024root___dump_triggers__nba(Vspk286_profile_prefix_tb___024root* vlSelf);
#endif  // VL_DEBUG
#ifdef VL_DEBUG
VL_ATTR_COLD void Vspk286_profile_prefix_tb___024root___dump_triggers__act(Vspk286_profile_prefix_tb___024root* vlSelf);
#endif  // VL_DEBUG

void Vspk286_profile_prefix_tb___024root___eval(Vspk286_profile_prefix_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_profile_prefix_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_profile_prefix_tb___024root___eval\n"); );
    // Init
    IData/*31:0*/ __VnbaIterCount;
    CData/*0:0*/ __VnbaContinue;
    // Body
    __VnbaIterCount = 0U;
    __VnbaContinue = 1U;
    while (__VnbaContinue) {
        if (VL_UNLIKELY((0x64U < __VnbaIterCount))) {
#ifdef VL_DEBUG
            Vspk286_profile_prefix_tb___024root___dump_triggers__nba(vlSelf);
#endif
            VL_FATAL_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 4, "", "NBA region did not converge.");
        }
        __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
        __VnbaContinue = 0U;
        vlSelf->__VactIterCount = 0U;
        vlSelf->__VactContinue = 1U;
        while (vlSelf->__VactContinue) {
            if (VL_UNLIKELY((0x64U < vlSelf->__VactIterCount))) {
#ifdef VL_DEBUG
                Vspk286_profile_prefix_tb___024root___dump_triggers__act(vlSelf);
#endif
                VL_FATAL_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_profile_prefix_tb.sv", 4, "", "Active region did not converge.");
            }
            vlSelf->__VactIterCount = ((IData)(1U) 
                                       + vlSelf->__VactIterCount);
            vlSelf->__VactContinue = 0U;
            if (Vspk286_profile_prefix_tb___024root___eval_phase__act(vlSelf)) {
                vlSelf->__VactContinue = 1U;
            }
        }
        if (Vspk286_profile_prefix_tb___024root___eval_phase__nba(vlSelf)) {
            __VnbaContinue = 1U;
        }
    }
}

#ifdef VL_DEBUG
void Vspk286_profile_prefix_tb___024root___eval_debug_assertions(Vspk286_profile_prefix_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_profile_prefix_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_profile_prefix_tb___024root___eval_debug_assertions\n"); );
}
#endif  // VL_DEBUG
