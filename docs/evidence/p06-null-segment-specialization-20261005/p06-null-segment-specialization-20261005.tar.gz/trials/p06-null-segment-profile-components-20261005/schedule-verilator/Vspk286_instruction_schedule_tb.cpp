// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Model implementation (design independent parts)

#include "Vspk286_instruction_schedule_tb__pch.h"

//============================================================
// Constructors

Vspk286_instruction_schedule_tb::Vspk286_instruction_schedule_tb(VerilatedContext* _vcontextp__, const char* _vcname__)
    : VerilatedModel{*_vcontextp__}
    , vlSymsp{new Vspk286_instruction_schedule_tb__Syms(contextp(), _vcname__, this)}
    , rootp{&(vlSymsp->TOP)}
{
    // Register model with the context
    contextp()->addModel(this);
}

Vspk286_instruction_schedule_tb::Vspk286_instruction_schedule_tb(const char* _vcname__)
    : Vspk286_instruction_schedule_tb(Verilated::threadContextp(), _vcname__)
{
}

//============================================================
// Destructor

Vspk286_instruction_schedule_tb::~Vspk286_instruction_schedule_tb() {
    delete vlSymsp;
}

//============================================================
// Evaluation function

#ifdef VL_DEBUG
void Vspk286_instruction_schedule_tb___024root___eval_debug_assertions(Vspk286_instruction_schedule_tb___024root* vlSelf);
#endif  // VL_DEBUG
void Vspk286_instruction_schedule_tb___024root___eval_static(Vspk286_instruction_schedule_tb___024root* vlSelf);
void Vspk286_instruction_schedule_tb___024root___eval_initial(Vspk286_instruction_schedule_tb___024root* vlSelf);
void Vspk286_instruction_schedule_tb___024root___eval_settle(Vspk286_instruction_schedule_tb___024root* vlSelf);
void Vspk286_instruction_schedule_tb___024root___eval(Vspk286_instruction_schedule_tb___024root* vlSelf);

void Vspk286_instruction_schedule_tb::eval_step() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate Vspk286_instruction_schedule_tb::eval_step\n"); );
#ifdef VL_DEBUG
    // Debug assertions
    Vspk286_instruction_schedule_tb___024root___eval_debug_assertions(&(vlSymsp->TOP));
#endif  // VL_DEBUG
    vlSymsp->__Vm_deleter.deleteAll();
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) {
        vlSymsp->__Vm_didInit = true;
        VL_DEBUG_IF(VL_DBG_MSGF("+ Initial\n"););
        Vspk286_instruction_schedule_tb___024root___eval_static(&(vlSymsp->TOP));
        Vspk286_instruction_schedule_tb___024root___eval_initial(&(vlSymsp->TOP));
        Vspk286_instruction_schedule_tb___024root___eval_settle(&(vlSymsp->TOP));
    }
    VL_DEBUG_IF(VL_DBG_MSGF("+ Eval\n"););
    Vspk286_instruction_schedule_tb___024root___eval(&(vlSymsp->TOP));
    // Evaluate cleanup
    Verilated::endOfEval(vlSymsp->__Vm_evalMsgQp);
}

//============================================================
// Events and timing
bool Vspk286_instruction_schedule_tb::eventsPending() { return !vlSymsp->TOP.__VdlySched.empty(); }

uint64_t Vspk286_instruction_schedule_tb::nextTimeSlot() { return vlSymsp->TOP.__VdlySched.nextTimeSlot(); }

//============================================================
// Utilities

const char* Vspk286_instruction_schedule_tb::name() const {
    return vlSymsp->name();
}

//============================================================
// Invoke final blocks

void Vspk286_instruction_schedule_tb___024root___eval_final(Vspk286_instruction_schedule_tb___024root* vlSelf);

VL_ATTR_COLD void Vspk286_instruction_schedule_tb::final() {
    Vspk286_instruction_schedule_tb___024root___eval_final(&(vlSymsp->TOP));
}

//============================================================
// Implementations of abstract methods from VerilatedModel

const char* Vspk286_instruction_schedule_tb::hierName() const { return vlSymsp->name(); }
const char* Vspk286_instruction_schedule_tb::modelName() const { return "Vspk286_instruction_schedule_tb"; }
unsigned Vspk286_instruction_schedule_tb::threads() const { return 1; }
void Vspk286_instruction_schedule_tb::prepareClone() const { contextp()->prepareClone(); }
void Vspk286_instruction_schedule_tb::atClone() const {
    contextp()->threadPoolpOnClone();
}

//============================================================
// Trace configuration

VL_ATTR_COLD void Vspk286_instruction_schedule_tb::trace(VerilatedVcdC* tfp, int levels, int options) {
    vl_fatal(__FILE__, __LINE__, __FILE__,"'Vspk286_instruction_schedule_tb::trace()' called on model that was Verilated without --trace option");
}
