// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vspk286_instruction_schedule_tb.h for the primary calling header

#ifndef VERILATED_VSPK286_INSTRUCTION_SCHEDULE_TB___024ROOT_H_
#define VERILATED_VSPK286_INSTRUCTION_SCHEDULE_TB___024ROOT_H_  // guard

#include "verilated.h"
#include "verilated_timing.h"


class Vspk286_instruction_schedule_tb__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vspk286_instruction_schedule_tb___024root final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__clk;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__reset;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__historical_enable;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__cpu_boundary;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__cancel;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__preserve_cancel;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__start_interval;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__start_body;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__metadata_valid;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__metadata_freeze;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__read_wait_event;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__alignment_event;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__functional_retired;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__repeat_checkpoint;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__target_length_ready;
    CData/*3:0*/ spk286_instruction_schedule_tb__DOT__target_length_clocks;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__active;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__body_active;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__retire_pending;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__head_permit;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__deadline_ready;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__retire_fire;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__implementation_extension;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__active_q;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__body_q;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__pending_q;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__qualified_q;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__frozen_q;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__admission_window_q;
    CData/*0:0*/ __VstlFirstIteration;
    CData/*0:0*/ __Vtrigprevexpr___TOP__spk286_instruction_schedule_tb__DOT__clk__0;
    CData/*0:0*/ __VactContinue;
    SData/*9:0*/ spk286_instruction_schedule_tb__DOT__metadata_clocks;
    SData/*9:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q;
    SData/*9:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__base_q;
    SData/*9:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__extra_q;
    SData/*10:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_next;
    SData/*10:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__extra_next;
    SData/*11:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__total;
    IData/*31:0*/ spk286_instruction_schedule_tb__DOT__checks;
    IData/*31:0*/ __VactIterCount;
    VlDelayScheduler __VdlySched;
    VlTriggerScheduler __VtrigSched_h08021459__0;
    VlTriggerScheduler __VtrigSched_h080213a8__0;
    VlTriggerVec<1> __VstlTriggered;
    VlTriggerVec<3> __VactTriggered;
    VlTriggerVec<3> __VnbaTriggered;

    // INTERNAL VARIABLES
    Vspk286_instruction_schedule_tb__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vspk286_instruction_schedule_tb___024root(Vspk286_instruction_schedule_tb__Syms* symsp, const char* v__name);
    ~Vspk286_instruction_schedule_tb___024root();
    VL_UNCOPYABLE(Vspk286_instruction_schedule_tb___024root);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
