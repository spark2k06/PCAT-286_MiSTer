// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vspk286_instruction_schedule_tb.h for the primary calling header

#include "Vspk286_instruction_schedule_tb__pch.h"
#include "Vspk286_instruction_schedule_tb___024root.h"

VlCoroutine Vspk286_instruction_schedule_tb___024root___eval_initial__TOP__Vtiming__0(Vspk286_instruction_schedule_tb___024root* vlSelf);
VlCoroutine Vspk286_instruction_schedule_tb___024root___eval_initial__TOP__Vtiming__1(Vspk286_instruction_schedule_tb___024root* vlSelf);

void Vspk286_instruction_schedule_tb___024root___eval_initial(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___eval_initial\n"); );
    // Body
    Vspk286_instruction_schedule_tb___024root___eval_initial__TOP__Vtiming__0(vlSelf);
    Vspk286_instruction_schedule_tb___024root___eval_initial__TOP__Vtiming__1(vlSelf);
    vlSelf->__Vtrigprevexpr___TOP__spk286_instruction_schedule_tb__DOT__clk__0 
        = vlSelf->spk286_instruction_schedule_tb__DOT__clk;
}

VL_INLINE_OPT VlCoroutine Vspk286_instruction_schedule_tb___024root___eval_initial__TOP__Vtiming__1(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___eval_initial__TOP__Vtiming__1\n"); );
    // Body
    while (1U) {
        co_await vlSelf->__VdlySched.delay(0x1388ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                           4);
        vlSelf->spk286_instruction_schedule_tb__DOT__clk 
            = (1U & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__clk)));
    }
}

VL_INLINE_OPT void Vspk286_instruction_schedule_tb___024root___act_comb__TOP__0(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___act_comb__TOP__0\n"); );
    // Init
    SData/*10:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__effective_base;
    spk286_instruction_schedule_tb__DOT__dut__DOT__effective_base = 0;
    SData/*12:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__execution_budget_sum;
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_budget_sum = 0;
    SData/*12:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment_sum;
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment_sum = 0;
    SData/*12:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment_carry;
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment_carry = 0;
    SData/*12:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment;
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment = 0;
    SData/*12:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__execution_compare_sum;
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_compare_sum = 0;
    SData/*12:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__execution_compare_carry;
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_compare_carry = 0;
    SData/*12:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__execution_difference;
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_difference = 0;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__execution_productive_boundary;
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_productive_boundary = 0;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__execution_elapsed_saturated;
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_elapsed_saturated = 0;
    // Body
    vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__extra_next 
        = (0x7ffU & ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__extra_q) 
                     + ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__alignment_event)
                         ? 2U : 0U)));
    if ((0x3ffU < (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__extra_next))) {
        vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__extra_next = 0x3ffU;
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__active 
        = ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__active_q) 
           & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__historical_enable));
    vlSelf->spk286_instruction_schedule_tb__DOT__body_active 
        = ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__body_q) 
           & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__historical_enable));
    vlSelf->spk286_instruction_schedule_tb__DOT__retire_pending 
        = ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__pending_q) 
           & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__historical_enable));
    vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_next 
        = (0x7ffU & ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q) 
                     + ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary) 
                        & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__read_wait_event)))));
    if ((0x3ffU < (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_next))) {
        vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_next = 0x3ffU;
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__head_permit 
        = (1U & ((~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__historical_enable)) 
                 | ((~ ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__pending_q) 
                        | ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__active_q) 
                           & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__body_q)))) 
                    & ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary) 
                       | (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__admission_window_q)))));
    spk286_instruction_schedule_tb__DOT__dut__DOT__effective_base 
        = (((~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__frozen_q)) 
            & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__metadata_valid))
            ? (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__metadata_clocks)
            : (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__base_q));
    vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total 
        = (0xfffU & (((IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__effective_base) 
                      + (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__extra_q)) 
                     + (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__target_length_clocks)));
    if ((0x3ffU < (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total))) {
        vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total = 0x3ffU;
    }
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_budget_sum 
        = vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__base_q;
    if (((~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__frozen_q)) 
         & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__metadata_valid))) {
        spk286_instruction_schedule_tb__DOT__dut__DOT__execution_budget_sum 
            = vlSelf->spk286_instruction_schedule_tb__DOT__metadata_clocks;
    }
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment_sum 
        = (0x1fffU & (((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__extra_q) 
                       ^ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__target_length_clocks)) 
                      ^ (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q))));
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment_carry 
        = (((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__extra_q) 
            & ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__target_length_clocks) 
               | (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q)))) 
           | ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__target_length_clocks) 
              & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q))));
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment 
        = (0x1fffU & ((IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment_sum) 
                      + VL_SHIFTL_III(13,13,32, (IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment_carry), 1U)));
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_compare_sum 
        = ((IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_budget_sum) 
           ^ (IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment));
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_compare_carry 
        = ((IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_budget_sum) 
           & (IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment));
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_difference 
        = (0x1fffU & ((IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_compare_sum) 
                      + VL_SHIFTL_III(13,13,32, (IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_compare_carry), 1U)));
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_productive_boundary 
        = ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary) 
           & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__read_wait_event)));
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_elapsed_saturated 
        = ((0x3ffU == (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q)) 
           | ((IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_productive_boundary) 
              & (0x3feU == (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q))));
    vlSelf->spk286_instruction_schedule_tb__DOT__deadline_ready 
        = (1U & ((~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__historical_enable)) 
                 | ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__active_q) 
                    & ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__body_q) 
                       & (((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__qualified_q) 
                           | ((~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__frozen_q)) 
                              & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__metadata_valid))) 
                          & ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__target_length_ready) 
                             & ((IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_elapsed_saturated) 
                                | (((IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_difference) 
                                    >> 0xcU) | ((IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_productive_boundary) 
                                                & (0U 
                                                   == (IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_difference)))))))))));
    vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire 
        = ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__historical_enable)
            ? ((~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__reset)) 
               & ((~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__cancel)) 
                  & ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary) 
                     & ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__deadline_ready) 
                        & ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__pending_q) 
                           | (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired))))))
            : (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired));
}

void Vspk286_instruction_schedule_tb___024root___eval_act(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___eval_act\n"); );
    // Body
    if ((7ULL & vlSelf->__VactTriggered.word(0U))) {
        Vspk286_instruction_schedule_tb___024root___act_comb__TOP__0(vlSelf);
    }
}

VL_INLINE_OPT void Vspk286_instruction_schedule_tb___024root___nba_sequent__TOP__0(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___nba_sequent__TOP__0\n"); );
    // Init
    CData/*0:0*/ __Vdly__spk286_instruction_schedule_tb__DOT__dut__DOT__pending_q;
    __Vdly__spk286_instruction_schedule_tb__DOT__dut__DOT__pending_q = 0;
    CData/*0:0*/ __Vdly__spk286_instruction_schedule_tb__DOT__dut__DOT__frozen_q;
    __Vdly__spk286_instruction_schedule_tb__DOT__dut__DOT__frozen_q = 0;
    // Body
    __Vdly__spk286_instruction_schedule_tb__DOT__dut__DOT__pending_q 
        = vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__pending_q;
    __Vdly__spk286_instruction_schedule_tb__DOT__dut__DOT__frozen_q 
        = vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__frozen_q;
    if ((1U & (((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__reset) 
                | (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__historical_enable))) 
               | ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__cancel) 
                  & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__preserve_cancel)))))) {
        vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__admission_window_q = 0U;
        vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__body_q = 0U;
        __Vdly__spk286_instruction_schedule_tb__DOT__dut__DOT__pending_q = 0U;
        vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__qualified_q = 0U;
        __Vdly__spk286_instruction_schedule_tb__DOT__dut__DOT__frozen_q = 0U;
        vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q = 0U;
        vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__base_q = 0U;
        vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__extra_q = 0U;
        vlSelf->spk286_instruction_schedule_tb__DOT__implementation_extension = 0U;
        vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__active_q = 0U;
    } else {
        if (vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire) {
            vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__admission_window_q = 1U;
            vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__body_q = 0U;
        }
        if (vlSelf->spk286_instruction_schedule_tb__DOT__start_body) {
            vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__admission_window_q = 0U;
        }
        if (vlSelf->spk286_instruction_schedule_tb__DOT__repeat_checkpoint) {
            vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__body_q = 1U;
        }
        if (vlSelf->spk286_instruction_schedule_tb__DOT__start_body) {
            vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__body_q = 1U;
        }
        if (vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__active_q) {
            vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q 
                = (0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_next));
            vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__extra_q 
                = (0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__extra_next));
            if (((~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__frozen_q)) 
                 & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__metadata_valid))) {
                vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__base_q 
                    = vlSelf->spk286_instruction_schedule_tb__DOT__metadata_clocks;
                vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__qualified_q = 1U;
            }
            if (((((((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary) 
                     & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__read_wait_event))) 
                    & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__deadline_ready)) 
                   & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__pending_q))) 
                  & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired))) 
                 & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__repeat_checkpoint)))) {
                vlSelf->spk286_instruction_schedule_tb__DOT__implementation_extension = 1U;
            }
            if (vlSelf->spk286_instruction_schedule_tb__DOT__metadata_freeze) {
                __Vdly__spk286_instruction_schedule_tb__DOT__dut__DOT__frozen_q = 1U;
            }
            if (vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired) {
                __Vdly__spk286_instruction_schedule_tb__DOT__dut__DOT__pending_q = 1U;
            }
        }
        if (vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire) {
            __Vdly__spk286_instruction_schedule_tb__DOT__dut__DOT__pending_q = 0U;
            vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__qualified_q = 0U;
            __Vdly__spk286_instruction_schedule_tb__DOT__dut__DOT__frozen_q = 0U;
            vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q = 0U;
            vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__base_q = 0U;
            vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__extra_q = 0U;
            vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__active_q = 0U;
        }
        if (vlSelf->spk286_instruction_schedule_tb__DOT__repeat_checkpoint) {
            __Vdly__spk286_instruction_schedule_tb__DOT__dut__DOT__pending_q = 0U;
            vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__qualified_q = 1U;
            __Vdly__spk286_instruction_schedule_tb__DOT__dut__DOT__frozen_q = 1U;
            vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q = 0U;
            vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__base_q = 5U;
            vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__extra_q = 0U;
            vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__active_q = 1U;
        }
        if (vlSelf->spk286_instruction_schedule_tb__DOT__start_interval) {
            vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__body_q 
                = vlSelf->spk286_instruction_schedule_tb__DOT__start_body;
            __Vdly__spk286_instruction_schedule_tb__DOT__dut__DOT__pending_q = 0U;
            vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__qualified_q 
                = vlSelf->spk286_instruction_schedule_tb__DOT__metadata_valid;
            __Vdly__spk286_instruction_schedule_tb__DOT__dut__DOT__frozen_q = 0U;
            vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q = 0U;
            vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__base_q 
                = vlSelf->spk286_instruction_schedule_tb__DOT__metadata_clocks;
            vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__extra_q = 0U;
            vlSelf->spk286_instruction_schedule_tb__DOT__implementation_extension = 0U;
            vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__active_q = 1U;
        }
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__pending_q 
        = __Vdly__spk286_instruction_schedule_tb__DOT__dut__DOT__pending_q;
    vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__frozen_q 
        = __Vdly__spk286_instruction_schedule_tb__DOT__dut__DOT__frozen_q;
}

VL_INLINE_OPT void Vspk286_instruction_schedule_tb___024root___nba_comb__TOP__0(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___nba_comb__TOP__0\n"); );
    // Init
    SData/*10:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__effective_base;
    spk286_instruction_schedule_tb__DOT__dut__DOT__effective_base = 0;
    SData/*12:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__execution_budget_sum;
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_budget_sum = 0;
    SData/*12:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment_sum;
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment_sum = 0;
    SData/*12:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment_carry;
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment_carry = 0;
    SData/*12:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment;
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment = 0;
    SData/*12:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__execution_compare_sum;
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_compare_sum = 0;
    SData/*12:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__execution_compare_carry;
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_compare_carry = 0;
    SData/*12:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__execution_difference;
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_difference = 0;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__execution_productive_boundary;
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_productive_boundary = 0;
    CData/*0:0*/ spk286_instruction_schedule_tb__DOT__dut__DOT__execution_elapsed_saturated;
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_elapsed_saturated = 0;
    // Body
    vlSelf->spk286_instruction_schedule_tb__DOT__body_active 
        = ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__body_q) 
           & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__historical_enable));
    vlSelf->spk286_instruction_schedule_tb__DOT__retire_pending 
        = ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__pending_q) 
           & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__historical_enable));
    vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__extra_next 
        = (0x7ffU & ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__extra_q) 
                     + ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__alignment_event)
                         ? 2U : 0U)));
    if ((0x3ffU < (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__extra_next))) {
        vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__extra_next = 0x3ffU;
    }
    spk286_instruction_schedule_tb__DOT__dut__DOT__effective_base 
        = (((~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__frozen_q)) 
            & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__metadata_valid))
            ? (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__metadata_clocks)
            : (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__base_q));
    vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total 
        = (0xfffU & (((IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__effective_base) 
                      + (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__extra_q)) 
                     + (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__target_length_clocks)));
    if ((0x3ffU < (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total))) {
        vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total = 0x3ffU;
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_next 
        = (0x7ffU & ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q) 
                     + ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary) 
                        & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__read_wait_event)))));
    if ((0x3ffU < (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_next))) {
        vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_next = 0x3ffU;
    }
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_budget_sum 
        = vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__base_q;
    if (((~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__frozen_q)) 
         & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__metadata_valid))) {
        spk286_instruction_schedule_tb__DOT__dut__DOT__execution_budget_sum 
            = vlSelf->spk286_instruction_schedule_tb__DOT__metadata_clocks;
    }
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment_sum 
        = (0x1fffU & (((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__extra_q) 
                       ^ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__target_length_clocks)) 
                      ^ (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q))));
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment_carry 
        = (((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__extra_q) 
            & ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__target_length_clocks) 
               | (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q)))) 
           | ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__target_length_clocks) 
              & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q))));
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment 
        = (0x1fffU & ((IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment_sum) 
                      + VL_SHIFTL_III(13,13,32, (IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment_carry), 1U)));
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_compare_sum 
        = ((IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_budget_sum) 
           ^ (IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment));
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_compare_carry 
        = ((IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_budget_sum) 
           & (IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_adjustment));
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_difference 
        = (0x1fffU & ((IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_compare_sum) 
                      + VL_SHIFTL_III(13,13,32, (IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_compare_carry), 1U)));
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_productive_boundary 
        = ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary) 
           & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__read_wait_event)));
    spk286_instruction_schedule_tb__DOT__dut__DOT__execution_elapsed_saturated 
        = ((0x3ffU == (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q)) 
           | ((IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_productive_boundary) 
              & (0x3feU == (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q))));
    vlSelf->spk286_instruction_schedule_tb__DOT__active 
        = ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__active_q) 
           & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__historical_enable));
    vlSelf->spk286_instruction_schedule_tb__DOT__head_permit 
        = (1U & ((~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__historical_enable)) 
                 | ((~ ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__pending_q) 
                        | ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__active_q) 
                           & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__body_q)))) 
                    & ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary) 
                       | (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__admission_window_q)))));
    vlSelf->spk286_instruction_schedule_tb__DOT__deadline_ready 
        = (1U & ((~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__historical_enable)) 
                 | ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__active_q) 
                    & ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__body_q) 
                       & (((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__qualified_q) 
                           | ((~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__frozen_q)) 
                              & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__metadata_valid))) 
                          & ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__target_length_ready) 
                             & ((IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_elapsed_saturated) 
                                | (((IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_difference) 
                                    >> 0xcU) | ((IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_productive_boundary) 
                                                & (0U 
                                                   == (IData)(spk286_instruction_schedule_tb__DOT__dut__DOT__execution_difference)))))))))));
    vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire 
        = ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__historical_enable)
            ? ((~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__reset)) 
               & ((~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__cancel)) 
                  & ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary) 
                     & ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__deadline_ready) 
                        & ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__pending_q) 
                           | (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired))))))
            : (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired));
}

void Vspk286_instruction_schedule_tb___024root___eval_nba(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___eval_nba\n"); );
    // Body
    if ((1ULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vspk286_instruction_schedule_tb___024root___nba_sequent__TOP__0(vlSelf);
    }
    if ((7ULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vspk286_instruction_schedule_tb___024root___nba_comb__TOP__0(vlSelf);
    }
}

void Vspk286_instruction_schedule_tb___024root___timing_resume(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___timing_resume\n"); );
    // Body
    if ((2ULL & vlSelf->__VactTriggered.word(0U))) {
        vlSelf->__VtrigSched_h08021459__0.resume("@(negedge spk286_instruction_schedule_tb.clk)");
    }
    if ((1ULL & vlSelf->__VactTriggered.word(0U))) {
        vlSelf->__VtrigSched_h080213a8__0.resume("@(posedge spk286_instruction_schedule_tb.clk)");
    }
    if ((4ULL & vlSelf->__VactTriggered.word(0U))) {
        vlSelf->__VdlySched.resume();
    }
}

void Vspk286_instruction_schedule_tb___024root___timing_commit(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___timing_commit\n"); );
    // Body
    if ((! (2ULL & vlSelf->__VactTriggered.word(0U)))) {
        vlSelf->__VtrigSched_h08021459__0.commit("@(negedge spk286_instruction_schedule_tb.clk)");
    }
    if ((! (1ULL & vlSelf->__VactTriggered.word(0U)))) {
        vlSelf->__VtrigSched_h080213a8__0.commit("@(posedge spk286_instruction_schedule_tb.clk)");
    }
}

void Vspk286_instruction_schedule_tb___024root___eval_triggers__act(Vspk286_instruction_schedule_tb___024root* vlSelf);

bool Vspk286_instruction_schedule_tb___024root___eval_phase__act(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___eval_phase__act\n"); );
    // Init
    VlTriggerVec<3> __VpreTriggered;
    CData/*0:0*/ __VactExecute;
    // Body
    Vspk286_instruction_schedule_tb___024root___eval_triggers__act(vlSelf);
    Vspk286_instruction_schedule_tb___024root___timing_commit(vlSelf);
    __VactExecute = vlSelf->__VactTriggered.any();
    if (__VactExecute) {
        __VpreTriggered.andNot(vlSelf->__VactTriggered, vlSelf->__VnbaTriggered);
        vlSelf->__VnbaTriggered.thisOr(vlSelf->__VactTriggered);
        Vspk286_instruction_schedule_tb___024root___timing_resume(vlSelf);
        Vspk286_instruction_schedule_tb___024root___eval_act(vlSelf);
    }
    return (__VactExecute);
}

bool Vspk286_instruction_schedule_tb___024root___eval_phase__nba(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___eval_phase__nba\n"); );
    // Init
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = vlSelf->__VnbaTriggered.any();
    if (__VnbaExecute) {
        Vspk286_instruction_schedule_tb___024root___eval_nba(vlSelf);
        vlSelf->__VnbaTriggered.clear();
    }
    return (__VnbaExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vspk286_instruction_schedule_tb___024root___dump_triggers__nba(Vspk286_instruction_schedule_tb___024root* vlSelf);
#endif  // VL_DEBUG
#ifdef VL_DEBUG
VL_ATTR_COLD void Vspk286_instruction_schedule_tb___024root___dump_triggers__act(Vspk286_instruction_schedule_tb___024root* vlSelf);
#endif  // VL_DEBUG

void Vspk286_instruction_schedule_tb___024root___eval(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___eval\n"); );
    // Init
    IData/*31:0*/ __VnbaIterCount;
    CData/*0:0*/ __VnbaContinue;
    // Body
    __VnbaIterCount = 0U;
    __VnbaContinue = 1U;
    while (__VnbaContinue) {
        if (VL_UNLIKELY((0x64U < __VnbaIterCount))) {
#ifdef VL_DEBUG
            Vspk286_instruction_schedule_tb___024root___dump_triggers__nba(vlSelf);
#endif
            VL_FATAL_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 2, "", "NBA region did not converge.");
        }
        __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
        __VnbaContinue = 0U;
        vlSelf->__VactIterCount = 0U;
        vlSelf->__VactContinue = 1U;
        while (vlSelf->__VactContinue) {
            if (VL_UNLIKELY((0x64U < vlSelf->__VactIterCount))) {
#ifdef VL_DEBUG
                Vspk286_instruction_schedule_tb___024root___dump_triggers__act(vlSelf);
#endif
                VL_FATAL_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 2, "", "Active region did not converge.");
            }
            vlSelf->__VactIterCount = ((IData)(1U) 
                                       + vlSelf->__VactIterCount);
            vlSelf->__VactContinue = 0U;
            if (Vspk286_instruction_schedule_tb___024root___eval_phase__act(vlSelf)) {
                vlSelf->__VactContinue = 1U;
            }
        }
        if (Vspk286_instruction_schedule_tb___024root___eval_phase__nba(vlSelf)) {
            __VnbaContinue = 1U;
        }
    }
}

#ifdef VL_DEBUG
void Vspk286_instruction_schedule_tb___024root___eval_debug_assertions(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___eval_debug_assertions\n"); );
}
#endif  // VL_DEBUG
