// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vspk286_instruction_schedule_tb.h for the primary calling header

#include "Vspk286_instruction_schedule_tb__pch.h"
#include "Vspk286_instruction_schedule_tb___024root.h"

VL_ATTR_COLD void Vspk286_instruction_schedule_tb___024root___eval_static__TOP(Vspk286_instruction_schedule_tb___024root* vlSelf);

VL_ATTR_COLD void Vspk286_instruction_schedule_tb___024root___eval_static(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___eval_static\n"); );
    // Body
    Vspk286_instruction_schedule_tb___024root___eval_static__TOP(vlSelf);
}

VL_ATTR_COLD void Vspk286_instruction_schedule_tb___024root___eval_static__TOP(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___eval_static__TOP\n"); );
    // Body
    vlSelf->spk286_instruction_schedule_tb__DOT__clk = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__reset = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__historical_enable = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__cancel = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__preserve_cancel = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_valid = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_freeze = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__read_wait_event = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__alignment_event = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__repeat_checkpoint = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_clocks = 2U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_ready = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_clocks = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__checks = 0U;
}

VL_ATTR_COLD void Vspk286_instruction_schedule_tb___024root___eval_final(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___eval_final\n"); );
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vspk286_instruction_schedule_tb___024root___dump_triggers__stl(Vspk286_instruction_schedule_tb___024root* vlSelf);
#endif  // VL_DEBUG
VL_ATTR_COLD bool Vspk286_instruction_schedule_tb___024root___eval_phase__stl(Vspk286_instruction_schedule_tb___024root* vlSelf);

VL_ATTR_COLD void Vspk286_instruction_schedule_tb___024root___eval_settle(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___eval_settle\n"); );
    // Init
    IData/*31:0*/ __VstlIterCount;
    CData/*0:0*/ __VstlContinue;
    // Body
    __VstlIterCount = 0U;
    vlSelf->__VstlFirstIteration = 1U;
    __VstlContinue = 1U;
    while (__VstlContinue) {
        if (VL_UNLIKELY((0x64U < __VstlIterCount))) {
#ifdef VL_DEBUG
            Vspk286_instruction_schedule_tb___024root___dump_triggers__stl(vlSelf);
#endif
            VL_FATAL_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 2, "", "Settle region did not converge.");
        }
        __VstlIterCount = ((IData)(1U) + __VstlIterCount);
        __VstlContinue = 0U;
        if (Vspk286_instruction_schedule_tb___024root___eval_phase__stl(vlSelf)) {
            __VstlContinue = 1U;
        }
        vlSelf->__VstlFirstIteration = 0U;
    }
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vspk286_instruction_schedule_tb___024root___dump_triggers__stl(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___dump_triggers__stl\n"); );
    // Body
    if ((1U & (~ (IData)(vlSelf->__VstlTriggered.any())))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelf->__VstlTriggered.word(0U))) {
        VL_DBG_MSGF("         'stl' region trigger index 0 is active: Internal 'stl' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

void Vspk286_instruction_schedule_tb___024root___act_comb__TOP__0(Vspk286_instruction_schedule_tb___024root* vlSelf);

VL_ATTR_COLD void Vspk286_instruction_schedule_tb___024root___eval_stl(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___eval_stl\n"); );
    // Body
    if ((1ULL & vlSelf->__VstlTriggered.word(0U))) {
        Vspk286_instruction_schedule_tb___024root___act_comb__TOP__0(vlSelf);
    }
}

VL_ATTR_COLD void Vspk286_instruction_schedule_tb___024root___eval_triggers__stl(Vspk286_instruction_schedule_tb___024root* vlSelf);

VL_ATTR_COLD bool Vspk286_instruction_schedule_tb___024root___eval_phase__stl(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___eval_phase__stl\n"); );
    // Init
    CData/*0:0*/ __VstlExecute;
    // Body
    Vspk286_instruction_schedule_tb___024root___eval_triggers__stl(vlSelf);
    __VstlExecute = vlSelf->__VstlTriggered.any();
    if (__VstlExecute) {
        Vspk286_instruction_schedule_tb___024root___eval_stl(vlSelf);
    }
    return (__VstlExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vspk286_instruction_schedule_tb___024root___dump_triggers__act(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___dump_triggers__act\n"); );
    // Body
    if ((1U & (~ (IData)(vlSelf->__VactTriggered.any())))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelf->__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 0 is active: @(posedge spk286_instruction_schedule_tb.clk)\n");
    }
    if ((2ULL & vlSelf->__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 1 is active: @(negedge spk286_instruction_schedule_tb.clk)\n");
    }
    if ((4ULL & vlSelf->__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 2 is active: @([true] __VdlySched.awaitingCurrentTime())\n");
    }
}
#endif  // VL_DEBUG

#ifdef VL_DEBUG
VL_ATTR_COLD void Vspk286_instruction_schedule_tb___024root___dump_triggers__nba(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___dump_triggers__nba\n"); );
    // Body
    if ((1U & (~ (IData)(vlSelf->__VnbaTriggered.any())))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelf->__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 0 is active: @(posedge spk286_instruction_schedule_tb.clk)\n");
    }
    if ((2ULL & vlSelf->__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 1 is active: @(negedge spk286_instruction_schedule_tb.clk)\n");
    }
    if ((4ULL & vlSelf->__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 2 is active: @([true] __VdlySched.awaitingCurrentTime())\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vspk286_instruction_schedule_tb___024root___ctor_var_reset(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___ctor_var_reset\n"); );
    // Body
    vlSelf->spk286_instruction_schedule_tb__DOT__clk = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__reset = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__historical_enable = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__cancel = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__preserve_cancel = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_valid = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_freeze = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__read_wait_event = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__alignment_event = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__repeat_checkpoint = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_clocks = VL_RAND_RESET_I(10);
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_ready = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_clocks = VL_RAND_RESET_I(4);
    vlSelf->spk286_instruction_schedule_tb__DOT__active = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__body_active = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__retire_pending = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__head_permit = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__deadline_ready = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__implementation_extension = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__checks = VL_RAND_RESET_I(32);
    vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__active_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__body_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__pending_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__qualified_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__frozen_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__admission_window_q = VL_RAND_RESET_I(1);
    vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q = VL_RAND_RESET_I(10);
    vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__base_q = VL_RAND_RESET_I(10);
    vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__extra_q = VL_RAND_RESET_I(10);
    vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_next = VL_RAND_RESET_I(11);
    vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__extra_next = VL_RAND_RESET_I(11);
    vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total = VL_RAND_RESET_I(12);
    vlSelf->__Vtrigprevexpr___TOP__spk286_instruction_schedule_tb__DOT__clk__0 = VL_RAND_RESET_I(1);
}
