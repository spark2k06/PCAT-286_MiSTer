// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vspk286_instruction_schedule_tb.h for the primary calling header

#include "Vspk286_instruction_schedule_tb__pch.h"
#include "Vspk286_instruction_schedule_tb__Syms.h"
#include "Vspk286_instruction_schedule_tb___024root.h"

VL_INLINE_OPT VlCoroutine Vspk286_instruction_schedule_tb___024root___eval_initial__TOP__Vtiming__0(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___eval_initial__TOP__Vtiming__0\n"); );
    // Init
    IData/*31:0*/ spk286_instruction_schedule_tb__DOT__unnamedblk7__DOT__k;
    spk286_instruction_schedule_tb__DOT__unnamedblk7__DOT__k = 0;
    IData/*31:0*/ spk286_instruction_schedule_tb__DOT__unnamedblk8__DOT__k;
    spk286_instruction_schedule_tb__DOT__unnamedblk8__DOT__k = 0;
    IData/*31:0*/ spk286_instruction_schedule_tb__DOT__unnamedblk9__DOT__k;
    spk286_instruction_schedule_tb__DOT__unnamedblk9__DOT__k = 0;
    IData/*31:0*/ spk286_instruction_schedule_tb__DOT__unnamedblk10__DOT__k;
    spk286_instruction_schedule_tb__DOT__unnamedblk10__DOT__k = 0;
    IData/*31:0*/ spk286_instruction_schedule_tb__DOT__unnamedblk11__DOT__k;
    spk286_instruction_schedule_tb__DOT__unnamedblk11__DOT__k = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__2__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__2__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__4__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__4__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__5__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__5__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__5__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__8__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__8__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__9__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__9__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__start__11__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__11__boundary = 0;
    IData/*31:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__start__11__budget;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__11__budget = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__12__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__12__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__14__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__14__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__14__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__15__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__15__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__16__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__16__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__16__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__18__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__18__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__18__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__19__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__19__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__20__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__20__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__20__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__22__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__22__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__23__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__23__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__23__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__25__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__25__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__25__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__26__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__26__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__27__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__27__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__27__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__start__29__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__29__boundary = 0;
    IData/*31:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__start__29__budget;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__29__budget = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__30__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__30__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__32__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__32__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__32__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__33__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__33__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__34__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__34__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__36__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__36__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__36__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__37__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__37__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__38__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__38__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__38__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__40__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__40__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__41__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__41__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__43__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__43__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__43__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__45__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__45__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__46__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__46__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__start__48__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__48__boundary = 0;
    IData/*31:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__start__48__budget;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__48__budget = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__49__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__49__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__51__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__51__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__51__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__52__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__52__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__53__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__53__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__55__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__55__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__56__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__56__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__58__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__58__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__59__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__59__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__61__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__61__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__62__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__62__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__64__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__64__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__64__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__65__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__65__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__66__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__66__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__68__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__68__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__68__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__69__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__69__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__70__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__70__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__70__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__72__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__72__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__73__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__73__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__73__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__76__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__76__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__77__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__77__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__start__79__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__79__boundary = 0;
    IData/*31:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__start__79__budget;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__79__budget = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__80__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__80__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__82__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__82__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__82__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__83__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__83__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__84__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__84__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__86__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__86__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__87__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__87__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__89__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__89__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__90__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__90__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__92__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__92__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__92__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__93__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__93__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__94__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__94__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__96__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__96__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__97__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__97__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__99__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__99__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__99__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__100__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__100__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__101__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__101__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__103__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__103__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__103__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__104__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__104__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__105__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__105__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__107__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__107__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__107__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__108__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__108__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__109__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__109__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__111__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__111__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__111__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__112__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__112__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__113__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__113__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__115__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__115__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__116__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__116__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__116__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__118__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__118__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__119__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__119__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__119__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__122__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__122__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__123__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__123__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__start__125__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__125__boundary = 0;
    IData/*31:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__start__125__budget;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__125__budget = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__126__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__126__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__128__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__128__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__128__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__129__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__129__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__130__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__130__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__132__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__132__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__133__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__133__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__135__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__135__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__136__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__136__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__138__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__138__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__138__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__140__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__140__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__141__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__141__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__start__143__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__143__boundary = 0;
    IData/*31:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__start__143__budget;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__143__budget = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__144__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__144__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__146__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__146__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__146__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__147__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__147__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__148__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__148__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__150__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__150__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__151__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__151__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__153__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__153__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__153__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__154__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__154__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__155__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__155__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__155__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__158__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__158__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__159__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__159__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__start__161__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__161__boundary = 0;
    IData/*31:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__start__161__budget;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__161__budget = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__162__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__162__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__164__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__164__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__164__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__165__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__165__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__166__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__166__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__168__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__168__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__169__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__169__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__171__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__171__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__171__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__172__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__172__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__173__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__173__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__175__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__175__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__175__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__176__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__176__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__177__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__177__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__177__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__179__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__179__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__180__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__180__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__180__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__183__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__183__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__184__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__184__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__start__186__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__186__boundary = 0;
    IData/*31:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__start__186__budget;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__186__budget = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__187__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__187__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__189__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__189__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__189__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__190__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__190__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__191__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__191__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__193__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__193__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__193__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__194__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__194__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__195__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__195__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__197__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__197__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__198__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__198__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__200__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__200__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__201__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__201__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__201__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__204__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__204__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__205__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__205__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__start__207__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__207__boundary = 0;
    IData/*31:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__start__207__budget;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__207__budget = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__208__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__208__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__210__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__210__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__210__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__211__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__211__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__212__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__212__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__214__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__214__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__215__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__215__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__217__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__217__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__217__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__218__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__218__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__219__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__219__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__221__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__221__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__222__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__222__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__224__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__224__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__225__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__225__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__225__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__228__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__228__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__229__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__229__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__start__231__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__231__boundary = 0;
    IData/*31:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__start__231__budget;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__231__budget = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__232__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__232__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__234__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__234__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__234__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__235__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__235__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__236__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__236__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__238__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__238__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__239__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__239__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__241__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__241__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__241__label;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__242__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__242__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__243__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__243__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__tick__245__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__245__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__246__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__246__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__248__boundary;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__248__boundary = 0;
    CData/*0:0*/ __Vtask_spk286_instruction_schedule_tb__DOT__check__249__condition;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__249__condition = 0;
    std::string __Vtask_spk286_instruction_schedule_tb__DOT__check__249__label;
    // Body
    vlSelf->spk286_instruction_schedule_tb__DOT__reset = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__cancel = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__preserve_cancel = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_valid = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_freeze = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__read_wait_event = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__alignment_event = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__repeat_checkpoint = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_ready = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_clocks = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__2__boundary = 0U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__2__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__reset = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__historical_enable = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__4__boundary = 0U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__4__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       57);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__5__label = 
        std::string{"MAX exact combinational bypass"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__5__condition 
        = (((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__head_permit) 
            & ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire) 
               == (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired))) 
           & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__active)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__5__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__5__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__4__boundary = 1U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__4__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 0U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       57);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__5__label = 
        std::string{"MAX exact combinational bypass"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__5__condition 
        = (((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__head_permit) 
            & ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire) 
               == (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired))) 
           & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__active)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__5__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__5__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__4__boundary = 0U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__4__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 1U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       57);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__5__label = 
        std::string{"MAX exact combinational bypass"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__5__condition 
        = (((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__head_permit) 
            & ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire) 
               == (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired))) 
           & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__active)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__5__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__5__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__4__boundary = 1U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__4__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 1U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       57);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__5__label = 
        std::string{"MAX exact combinational bypass"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__5__condition 
        = (((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__head_permit) 
            & ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire) 
               == (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired))) 
           & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__active)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__5__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__5__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__historical_enable = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__reset = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__cancel = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__preserve_cancel = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_valid = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_freeze = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__read_wait_event = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__alignment_event = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__repeat_checkpoint = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_ready = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_clocks = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__8__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__9__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__8__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__9__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__reset = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__11__budget = 2U;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__11__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__12__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__start__11__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__12__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_clocks 
        = (0x3ffU & __Vtask_spk286_instruction_schedule_tb__DOT__start__11__budget);
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 1U;
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__14__label = 
        std::string{"interval admission starts age0"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__14__condition 
        = (((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__active) 
            & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__body_active)) 
           & (0U == (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__14__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__14__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__15__boundary = 0U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__15__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 1U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       63);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__16__label = 
        std::string{"early raw retirement retained"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__16__condition 
        = (1U & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__16__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__16__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__18__label = 
        std::string{"single pending raw token"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__18__condition 
        = vlSelf->spk286_instruction_schedule_tb__DOT__retire_pending;
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__18__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__18__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__19__boundary = 1U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__19__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__20__label = 
        std::string{"two clocks not one"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__20__condition 
        = (1U & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__20__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__20__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__22__boundary = 1U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__22__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__23__label = 
        std::string{"second virtual boundary retires"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__23__condition 
        = vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire;
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__23__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__23__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__25__label = 
        std::string{"one qualified retirement consumes token"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__25__condition 
        = (1U & ((~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__active)) 
                 & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__retire_pending))));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__25__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__25__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__26__boundary = 0U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__26__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__27__label = 
        std::string{"post-retire fabric admission window"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__27__condition 
        = vlSelf->spk286_instruction_schedule_tb__DOT__head_permit;
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__27__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__27__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__start__29__budget = 3U;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__29__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__30__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__start__29__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__30__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_clocks 
        = (0x3ffU & __Vtask_spk286_instruction_schedule_tb__DOT__start__29__budget);
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 1U;
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__32__label = 
        std::string{"interval admission starts age0"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__32__condition 
        = (((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__active) 
            & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__body_active)) 
           & (0U == (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__32__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__32__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__33__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__34__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__33__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__34__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__36__label = 
        std::string{"post-retire window shares boundary origin"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__36__condition 
        = (1U == (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__36__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__36__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__33__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__34__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__33__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__34__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__36__label = 
        std::string{"post-retire window shares boundary origin"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__36__condition 
        = (2U == (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__36__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__36__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__37__boundary = 1U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__37__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 1U;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       71);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__38__label = 
        std::string{"same-edge raw at third boundary"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__38__condition 
        = vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire;
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__38__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__38__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__40__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__41__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__40__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__41__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__43__label = 
        std::string{"retirement is not replayed"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__43__condition 
        = (1U & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__43__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__43__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    vlSelf->spk286_instruction_schedule_tb__DOT__reset = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__cancel = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__preserve_cancel = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_valid = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_freeze = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__read_wait_event = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__alignment_event = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__repeat_checkpoint = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_ready = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_clocks = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__45__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__46__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__45__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__46__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__reset = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_valid = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__48__budget = 3U;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__48__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__49__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__start__48__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__49__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_clocks 
        = (0x3ffU & __Vtask_spk286_instruction_schedule_tb__DOT__start__48__budget);
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 1U;
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__51__label = 
        std::string{"interval admission starts age0"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__51__condition 
        = (((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__active) 
            & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__body_active)) 
           & (0U == (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__51__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__51__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__52__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__53__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__52__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__53__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__55__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__56__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__55__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__56__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__58__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__59__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__58__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__59__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__61__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__62__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__61__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__62__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__64__label = 
        std::string{"missing required current metadata blocks publication"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__64__condition 
        = (1U & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__64__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__64__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_valid = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_clocks = 7U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__65__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__66__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__65__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__66__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__68__label = 
        std::string{"late form replaces base without additive replay"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__68__condition 
        = (7U == (0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__68__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__68__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__69__boundary = 1U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__69__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__70__label = 
        std::string{"memory budget not early"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__70__condition 
        = (1U & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__70__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__70__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__69__boundary = 1U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__69__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__70__label = 
        std::string{"memory budget not early"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__70__condition 
        = (1U & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__70__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__70__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__69__boundary = 1U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__69__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__70__label = 
        std::string{"memory budget not early"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__70__condition 
        = (1U & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__70__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__70__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__72__boundary = 1U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__72__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__73__label = 
        std::string{"late qualified seven-clock row"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__73__condition 
        = vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire;
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__73__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__73__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__reset = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__cancel = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__preserve_cancel = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_valid = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_freeze = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__read_wait_event = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__alignment_event = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__repeat_checkpoint = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_ready = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_clocks = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__76__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__77__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__76__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__77__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__reset = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__79__budget = 7U;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__79__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__80__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__start__79__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__80__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_clocks 
        = (0x3ffU & __Vtask_spk286_instruction_schedule_tb__DOT__start__79__budget);
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 1U;
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__82__label = 
        std::string{"interval admission starts age0"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__82__condition 
        = (((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__active) 
            & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__body_active)) 
           & (0U == (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__82__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__82__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    vlSelf->spk286_instruction_schedule_tb__DOT__alignment_event = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__83__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__84__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__83__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__84__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__86__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__87__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__86__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__87__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__alignment_event = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__read_wait_event = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__89__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__90__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__89__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__90__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__read_wait_event = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__92__label = 
        std::string{"two odd references and productive-clock READ wait"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__92__condition 
        = ((0xbU == (0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total))) 
           & (0U == (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__92__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__92__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_freeze = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__93__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__94__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__93__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__94__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_freeze = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_clocks = 2U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__96__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__97__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__96__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__97__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__99__label = 
        std::string{"freeze preserves accepted metadata"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__99__condition 
        = (0xbU == (0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__99__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__99__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    vlSelf->spk286_instruction_schedule_tb__DOT__cancel = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__preserve_cancel = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__100__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__101__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__100__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__101__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__103__label = 
        std::string{"software transition preserves interval"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__103__condition 
        = vlSelf->spk286_instruction_schedule_tb__DOT__active;
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__103__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__103__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    vlSelf->spk286_instruction_schedule_tb__DOT__cancel = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__preserve_cancel = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__repeat_checkpoint = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__104__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__105__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__104__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__105__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__repeat_checkpoint = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__107__label = 
        std::string{"REP checkpoint starts next iteration only"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__107__condition 
        = ((0U == (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q)) 
           & (5U == (0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total))));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__107__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__107__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_clocks = 0x64U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__108__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__109__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__108__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__109__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__111__label = 
        std::string{"REP frozen per-iteration excludes setup replay"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__111__condition 
        = (5U == (0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__111__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__111__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__112__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__113__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__112__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__113__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__115__boundary = 1U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__115__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__116__label = 
        std::string{"REP per-iteration budget binding"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__116__condition 
        = (1U & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__116__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__116__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__115__boundary = 1U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__115__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__116__label = 
        std::string{"REP per-iteration budget binding"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__116__condition 
        = (1U & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__116__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__116__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__115__boundary = 1U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__115__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__116__label = 
        std::string{"REP per-iteration budget binding"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__116__condition 
        = (1U & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__116__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__116__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__115__boundary = 1U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__115__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__116__label = 
        std::string{"REP per-iteration budget binding"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__116__condition 
        = (1U & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__116__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__116__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__118__boundary = 1U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__118__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__119__label = 
        std::string{"REP final raw token retires after iteration"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__119__condition 
        = vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire;
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__119__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__119__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__reset = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__cancel = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__preserve_cancel = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_valid = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_freeze = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__read_wait_event = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__alignment_event = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__repeat_checkpoint = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_ready = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_clocks = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__122__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__123__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__122__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__123__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__reset = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__125__budget = 2U;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__125__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__126__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__start__125__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__126__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_clocks 
        = (0x3ffU & __Vtask_spk286_instruction_schedule_tb__DOT__start__125__budget);
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 1U;
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__128__label = 
        std::string{"interval admission starts age0"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__128__condition 
        = (((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__active) 
            & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__body_active)) 
           & (0U == (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__128__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__128__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__129__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__130__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__129__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__130__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__cancel = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__132__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__133__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__132__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__133__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__cancel = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__135__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__136__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__135__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__136__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__138__label = 
        std::string{"cancel invalidates raw and timing token"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__138__condition 
        = (1U & (((~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__active)) 
                  & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__retire_pending))) 
                 & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire))));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__138__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__138__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    vlSelf->spk286_instruction_schedule_tb__DOT__reset = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__cancel = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__preserve_cancel = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_valid = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_freeze = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__read_wait_event = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__alignment_event = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__repeat_checkpoint = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_ready = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_clocks = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__140__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__141__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__140__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__141__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__reset = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__143__budget = 2U;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__143__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__144__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__start__143__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__144__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_clocks 
        = (0x3ffU & __Vtask_spk286_instruction_schedule_tb__DOT__start__143__budget);
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 1U;
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__146__label = 
        std::string{"interval admission starts age0"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__146__condition 
        = (((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__active) 
            & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__body_active)) 
           & (0U == (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__146__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__146__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__147__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__148__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__147__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__148__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__150__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__151__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__150__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__151__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__153__label = 
        std::string{"real functional lateness recorded"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__153__condition 
        = vlSelf->spk286_instruction_schedule_tb__DOT__implementation_extension;
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__153__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__153__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__154__boundary = 1U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__154__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__155__label = 
        std::string{"late functional result still publishes safely"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__155__condition 
        = vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire;
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__155__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__155__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__reset = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__cancel = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__preserve_cancel = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_valid = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_freeze = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__read_wait_event = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__alignment_event = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__repeat_checkpoint = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_ready = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_clocks = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__158__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__159__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__158__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__159__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__reset = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__161__budget = 7U;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__161__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__162__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__start__161__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__162__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_clocks 
        = (0x3ffU & __Vtask_spk286_instruction_schedule_tb__DOT__start__161__budget);
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 1U;
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__164__label = 
        std::string{"interval admission starts age0"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__164__condition 
        = (((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__active) 
            & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__body_active)) 
           & (0U == (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__164__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__164__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_ready = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_freeze = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__165__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__166__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__165__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__166__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_freeze = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__168__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__169__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__168__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__169__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__168__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__169__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__168__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__169__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__168__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__169__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__168__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__169__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__168__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__169__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__168__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__169__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__168__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__169__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__168__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__169__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__168__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__169__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__168__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__169__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__168__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__169__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__168__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__169__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__171__label = 
        std::string{"missing target length holds source beyond frozen base END"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__171__condition 
        = (((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__retire_pending) 
            & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__deadline_ready))) 
           & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__171__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__171__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_clocks = 2U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_clocks = 3U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_ready = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__172__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__173__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__172__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__173__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__175__label = 
        std::string{"late target length extends frozen source base"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__175__condition 
        = (0xaU == (0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__175__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__175__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__176__boundary = 1U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__176__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__177__label = 
        std::string{"base plus target encoding not early"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__177__condition 
        = (1U & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__177__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__177__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__176__boundary = 1U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__176__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__177__label = 
        std::string{"base plus target encoding not early"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__177__condition 
        = (1U & (~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__177__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__177__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__179__boundary = 1U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__179__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__180__label = 
        std::string{"source retires after seven plus three"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__180__condition 
        = vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire;
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__180__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__180__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__reset = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__cancel = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__preserve_cancel = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_valid = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_freeze = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__read_wait_event = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__alignment_event = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__repeat_checkpoint = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_ready = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_clocks = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__183__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__184__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__183__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__184__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__reset = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__186__budget = 0xc3U;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__186__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__187__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__start__186__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__187__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_clocks 
        = (0x3ffU & __Vtask_spk286_instruction_schedule_tb__DOT__start__186__budget);
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 1U;
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__189__label = 
        std::string{"interval admission starts age0"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__189__condition 
        = (((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__active) 
            & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__body_active)) 
           & (0U == (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__189__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__189__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    vlSelf->spk286_instruction_schedule_tb__DOT__read_wait_event = 1U;
    spk286_instruction_schedule_tb__DOT__unnamedblk7__DOT__k = 0U;
    while (VL_GTS_III(32, 0x44cU, spk286_instruction_schedule_tb__DOT__unnamedblk7__DOT__k)) {
        __Vtask_spk286_instruction_schedule_tb__DOT__tick__190__boundary = 1U;
        __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__191__boundary 
            = __Vtask_spk286_instruction_schedule_tb__DOT__tick__190__boundary;
        co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                           nullptr, 
                                                           "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                           28);
        vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
            = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__191__boundary;
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                           28);
        co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                           nullptr, 
                                                           "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                           31);
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                           31);
        spk286_instruction_schedule_tb__DOT__unnamedblk7__DOT__k 
            = ((IData)(1U) + spk286_instruction_schedule_tb__DOT__unnamedblk7__DOT__k);
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__read_wait_event = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__193__label = 
        std::string{"unbounded READ waits do not saturate a debt"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__193__condition 
        = ((0U == (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q)) 
           & (0xc3U == (0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total))));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__193__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__193__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__194__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__195__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__194__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__195__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 0U;
    spk286_instruction_schedule_tb__DOT__unnamedblk8__DOT__k = 0U;
    while (VL_GTS_III(32, 0xc2U, spk286_instruction_schedule_tb__DOT__unnamedblk8__DOT__k)) {
        __Vtask_spk286_instruction_schedule_tb__DOT__tick__197__boundary = 1U;
        __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__198__boundary 
            = __Vtask_spk286_instruction_schedule_tb__DOT__tick__197__boundary;
        co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                           nullptr, 
                                                           "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                           28);
        vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
            = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__198__boundary;
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                           28);
        co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                           nullptr, 
                                                           "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                           31);
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                           31);
        spk286_instruction_schedule_tb__DOT__unnamedblk8__DOT__k 
            = ((IData)(1U) + spk286_instruction_schedule_tb__DOT__unnamedblk8__DOT__k);
    }
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__200__boundary = 1U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__200__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__201__label = 
        std::string{"base195 after1100waits needs195productive boundaries"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__201__condition 
        = vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire;
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__201__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__201__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__reset = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__cancel = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__preserve_cancel = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_valid = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_freeze = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__read_wait_event = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__alignment_event = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__repeat_checkpoint = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_ready = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_clocks = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__204__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__205__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__204__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__205__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__reset = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__207__budget = 0x3fcU;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__207__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__208__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__start__207__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__208__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_clocks 
        = (0x3ffU & __Vtask_spk286_instruction_schedule_tb__DOT__start__207__budget);
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 1U;
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__210__label = 
        std::string{"interval admission starts age0"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__210__condition 
        = (((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__active) 
            & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__body_active)) 
           & (0U == (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__210__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__210__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    vlSelf->spk286_instruction_schedule_tb__DOT__alignment_event = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__211__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__212__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__211__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__212__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__214__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__215__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__214__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__215__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__alignment_event = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__217__label = 
        std::string{"budget saturates without overflow"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__217__condition 
        = (0x3ffU == (0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__217__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__217__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__218__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__219__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__218__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__219__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 0U;
    spk286_instruction_schedule_tb__DOT__unnamedblk9__DOT__k = 0U;
    while (VL_GTS_III(32, 0x3feU, spk286_instruction_schedule_tb__DOT__unnamedblk9__DOT__k)) {
        __Vtask_spk286_instruction_schedule_tb__DOT__tick__221__boundary = 1U;
        __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__222__boundary 
            = __Vtask_spk286_instruction_schedule_tb__DOT__tick__221__boundary;
        co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                           nullptr, 
                                                           "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                           28);
        vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
            = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__222__boundary;
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                           28);
        co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                           nullptr, 
                                                           "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                           31);
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                           31);
        spk286_instruction_schedule_tb__DOT__unnamedblk9__DOT__k 
            = ((IData)(1U) + spk286_instruction_schedule_tb__DOT__unnamedblk9__DOT__k);
    }
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__224__boundary = 1U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__224__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__225__label = 
        std::string{"saturation does not strand boot"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__225__condition 
        = vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire;
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__225__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__225__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__reset = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__cancel = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__preserve_cancel = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_valid = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_freeze = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__read_wait_event = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__alignment_event = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__repeat_checkpoint = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_ready = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_clocks = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__228__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__229__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__228__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__229__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__reset = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__231__budget = 0x3ffU;
    __Vtask_spk286_instruction_schedule_tb__DOT__start__231__boundary = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__232__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__start__231__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__232__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__metadata_clocks 
        = (0x3ffU & __Vtask_spk286_instruction_schedule_tb__DOT__start__231__budget);
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 1U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 1U;
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__start_interval = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__start_body = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__check__234__label = 
        std::string{"interval admission starts age0"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__234__condition 
        = (((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__active) 
            & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__body_active)) 
           & (0U == (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__234__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__234__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_ready = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__alignment_event = 1U;
    spk286_instruction_schedule_tb__DOT__unnamedblk10__DOT__k = 0U;
    while (VL_GTS_III(32, 0x200U, spk286_instruction_schedule_tb__DOT__unnamedblk10__DOT__k)) {
        __Vtask_spk286_instruction_schedule_tb__DOT__tick__235__boundary = 0U;
        __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__236__boundary 
            = __Vtask_spk286_instruction_schedule_tb__DOT__tick__235__boundary;
        co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                           nullptr, 
                                                           "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                           28);
        vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
            = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__236__boundary;
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                           28);
        co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                           nullptr, 
                                                           "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                           31);
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                           31);
        spk286_instruction_schedule_tb__DOT__unnamedblk10__DOT__k 
            = ((IData)(1U) + spk286_instruction_schedule_tb__DOT__unnamedblk10__DOT__k);
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__alignment_event = 0U;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_clocks = 0xaU;
    vlSelf->spk286_instruction_schedule_tb__DOT__target_length_ready = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__238__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__239__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__238__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__239__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__241__label = 
        std::string{"maxbase plus saturated odd plus length cannot wrap a narrow sum"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__241__condition 
        = (0x3ffU == (0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__241__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__241__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 1U;
    __Vtask_spk286_instruction_schedule_tb__DOT__tick__242__boundary = 0U;
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__243__boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__tick__242__boundary;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__243__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    vlSelf->spk286_instruction_schedule_tb__DOT__functional_retired = 0U;
    spk286_instruction_schedule_tb__DOT__unnamedblk11__DOT__k = 0U;
    while (VL_GTS_III(32, 0x3feU, spk286_instruction_schedule_tb__DOT__unnamedblk11__DOT__k)) {
        __Vtask_spk286_instruction_schedule_tb__DOT__tick__245__boundary = 1U;
        __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__246__boundary 
            = __Vtask_spk286_instruction_schedule_tb__DOT__tick__245__boundary;
        co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                           nullptr, 
                                                           "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                           28);
        vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
            = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__246__boundary;
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                           28);
        co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                           nullptr, 
                                                           "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                           31);
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                           31);
        spk286_instruction_schedule_tb__DOT__unnamedblk11__DOT__k 
            = ((IData)(1U) + spk286_instruction_schedule_tb__DOT__unnamedblk11__DOT__k);
    }
    __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__248__boundary = 1U;
    co_await vlSelf->__VtrigSched_h08021459__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(negedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       28);
    vlSelf->spk286_instruction_schedule_tb__DOT__cpu_boundary 
        = __Vtask_spk286_instruction_schedule_tb__DOT__edge_begin__248__boundary;
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       28);
    __Vtask_spk286_instruction_schedule_tb__DOT__check__249__label = 
        std::string{"max1023 plus max1023 plus length10 retains saturated deadline"};
    __Vtask_spk286_instruction_schedule_tb__DOT__check__249__condition 
        = vlSelf->spk286_instruction_schedule_tb__DOT__retire_fire;
    if (VL_UNLIKELY((1U & (~ (IData)(__Vtask_spk286_instruction_schedule_tb__DOT__check__249__condition))))) {
        VL_WRITEF("[%0t] %%Fatal: spk286_instruction_schedule_tb.sv:23: Assertion failed in %Nspk286_instruction_schedule_tb.check: SCHEDULE_ORACLE_FAILED %@ age%0# budget%0#\n",
                  64,VL_TIME_UNITED_Q(1000),-9,vlSymsp->name(),
                  -1,&(__Vtask_spk286_instruction_schedule_tb__DOT__check__249__label),
                  10,(IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__elapsed_q),
                  10,(0x3ffU & (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__dut__DOT__total)));
        VL_STOP_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 23, "");
    }
    vlSelf->spk286_instruction_schedule_tb__DOT__checks 
        = ((IData)(1U) + vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    co_await vlSelf->__VtrigSched_h080213a8__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge spk286_instruction_schedule_tb.clk)", 
                                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                                       31);
    co_await vlSelf->__VdlySched.delay(0x3e8ULL, nullptr, 
                                       "/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 
                                       31);
    VL_WRITEF("PROFILE_SCHEDULE_PASS checks%0d\n",32,
              vlSelf->spk286_instruction_schedule_tb__DOT__checks);
    VL_FINISH_MT("/mnt/d/GitHub/PCAT-286_MiSTer/sim/spk286_timing/spk286_instruction_schedule_tb.sv", 137, "");
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vspk286_instruction_schedule_tb___024root___dump_triggers__act(Vspk286_instruction_schedule_tb___024root* vlSelf);
#endif  // VL_DEBUG

void Vspk286_instruction_schedule_tb___024root___eval_triggers__act(Vspk286_instruction_schedule_tb___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vspk286_instruction_schedule_tb__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vspk286_instruction_schedule_tb___024root___eval_triggers__act\n"); );
    // Body
    vlSelf->__VactTriggered.set(0U, ((IData)(vlSelf->spk286_instruction_schedule_tb__DOT__clk) 
                                     & (~ (IData)(vlSelf->__Vtrigprevexpr___TOP__spk286_instruction_schedule_tb__DOT__clk__0))));
    vlSelf->__VactTriggered.set(1U, ((~ (IData)(vlSelf->spk286_instruction_schedule_tb__DOT__clk)) 
                                     & (IData)(vlSelf->__Vtrigprevexpr___TOP__spk286_instruction_schedule_tb__DOT__clk__0)));
    vlSelf->__VactTriggered.set(2U, vlSelf->__VdlySched.awaitingCurrentTime());
    vlSelf->__Vtrigprevexpr___TOP__spk286_instruction_schedule_tb__DOT__clk__0 
        = vlSelf->spk286_instruction_schedule_tb__DOT__clk;
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vspk286_instruction_schedule_tb___024root___dump_triggers__act(vlSelf);
    }
#endif
}
