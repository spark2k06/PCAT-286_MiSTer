// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vspk286_instruction_schedule_tb.h for the primary calling header

#include "Vspk286_instruction_schedule_tb__pch.h"
#include "Vspk286_instruction_schedule_tb__Syms.h"
#include "Vspk286_instruction_schedule_tb___024root.h"

void Vspk286_instruction_schedule_tb___024root___ctor_var_reset(Vspk286_instruction_schedule_tb___024root* vlSelf);

Vspk286_instruction_schedule_tb___024root::Vspk286_instruction_schedule_tb___024root(Vspk286_instruction_schedule_tb__Syms* symsp, const char* v__name)
    : VerilatedModule{v__name}
    , __VdlySched{*symsp->_vm_contextp__}
    , vlSymsp{symsp}
 {
    // Reset structure values
    Vspk286_instruction_schedule_tb___024root___ctor_var_reset(this);
}

void Vspk286_instruction_schedule_tb___024root::__Vconfigure(bool first) {
    if (false && first) {}  // Prevent unused
}

Vspk286_instruction_schedule_tb___024root::~Vspk286_instruction_schedule_tb___024root() {
}
