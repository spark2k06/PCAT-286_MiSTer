#!/usr/bin/env python3
"""Recover completed v1 streams, then finish IOPL and remaining units.

Only build artifacts are written. Original assertions, fixtures, watchdogs and
trace views are preserved. The failed IOPL6 host timeout is not accepted.
Two host jobs run concurrently; IOPL gets 900s host allowance only.
"""
from concurrent.futures import ThreadPoolExecutor
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
V1 = ROOT / "build/p06-ready-chain-profile-compat-20261004-v1"
FIT = ROOT / "build/p06-ready-chain-allfeatures-20261004-v1"
sys.path.insert(0, str(ROOT / "scripts"))
sys.dont_write_bytecode = True
import test_p06_profile_compatibility as h

DONE = h.UNITS[:22]
REST = ["stack_frame_lifecycle", "far_lifecycle", "muldiv_lifecycle"]
IOPL_PAIRED = [0, 7]
COUNTS = dict(iverilog=202, verilator=64, max_equivalence=26,
              dual_trace_pairs=58, unpaired_verilator_functional=6)


def require(value, message):
    if not value:
        raise AssertionError(message)


def js(path):
    return json.loads(path.read_text())


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", newline="\n")


def source_set():
    paths = h.original_sources() + [ROOT / n for n in (
        "scripts/build_p06_profile_cpu.py", "scripts/test_p06_profile_compatibility.py",
        "rtl/spk286_timing/spk286_instruction_schedule.sv",
        "rtl/spk286_timing/spk286_instruction_timing.sv",
        "rtl/spk286_integration/spk286_at_cpu_profile.sv",
        "vendor/spk286/sim/unit/spk286_signals.svh")]
    paths += [h.CPU / f"sim/unit/spk286_{unit}_tb.sv" for unit in h.UNITS]
    return {p.relative_to(ROOT).as_posix(): h.sha(p) for p in paths}


def guard():
    before = js(OUT / "launch.json")["source_sha256"]
    require(source_set() == before, "Compatibility source changed")
    require(h.sha(Path(__file__)) == js(OUT / "launch.json")["completion_runner_sha256"],
            "Completion runner changed")
    return before


def digest(stem):
    data = js(stem.with_suffix(".digest.json"))
    for key in ("bytes", "canonical_bytes", "rows"):
        require(type(data[key]) is int and data[key] > 0, "Missing/incomplete trace count")
    for key in ("sha256", "canonical_sha256"):
        require(len(data[key]) == 64, "Trace digest missing")
    if stem.exists():
        require(h.sha(stem) == data["sha256"] and stem.stat().st_size == data["bytes"], "Raw trace drift")
    else:
        require(data["storage"] == "streamed raw/canonical SHA256", "Missing streamed trace")
        for suffix in (".prefix.txt", ".tail.txt"):
            require(stem.with_suffix(suffix).is_file(), "Missing retained observer samples")
    return data


def completed_record(directory, unit, profile, simulator, recovered=False):
    log = directory / unit / f"profile-{profile}-{simulator}.log"
    text = log.read_text()
    passes = h.pass_lines(text)
    require(passes and not any(word in text for word in ("FATAL", "FAIL", "Error", "TIMEOUT")),
            "No completed normal PASS log: " + str(log))
    trace = digest(log.with_suffix(".csv"))
    record = dict(unit=unit, profile=profile, name=h.PROFILE_NAMES[profile], simulator=simulator,
                  status="PASS", returncode=0, **{"pass": passes}, trace_sha256=trace["sha256"],
                  canonical_trace_sha256=trace["canonical_sha256"], trace=trace)
    if recovered:
        record["recovery"] = "Completed terminal PASS log and finished observer digest; v1 did not leave a global receipt. Host RC0 is inferred from normal unchanged-bench completion, not from an invented initial receipt."
    if simulator == "verilator":
        record["comparison"] = "Complete declared CANONICAL SHA256/byte-count/row-count equality to Icarus"
    return record


def max_record(directory, unit, recovered=False):
    original = digest(directory / unit / "original-max.csv")
    profiled = digest(directory / unit / "profile-0-iverilog.csv")
    log = directory / unit / "original-run.log"
    text = log.read_text()
    require(h.pass_lines(text) and not any(word in text for word in ("FATAL", "FAIL", "Error", "TIMEOUT")),
            "Original MAX has no completed PASS")
    require(all(original[k] == profiled[k] for k in ("sha256", "bytes", "rows")), "MAX raw mismatch")
    record = dict(unit=unit, status="PASS", kind="MAX per-edge equivalence",
        original_trace_sha256=original["sha256"], profiled_trace_sha256=profiled["sha256"],
        comparison="SHA256/byte-count/row-count equality of complete RAW per-edge stream")
    if recovered:
        record["recovery"] = "Completed original/profiled v1 logs and finished RAW stream digests"
    return record


def compare(a, b, canonical=False):
    keys = ("canonical_sha256", "canonical_bytes", "rows") if canonical else ("sha256", "bytes", "rows")
    require(all(a[k] == b[k] for k in keys), "Complete observer stream comparison failed")


def freeze_files(source, target):
    target.mkdir()
    hashes = {}
    for path in sorted(source.iterdir()):
        if path.is_file() and path.suffix in (".sv", ".json", ".log", ".txt", ".csv"):
            hashes[path.name] = h.sha(path)
            shutil.copyfile(path, target / path.name)
            require(h.sha(target / path.name) == hashes[path.name] == h.sha(path), "Copy drift")
    return hashes


def start():
    require(not (OUT / "launch.json").exists(), "Completion output already launched")
    require(DONE[-1] == "protected_retf" and len(DONE) == 22, "Recovery range changed")
    sources = source_set()
    fm = js(FIT / "manifest.json")["source_sha256"]
    fm = {name.replace("\\", "/"): value for name, value in fm.items()}
    require(all(fm.get(name) == digest for name, digest in sources.items()),
            "Recovered/new source closure differs from frozen fit manifest")
    generation = js(V1 / "generated/generation.json")
    require(all(h.sha(ROOT / name) == value for name, value in generation["sources_sha256"].items()),
            "v1 generation source guard drift")
    for name, value in generation["generated_sha256"].items():
        require(h.sha(V1 / "generated" / name) == value, "v1 generated artifact drift")
        require(h.sha(ROOT / "vendor/spk286/rtl/timed" / name) == value, "Selected production artifact drift")
    rebuild = OUT / "fixture-rebuild"
    rebuild.mkdir()
    selected = h.build(rebuild / "generated")
    require({name: h.sha(p) for name, p in selected.items()} == generation["generated_sha256"],
            "Current generation does not reproduce v1")
    for unit in h.UNITS:
        h.fixture(rebuild, unit)
        for name in ("fixture.json", f"spk286_{unit}_profiled_tb.sv", f"spk286_{unit}_original_tb.sv"):
            require(h.sha(rebuild / unit / name) == h.sha(V1 / unit / name), "Fixture no longer byte-identical: " + unit)
    versions = {}
    for name, command in {"python": [sys.executable, "--version"], "iverilog": ["iverilog", "-V"],
                          "verilator": ["verilator", "--version"]}.items():
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
        require(result.returncode == 0, "Cannot record tool version: " + name)
        versions[name] = result.stdout + result.stderr
    write(OUT / "launch.json", dict(source_sha256=sources, completion_runner_sha256=h.sha(Path(__file__)),
        frozen_fit_manifest_sha256=h.sha(FIT / "manifest.json"), v1_generation_sha256=h.sha(V1 / "generated/generation.json"),
        generated_source_sha256=generation["generated_sha256"], tool_versions=versions, jobs=2,
        commands=[[sys.executable, str(Path(__file__)), "--worker", name] for name in ("iopl", "rest")],
        reported_incomplete_attempt=dict(unit="iopl_access", profile=1, nominal_mhz="6", host_timeout_seconds=300,
            status="HOST_TIMEOUT_NOT_ACCEPTED", provenance="Parent reports initial host TimeoutExpired; v1 has no global receipt or completed profile1 log/digest. The original v1 directory is preserved unchanged.",
            path=V1.relative_to(ROOT).as_posix())))
    recovered = OUT / "recovered"
    recovered.mkdir()
    freeze_files(V1 / "generated", recovered / "generated")
    all_hashes, records = {}, []
    for unit in DONE:
        all_hashes[unit] = freeze_files(V1 / unit, recovered / unit)
        for profile in range(8):
            ic = completed_record(recovered, unit, profile, "iverilog", True)
            records.append(ic)
            if unit in h.DUAL:
                vl = completed_record(recovered, unit, profile, "verilator", True)
                compare(ic["trace"], vl["trace"], True)
                records.append(vl)
        records.append(max_record(recovered, unit, True))
    write(recovered / "recovery-manifest.json", all_hashes)
    write(recovered / "receipt.json", dict(status="PASS", source_sha256=sources,
        generated_source_sha256=generation["generated_sha256"], units=DONE, profiles=list(range(8)),
        results=records, failures=[], source_changes=[],
        code_stimulus_adjustments={u: js(recovered / u / "fixture.json")["code_stimulus_adjustments"] for u in DONE},
        scope="Recovery of completed terminal PASS logs and finished per-edge streams, with fixture/generator byte identity and frozen fit input binding; no initial global receipt invented."))
    # Recover the completed IOPL MAX run; never copy/accept the timed-out profile1.
    iopl = OUT / "iopl"
    iopl.mkdir()
    freeze_files(V1 / "generated", iopl / "generated")
    freeze_files(V1 / "iopl_access", iopl / "iopl_access")
    require(completed_record(iopl, "iopl_access", 0, "iverilog", True)["status"] == "PASS", "IOPL MAX not completed")
    guard()
    print("COMPLETED_V1_RECOVERY_PASS units=22 Icarus=176 Verilator=56 MAX=22", flush=True)


def worker(name):
    guard()
    host_runs = []
    original_run = h.run
    def bounded(command, log, timeout=300, check=True):
        command = list(command)
        if "iopl_access" in str(log) and timeout == 300:
            timeout = 900
        if command and str(command[0]) == "verilator" and "-j" in command:
            command[command.index("-j") + 1] = "2"
        begun = time.monotonic()
        result = original_run(command, log, timeout, check)
        host_runs.append(dict(command=[str(v) for v in command], log=log.relative_to(ROOT).as_posix(),
                              timeout_seconds=timeout, seconds=time.monotonic()-begun, returncode=result.returncode))
        return result
    h.run = bounded
    if name == "rest":
        sys.argv = [str(ROOT / "scripts/test_p06_profile_compatibility.py"), "--output", str(OUT / "rest"),
                    "--units", ",".join(REST), "--dual-units", ""]
        h.main()
    else:
        directory = OUT / "iopl"
        unit = "iopl_access"
        target = directory / unit
        original = h.original_sources()
        selected = [p for p in original if p.name not in {"spk286.sv", "spk286_events.sv"}]
        selected += [directory / "generated" / name for name in js(OUT / "launch.json")["generated_source_sha256"]]
        selected += [ROOT / name for name in ("rtl/spk286_timing/spk286_instruction_schedule.sv",
            "rtl/spk286_timing/spk286_instruction_timing.sv", "rtl/spk286_integration/spk286_at_cpu_profile.sv")]
        include = ["-I"+str(h.CPU / "rtl"), "-I"+str(h.CPU / "sim/unit")]
        top = "spk286_iopl_access_tb"
        profiled, golden = target / (top.replace("_tb", "_profiled_tb") + ".sv"), target / (top.replace("_tb", "_original_tb") + ".sv")
        h.run(["iverilog", "-g2012", "-s", top, *include, "-o", target / "profiled.vvp", *selected, profiled],
              target / "fresh-iverilog-build.log", timeout=120)
        result = h.test_run(["vvp", target / "profiled.vvp"], target / "profile-7-iverilog.log",
                            target / "profile-7-iverilog.csv", 7, 16, "digest")
        require(result.returncode == 0, "IOPL25 Icarus did not complete")
        records = [completed_record(directory, unit, p, "iverilog", p == 0) for p in IOPL_PAIRED]
        h.run(["iverilog", "-g2012", "-s", top, *include, "-o", target / "original.vvp", *original, golden],
              target / "original-build.log", timeout=120)
        result = h.test_run(["vvp", target / "original.vvp"], target / "original-run.log",
                            target / "original-max.csv", 0, 1, "digest")
        require(result.returncode == 0, "IOPL golden MAX did not complete")
        records.append(max_record(directory, unit))
        h.run(["verilator", "--binary", "--timing", "--assert", "-CFLAGS", "-O0", "-j", "2",
               "--top-module", top, "--Mdir", target / "obj", "-o", "profiled-test", *include, *selected, profiled],
              target / "verilator-build.log", timeout=900)
        for profile in range(8):
            result = h.test_run([target / "obj/profiled-test"], target / f"profile-{profile}-verilator.log",
                target / f"profile-{profile}-verilator.csv", profile, 16, "digest")
            require(result.returncode == 0, "IOPL Verilator did not complete: " + str(profile))
            record = completed_record(directory, unit, profile, "verilator")
            if profile in IOPL_PAIRED:
                peer = next(r for r in records if r.get("profile") == profile and r.get("simulator") == "iverilog")
                compare(peer["trace"], record["trace"], True)
            else:
                record["comparison"] = "unpaired Verilator functional assertions; no Icarus trace comparison"
            records.append(record)
            print("IOPL_COMPLETED_PASS", h.PROFILE_NAMES[profile], flush=True)
        write(directory / "receipt.json", dict(status="PASS", source_sha256=guard(),
            generated_source_sha256=js(OUT / "launch.json")["generated_source_sha256"], units=[unit], profiles=list(range(8)),
            results=records, failures=[], source_changes=[], code_stimulus_adjustments={unit: []},
            scope="Original IOPL assertions; recovered Icarus MAX, fresh Icarus25/goldenMAX, eight Verilator profiles; six profiles unpaired."))
    guard()
    write(OUT / (name + "-host-runs.json"), host_runs)


def aggregate():
    guard()
    records, leaves, sources, adjustments = [], [], {}, {}
    expected_generated = js(OUT / "launch.json")["generated_source_sha256"]
    for name in ("recovered", "rest", "iopl"):
        path = OUT / name / "receipt.json"
        receipt = js(path)
        require(receipt["status"] == "PASS" and not receipt["failures"] and not receipt["source_changes"], "Unaccepted leaf")
        require(receipt["generated_source_sha256"] == expected_generated, "Leaf generated CPU mismatch")
        for source, value in receipt["source_sha256"].items():
            require(h.sha(ROOT / source) == value and (source not in sources or sources[source] == value), "Leaf source drift")
            sources[source] = value
        for record in receipt["results"]:
            unit = record["unit"]
            if record.get("kind") == "MAX per-edge equivalence":
                current = max_record(path.parent, unit, "recovery" in record)
                require(current == record, "Leaf MAX result drift")
            else:
                current = completed_record(path.parent, unit, record["profile"], record["simulator"], "recovery" in record)
                if "unpaired" in record.get("comparison", ""):
                    current["comparison"] = record["comparison"]
                require(current == record, "Leaf trace/log result drift")
            records.append({**record, "artifact_root": path.parent.relative_to(ROOT).as_posix(),
                            "leaf_receipt": path.relative_to(ROOT).as_posix()})
        leaves.append(dict(path=path.relative_to(ROOT).as_posix(), sha256=h.sha(path)))
        adjustments.update(receipt["code_stimulus_adjustments"])
    actual = [(r["unit"], r.get("simulator", "MAX equivalence"), r.get("profile", 0)) for r in records]
    expected = {(u, "iverilog", p) for u in h.UNITS for p in range(8) if u != "iopl_access" or p in IOPL_PAIRED}
    expected |= {(u, "verilator", p) for u in h.DUAL + ["iopl_access"] for p in range(8)}
    expected |= {(u, "MAX equivalence", 0) for u in h.UNITS}
    require(len(actual) == len(set(actual)) and set(actual) == expected, "Exact unique matrix incomplete")
    indexed = {(r["unit"], r["simulator"], r["profile"]): r for r in records if "simulator" in r}
    pairs = 0
    for unit in h.DUAL + ["iopl_access"]:
        for profile in range(8):
            ic = indexed.get((unit, "iverilog", profile))
            if ic:
                compare(ic["trace"], indexed[(unit, "verilator", profile)]["trace"], True)
                pairs += 1
    require(pairs == 58, "Dual pair count mismatch")
    artifacts = {p.relative_to(OUT).as_posix(): h.sha(p) for p in OUT.rglob("*") if p.is_file() and
                 p.suffix in (".py", ".json", ".log", ".sv", ".txt", ".csv") and
                 p.name not in ("receipt.json", "artifacts-manifest.json")}
    guard()
    receipt = dict(status="PASS", units=h.UNITS, profiles=list(range(8)), counts=COUNTS,
        source_sha256=sources, generated_source_sha256=expected_generated,
        verification_source_sha256={"complete_compat.py": h.sha(Path(__file__))},
        leaf_receipts=leaves, code_stimulus_adjustments=adjustments, results=records, failures=[], source_changes=[],
        omitted_icarus=[dict(unit="iopl_access", profile=p, name=h.PROFILE_NAMES[p]) for p in range(1, 7)],
        recovered_completed_units=DONE, launch_sha256=h.sha(OUT / "launch.json"),
        incomplete_attempt=js(OUT / "launch.json")["reported_incomplete_attempt"],
        source_before_after_equal=True, artifacts_manifest_sha256=None,
        scope="Directed 26x8 functional coverage: 202 Icarus +64 Verilator +26 raw MAX pairs; 58 canonical pairs, six unpaired IOPL profiles. Completed v1 results recovered from unchanged terminal PASS logs/finished digests and byte-identical fixtures, with frozen-fit source identity; no initial global receipt invented. IOPL6 host300s timeout remains unaccepted. Original assertions/SV watchdogs preserved; only IOPL host allowance900s and compiler jobs2. Complete streamed hashes are retained with bounded samples, not reconstructed full CSVs. No hardware/historical cycle-accuracy claim.")
    write(OUT / "artifacts-manifest.json", artifacts)
    receipt["artifacts_manifest_sha256"] = h.sha(OUT / "artifacts-manifest.json")
    write(OUT / "receipt.json", receipt)
    print("READY_CHAIN_COMPATIBILITY_COMPLETE_PASS Icarus202 Verilator64 MAX26 dual58 unpaired6", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worker", choices=("iopl", "rest"))
    args = parser.parse_args()
    if args.worker:
        worker(args.worker)
        return
    start()
    commands = js(OUT / "launch.json")["commands"]
    def launch(command):
        label = command[-1]
        begun = time.monotonic()
        with (OUT / (label + "-progress.log")).open("w") as log:
            result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        return dict(job=label, returncode=result.returncode, seconds=time.monotonic()-begun)
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(launch, commands))
    write(OUT / "job-exits.json", results)
    require(all(row["returncode"] == 0 for row in results), "A completion job failed; see preserved progress logs")
    aggregate()


if __name__ == "__main__":
    main()
