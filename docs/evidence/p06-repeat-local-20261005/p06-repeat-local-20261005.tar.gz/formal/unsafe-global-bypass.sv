module miter (
    input [7:0] operation, input raw_allowed, permission,
    input [23:0] context_bits
);
    wire legacy_allowed = raw_allowed && permission;
    always @* begin
        assume(operation == 8'd121 || operation == 8'd128 || permission);
        assert(legacy_allowed == raw_allowed);
        assert((legacy_allowed && (operation == 8'd195)) == (raw_allowed && (operation == 8'd195))); // io_privilege_check
        assert((legacy_allowed && ((operation == 8'd131) || (operation == 8'd132) || (operation == 8'd133) || (operation == 8'd134))) == (raw_allowed && ((operation == 8'd131) || (operation == 8'd132) || (operation == 8'd133) || (operation == 8'd134)))); // io_operation
        assert((legacy_allowed && (operation == 8'd135)) == (raw_allowed && (operation == 8'd135))); // fetch_port
        assert((legacy_allowed && !((context_bits[0] && context_bits[1] && ((legacy_allowed && (operation == 8'd32)) || (legacy_allowed && (operation == 8'd195)) || (legacy_allowed && ((operation == 8'd131) || (operation == 8'd132) || (operation == 8'd133) || (operation == 8'd134)))))) && context_bits[2] && ((operation == 8'd131) || (operation == 8'd132))) == (raw_allowed && !((context_bits[0] && context_bits[1] && ((legacy_allowed && (operation == 8'd32)) || (legacy_allowed && (operation == 8'd195)) || (legacy_allowed && ((operation == 8'd131) || (operation == 8'd132) || (operation == 8'd133) || (operation == 8'd134)))))) && context_bits[2] && ((operation == 8'd131) || (operation == 8'd132)))); // io_read
        assert((legacy_allowed && !((context_bits[0] && context_bits[1] && ((legacy_allowed && (operation == 8'd32)) || (legacy_allowed && (operation == 8'd195)) || (legacy_allowed && ((operation == 8'd131) || (operation == 8'd132) || (operation == 8'd133) || (operation == 8'd134)))))) && context_bits[3] && ((operation == 8'd133) || (operation == 8'd134))) == (raw_allowed && !((context_bits[0] && context_bits[1] && ((legacy_allowed && (operation == 8'd32)) || (legacy_allowed && (operation == 8'd195)) || (legacy_allowed && ((operation == 8'd131) || (operation == 8'd132) || (operation == 8'd133) || (operation == 8'd134)))))) && context_bits[3] && ((operation == 8'd133) || (operation == 8'd134)))); // io_write
        assert((legacy_allowed && (operation == 8'd122)) == (raw_allowed && (operation == 8'd122))); // string_step_source
        assert((legacy_allowed && (operation == 8'd123)) == (raw_allowed && (operation == 8'd123))); // string_step_dest
        assert((legacy_allowed && (operation == 8'd124)) == (raw_allowed && (operation == 8'd124))); // string_count
        assert((legacy_allowed && (operation == 8'd125) && context_bits[4]) == (raw_allowed && (operation == 8'd125) && context_bits[4])); // string_read0
        assert((legacy_allowed && (operation == 8'd126) && context_bits[4]) == (raw_allowed && (operation == 8'd126) && context_bits[4])); // string_read1
        assert((legacy_allowed && (operation == 8'd127) && context_bits[4] && context_bits[5]) == (raw_allowed && (operation == 8'd127) && context_bits[4] && context_bits[5])); // string_store
        assert((legacy_allowed && (operation == 8'd129)) == (raw_allowed && (operation == 8'd129))); // string_read_acc
        assert((legacy_allowed && (operation == 8'd130) && context_bits[5]) == (raw_allowed && (operation == 8'd130) && context_bits[5])); // string_write_acc
        assert((legacy_allowed && (operation == 8'd113)) == (raw_allowed && (operation == 8'd113))); // check_push2
        assert((legacy_allowed && (operation == 8'd114)) == (raw_allowed && (operation == 8'd114))); // check_pop2
        assert((legacy_allowed && (operation == 8'd164)) == (raw_allowed && (operation == 8'd164))); // check_call_frame
        assert((legacy_allowed && (operation == 8'd165)) == (raw_allowed && (operation == 8'd165))); // copy_call_parameters
        assert((legacy_allowed && (operation == 8'd115) && context_bits[6] && !((context_bits[0] && context_bits[7] && context_bits[2] && context_bits[8]))) == (raw_allowed && (operation == 8'd115) && context_bits[6] && !((context_bits[0] && context_bits[7] && context_bits[2] && context_bits[8])))); // add_allocation_sp
        assert((legacy_allowed && (operation >= 8'd78) && (operation <= 8'd85)) == (raw_allowed && (operation >= 8'd78) && (operation <= 8'd85))); // frame_read_gpr
        assert((legacy_allowed && (operation >= 8'd86) && (operation <= 8'd93) && context_bits[5]) == (raw_allowed && (operation >= 8'd86) && (operation <= 8'd93) && context_bits[5])); // frame_write_gpr
        assert((legacy_allowed && (operation == 8'd94) && context_bits[5]) == (raw_allowed && (operation == 8'd94) && context_bits[5])); // save_auxiliary
        assert((legacy_allowed && (operation == 8'd95) && context_bits[9]) == (raw_allowed && (operation == 8'd95) && context_bits[9])); // restore_auxiliary
        assert((legacy_allowed && (operation == 8'd96) && context_bits[5]) == (raw_allowed && (operation == 8'd96) && context_bits[5])); // save_allocation
        assert((legacy_allowed && (operation == 8'd97) && context_bits[2]) == (raw_allowed && (operation == 8'd97) && context_bits[2])); // load_counter
        assert((legacy_allowed && (operation == 8'd98) && context_bits[10] && context_bits[11]) == (raw_allowed && (operation == 8'd98) && context_bits[10] && context_bits[11])); // decrement_counter
        assert((legacy_allowed && context_bits[10] && ((operation == 8'd99) || (operation == 8'd100))) == (raw_allowed && context_bits[10] && ((operation == 8'd99) || (operation == 8'd100)))); // counter_branch
        assert((legacy_allowed && (operation == 8'd101)) == (raw_allowed && (operation == 8'd101))); // check_push8
        assert((legacy_allowed && (operation == 8'd102)) == (raw_allowed && (operation == 8'd102))); // check_pop8
        assert((legacy_allowed && (operation == 8'd103)) == (raw_allowed && (operation == 8'd103))); // begin_stack_cursor
        assert((legacy_allowed && (operation == 8'd112) && context_bits[12]) == (raw_allowed && (operation == 8'd112) && context_bits[12])); // read_stack_cursor
        assert((legacy_allowed && (operation == 8'd104) && context_bits[5]) == (raw_allowed && (operation == 8'd104) && context_bits[5])); // check_stack_word
        assert((legacy_allowed && (operation == 8'd109)) == (raw_allowed && (operation == 8'd109))); // check_rm32
        assert((legacy_allowed && (operation == 8'd111) && context_bits[9] && context_bits[3]) == (raw_allowed && (operation == 8'd111) && context_bits[9] && context_bits[3])); // check_bounds
        assert((legacy_allowed && (operation == 8'd105) && context_bits[5]) == (raw_allowed && (operation == 8'd105) && context_bits[5])); // set_frame_address
        assert((legacy_allowed && (operation == 8'd106) && context_bits[13]) == (raw_allowed && (operation == 8'd106) && context_bits[13])); // read_frame_address
        assert((legacy_allowed && (operation == 8'd107) && context_bits[13]) == (raw_allowed && (operation == 8'd107) && context_bits[13])); // decrement_frame_address
        assert((legacy_allowed && (operation == 8'd108) && context_bits[6] && context_bits[12]) == (raw_allowed && (operation == 8'd108) && context_bits[6] && context_bits[12])); // allocate_stack
        assert((legacy_allowed && (operation == 8'd110)) == (raw_allowed && (operation == 8'd110))); // set_ea_plus2
        assert((legacy_allowed && (operation == 8'd196)) == (raw_allowed && (operation == 8'd196))); // npx_esc_check
        assert((legacy_allowed && (operation == 8'd197)) == (raw_allowed && (operation == 8'd197))); // npx_wait_check
        assert((legacy_allowed && ((operation == 8'd116) || (operation == 8'd118) || (operation == 8'd117)) && context_bits[5] && (!((operation == 8'd118)) || context_bits[2]) && !(context_bits[14])) == (raw_allowed && ((operation == 8'd116) || (operation == 8'd118) || (operation == 8'd117)) && context_bits[5] && (!((operation == 8'd118)) || context_bits[2]) && !(context_bits[14]))); // muldiv_request
        assert((legacy_allowed && (operation == 8'd119) && context_bits[15]) == (raw_allowed && (operation == 8'd119) && context_bits[15])); // write_result_ax
        assert((legacy_allowed && (operation == 8'd120) && context_bits[9] && context_bits[16]) == (raw_allowed && (operation == 8'd120) && context_bits[9] && context_bits[16])); // write_result_dx
        assert((legacy_allowed && (operation == 8'd74) && context_bits[3] && !(context_bits[14])) == (raw_allowed && (operation == 8'd74) && context_bits[3] && !(context_bits[14]))); // adjust_request
        assert((legacy_allowed && (operation == 8'd75)) == (raw_allowed && (operation == 8'd75))); // check_arithmetic
        assert((legacy_allowed && (operation == 8'd76)) == (raw_allowed && (operation == 8'd76))); // read_segment
        assert((legacy_allowed && (operation == 8'd77) && context_bits[5] && !(context_bits[0])) == (raw_allowed && (operation == 8'd77) && context_bits[5] && !(context_bits[0]))); // segment_write
        assert((legacy_allowed && ((operation == 8'd136) || (operation == 8'd137))) == (raw_allowed && ((operation == 8'd136) || (operation == 8'd137)))); // system_table_store
        assert((legacy_allowed && ((operation == 8'd138) || (operation == 8'd139))) == (raw_allowed && ((operation == 8'd138) || (operation == 8'd139)))); // system_table_load
        assert((legacy_allowed && (operation == 8'd140)) == (raw_allowed && (operation == 8'd140))); // system_msw_store
        assert((legacy_allowed && (operation == 8'd141)) == (raw_allowed && (operation == 8'd141))); // system_msw_load
        assert((legacy_allowed && (operation == 8'd142)) == (raw_allowed && (operation == 8'd142))); // system_ldtr_store
        assert((legacy_allowed && (operation == 8'd143)) == (raw_allowed && (operation == 8'd143))); // system_tr_store
        assert((legacy_allowed && (operation == 8'd193)) == (raw_allowed && (operation == 8'd193))); // system_protected_check
        assert((legacy_allowed && (operation == 8'd194)) == (raw_allowed && (operation == 8'd194))); // system_privilege_check
        assert((legacy_allowed && (operation == 8'd146)) == (raw_allowed && (operation == 8'd146))); // system_verify_read
        assert((legacy_allowed && (operation == 8'd147)) == (raw_allowed && (operation == 8'd147))); // system_verify_write
        assert((legacy_allowed && (operation == 8'd166)) == (raw_allowed && (operation == 8'd166))); // arpl_check_operation
        assert((legacy_allowed && (operation == 8'd167) && context_bits[3]) == (raw_allowed && (operation == 8'd167) && context_bits[3])); // arpl_operation
        assert((legacy_allowed && (operation == 8'd168)) == (raw_allowed && (operation == 8'd168))); // clts_operation
        assert((legacy_allowed && (operation == 8'd144)) == (raw_allowed && (operation == 8'd144))); // descriptor_load_ldtr
        assert((legacy_allowed && (operation == 8'd145)) == (raw_allowed && (operation == 8'd145))); // descriptor_load_tr
        assert((legacy_allowed && (operation == 8'd148)) == (raw_allowed && (operation == 8'd148))); // descriptor_load_access
        assert((legacy_allowed && (operation == 8'd149)) == (raw_allowed && (operation == 8'd149))); // descriptor_load_limit
        assert((legacy_allowed && (operation == 8'd77) && context_bits[5] && context_bits[0]) == (raw_allowed && (operation == 8'd77) && context_bits[5] && context_bits[0])); // segment_reload_operation
        assert((legacy_allowed && context_bits[0] && (operation == 8'd150) && context_bits[17] && !(context_bits[18])) == (raw_allowed && context_bits[0] && (operation == 8'd150) && context_bits[17] && !(context_bits[18]))); // jmp_gate_cs_validation_operation
        assert((legacy_allowed && context_bits[0] && (((operation == 8'd150) && !((legacy_allowed && context_bits[0] && (operation == 8'd150) && context_bits[17] && !(context_bits[18])))) || ((operation == 8'd160) && !(context_bits[17])))) == (raw_allowed && context_bits[0] && (((operation == 8'd150) && !((legacy_allowed && context_bits[0] && (operation == 8'd150) && context_bits[17] && !(context_bits[18])))) || ((operation == 8'd160) && !(context_bits[17]))))); // cs_validation_operation
        assert((legacy_allowed && (operation == 8'd159) && context_bits[0]) == (raw_allowed && (operation == 8'd159) && context_bits[0])); // call_gate_validation_operation
        assert((legacy_allowed && (operation == 8'd161)) == (raw_allowed && (operation == 8'd161))); // call_stack_validation_operation
        assert((legacy_allowed && (operation == 8'd162) && context_bits[0]) == (raw_allowed && (operation == 8'd162) && context_bits[0])); // call_ss_validation_operation
        assert((legacy_allowed && (operation == 8'd163)) == (raw_allowed && (operation == 8'd163))); // call_gate_stack_switch_operation
        assert((legacy_allowed && (operation == 8'd156) && context_bits[0]) == (raw_allowed && (operation == 8'd156) && context_bits[0])); // iret_cs_validation_operation
        assert((legacy_allowed && (operation == 8'd157)) == (raw_allowed && (operation == 8'd157))); // iret_outer_frame_operation
        assert((legacy_allowed && (operation == 8'd158) && context_bits[0]) == (raw_allowed && (operation == 8'd158) && context_bits[0])); // iret_ss_validation_operation
        assert((legacy_allowed && (operation == 8'd151)) == (raw_allowed && (operation == 8'd151))); // event_gate_operation
        assert((legacy_allowed && (operation == 8'd152)) == (raw_allowed && (operation == 8'd152))); // event_gate_ip_operation
        assert((legacy_allowed && (operation == 8'd153)) == (raw_allowed && (operation == 8'd153))); // event_gate_cs_operation
        assert((legacy_allowed && (operation == 8'd72)) == (raw_allowed && (operation == 8'd72))); // constant_zero
        assert((legacy_allowed && (operation == 8'd73)) == (raw_allowed && (operation == 8'd73))); // constant_ones
        assert((legacy_allowed && (operation == 8'd71)) == (raw_allowed && (operation == 8'd71))); // dispatch_request
        assert((legacy_allowed && (operation == 8'd64)) == (raw_allowed && (operation == 8'd64))); // read_ea
        assert((legacy_allowed && (operation == 8'd67)) == (raw_allowed && (operation == 8'd67))); // read_target
        assert((legacy_allowed && (operation == 8'd68) && context_bits[2]) == (raw_allowed && (operation == 8'd68) && context_bits[2])); // move_source
        assert((legacy_allowed && (operation == 8'd69) && context_bits[2]) == (raw_allowed && (operation == 8'd69) && context_bits[2])); // set_address
        assert((legacy_allowed && (operation == 8'd70) && context_bits[5]) == (raw_allowed && (operation == 8'd70) && context_bits[5])); // add_base
        assert((legacy_allowed && (operation == 8'd62) && context_bits[3] && !(context_bits[14])) == (raw_allowed && (operation == 8'd62) && context_bits[3] && !(context_bits[14]))); // shift_request
        assert((legacy_allowed && (operation == 8'd63)) == (raw_allowed && (operation == 8'd63))); // count_low
        assert((legacy_allowed && (operation == 8'd172) && context_bits[5]) == (raw_allowed && (operation == 8'd172) && context_bits[5])); // carry_fill_byte
        assert((legacy_allowed && (operation == 8'd58)) == (raw_allowed && (operation == 8'd58))); // direct_flags
        assert((legacy_allowed && (operation == 8'd59) && context_bits[5]) == (raw_allowed && (operation == 8'd59) && context_bits[5])); // sign_extend_byte
        assert((legacy_allowed && (operation == 8'd60) && context_bits[5]) == (raw_allowed && (operation == 8'd60) && context_bits[5])); // sign_fill_word
        assert((legacy_allowed && (operation == 8'd61)) == (raw_allowed && (operation == 8'd61))); // constant_one
        assert((legacy_allowed && (operation == 8'd21) && context_bits[5]) == (raw_allowed && (operation == 8'd21) && context_bits[5])); // push_operation
        assert((legacy_allowed && (operation == 8'd155)) == (raw_allowed && (operation == 8'd155))); // push_event_error
        assert((legacy_allowed && ((operation == 8'd22) || (operation == 8'd43) || (operation == 8'd44) || ((legacy_allowed && (operation == 8'd157)) && (context_bits[0] && context_bits[7] && context_bits[2] && context_bits[8]) && context_bits[19]))) == (raw_allowed && ((operation == 8'd22) || (operation == 8'd43) || (operation == 8'd44) || ((legacy_allowed && (operation == 8'd157)) && (context_bits[0] && context_bits[7] && context_bits[2] && context_bits[8]) && context_bits[19])))); // pop_operation
        assert((legacy_allowed && (operation == 8'd23)) == (raw_allowed && (operation == 8'd23))); // read_ip
        assert((legacy_allowed && (operation == 8'd24) && context_bits[2]) == (raw_allowed && (operation == 8'd24) && context_bits[2])); // target_relative
        assert((legacy_allowed && (operation == 8'd25) && context_bits[5]) == (raw_allowed && (operation == 8'd25) && context_bits[5])); // target_absolute
        assert((legacy_allowed && (operation == 8'd26) && context_bits[20]) == (raw_allowed && (operation == 8'd26) && context_bits[20])); // redirect_operation
        assert((legacy_allowed && (operation == 8'd27) && context_bits[2]) == (raw_allowed && (operation == 8'd27) && context_bits[2])); // adjust_stack
        assert((legacy_allowed && (operation == 8'd28)) == (raw_allowed && (operation == 8'd28))); // count_operation
        assert((legacy_allowed && (operation == 8'd19)) == (raw_allowed && (operation == 8'd19))); // check_operand
        assert((legacy_allowed && (operation == 8'd29)) == (raw_allowed && (operation == 8'd29))); // fetch_byte
        assert((legacy_allowed && (operation == 8'd50)) == (raw_allowed && (operation == 8'd50))); // fetch_byte_tmp1
        assert((legacy_allowed && (operation == 8'd30)) == (raw_allowed && (operation == 8'd30))); // read_flags
        assert((legacy_allowed && (operation == 8'd31) && context_bits[5]) == (raw_allowed && (operation == 8'd31) && context_bits[5])); // restore_flags
        assert((legacy_allowed && (operation == 8'd39)) == (raw_allowed && (operation == 8'd39))); // clear_if_tf
        assert((legacy_allowed && (operation == 8'd36)) == (raw_allowed && (operation == 8'd36))); // read_event_flags
        assert((legacy_allowed && (operation == 8'd37)) == (raw_allowed && (operation == 8'd37))); // read_event_cs
        assert((legacy_allowed && (operation == 8'd38)) == (raw_allowed && (operation == 8'd38))); // read_event_ip
        assert((legacy_allowed && (operation == 8'd40)) == (raw_allowed && (operation == 8'd40))); // vector_ip
        assert((legacy_allowed && (operation == 8'd41)) == (raw_allowed && (operation == 8'd41))); // vector_cs
        assert((legacy_allowed && (operation == 8'd154)) == (raw_allowed && (operation == 8'd154))); // clear_event_flags
        assert((legacy_allowed && (operation == 8'd42) && context_bits[3]) == (raw_allowed && (operation == 8'd42) && context_bits[3])); // commit_context
        assert((legacy_allowed && (operation == 8'd45) && context_bits[21]) == (raw_allowed && (operation == 8'd45) && context_bits[21])); // iret_commit
        assert((legacy_allowed && (operation == 8'd35)) == (raw_allowed && (operation == 8'd35))); // ack_operation
        assert((legacy_allowed && (operation == 8'd34)) == (raw_allowed && (operation == 8'd34))); // request_event
        assert((legacy_allowed && (operation == 8'd33)) == (raw_allowed && (operation == 8'd33))); // halt_operation
        assert((legacy_allowed && (operation == 8'd169)) == (raw_allowed && (operation == 8'd169))); // task_switch_operation
        assert((legacy_allowed && (operation == 8'd170) && context_bits[0] && context_bits[22]) == (raw_allowed && (operation == 8'd170) && context_bits[0] && context_bits[22])); // task_return_operation
        assert((legacy_allowed && ((operation == 8'd1) || (operation == 8'd11))) == (raw_allowed && ((operation == 8'd1) || (operation == 8'd11)))); // fetch_word
        assert((legacy_allowed && ((operation == 8'd12) || (operation == 8'd20))) == (raw_allowed && ((operation == 8'd12) || (operation == 8'd20)))); // fetch_signed_byte
        assert((legacy_allowed && ((operation == 8'd2) || (operation == 8'd54)) && context_bits[5]) == (raw_allowed && ((operation == 8'd2) || (operation == 8'd54)) && context_bits[5])); // move_word
        assert((legacy_allowed && ((operation == 8'd13) || (operation == 8'd53))) == (raw_allowed && ((operation == 8'd13) || (operation == 8'd53)))); // read_destination
        assert((legacy_allowed && ((operation == 8'd55) || (operation == 8'd56) || (operation == 8'd15) || (operation == 8'd16) || ((operation == 8'd17) || (operation == 8'd57))) && context_bits[15] && !(context_bits[23])) == (raw_allowed && ((operation == 8'd55) || (operation == 8'd56) || (operation == 8'd15) || (operation == 8'd16) || ((operation == 8'd17) || (operation == 8'd57))) && context_bits[15] && !(context_bits[23]))); // commit_result
        assert((legacy_allowed && (operation == 8'd14) && context_bits[5] && context_bits[2] && !(context_bits[14])) == (raw_allowed && (operation == 8'd14) && context_bits[5] && context_bits[2] && !(context_bits[14]))); // compute_alu
        assert((legacy_allowed && (operation == 8'd18) && context_bits[14] && context_bits[23]) == (raw_allowed && (operation == 8'd18) && context_bits[14] && context_bits[23])); // commit_flags
    end
endmodule
