import hashlib,io,json,tarfile
from datetime import datetime,timezone
from pathlib import Path
root=Path(__file__).resolve().parents[1]
run=root/'build/p06-repeat-local-allfeatures-20261005-v1'
dest=root/'docs/evidence/p06-repeat-local-fit-stopped-20261005'
dest.mkdir(exist_ok=False)
sha=lambda data:hashlib.sha256(data).hexdigest()
manifest=json.loads((run/'manifest.json').read_text())
assert not (run/'completed.txt').exists()
assert not (run/'work/output_files/PCAT-286.rbf').exists()
payload={'collector.py':Path(__file__).read_bytes()}
changes=[]
for name,h in manifest['source_sha256'].items():
    data=(run/'work'/name).read_bytes()
    if sha(data)!=h:
        assert name=='build_id.v',name
        expected='`define BUILD_DATE "'+datetime.fromisoformat((run/'compile-started.txt').read_text().strip()).strftime('%y%m%d')+'"'
        assert data.decode()==expected
        changes.append({'path':name,'before_sha256':h,'compiled_sha256':sha(data),'scope':'Compile preflow BUILD_DATE only'})
    payload['frozen-source/'+name]=data
for p in run.iterdir():
    if p.is_file():payload['run/'+p.name]=p.read_bytes()
for p in (run/'work/output_files').iterdir():
    if p.is_file() and p.suffix in ('.rpt','.summary'):
        payload['partial-reports/'+p.name]=p.read_bytes()
payload['launch.sh']=(root/'build/run-p06-repeat-local-allfeatures-20261005-v1.sh').read_bytes()
result={'status':'FIT_STOPPED_NO_TIMING_RESULT','frozen_head':manifest['head'],
    'reason':'Superseded by the separately verified 133-strobe decoder extension; user then prioritized main-menu live speed selection before further timing fitting',
    'container':'pcat-p06-repeat-local-20261005-v1','container_cleanup':'docker stop succeeded; --rm removed the owned container; subsequent docker ps returned no active containers',
    'started_utc':(run/'compile-started.txt').read_text().strip(),'archived_utc':datetime.now(timezone.utc).isoformat(),
    'effective_source_changes':changes,'frozen_inputs':len(manifest['source_sha256']),
    'setup_hold':'NOT_MEASURED','rbf':'NOT_GENERATED','full_regression':'USER_DEFERRED'}
def write(name,obj):(dest/name).write_text(json.dumps(obj,indent=2)+'\n',newline='\n')
write('result.json',result);payload['result.json']=(dest/'result.json').read_bytes()
archive=dest/'p06-repeat-local-fit-stopped-20261005.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as t:
    for name,data in payload.items():
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as t:
    assert set(t.getnames())==set(payload)
    for m in t:assert t.extractfile(m).read()==payload[m.name]
write('manifest.json',{'status':'SEALED_STOPPED_FIT','archive':archive.name,'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'members':len(payload),'verification':'Every archived member read back byte-identical before cleanup'})
write('cleanup.json',{'status':'PENDING','targets':[(p.relative_to(root)).as_posix() for p in (run/'work').iterdir() if p.name!='output_files']+['build/seal-p06-stopped-fit-20261005.py'],'removed_logical_bytes':None,'archive_sha256':sha(archive.read_bytes())})
print('STOPPED_FIT_SEALED',len(payload),archive.stat().st_size)
