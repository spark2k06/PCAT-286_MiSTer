/*
 * Copyright (c) 2014, Aleksander Osman
 * All rights reserved.
 * 
 * Fixes and Sound Blaster 16 support (C) 2017-2020 Alexey Melnikov
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 * * Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 * 
 * * Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//
// Adapted for PCXT-EGA from ao486's rtl/soc/sound/sound_dsp.v.
//
// The body below is upstream's, near enough verbatim. Three things differ, all
// marked with a PCXT-EGA comment where they appear: the module name, the
// ce_smp accumulator being hoisted out of its always block so the sample clock
// survives simulation, and the reset latch no longer being gated by
// highspeed_mode. Keeping the divergence that small is deliberate - this file
// is worth being able to re-sync when upstream fixes something.
//
// Nothing was trimmed for the reduced Sound Blaster Pro this core ships,
// because nothing needed to be. Upstream already carries an `sbp` input that
// gates every SB16-only feature: the 41h/42h sample-rate commands, the
// 45h/47h auto-DMA continues, the whole B0h-CFh "new DMA" group, the copyright
// string and the CSP registers all disappear when it is high, and the DSP
// reports version 3.02 instead of 4.05. Tying it high in the wrapper, with
// dma_16_en low, leaves the 16-bit path unreachable for synthesis to prune.
//
// Carving that logic out by hand would have been work in the wrong direction:
// it is interlinked with dma_finished, dma_restart_possible and
// dma_normal_req, so the surgery risks the paths that do matter while saving
// logic the fitter removes anyway.
//
// The ADPCM decoders are kept for the same reason plus one more: 2/3/4-bit
// ADPCM is genuine Sound Blaster Pro functionality that real software uses,
// not an SB16 extension.
//
// See rtl/sound/soundblaster.sv for how this is wired to this core's ISA bus
// and KF8237, neither of which resembles ao486's.
//
module sb_dsp
(
	input             clk,
	input             rst_n,

	input      [27:0] clock_rate,

	input             ce_1us,

	output reg        irq8,
	output reg        irq16,

	//io slave 0-Fh
	input       [3:0] io_address,
	input             io_read,
	output      [7:0] io_readdata,
	input             io_write,
	input       [7:0] io_writedata,

	//dma
	output            dma_req8,
	output            dma_req16,
	input             dma_ack,
	input      [15:0] dma_readdata,
	output     [15:0] dma_writedata,
	input             dma_16_en,
	input             sbp,
	input             sbp_stereo,
	input             sbp_stereo_ff_rst,

	//audio
	output reg [15:0] sample_value_l,
	output reg [15:0] sample_value_r
);

//------------------------------------------------------------------------------

reg io_read_last;
always @(posedge clk) begin
	if (!rst_n)            io_read_last <= 1'b0;
	else if (io_read_last) io_read_last <= 1'b0;
	else                   io_read_last <= io_read;
end
wire io_read_valid = io_read && io_read_last == 1'b0;

//------------------------------------------------------------------------------

assign io_readdata =
	  (io_address == 4'hA) ? read_buffer[15:8] :
	  (io_address == 4'hC) ? {write_buffer_busy, 7'h7F } :
	  (io_address == 4'hE) ? {read_ready, 7'h7F } :
	                         8'hFF;

//------------------------------------------------------------------------------

wire highspeed_start = cmd_high_auto_dma_out || cmd_high_single_dma_out || cmd_high_auto_dma_input || cmd_high_single_dma_input;

reg highspeed_mode;
always @(posedge clk) begin
	if(!rst_n)                              highspeed_mode <= 1'b0;
	else if(sw_reset || highspeed_reset)    highspeed_mode <= 1'b0;
	else if(highspeed_start)                highspeed_mode <= 1'b1;
	else if(dma_finished)                   highspeed_mode <= 1'b0;
end

reg midi_uart_mode;
always @(posedge clk) begin
	if(!rst_n)                  midi_uart_mode <= 1'b0;
	else if(midi_uart_reset)    midi_uart_mode <= 1'b0;
	else if(cmd_midi_uart)      midi_uart_mode <= 1'b1;
end

// PCXT-EGA: upstream gates this latch with ~highspeed_mode. That loses the
// first half of a reset sequence used to abort a high-speed block, and a
// driver that aborts one then hangs.
//
// The only way out of high-speed mode is a DSP reset, and a driver writes
// the usual pair: 1 to 2x6h, then 0, then waits for the AAh that says the
// DSP is back. The write of 1 does leave high-speed mode - it sets
// highspeed_reset below - but with the gate in place it does not reach
// this latch, because highspeed_mode is still set on that very cycle. By
// the time the 0 arrives the mode has cleared, so sw_reset is evaluated
// normally and finds reset_reg still 0. No reset, no AAh, and the driver
// waits for a byte that will never come.
//
// A real card's reset latch is a flip-flop on bit 0 with nothing gating
// it, so it keeps the 1 and answers the 0. CT-VOICE.DRV depends on that:
// it writes 1 to the reset port and compares the reply against AAh.
reg reset_reg;
always @(posedge clk) begin
	if(!rst_n)                                                      reset_reg <= 1'b0;
	else if(io_write && io_address == 4'h6)                         reset_reg <= io_writedata[0];
end

wire highspeed_reset = io_write && io_address == 4'h6 &&  highspeed_mode;
wire midi_uart_reset = io_write && io_address == 4'h6 && ~highspeed_mode &&  midi_uart_mode && reset_reg && ~io_writedata[0];
wire sw_reset        = io_write && io_address == 4'h6 && ~highspeed_mode && ~midi_uart_mode && reset_reg && ~io_writedata[0];

//------------------------------------------------------------------------------ dummy input

wire input_strobe = cmd_direct_input || dma_input;

reg input_direction;
always @(posedge clk) begin
	if(!rst_n)                                                              input_direction <= 1'b0;
	else if(sw_reset)                                                       input_direction <= 1'b0;
	else if(input_strobe && ~(input_direction) && input_sample == 8'd254)   input_direction <= 1'b1;
	else if(input_strobe && input_direction    && input_sample == 8'd1)     input_direction <= 1'b0;
end

reg [7:0] input_sample;
always @(posedge clk) begin
	if(!rst_n)                                  input_sample <= 8'd128;
	else if(sw_reset)                           input_sample <= 8'd128;
	else if(input_strobe && ~(input_direction)) input_sample <= input_sample + 8'd1;
	else if(input_strobe && input_direction)    input_sample <= input_sample - 8'd1;
end

assign dma_writedata = (dma_id_active) ? {dma_id_value,dma_id_value} : {input_sample,input_sample};

//------------------------------------------------------------------------------

localparam [511:0] dsp_cmd_len = {
	2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd2, 2'd1, 2'd0,  2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd0,  // 0xf0
	2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd1,  2'd0, 2'd1, 2'd0, 2'd1,  // 0xe0
	2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd0,  // 0xd0
	2'd3, 2'd3, 2'd3, 2'd3,  2'd3, 2'd3, 2'd3, 2'd3,  2'd3, 2'd3, 2'd3, 2'd3,  2'd3, 2'd3, 2'd3, 2'd3,  // 0xc0
	2'd3, 2'd3, 2'd3, 2'd3,  2'd3, 2'd3, 2'd3, 2'd3,  2'd3, 2'd3, 2'd3, 2'd3,  2'd3, 2'd3, 2'd3, 2'd3,  // 0xb0
	2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd0,  // 0xa0
	2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd0,  // 0x90
	2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd2,  // 0x80
	2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd0,  2'd2, 2'd2, 2'd2, 2'd2,  2'd0, 2'd0, 2'd0, 2'd0,  // 0x70
	2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd0,  // 0x60
	2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd0,  // 0x50
	2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd2,  2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd2, 2'd2, 2'd1,  // 0x40
	2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd1,  2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd0,  // 0x30
	2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd2,  2'd0, 2'd0, 2'd0, 2'd0,  // 0x20
	2'd0, 2'd0, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd0,  2'd2, 2'd2, 2'd2, 2'd2,  2'd0, 2'd0, 2'd0, 2'd1,  // 0x10
	2'd1, 2'd2, 2'd0, 2'd0,  2'd0, 2'd0, 2'd0, 2'd1,  2'd0, 2'd0, 2'd2, 2'd1,  2'd0, 2'd0, 2'd0, 2'd0   // 0x00
};

wire [1:0] cmd_len    = dsp_cmd_len[(io_writedata*2) +:2];

wire       cmd_start  = !write_left && io_write && io_address == 4'hC && (~midi_uart_mode && ~highspeed_mode);
wire       cmd_cont   =  write_left && io_write && io_address == 4'hC;
wire       cmd_finish = cmd_recv_d & ~cmd_recv;

wire [7:0] cmd        = cmd_finish ? cmd_curr : 8'h00;

wire write_buffer_busy = dsp_busy;

reg cmd_recv;
always @(posedge clk) begin
	if(!rst_n)               cmd_recv <= 1'd0;
	else if(sw_reset)        cmd_recv <= 1'd0;
	else if(cmd_start)       cmd_recv <= 1'd1;
	else if(!write_left)     cmd_recv <= 1'd0;
end

reg cmd_recv_d;
always @(posedge clk) begin
	if(!rst_n)               cmd_recv_d <= 1'd0;
	else if(sw_reset)        cmd_recv_d <= 1'd0;
	else                     cmd_recv_d <= cmd_recv;
end

reg [1:0] write_left;
always @(posedge clk) begin
	if(!rst_n)               write_left <= 2'd0;
	else if(sw_reset)        write_left <= 2'd0;
	else if(cmd_start)       write_left <= cmd_len;
	else if(cmd_cont)        write_left <= write_left - 2'd1;
end

reg [7:0] cmd_curr;
always @(posedge clk) begin
	if(!rst_n)               cmd_curr <= 8'd0;
	else if(sw_reset)        cmd_curr <= 8'd0;
	else if(cmd_start)       cmd_curr <= io_writedata;
end

reg [23:0] write_buffer;
always @(posedge clk) begin
	if(!rst_n)               write_buffer <= 24'd0;
	else if(sw_reset)        write_buffer <= 24'd0;
	else if(cmd_start)       write_buffer <= 24'd0;
	else if(cmd_cont)        write_buffer <= { write_buffer[15:0], io_writedata };
end

//------------------------------------------------------------------------------

// Group 0
//wire cmd_csp_cmd3               = cmd == 8'h03;
//wire cmd_csp_set_mode           = cmd == 8'h04;
//wire cmd_csp_set_par            = cmd == 8'h05;
wire cmd_csp_get_ver            = cmd == 8'h08;
//wire cmd_csp_set_reg            = cmd == 8'h0E;
wire cmd_csp_get_reg            = cmd == 8'h0F;

// Group 1: Primary DMA audio
wire cmd_direct_output          = cmd == 8'h10;
wire cmd_single_dma_output      = cmd == 8'h14;
wire cmd_single_2_adpcm_out     = cmd == 8'h16;
wire cmd_single_2_adpcm_out_ref = cmd == 8'h17;
wire cmd_auto_dma_out           = cmd == 8'h1C;
wire cmd_auto_2_adpcm_out_ref   = cmd == 8'h1F;

// Group 2: Recording control
wire cmd_direct_input           = cmd == 8'h20;
wire cmd_single_dma_input       = cmd == 8'h24;
wire cmd_auto_dma_input         = cmd == 8'h2C;

// Group 3: MIDI operations
//wire cmd_midi_polling_input     = cmd == 8'h30;
//wire cmd_midi_interrupt_input   = cmd == 8'h31;
wire cmd_midi_uart              = { cmd[7:2], 2'b00 } == 8'h34;
//wire cmd_midi_output            = cmd == 8'h38;

// Group 4: DSP configuration
wire cmd_set_time_constant      = cmd == 8'h40;
wire cmd_set_sample_rate        =(cmd == 8'h41 || cmd == 8'h42) && ~sbp;
wire cmd_auto_dma_continue      =(cmd == 8'h45 || cmd == 8'h47) && ~sbp;
wire cmd_set_block_size         = cmd == 8'h48;

// Group 5: SBPro RAM playback (DSP v3.xx only)
//wire cmd_ram_playback_stop      = (cmd == 8'h50 && sbp);
//wire cmd_ram_playback_start     = (cmd == 8'h51 && sbp);
//wire cmd_ram_load               = (cmd == 8'h58 && sbp);
//wire cmd_ram_load_and_playback  = (cmd == 8'h59 && sbp);

// Group 6

// Group 7: Secondary DMA audio
wire cmd_single_4_adpcm_out     = cmd == 8'h74;
wire cmd_single_4_adpcm_out_ref = cmd == 8'h75;
wire cmd_single_3_adpcm_out     = cmd == 8'h76;
wire cmd_single_3_adpcm_out_ref = cmd == 8'h77;
wire cmd_auto_4_adpcm_out_ref   = cmd == 8'h7D;
wire cmd_auto_3_adpcm_out_ref   = cmd == 8'h7F;

// Group 8: Silence generation
wire cmd_pause_dac              = cmd == 8'h80;

// Group 9: High-speed transfers
wire cmd_high_auto_dma_out      = (cmd & 8'hF9) == 8'h90; // 90h, 92h, 94h, 96h
wire cmd_high_single_dma_out    = (cmd & 8'hF9) == 8'h91; // 91h, 93h, 95h, 97h
wire cmd_high_auto_dma_input    = (cmd & 8'hF9) == 8'h98; // 98h, 9Ah, 9Ch, 9Eh
wire cmd_high_single_dma_input  = (cmd & 8'hF9) == 8'h99; // 99h, 9Bh, 9Dh, 9Fh

// Group A: SBPro Input Mode Mono/Stereo control (DSP v3.xx only)
//wire cmd_input_mode_mono        = (cmd & 8'hF8) == 8'hA0 && sbp; // A0h-A7h
//wire cmd_input_mode_stereo      = (cmd & 8'hF8) == 8'hA8 && sbp; // A8h-AFh

// Group B: SB16 16-bit DMA mode (DSP v4.xx only)
// Group C: SB16  8-bit DMA mode (DSP v4.xx only)
wire cmd_new_dma                =(cmd[7:4] == 4'hB || cmd[7:4] == 4'hC) && ~sbp;

// Group D: Miscellaneous
wire cmd_dma_pause_start        = cmd == 8'hD0 || (cmd == 8'hD5 && ~sbp);
wire cmd_speaker_on             = cmd == 8'hD1;
wire cmd_speaker_off            = cmd == 8'hD3;
wire cmd_dma_pause_end          = cmd == 8'hD4 || (cmd == 8'hD6 && ~sbp);
wire cmd_speaker_status         = cmd == 8'hD8;
wire cmd_auto_dma_exit          = cmd == 8'hDA || (cmd == 8'hD9 && ~sbp);

// Group E: DSP identification
wire cmd_dsp_identification     = cmd == 8'hE0;
wire cmd_dsp_version            = cmd == 8'hE1;
wire cmd_dma_id                 = cmd == 8'hE2;
wire cmd_copyright              =(cmd == 8'hE3 && ~sbp);
wire cmd_test_register_write    = cmd == 8'hE4;
wire cmd_test_register_read     = cmd == 8'hE8;

// Group F: Auxiliary commands
wire cmd_trigger_irq8           = cmd == 8'hF2;
wire cmd_trigger_irq16          =(cmd == 8'hF3 && ~sbp);
wire cmd_dsp_ram_test           = cmd == 8'hF8;
wire cmd_f9_test                = cmd == 8'hF9;

wire cmd_new_single_output      = cmd_new_dma & ~cmd[2] & ~cmd[3];
wire cmd_new_auto_output        = cmd_new_dma &  cmd[2] & ~cmd[3];
wire cmd_new_single_input       = cmd_new_dma & ~cmd[2] &  cmd[3];
wire cmd_new_auto_input         = cmd_new_dma &  cmd[2] &  cmd[3];
wire cmd_new_block_size         = cmd_new_dma;

/*
 Cx/Bx - Program 8/16-bit DMA mode digitized sound I/O
         Command sequence:  Command, Mode, Lo(Length-1), Hi(Length-1)
         Command:
         ╔════╤════╤════╤══════╤═══════╤══════╤═══════╤════╗
         ║ D7 │ D6 │ D5 │  D4  │  D3   │  D2  │  D1   │ D0 ║
         ╠════╪════╪════╪══════╪═══════╪══════╪═══════╪════╣
         ║  1 │  * │  * │ 16/8 │  A/D  │  A/I │ FIFO  │  0 ║
         ╚════╧════╧════┼──────┼───────┼──────┼───────┼════╝
                        │ 0=8  │ 0=D/A │ 0=SC │ 0=off │
                        │ 1=16 │ 1=A/D │ 1=AI │ 1=on  │
                        └──────┴───────┴──────┴───────┘
         Common commands:
           C8/B8 - single-cycle input
           C0/B0 - single-cycle output
           CE/BE - auto-initialized input
           C6/B6 - auto-initialized output

         Mode:
         ╔════╤════╤══════════╤════════════╤════╤════╤════╤════╗
         ║ D7 │ D6 │    D5    │     D4     │ D3 │ D2 │ D1 │ D0 ║
         ╠════╪════╪══════════╪════════════╪════╪════╪════╪════╣
         ║  0 │  0 │  Stereo  │   Signed   │  0 │  0 │  0 │  0 ║
         ╚════╧════┼──────────┼────────────┼════╧════╧════╧════╝
                   │ 0=Mono   │ 0=unsigned │
                   │ 1=Stereo │ 1=signed   │
                   └──────────┴────────────┘
*/

//------------------------------------------------------------------------------ reply

wire read_ready = ~midi_uart_mode && (read_buffer_size || copy_cnt);

wire read_reply = io_read_valid && io_address == 4'hA;

reg [1:0] read_buffer_size;
always @(posedge clk) begin
	if(!rst_n)                              read_buffer_size <= 2'd0;
	else if(sw_reset)                       read_buffer_size <= 2'd1;
	else if(cmd_dsp_version)                read_buffer_size <= 2'd2;
	else if(cmd_direct_input)               read_buffer_size <= 2'd1;
	else if(cmd_speaker_status)             read_buffer_size <= 2'd1;
	else if(cmd_dsp_identification)         read_buffer_size <= 2'd1;
	else if(cmd_dsp_ram_test)               read_buffer_size <= 2'd1;
	else if(cmd_test_register_read)         read_buffer_size <= 2'd1;
	else if(cmd_csp_get_ver & ~sbp)         read_buffer_size <= 2'd1;
	else if(cmd_csp_get_reg & ~sbp)         read_buffer_size <= 2'd1;
	else if(cmd_f9_test & ~sbp)             read_buffer_size <= 2'd1;
	else if(cmd)                            read_buffer_size <= 2'd0; // all other commands

	else if(read_reply && read_buffer_size) read_buffer_size <= read_buffer_size - 2'd1;
end

localparam COPY_STR_SB16 = 368'h434F505952494748542028432920435245415449564520544543484E4F4C4F4759204C54442C20313939322E0000;
localparam COPY_CNT_SB16 = 6'd45;

reg [5:0] copy_cnt;
always @(posedge clk) begin
	if(!rst_n | sw_reset)                   copy_cnt <= 6'd0;
	else if(cmd_copyright)                  copy_cnt <= COPY_CNT_SB16;
	else if(cmd)                            copy_cnt <= 6'd0;
	else if(read_reply && copy_cnt)         copy_cnt <= copy_cnt - 1'd1;
end

reg [15:0] read_buffer;
always @(posedge clk) begin
	if(!rst_n)                              read_buffer <= 16'd0;
	else if(sw_reset)                       read_buffer <= { 8'hAA, 8'hAA };
	// PCXT-EGA: 3.00, not upstream's 3.02. Those are different cards: 3.02 is a
	// Sound Blaster Pro 2, which carries an OPL3, and 3.00 is the Pro 1 with a
	// single OPL2 behind a CT1345 mixer - which is what this core actually is.
	// ao486 answers 3.02 honestly because it has the OPL3; here it would be a
	// claim to hardware that is not present, and drivers pick their setup path
	// by this number. CT-VOICE.DRV ships a separate build per card for exactly
	// that reason, and the one that matches this core is the Pro 1 build.
	else if(cmd_dsp_version)                read_buffer <= sbp ? { 8'h03, 8'h00 } : { 8'h04, 8'h05 }; // DSP Version: sbp=v3.00 (Pro 1), sb16=v4.05
	else if(cmd_direct_input)               read_buffer <= { input_sample, input_sample };
	else if(cmd_speaker_status)             read_buffer <= (speaker_on)? 16'hFFFF : 16'h0000;
	else if(cmd_dsp_identification)         read_buffer <= { ~write_buffer[7:0], ~write_buffer[7:0] };
	else if(cmd_dsp_ram_test)               read_buffer <= { 8'h00, 8'h00 };
	else if(cmd_test_register_read)         read_buffer <= { test_register, test_register };
	else if(cmd_copyright)                  read_buffer <= 16'd0;
	else if(cmd_csp_get_ver & ~sbp)         read_buffer <= 16'hFFFF;
	else if(cmd_csp_get_reg & ~sbp)         read_buffer <= (write_buffer[7:0] == 8'h09) ? 16'hF8F8 : 16'hFFFF;
	else if(cmd_f9_test & ~sbp)             read_buffer <= (write_buffer[7:0] == 8'h0E) ? 16'hFFFF :
	                                                       (write_buffer[7:0] == 8'h0F) ? 16'h0707 :
	                                                       (write_buffer[7:0] == 8'h37) ? 16'h3838 : 16'h0000;	

	else if(read_reply && read_buffer_size) read_buffer[15:8] <= read_buffer[7:0]; // repeat last byte
	else if(copy_cnt)                       read_buffer[15:8] <= COPY_STR_SB16[(copy_cnt*8) +:8];
end

//------------------------------------------------------------------------------ Command E2: Firmware Validation
// Performs challenge/response authentication using DSP ID registers

reg [7:0] dma_id_value;
always @(posedge clk) begin
	if(!rst_n)          dma_id_value <= 8'hAA;
	else if(sw_reset)   dma_id_value <= 8'hAA;
	else if(cmd_dma_id) dma_id_value <= dma_id_value + (write_buffer[7:0] ^ dma_xor_value);
end

reg [7:0] dma_xor_value;
always @(posedge clk) begin
	if(!rst_n)          dma_xor_value <= 8'h96;
	else if(sw_reset)   dma_xor_value <= 8'h96;
	else if(cmd_dma_id) dma_xor_value <= {dma_xor_value[1:0],dma_xor_value[7:2]};
end

reg dma_id_active;
always @(posedge clk) begin
	if(!rst_n)          dma_id_active <= 1'b0;
	else if(sw_reset)   dma_id_active <= 1'b0;
	else if(cmd_dma_id) dma_id_active <= 1'b1;
	else if(dma_ack_w)  dma_id_active <= 1'b0;
end

//------------------------------------------------------------------------------

reg [7:0] test_register;
always @(posedge clk) begin
	if(!rst_n)                          test_register <= 8'd0;
	else if(cmd_test_register_write)    test_register <= write_buffer[7:0];
end

reg speaker_on; // not affecting actual output on DSP 4.xx
always @(posedge clk) begin
	if(!rst_n)                  speaker_on <= 1'b0;
	else if(sw_reset)           speaker_on <= 1'b0;
	else if(cmd_speaker_on)     speaker_on <= 1'b1;
	else if(cmd_speaker_off)    speaker_on <= 1'b0;
end

//reg input_stereo;
//always @(posedge clk) begin
//	if(!rst_n)                        input_stereo <= 1'b0;
//	else if(sw_reset)                 input_stereo <= 1'b0;
//	else if(cmd_input_mode_stereo)    input_stereo <= 1'b1;
//	else if(cmd_input_mode_mono)      input_stereo <= 1'b0;
//end

reg [15:0] block_size;
always @(posedge clk) begin
	if(!rst_n)                                       block_size <= 16'h07ff;
	else if(sw_reset)                                block_size <= 16'd0;
	else if(cmd_set_block_size | cmd_new_block_size) block_size <= { write_buffer[7:0], write_buffer[15:8] };
end

//------------------------------------------------------------------------------ pause dac

reg pause_active; // mode_silence
always @(posedge clk) begin
	if(!rst_n)                pause_active <= 1'b0;
	else if(sw_reset)         pause_active <= 1'b0;
	else if(pause_finished)   pause_active <= 1'b0;
	else if(cmd_pause_dac)    pause_active <= 1'b1;
end

wire pause_decrement = pause_active && timer_0_isr;
wire pause_finished  = pause_decrement && !len_left;

//------------------------------------------------------------------------------ sample clk

// PCXT-EGA: `sum` was declared inside this always block upstream. It is
// hoisted here so the sample clock can be simulated: Verilator treats a
// block-local reg carrying an initialiser as automatic and re-zeroes it every
// clock, so the accumulator never reaches clock_rate and ce_smp never fires -
// which silences the DSP entirely under simulation. Quartus follows
// Verilog-2001 and makes it static, so this changes nothing in hardware.
reg [27:0] ce_smp_sum = 0;
reg ce_smp;
always @(posedge clk) begin
	if(!rst_n) begin
		ce_smp_sum = 0;
	end else begin
		ce_smp = 0;
		ce_smp_sum = ce_smp_sum + clk_smp;
		if(ce_smp_sum >= clock_rate) begin
			ce_smp_sum = ce_smp_sum - clock_rate;
			ce_smp = 1;
		end
	end
end

reg [27:0] clk_smp;
always @(posedge clk) begin
	if(!rst_n || sw_reset || cmd_set_time_constant) clk_smp <= 1000000; // 1 MHz
	else if(cmd_set_sample_rate)                    clk_smp <= write_buffer[15:0];
end

reg sample_rate_active;
always @(posedge clk) begin
	if(!rst_n || sw_reset || cmd_set_time_constant) sample_rate_active <= 1'b0;
	else if(cmd_set_sample_rate)                    sample_rate_active <= 1'b1;
end

//------------------------------------------------------------------------------ irq

always @(posedge clk) begin
	if(!rst_n || sw_reset)                                                        irq8 <= 1'b0;
	else if((dma_finished || pause_finished || dma_auto_restart) && ~dma_16_req)  irq8 <= 1'b1;
	else if(trg_irq8)                                                             irq8 <= 1'b1;
	else if(io_read_valid && io_address == 4'hE)                                  irq8 <= 1'b0;
end

// timeout for some games
reg trg_irq8;
always @(posedge clk) begin
	reg [7:0] cnt;
	
	trg_irq8 <= &cnt;
	if(cnt) cnt <= cnt + 1'd1;

	if(!rst_n || sw_reset)                               cnt <= 8'b0;
	else if(cmd_trigger_irq8)                            cnt <= 8'b1;
	else if(io_read_valid && io_address == 4'hE && irq8) cnt <= 8'b0;
end

always @(posedge clk) begin
	if(!rst_n || sw_reset)                                                        irq16 <= 1'b0;
	else if((dma_finished || pause_finished || dma_auto_restart) && dma_16_req)   irq16 <= 1'b1;
	else if(cmd_trigger_irq16)                                                    irq16 <= 1'b1;
	else if(io_read_valid && io_address == 4'hF)                                  irq16 <= 1'b0;
end

//------------------------------------------------------------------------------ dma commands

localparam [4:0] S_IDLE                 = 5'd0;
localparam [4:0] S_OUT_SINGLE_8_BIT     = 5'd1;
localparam [4:0] S_OUT_SINGLE_4_BIT     = 5'd2;
localparam [4:0] S_OUT_SINGLE_3_BIT     = 5'd3;
localparam [4:0] S_OUT_SINGLE_2_BIT     = 5'd4;
localparam [4:0] S_OUT_SINGLE_4_BIT_REF = 5'd5;
localparam [4:0] S_OUT_SINGLE_3_BIT_REF = 5'd6;
localparam [4:0] S_OUT_SINGLE_2_BIT_REF = 5'd7;
localparam [4:0] S_OUT_AUTO_8_BIT       = 5'd8;
localparam [4:0] S_OUT_AUTO_4_BIT_REF   = 5'd9;
localparam [4:0] S_OUT_AUTO_3_BIT_REF   = 5'd10;
localparam [4:0] S_OUT_AUTO_2_BIT_REF   = 5'd11;
localparam [4:0] S_IN_SINGLE            = 5'd12;
localparam [4:0] S_IN_AUTO              = 5'd13;
localparam [4:0] S_OUT_SINGLE_HIGH      = 5'd14;
localparam [4:0] S_OUT_AUTO_HIGH        = 5'd15;
localparam [4:0] S_IN_SINGLE_HIGH       = 5'd16;
localparam [4:0] S_IN_AUTO_HIGH         = 5'd17;
localparam [4:0] S_OUT_SINGLE_NEW       = 5'd18;
localparam [4:0] S_OUT_AUTO_NEW         = 5'd19;
localparam [4:0] S_IN_SINGLE_NEW        = 5'd20;
localparam [4:0] S_IN_AUTO_NEW          = 5'd21;

reg [4:0] dma_command;

always @(posedge clk) begin
	if(!rst_n)                                  dma_command <= S_IDLE;
	else if(sw_reset)                           dma_command <= S_IDLE;

	else if(cmd_single_dma_output)              dma_command <= S_OUT_SINGLE_8_BIT;
	else if(cmd_single_4_adpcm_out)             dma_command <= S_OUT_SINGLE_4_BIT;
	else if(cmd_single_3_adpcm_out)             dma_command <= S_OUT_SINGLE_3_BIT;
	else if(cmd_single_2_adpcm_out)             dma_command <= S_OUT_SINGLE_2_BIT;

	else if(cmd_single_4_adpcm_out_ref)         dma_command <= S_OUT_SINGLE_4_BIT_REF;
	else if(cmd_single_3_adpcm_out_ref)         dma_command <= S_OUT_SINGLE_3_BIT_REF;
	else if(cmd_single_2_adpcm_out_ref)         dma_command <= S_OUT_SINGLE_2_BIT_REF;

	else if(cmd_auto_dma_out)                   dma_command <= S_OUT_AUTO_8_BIT;
	else if(cmd_auto_4_adpcm_out_ref)           dma_command <= S_OUT_AUTO_4_BIT_REF;
	else if(cmd_auto_3_adpcm_out_ref)           dma_command <= S_OUT_AUTO_3_BIT_REF;
	else if(cmd_auto_2_adpcm_out_ref)           dma_command <= S_OUT_AUTO_2_BIT_REF;

	else if(cmd_single_dma_input)               dma_command <= S_IN_SINGLE;
	else if(cmd_auto_dma_input)                 dma_command <= S_IN_AUTO;

	else if(cmd_high_single_dma_out)            dma_command <= S_OUT_SINGLE_HIGH;
	else if(cmd_high_auto_dma_out)              dma_command <= S_OUT_AUTO_HIGH;

	else if(cmd_high_single_dma_input)          dma_command <= S_IN_SINGLE_HIGH;
	else if(cmd_high_auto_dma_input)            dma_command <= S_IN_AUTO_HIGH;

	else if(cmd_new_single_output)              dma_command <= S_OUT_SINGLE_NEW;
	else if(cmd_new_auto_output)                dma_command <= S_OUT_AUTO_NEW;
	else if(cmd_new_single_input)               dma_command <= S_IN_SINGLE_NEW;
	else if(cmd_new_auto_input)                 dma_command <= S_IN_AUTO_NEW;

	else if(dma_single_start || dma_auto_start) dma_command <= S_IDLE;
end

//------------------------------------------------------------------------------ dma

wire dma_single_start = dma_restart_possible && (
	dma_command == S_OUT_SINGLE_8_BIT || dma_command == S_OUT_SINGLE_4_BIT     || dma_command == S_OUT_SINGLE_3_BIT     || dma_command == S_OUT_SINGLE_2_BIT     ||
	                                     dma_command == S_OUT_SINGLE_4_BIT_REF || dma_command == S_OUT_SINGLE_3_BIT_REF || dma_command == S_OUT_SINGLE_2_BIT_REF ||
	dma_command == S_IN_SINGLE ||
	dma_command == S_OUT_SINGLE_HIGH || dma_command == S_IN_SINGLE_HIGH ||
	dma_command == S_OUT_SINGLE_NEW  || dma_command == S_IN_SINGLE_NEW
);

wire dma_auto_start = dma_restart_possible && (
	dma_command == S_OUT_AUTO_8_BIT || dma_command == S_OUT_AUTO_4_BIT_REF || dma_command == S_OUT_AUTO_3_BIT_REF || dma_command == S_OUT_AUTO_2_BIT_REF ||
	dma_command == S_IN_AUTO ||
	dma_command == S_OUT_AUTO_HIGH || dma_command == S_IN_AUTO_HIGH ||
	dma_command == S_OUT_AUTO_NEW  || dma_command == S_IN_AUTO_NEW
);

wire dma_new_start = dma_restart_possible && (
	dma_command == S_OUT_SINGLE_NEW  || dma_command == S_IN_SINGLE_NEW ||
	dma_command == S_OUT_AUTO_NEW  || dma_command == S_IN_AUTO_NEW
);

reg dma_normal_req;
always @(posedge clk) begin
	if(!rst_n)                                                               dma_normal_req <= 1'b0;
	else if(sw_reset || highspeed_reset)                                     dma_normal_req <= 1'b0;
	else if(dma_valid)                                                       dma_normal_req <= 1'b0;
	else if(dma_in_progress && timer_0_isr && !adpcm_wait && ~pause_active)  dma_normal_req <= 1'b1;
end

wire dma_valid  = dma_normal_req && dma_ack_w && ~dma_id_active;
wire dma_output = ~dma_is_input && dma_valid;
wire dma_input  =  dma_is_input && dma_valid;

wire dma_finished = dma_in_progress && ~dma_autoinit && !len_left && (
	(adpcm_type == ADPCM_NONE && (dma_valid|dma_ack_stereo)) ||
	(adpcm_type != ADPCM_NONE && adpcm_output && adpcm_wait == 2'd1)
);

wire dma_auto_restart = dma_in_progress && dma_autoinit && !len_left && (
	(adpcm_type == ADPCM_NONE && (dma_valid|dma_ack_stereo)) ||
	(adpcm_type != ADPCM_NONE && adpcm_output && adpcm_wait == 2'd1)
);

// After receiving a new DMA command the DSP will finish transferring any bytes for the current output command,
// or if DMA has been paused then a new command can start immediately.
wire dma_restart_possible = ~tr0 || (
	(!adpcm_wait || (adpcm_type != ADPCM_NONE && adpcm_wait == 2'd1)) && 
	(~dma_in_progress || dma_auto_restart)
);

reg [15:0] len_left;
always @(posedge clk) begin
	if(!rst_n)                                                      len_left <= 16'd0;
	else if(sw_reset || highspeed_reset)                            len_left <= 16'd0;
	else if((dma_single_start && ~highspeed_mode) || cmd_pause_dac) len_left <= { write_buffer[7:0], write_buffer[15:8] };
	else if(dma_auto_start || dma_auto_restart || highspeed_start)  len_left <= { block_size };
	else if((dma_valid|dma_ack_stereo) && len_left > 16'd0)         len_left <= len_left - 1'd1;
	else if(pause_decrement && len_left > 16'd0)                    len_left <= len_left - 1'd1;
	else if(pause_finished || dma_finished)                         len_left <= 16'd0;
end

reg dma_in_progress;
always @(posedge clk) begin
	if(!rst_n)                                                       dma_in_progress <= 1'b0;
	else if(sw_reset || highspeed_reset)                             dma_in_progress <= 1'b0;
	else if(cmd_dma_pause_start || dma_finished)                     dma_in_progress <= 1'b0;
	else if(cmd_dma_pause_end || dma_single_start || dma_auto_start) dma_in_progress <= 1'b1;
end

reg dma_is_input;
always @(posedge clk) begin
	if(!rst_n)                                                                dma_is_input <= 1'b0;
	else if(sw_reset || highspeed_reset)                                      dma_is_input <= 1'b0;
	else if((dma_single_start || dma_auto_start) 
	 && (   dma_command == S_IN_SINGLE      || dma_command == S_IN_AUTO
	     || dma_command == S_IN_SINGLE_HIGH || dma_command == S_IN_AUTO_HIGH
	     || dma_command == S_IN_SINGLE_NEW  || dma_command == S_IN_AUTO_NEW)) dma_is_input <= 1'b1;
	else if(dma_single_start || dma_auto_start)                               dma_is_input <= 1'b0;
end

reg dma_autoinit;
always @(posedge clk) begin
	if(!rst_n)                           dma_autoinit <= 1'b0;
	else if(sw_reset || highspeed_reset) dma_autoinit <= 1'b0;
	else if(dma_single_start)            dma_autoinit <= 1'b0;
	else if(dma_auto_start)              dma_autoinit <= 1'b1;
	else if(cmd_auto_dma_exit)           dma_autoinit <= 1'b0;
	else if(cmd_auto_dma_continue)       dma_autoinit <= 1'b1;
end

//------------------------------------------------------------------------------ 8051 Timer 0 in Mode 2

// 8051 Timer 0 in Mode 2
// th0 = timer 0 reload value
// tl0 = timer 0 count value (incrementing)
// tf0 = timer 0 overflow pulse
// tr0 = timer 0 run enable
// et0 = timer 0 interrupt enable

localparam COLD_BOOT_TIME_CONSTANT = 8'h9C;

reg [7:0] time_constant;
always @(posedge clk) begin
	if(!rst_n)                     time_constant <= COLD_BOOT_TIME_CONSTANT; // cold boot
	else if(sw_reset)              time_constant <= COLD_BOOT_TIME_CONSTANT; // cold boot
	else if(cmd_set_time_constant) time_constant <= write_buffer[7:0];
end

reg [7:0] th0;
always @(posedge clk) begin
	if(!rst_n)                     th0 <= COLD_BOOT_TIME_CONSTANT; // cold boot
	else if(sw_reset)              th0 <= COLD_BOOT_TIME_CONSTANT; // cold boot
	else if(highspeed_reset)       th0 <= time_constant;           // warm boot
	else if(cmd_set_time_constant) th0 <= write_buffer[7:0];
end

reg [7:0] tl0;
always @(posedge clk) begin
	if(!rst_n)                     tl0 <= COLD_BOOT_TIME_CONSTANT; // cold boot
	else if(sw_reset)              tl0 <= COLD_BOOT_TIME_CONSTANT; // cold boot
	else if(highspeed_reset)       tl0 <= time_constant;           // warm boot
	else if(sample_rate_active)    tl0 <= 8'hFF;                   // SB16 sample rate
	else if(cmd_set_time_constant) tl0 <= write_buffer[7:0];
	else if(tf0)                   tl0 <= th0;                     // timer 0 reload on overflow
	else if(timer_0_tick)          tl0 <= tl0 + 1'd1;              // timer 0 increment
end

wire timer_0_tick = ce_smp && tr0;
wire tf0 = timer_0_tick && tl0 == 8'hFF; // timer 0 overflow
wire timer_0_isr = tf0 && et0; // assume: ea = 1 (global interrupt enable)

reg tr0;
always @(posedge clk) begin
	if(!rst_n)                                                                        tr0 <= 1'b0;
	else if(sw_reset || highspeed_reset)                                              tr0 <= 1'b0;
	else if(cmd_dma_pause_start || pause_finished || dma_finished)                    tr0 <= 1'b0;
	else if(cmd_dma_pause_end || cmd_pause_dac || dma_single_start || dma_auto_start) tr0 <= 1'b1;
end

reg et0;
always @(posedge clk) begin
	if(!rst_n)                                                                        et0 <= 1'b0;
	else if(sw_reset || highspeed_reset)                                              et0 <= 1'b0;
	else if(cmd_dma_pause_start || pause_finished || dma_finished)                    et0 <= 1'b0;
	else if(cmd_dma_pause_end || cmd_pause_dac || dma_single_start || dma_auto_start) et0 <= 1'b1;
end

//------------------------------------------------------------------------------ dsp busy

// The DSP busy flag is asserted when:
// - A DSP command is being processed
// - A DSP interrupt service routine is active (e.g., handling DMA or pause DAC)
// - High-speed mode is active
// - MIDI UART mode is active
// - SB16 is idle (the SB16 dsp_busy flag toggles while waiting for new commands)
wire dsp_busy = (dsp_busy_cnt > 0) || highspeed_mode || midi_uart_mode || (~sbp && dsp_busy_sb16_idle);

// Games, such as The Secret to Monkey Island, have a compiled in CT-VOICE driver
// that communicates to the DSP. When the driver knows a sound is currently playing,
// it adds an additional step before starting to play the new sound. The driver will poll
// the write status port (2xCh) until it sees a busy flag, and if it sees it then it sends
// the pause command first. If the driver never sees a busy status it will eventually
// timeout polling and skip sending the pause command.
//
// Without setting the busy flag a pause command is not sent and the game becomes
// out of sync with the number of bytes it expects to transfer and locks up.
//
// To replicate the expected behavior the write port status will return busy when the
// register is read the first time following a DMA request, and on subsequent reads it will
// return idle.
localparam S_DSP_BUSY_DURATION = 2'd3; // 2 us up to 3 us should be detectable when polling on a 486 at 15 MHz

wire dsp_busy_start = cmd_start || dma_req || pause_decrement;

reg [1:0] dsp_busy_cnt;
always @(posedge clk) begin
	if(!rst_n)                            dsp_busy_cnt <= 0;
	else if(sw_reset)                     dsp_busy_cnt <= 0;

	// Go busy for S_DSP_BUSY_DURATION on dsp_busy_start
	else if(dsp_busy_start)               dsp_busy_cnt <= S_DSP_BUSY_DURATION;

	// Go back to idle after countdown reaches 0
	else if(ce_1us && (dsp_busy_cnt > 0)) dsp_busy_cnt <= dsp_busy_cnt - 1'd1;
end

// Real SB16 DSP Idle: dsp_busy HIGH for 0.5 us, LOW for 3.5 us per 4 us cycle (250 kHz)
reg [1:0] dsp_busy_sb16_idle_cnt;
always @(posedge clk) begin
	if(!rst_n)       dsp_busy_sb16_idle_cnt <= 2'd0;
	else if(ce_1us)  dsp_busy_sb16_idle_cnt <= dsp_busy_sb16_idle_cnt + 1'd1;
end
wire dsp_busy_sb16_idle = (dsp_busy_sb16_idle_cnt == 0);

//------------------------------------------------------------------------------

reg [3:0] dma_format; // 16/8, sbp_stereo/mono, sb16_stereo/mono, signed/unsigned
always @(posedge clk) begin
	if(!rst_n || sw_reset)                     dma_format <= 0;
	else if(dma_new_start)                     dma_format <= {cmd_curr[4], 1'b0, write_buffer[21:20]};
	else if(dma_single_start | dma_auto_start) dma_format <= {1'b0, sbp_stereo, 1'b0, 1'b0};
end

reg sbp_lr; // this flip-flop is actually inside the mixer IC and not the DSP
always @(posedge clk) begin
	if(!rst_n || sbp_stereo_ff_rst) sbp_lr <= 1'b1; // first sample to right channel compensates for SBPro PCB L/R swap
	else if(sample_output)          sbp_lr <= ~sbp_lr;
end

wire   dma_16_req = dma_format[3];
wire   dma_16_use = dma_16_req & dma_16_en;

wire   dma_req   = dma_id_active || dma_normal_req;
assign dma_req8  = dma_req & ~dma_16_use;
assign dma_req16 = dma_req &  dma_16_use;

wire   dma_ack_w      = dma_ack_f & (~dma_format[1] |  sample_lr);
wire   dma_ack_stereo = dma_ack_f & ( dma_format[1] & ~sample_lr);

reg        sample_output;
reg        sample_lr;
reg [15:0] sample_dma[2];
always @(posedge clk) begin
	sample_lr <= dma_req & (sample_lr ^ (dma_ack_f & dma_format[1]));
	sample_output <= dma_output;

	if(dma_ack) begin
		if(~dma_16_req)    sample_dma[sample_lr]       <= {dma_readdata[7:0],8'd0};
		else if(dma_16_en) sample_dma[sample_lr]       <= dma_readdata;
		else if(~dma_hcnt) sample_dma[sample_lr][7:0]  <= dma_readdata[7:0];
		else               sample_dma[sample_lr][15:8] <= dma_readdata[7:0];
	end
end

wire dma_ack_f = dma_ack & (dma_hcnt | dma_16_en | ~dma_16_req);
reg  dma_hcnt;
always @(posedge clk) dma_hcnt <= dma_req & (dma_hcnt ^ dma_ack);

//------------------------------------------------------------------------------ adpcm

localparam [1:0] ADPCM_NONE = 2'd0;
localparam [1:0] ADPCM_4BIT = 2'd1;
localparam [1:0] ADPCM_3BIT = 2'd2;
localparam [1:0] ADPCM_2BIT = 2'd3;

wire adpcm_reference_start = 
	(dma_single_start || dma_auto_start) && (
	dma_command == S_OUT_SINGLE_2_BIT_REF || dma_command == S_OUT_SINGLE_3_BIT_REF || dma_command == S_OUT_SINGLE_4_BIT_REF ||
	dma_command == S_OUT_AUTO_2_BIT_REF   || dma_command == S_OUT_AUTO_3_BIT_REF   || dma_command == S_OUT_AUTO_4_BIT_REF
);

wire adpcm_output = timer_0_isr && adpcm_wait;

reg adpcm_reference_awaiting;
always @(posedge clk) begin
	if(!rst_n)                                      adpcm_reference_awaiting <= 1'b0;
	else if(sw_reset)                               adpcm_reference_awaiting <= 1'b0;
	else if(adpcm_reference_start)                  adpcm_reference_awaiting <= 1'b1;
	else if(dma_single_start || dma_auto_start)     adpcm_reference_awaiting <= 1'b0;
	else if(adpcm_reference_awaiting && dma_output) adpcm_reference_awaiting <= 1'b0;
	else if(dma_finished)                           adpcm_reference_awaiting <= 1'b0;
end

reg adpcm_reference_output;
always @(posedge clk) begin
	if(!rst_n)          adpcm_reference_output <= 1'b0;
	else                adpcm_reference_output <= adpcm_reference_awaiting;
end

reg [1:0] adpcm_wait;
always @(posedge clk) begin
	if(!rst_n)                                      adpcm_wait <= 2'd0;
	else if(sw_reset)                               adpcm_wait <= 2'd0;
	else if(dma_single_start || dma_auto_start)     adpcm_wait <= 2'd0;
	else if(adpcm_reference_awaiting && dma_output) adpcm_wait <= 2'd0;
	else if(dma_output && adpcm_type == ADPCM_2BIT) adpcm_wait <= 2'd3;
	else if(dma_output && adpcm_type == ADPCM_3BIT) adpcm_wait <= 2'd2;
	else if(dma_output && adpcm_type == ADPCM_4BIT) adpcm_wait <= 2'd1;
	else if(adpcm_output && adpcm_wait > 2'd0)      adpcm_wait <= adpcm_wait - 2'd1;
end

reg [7:0] adpcm_sample;
always @(posedge clk) begin
	if(!rst_n)                                          adpcm_sample <= 8'd0;
	else if(sw_reset)                                   adpcm_sample <= 8'd0;
	else if(dma_output)                                 adpcm_sample <= dma_readdata[7:0];
	else if(adpcm_output && adpcm_type == ADPCM_2BIT)   adpcm_sample <= { adpcm_sample[5:0], 2'b0 };
	else if(adpcm_output && adpcm_type == ADPCM_3BIT)   adpcm_sample <= { adpcm_sample[4:0], 3'b0 };
	else if(adpcm_output && adpcm_type == ADPCM_4BIT)   adpcm_sample <= { adpcm_sample[3:0], 4'b0 };
end

reg adpcm_active;
always @(posedge clk) begin
	if(!rst_n)                                          adpcm_active <= 1'b0;
	else if(sw_reset)                                   adpcm_active <= 1'b0;
	else if(adpcm_reference_awaiting && dma_output)     adpcm_active <= 1'b0;
	else if(adpcm_type != ADPCM_NONE && dma_output)     adpcm_active <= 1'b1;
	else if(adpcm_output)                               adpcm_active <= 1'b1;
	else                                                adpcm_active <= 1'b0;
end

wire [7:0] adpcm_active_value =
	(adpcm_type == ADPCM_2BIT)?     adpcm_2bit_reference_next :
	(adpcm_type == ADPCM_3BIT)?     adpcm_3bit_reference_next :
	                                adpcm_4bit_reference_next;

reg [1:0] adpcm_type;
always @(posedge clk) begin
	if(!rst_n)                                                                                                                                                              adpcm_type <= ADPCM_NONE;
	else if(sw_reset)                                                                                                                                                       adpcm_type <= ADPCM_NONE;
	else if((dma_single_start || dma_auto_start) && (dma_command == S_OUT_SINGLE_2_BIT_REF || dma_command == S_OUT_SINGLE_2_BIT || dma_command == S_OUT_AUTO_2_BIT_REF))    adpcm_type <= ADPCM_2BIT;
	else if((dma_single_start || dma_auto_start) && (dma_command == S_OUT_SINGLE_3_BIT_REF || dma_command == S_OUT_SINGLE_3_BIT || dma_command == S_OUT_AUTO_3_BIT_REF))    adpcm_type <= ADPCM_3BIT;
	else if((dma_single_start || dma_auto_start) && (dma_command == S_OUT_SINGLE_4_BIT_REF || dma_command == S_OUT_SINGLE_4_BIT || dma_command == S_OUT_AUTO_4_BIT_REF))    adpcm_type <= ADPCM_4BIT;
	else if((dma_single_start || dma_auto_start))                                                                                                                           adpcm_type <= ADPCM_NONE;
	else if(dma_finished)                                                                                                                                                   adpcm_type <= ADPCM_NONE;
end

reg [2:0] adpcm_step;
always @(posedge clk) begin
	if(!rst_n)                                          adpcm_step <= 3'd0;
	else if(sw_reset)                                   adpcm_step <= 3'd0;
	else if(adpcm_active && adpcm_type == ADPCM_2BIT)   adpcm_step <= adpcm_2bit_step_next;
	else if(adpcm_active && adpcm_type == ADPCM_3BIT)   adpcm_step <= adpcm_3bit_step_next;
	else if(adpcm_active && adpcm_type == ADPCM_4BIT)   adpcm_step <= adpcm_4bit_step_next;
	else if(adpcm_reference_awaiting && dma_output)     adpcm_step <= 3'd0;
end

reg [7:0] adpcm_reference;
always @(posedge clk) begin
	if(!rst_n)                                          adpcm_reference <= 8'd0;
	else if(sw_reset)                                   adpcm_reference <= 8'd0;
	else if(adpcm_active && adpcm_type == ADPCM_2BIT)   adpcm_reference <= adpcm_2bit_reference_next;
	else if(adpcm_active && adpcm_type == ADPCM_3BIT)   adpcm_reference <= adpcm_3bit_reference_next;
	else if(adpcm_active && adpcm_type == ADPCM_4BIT)   adpcm_reference <= adpcm_4bit_reference_next;
	else if(adpcm_reference_awaiting && dma_output)     adpcm_reference <= dma_readdata[7:0];
end

//------------------------------------------------------------------------------ adpcm 2 bit

wire [1:0] adpcm_2bit_sample = adpcm_sample[7:6];

wire [7:0] adpcm_2bit_reference_adjust =
	(adpcm_step[2:0] == 3'd0)?      { 7'd0, adpcm_2bit_sample[0] } :
	(adpcm_step[2:0] == 3'd1)?      { 6'd0, adpcm_2bit_sample[0], 1'b1 } :
	(adpcm_step[2:0] == 3'd2)?      { 5'd0, adpcm_2bit_sample[0], 2'b10 } :
	(adpcm_step[2:0] == 3'd3)?      { 4'd0, adpcm_2bit_sample[0], 3'b100 } :
	(adpcm_step[2:0] == 3'd4)?      { 3'd0, adpcm_2bit_sample[0], 4'b1000 } :
	                                { 2'd0, adpcm_2bit_sample[0], 5'b10000 }; //adpcm_step[2:0] == 3'd5

wire [8:0] adpcm_2bit_reference_sum = adpcm_reference + adpcm_2bit_reference_adjust;
wire [8:0] adpcm_2bit_reference_sub = adpcm_reference - adpcm_2bit_reference_adjust;

wire [7:0] adpcm_2bit_reference_next =
	(adpcm_2bit_sample[1] && adpcm_2bit_reference_sub[8])?  8'd0 :
	(adpcm_2bit_sample[1])?                                 adpcm_2bit_reference_sub[7:0] :
	(adpcm_2bit_reference_sum[8])?                          8'd255 :
	                                                        adpcm_2bit_reference_sum[7:0];
wire [2:0] adpcm_2bit_step_next =
	(adpcm_step < 3'd5 && adpcm_2bit_sample[0] == 1'b1)?    adpcm_step + 3'd1 :
	(adpcm_step > 3'd0 && adpcm_2bit_sample[0] == 1'b0)?    adpcm_step - 3'd1 :
	                                                        adpcm_step;

//------------------------------------------------------------------------------ adpcm 3 bit

wire [2:0] adpcm_3bit_sample = adpcm_sample[7:5];

wire [7:0] adpcm_3bit_reference_adjust =
	(adpcm_step[2:0] == 3'd0)?                                  { 6'd0, adpcm_3bit_sample[1:0] } :
	(adpcm_step[2:0] == 3'd1)?                                  { 5'd0, adpcm_3bit_sample[1:0], 1'b1 } :
	(adpcm_step[2:0] == 3'd2)?                                  { 4'd0, adpcm_3bit_sample[1:0], 2'b10 } :
	(adpcm_step[2:0] == 3'd3)?                                  { 3'd0, adpcm_3bit_sample[1:0], 3'b100 } :
	(adpcm_step[2:0] == 3'd4 && adpcm_3bit_sample == 3'd0)?     8'd5 :
	(adpcm_step[2:0] == 3'd4 && adpcm_3bit_sample == 3'd1)?     8'd15 :
	(adpcm_step[2:0] == 3'd4 && adpcm_3bit_sample == 3'd2)?     8'd25 :
	                                                            8'd35;

wire [8:0] adpcm_3bit_reference_sum = adpcm_reference + adpcm_3bit_reference_adjust;
wire [8:0] adpcm_3bit_reference_sub = adpcm_reference - adpcm_3bit_reference_adjust;

wire [7:0] adpcm_3bit_reference_next =
	(adpcm_3bit_sample[2] && adpcm_3bit_reference_sub[8])?  8'd0 :
	(adpcm_3bit_sample[2])?                                 adpcm_3bit_reference_sub[7:0] :
	(adpcm_3bit_reference_sum[8])?                          8'd255 :
	                                                        adpcm_3bit_reference_sum[7:0];
wire [2:0] adpcm_3bit_step_next =
	(adpcm_step < 3'd4 && adpcm_3bit_sample[1:0] == 2'b11)? adpcm_step + 3'd1 :
	(adpcm_step > 3'd0 && adpcm_3bit_sample[1:0] == 2'b00)? adpcm_step - 3'd1 :
	                                                        adpcm_step;

//------------------------------------------------------------------------------ adpcm 4 bit

wire [3:0] adpcm_4bit_sample = adpcm_sample[7:4];

wire [7:0] adpcm_4bit_reference_adjust =
	(adpcm_step[2:0] == 3'd0)?      { 5'd0, adpcm_4bit_sample[2:0] } :
	(adpcm_step[2:0] == 3'd1)?      { 4'd0, adpcm_4bit_sample[2:0], 1'b1 } :
	(adpcm_step[2:0] == 3'd2)?      { 3'd0, adpcm_4bit_sample[2:0], 2'b10 } :
	                                { 2'd0, adpcm_4bit_sample[2:0], 3'b100 }; //adpcm_step[2:0] == 3'd3

wire [8:0] adpcm_4bit_reference_sum = adpcm_reference + adpcm_4bit_reference_adjust;
wire [8:0] adpcm_4bit_reference_sub = adpcm_reference - adpcm_4bit_reference_adjust;

wire [7:0] adpcm_4bit_reference_next =
	(adpcm_4bit_sample[3] && adpcm_4bit_reference_sub[8])?  8'd0 :
	(adpcm_4bit_sample[3])?                                 adpcm_4bit_reference_sub[7:0] :
	(adpcm_4bit_reference_sum[8])?                          8'd255 :
	                                                        adpcm_4bit_reference_sum[7:0];
wire [2:0] adpcm_4bit_step_next =
	(adpcm_step < 3'd3 && adpcm_4bit_sample[2:0] >= 3'd5)?  adpcm_step + 3'd1 :
	(adpcm_step > 3'd0 && adpcm_4bit_sample[2:0] == 3'd0)?  adpcm_step - 3'd1 :
	                                                        adpcm_step;

//------------------------------------------------------------------------------

wire [15:0] sample =
	(adpcm_reference_output)?   {adpcm_sample, adpcm_sample} :
	(adpcm_active)?             {adpcm_active_value, adpcm_active_value} :
	                            {write_buffer[7:0], write_buffer[7:0]};

// Signed samples
wire [15:0] sample_dma_l = {            sample_dma[0][15] ^ ~dma_format[0],             sample_dma[0][14:0]};
wire [15:0] sample_dma_r = {sample_dma[dma_format[1]][15] ^ ~dma_format[0], sample_dma[dma_format[1]][14:0]};

// Attenuation should not be needed
//wire [15:0] sample_dma_l_attenuated = {sample_dma_l[15], sample_dma_l[15:1]}; // (-6dB)
//wire [15:0] sample_dma_r_attenuated = {sample_dma_r[15], sample_dma_r[15:1]}; // (-6dB)

always @(posedge clk) begin
	if((~speaker_on & sbp) | pause_active) begin
		sample_value_l <= 0;
		sample_value_r <= 0;
	end
	else if(sample_output && adpcm_type == ADPCM_NONE) begin
		if(dma_format[2]) begin
			// SBPro stereo (interleaved)
			if(~sbp_lr) sample_value_l <= sample_dma_l;
			else        sample_value_r <= sample_dma_l;
		end
		else begin
			sample_value_l <= sample_dma_l;
			sample_value_r <= sample_dma_r;
		end
	end
	else if(cmd_direct_output | adpcm_active | (~adpcm_reference_awaiting & adpcm_reference_output)) begin
		sample_value_l <= {~sample[15], sample[14:0]};
		sample_value_r <= {~sample[15], sample[14:0]};
	end
end

//------------------------------------------------------------------------------

endmodule
