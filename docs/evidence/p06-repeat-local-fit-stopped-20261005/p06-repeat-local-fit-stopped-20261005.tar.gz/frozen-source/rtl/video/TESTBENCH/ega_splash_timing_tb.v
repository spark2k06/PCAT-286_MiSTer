//============================================================================
//
//  EGA pre-BIOS splash timing regression.
//
//  The splash ROM is 320x200 and doubles every source pixel horizontally.
//  The CRTC must therefore expose exactly 640x200 active pixels. In
//  particular, the EGA CRTC interprets R1 as the last displayed character;
//  seeding R1 with 80 would expose 81 characters, or 648 pixels.
//
//  Run from rtl/video so the splash ROM can be loaded:
//    iverilog -g2012 -o splash_tb TESTBENCH/ega_splash_timing_tb.v \
//      UM6845R.v video_scandoubler.v ega_dot_clock.v ega_gfx_ctrl.v \
//      ega_sequencer.v ega_attrib_ctrl.v ega_pixel.v ega_text.v \
//      ega_splash_renderer.v ega_vgaport.v vga_mode13_ctrl.v \
//      vga_framebuffer.v vga_a000_cpu_frontend.v vga_mode13_address.v \
//      vga_dac.v vga_dac_io.v vga_mode13_timing.v \
//      vga_mode13_renderer.v ega_top.v
//    vvp splash_tb
//
//============================================================================

`timescale 1ns/1ps
`default_nettype wire

module ega_splash_timing_tb;

    reg clk = 1'b0;
    always #17.462 clk = ~clk;   // 28.636363 MHz video clock

    reg reset = 1'b1;

    wire hblank;
    wire vblank;
    wire vsync;
    wire de_o;

    ega_top dut (
        .clk(clk),
        .reset(reset),
        .bus_a(15'h0000),
        .bus_ior_l(1'b1),
        .bus_iow_l(1'b1),
        .bus_d(8'h00),
        .bus_out(),
        .bus_dir(),
        .bus_aen(1'b0),
        .ega_fetch_addr(),
        .ega_fetch_en(),
        .ega_plane0_data(8'h00),
        .ega_plane1_data(8'h00),
        .ega_plane2_data(8'h00),
        .ega_plane3_data(8'h00),
        .ega_fetch_data_valid(1'b0),
        .ega_text_cell_addr(),
        .ega_text_font_addr(),
        .ega_text_fetch_en(),
        .ega_text_char(8'h00),
        .ega_text_attr(8'h00),
        .ega_text_glyph(8'h00),
        .ega_text_data_valid(1'b0),
        .vga_framebuffer_addr(),
        .vga_framebuffer_read_en(),
        .vga_framebuffer_pixel(8'h00),
        .vga_framebuffer_data_valid(1'b0),
        .cpu_mem_select(1'b0),
        .cpu_mem_write(1'b0),
        .ega_cfg_toggle(),
        .ega_plane_write_mask_out(),
        .ega_odd_even_mode_out(),
        .ega_cpu_access_slot_out(),
        .ega_chain2_write_out(),
        .ega_chain2_read_out(),
        .ega_extended_memory_out(),
        .ega_mem_map_sel_out(),
        .ega_page_select_out(),
        .ega_write_mode_out(),
        .ega_read_mode_out(),
        .ega_read_plane_sel_out(),
        .ega_color_compare_out(),
        .ega_color_dont_care_out(),
        .ega_bit_mask_out(),
        .ega_set_reset_out(),
        .ega_enable_set_reset_out(),
        .ega_rop_select_out(),
        .ega_rotate_count_out(),
        .ega_blink_counter_out(),
        .ega_blink_state_out(),
        .hsync(),
        .hblank(hblank),
        .dbl_hsync(),
        .vsync(vsync),
        .vblank(vblank),
        .vblank_border(),
        .std_hsyncwidth(),
        .de_o(de_o),
        .ega_red(),
        .ega_green(),
        .ega_blue(),
        .ega_display_sel_out(),
        .ega_dot_toggle_out(),
        .ega_dot_clock_sel_out(),
        .ega_scandouble_active_out(),
        .ega_vmode_toggle_out(),
        .prebios_video(1'b0),
        .splashscreen(1'b1),
        .thin_font(1'b0),
        .scandouble_en(1'b0),
        .ega_enabled(1'b1),
        .ega_monitor_profile(2'b00),
        .vga_enabled(1'b0),
        .vga_mode13_set(1'b0),
        .vga_mode13_clear(1'b0),
        .vga_mode13_active_out(),
        .crt_h_offset(4'd0),
        .crt_v_offset(3'd0),
        .vsync_width_osd(3'd0),
        .hsync_width_osd(3'd0)
    );

    wire ce_pix = dut.ce_pix;

    integer errors = 0;
    integer active_width = 0;
    integer active_lines = 0;
    integer frames_checked = 0;
    time vsync_start_time = 0;
    time vsync_duration = 0;
    time vsync_period = 0;
    reg vsync_measured = 1'b0;
    reg active_measured = 1'b0;
    reg armed = 1'b0;
    reg capturing = 1'b0;
    reg de_q = 1'b0;
    reg vblank_q = 1'b1;

    always @(posedge clk) begin
        if (ce_pix) begin
            if (armed && vblank_q && !vblank) begin
                capturing = 1'b1;
                active_width = 0;
                active_lines = 0;
            end

            if (capturing && de_o)
                active_width = active_width + 1;

            if (capturing && de_q && !de_o) begin
                active_lines = active_lines + 1;
                if (active_width != 640) begin
                    $display("FAIL: splash line %0d is %0d pixels wide, expected 640",
                             active_lines, active_width);
                    errors = errors + 1;
                end
                active_width = 0;
            end

            if (capturing && !vblank_q && vblank) begin
                capturing = 1'b0;
                frames_checked = frames_checked + 1;
                if (active_lines != 200) begin
                    $display("FAIL: splash has %0d active lines, expected 200",
                             active_lines);
                    errors = errors + 1;
                end

                active_measured = 1'b1;
            end

            de_q = de_o;
            vblank_q = vblank;
        end
    end

    initial begin
        repeat (16) @(posedge clk);
        reset = 1'b0;
        // Ignore reset transients and the first frame while the CRTC pipelines
        // fill; measure the following complete visible field.
        repeat (2) @(posedge vblank);
        armed = 1'b1;
    end

    // Check the analogue timing as well as the active area. In particular, a
    // one-line VSYNC has the right frame rate but is too short for some 15 kHz
    // TVs to extract reliably from composite sync.
    initial begin
        wait (armed);
        @(negedge vsync);
        vsync_start_time = $time;
        @(posedge vsync);
        vsync_duration = $time - vsync_start_time;
        vsync_measured = 1'b1;
        @(negedge vsync);
        vsync_period = $time - vsync_start_time;
        wait (active_measured);

        $display("INFO: splash frame period is %0d ns (%0.4f Hz)",
                 vsync_period, 1000000000.0 / vsync_period);
        if (vsync_period < 16800000 || vsync_period > 16830000) begin
            $display("FAIL: splash frame period is outside the 59.5 Hz profile");
            errors = errors + 1;
        end
        if (vsync_duration < 190000 || vsync_duration > 192000) begin
            $display("FAIL: splash VSYNC is %0d ns, expected three scanlines",
                     vsync_duration);
            errors = errors + 1;
        end
        if (errors == 0)
            $display("PASS: splash active area is 640x200 (VSYNC %0d ns)",
                     vsync_duration);
        else
            $display("RESULT: FAIL (%0d errors)", errors);
        $finish;
    end

    initial begin
        #70000000;
        $display("RESULT: FAIL (timeout, checked %0d frames)", frames_checked);
        $finish;
    end

endmodule
