#!/usr/bin/env bash
set -euo pipefail

root=$(cd "$(dirname "$0")/.." && pwd)
build_dir="${PCAT_BUILD_DIR:-$root/build/a5-at-devices}"
mkdir -p "$build_dir"
cd "$root"

sources=(
  rtl/common/simple_fifo.v
  rtl/common/floppy.v
  rtl/common/ide.v
  sim/spk286_integration/dpram_model.sv
  rtl/spk286_integration/spk286_at_8042.sv
  rtl/spk286_integration/spk286_at_ems.sv
  rtl/spk286_integration/spk286_at_rtc_cmos.sv
  rtl/spk286_integration/spk286_at_fdc.sv
  rtl/spk286_integration/spk286_at_xtide.sv
  rtl/spk286_integration/spk286_at_storage_video.sv
  sys/at_cdc_snapshot.sv
  rtl/spk286_integration/spk286_at_video_adapter.sv
  rtl/spk286_integration/at286ctl.sv
  rtl/KFPC-XT/HDL/ega_vram_bram_frontend.sv
  rtl/common/tandy_pcjr_joy.sv
  rtl/spk286_integration/spk286_at_gameport.sv
  rtl/spk286_integration/spk286_at_sound.sv
  rtl/spk286_integration/spk286_at_serial.sv
  rtl/spk286_integration/spk286_at_device_router.sv
  rtl/spk286_integration/spk286_at_arbiter.sv
  rtl/spk286_integration/spk286_at_dma.sv
  sim/spk286_integration/spk286_at_devices_tb.sv
)
for source in rtl/video/*.v rtl/video/*.sv; do
  sources+=("$source")
done

iverilog -g2012 -DSPK286_AT_SIM_MODEL -s spk286_at_devices_tb \
  -o "$build_dir/a5_iv" "${sources[@]}" \
  >"$build_dir/iverilog-build.log" 2>&1
(cd "$root/rtl/video" && vvp "$build_dir/a5_iv") | tee "$build_dir/iverilog-run.log"

rm -rf "$build_dir/verilator-obj"
verilator --binary --timing -DSPK286_AT_SIM_MODEL --top-module spk286_at_devices_tb \
  -Wno-fatal --Mdir "$build_dir/verilator-obj" -o a5_vlt \
  "${sources[@]}" >"$build_dir/verilator-build.log" 2>&1
(cd "$root/rtl/video" && "$build_dir/verilator-obj/a5_vlt") | tee "$build_dir/verilator-run.log"

echo A5_AT_DEVICES_TEST_PASS
