import hashlib, io, json, tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'docs/evidence/p06-replay-head-20261005'
OUT.mkdir(exist_ok=False)
files = {}

def add(path, name):
    assert path.is_file() and name not in files
    files[name] = path.read_bytes()

for number in (1, 2, 3):
    base = ROOT / f'build/p06-replay-head-proof-20261005-v{number}'
    for p in sorted(base.iterdir()):
        if p.is_file() and p.suffix != '.vvp':
            add(p, f'proof-v{number}/{p.name}')
base = ROOT / 'build/p06-replay-head-integration-20261005-v1'
for p in sorted(base.rglob('*')):
    if p.is_file() and 'obj' not in p.relative_to(base).parts and p.suffix != '.vvp':
        add(p, 'integration/' + p.relative_to(base).as_posix())
receipt = json.loads((base / 'receipt.json').read_text())
proof = json.loads((ROOT / 'build/p06-replay-head-proof-20261005-v3/receipt.json').read_text())
inputs = {**receipt['sources_sha256'], **proof['source_sha256']}
for name, expected in inputs.items():
    p = ROOT / name
    assert hashlib.sha256(p.read_bytes()).hexdigest() == expected, name
    add(p, 'source/' + name)
add(Path(__file__).resolve(), 'collector.py')
manifest = {'status': 'SEALED_DIRECTED_EQUIVALENCE_PASS',
    'scope': 'Replay storage equivalence and directed CPU integration; fitted timing pending, full regression user deferred',
    'formal': proof['formal'], 'negative_controls': proof['negative_controls'],
    'members': {n: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for n, data in sorted(files.items())}}
files['members.json'] = (json.dumps(manifest, indent=2)+'\n').encode()
archive = OUT / 'p06-replay-head-20261005.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=6) as tar:
    for name, data in sorted(files.items()):
        info = tarfile.TarInfo(name); info.size = len(data); info.mode = 0o644
        tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    actual = {item.name: tar.extractfile(item).read() for item in tar.getmembers()}
assert actual == files
record = {**{k:v for k,v in manifest.items() if k!='members'},
    'archive': archive.name, 'bytes': archive.stat().st_size,
    'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'member_count': len(files), 'verification': 'Every archived member matched its original byte string',
    'cases_each_simulator': {'iverilog':777, 'verilator':777},
    'unit_checks_each_simulator':246, 'max_raw_stream_and_all_directed_clock_metrics':'unchanged',
    'timeout_record': 'proof-v1 records the 60-second bounded SAT timeout; proof-v3 uses proven state invariants and induction'}
(OUT/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
for src, name in [(ROOT/'build/p06-replay-head-proof-20261005-v3/receipt.json','proof.json'),
                  (base/'receipt.json','integration.json'),(base/'baseline-comparison.json','baseline-comparison.json')]:
    (OUT/name).write_bytes(src.read_bytes())
print(json.dumps(record,indent=2))
