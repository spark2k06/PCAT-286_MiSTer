module replay_miter (
    input clk, reset, cancel, start, capture, consume,
    input [7:0] capture_data
);
    wire valid_a, valid_b;
    wire [7:0] data_a, data_b;
    wire [3:0] count_a, count_b;
    spk286_target_replay a(.clk(clk),.reset(reset),.cancel(cancel),.start(start),
        .capture(capture),.consume(consume),.capture_data(capture_data),
        .valid(valid_a),.data(data_a),.count(count_a));
    spk286_target_replay_reference b(.clk(clk),.reset(reset),.cancel(cancel),.start(start),
        .capture(capture),.consume(consume),.capture_data(capture_data),
        .valid(valid_b),.data(data_b),.count(count_b));
    always @* begin
        assert(valid_a == valid_b);
        assert(data_a == data_b);
        assert(count_a == count_b);
    end
endmodule
