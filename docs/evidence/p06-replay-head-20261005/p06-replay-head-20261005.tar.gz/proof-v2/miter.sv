module replay_miter (
    input clk, reset, cancel, start, capture, consume,
    input [7:0] capture_data
);
    wire valid_a, valid_b;
    wire [7:0] data_a, data_b;
    wire [3:0] count_a, count_b;
    wire [3:0] write_a, write_b, read_a, read_b;
    wire [79:0] bytes_a, bytes_b;
    spk286_target_replay a(.clk(clk),.reset(reset),.cancel(cancel),.start(start),
        .capture(capture),.consume(consume),.capture_data(capture_data),
        .valid(valid_a),.data(data_a),.count(count_a),
        .proof_write(write_a),.proof_read(read_a),.proof_bytes(bytes_a));
    spk286_target_replay_reference b(.clk(clk),.reset(reset),.cancel(cancel),.start(start),
        .capture(capture),.consume(consume),.capture_data(capture_data),
        .valid(valid_b),.data(data_b),.count(count_b),
        .proof_write(write_b),.proof_read(read_b),.proof_bytes(bytes_b));
    always @* begin
        assert(write_a == write_b);
        assert(write_b <= 10);
        assert(read_b <= write_b);
        assert(read_a == read_b);
        assert(valid_a == valid_b);
        assert(data_a == data_b);
        assert(count_a == count_b);
    end
    for (genvar slot = 0; slot < 10; slot = slot + 1) begin
        wire [4:0] reference_slot = {1'b0, read_b} + slot;
        always @* if (slot < count_a)
            assert(bytes_a[slot*8 +: 8] == bytes_b[reference_slot*8 +: 8]);
    end
endmodule
