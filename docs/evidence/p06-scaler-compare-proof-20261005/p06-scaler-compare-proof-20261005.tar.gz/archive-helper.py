import hashlib,io,json,tarfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
source=root/'build/p06-scaler-compare-proof-20261005'
dest=root/'docs/evidence/p06-scaler-compare-proof-20261005'
dest.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
receipt=json.loads((source/'receipt.json').read_text())
assert receipt['status']=='PRIVATE_OSWEEP_COMPARE_EQUIVALENCE_PASS'
assert sha((root/'sys/ascal.vhd').read_bytes())==receipt['sources_sha256']['sys/ascal.vhd']
payload={p.relative_to(source).as_posix():p.read_bytes() for p in source.rglob('*') if p.is_file()}
for name,digest in receipt['artifacts_sha256'].items():
    assert sha(payload[name])==digest,name
payload['production-source/sys/ascal.vhd']=(root/'sys/ascal.vhd').read_bytes()
payload['archive-helper.py']=Path(__file__).read_bytes()
archive=dest/'p06-scaler-compare-proof-20261005.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as target:
    for name,data in payload.items():
        member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;member.mtime=0
        target.addfile(member,io.BytesIO(data))
with tarfile.open(archive) as target:
    assert set(target.getnames())==set(payload)
    for member in target:
        assert target.extractfile(member).read()==payload[member.name],member.name
assert sha((root/'sys/ascal.vhd').read_bytes())==receipt['sources_sha256']['sys/ascal.vhd']
(dest/'receipt.json').write_bytes(payload['receipt.json'])
manifest={'status':'SEALED_PRIVATE_PROOF_NO_PRODUCTION_CHANGE','archive':archive.name,
          'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'members':len(payload),
          'verification':'Every archived member read back equal before cleanup',
          'production_source_sha256':receipt['sources_sha256']['sys/ascal.vhd']}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',newline='\n')
(dest/'cleanup.json').write_text(json.dumps({'status':'PENDING','archive_sha256':manifest['sha256'],
    'targets':[source.relative_to(root).as_posix()]},indent=2)+'\n',newline='\n')
print('PRIVATE_SCALER_PROOF_SEALED',len(payload),archive.stat().st_size)
