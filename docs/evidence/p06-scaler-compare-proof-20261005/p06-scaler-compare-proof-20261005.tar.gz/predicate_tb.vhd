LIBRARY ieee; USE ieee.std_logic_1164.ALL; USE work.sweep_types.ALL;
ENTITY predicate_tb IS END; ARCHITECTURE test OF predicate_tb IS BEGIN
PROCESS VARIABLE o_hcpt,o_htotal : uint12; VARIABLE a,b,m : boolean;
VARIABLE bad : natural:=0;
BEGIN
FOR t IN 0 TO 4095 LOOP FOR x IN 0 TO 4095 LOOP
o_hcpt:=x; o_htotal:=t;
a:=o_hcpt+1<o_htotal; b:=o_htotal>0 AND o_hcpt<o_htotal-1;
m:=o_hcpt<o_htotal;
ASSERT a=b REPORT "Actual VHDL predicates differ" SEVERITY failure;
ASSERT a=(integer(t)-integer(x)>1) REPORT "Independent integer-distance oracle differs" SEVERITY failure;
IF a/=m THEN bad:=bad+1; END IF;
END LOOP; END LOOP;
ASSERT bad=4095 REPORT "Off-by-one control not detected exhaustively" SEVERITY failure;
REPORT "PREDICATE_PASS pairs=16777216 mutant_counterexamples=4095";
WAIT; END PROCESS; END;
