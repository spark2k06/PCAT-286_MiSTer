#!/usr/bin/env python3
"""Private, source-bound native VHDL OSWEEP equivalence proof; no RTL edits."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
SOURCE = ROOT / "sys/ascal.vhd"
IMAGE = "ghdl/ghdl:ubuntu22-llvm-11"

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def run(name, args, cwd=OUT, expect=0):
    log = OUT / f"{name}.log"
    with log.open("w") as stream:
        result = subprocess.run(args, cwd=cwd, stdout=stream, stderr=subprocess.STDOUT)
    if expect == 0:
        assert result.returncode == 0, (name, result.returncode, log)
    else:
        assert result.returncode != 0, (name, "negative control unexpectedly passed")
    return result.returncode

source_sha = sha(SOURCE)
source = SOURCE.read_text()
processes = re.findall(r"\bOSWEEP:PROCESS\(o_clk\) IS.*?END PROCESS OSWEEP;", source, re.S)
assert len(processes) == 1
reference = processes[0]
needle = "IF o_hcpt+1<o_htotal THEN"
replacement = "IF o_htotal>0 AND o_hcpt<o_htotal-1 THEN"
assert reference.count(needle) == 1
candidate = reference.replace(needle, replacement)
assert candidate.replace(replacement, needle) == reference
mutant = reference.replace(needle, "IF o_hcpt<o_htotal THEN")
subtype = re.findall(r"\bSUBTYPE uint12 IS natural RANGE 0 TO 4095;", source)
assert len(subtype) == 1
function = re.findall(r"\bFUNCTION to_std_logic \(a : boolean\).*?END FUNCTION to_std_logic;", source, re.S)
assert len(function) == 1
plain_process = re.sub(r"--[^\n]*", "", reference)
state_names = sorted(set(re.findall(r"\b(o_\w+)\s*(?:\([^;]*?\))?\s*<=", plain_process)))
ids = set(re.findall(r"\b(?:o_\w+|at_config_retime|AT_LOCAL_CONFIG|vtotal)\b", plain_process))
context_names = sorted(ids - set(state_names) - {"o_clk"})
types = {}
for names, kind in re.findall(r"\bSIGNAL\s+([a-zA-Z0-9_, ]+)\s*:\s*([^;]+);", source, re.I):
    for name in names.replace(" ", "").split(","):
        types[name] = kind.strip().split(":=")[0].strip()
types.update(o_ce="std_logic", at_config_retime="std_logic", AT_LOCAL_CONFIG="boolean", vtotal="uint12")
assert set(state_names + context_names) <= set(types)
assert all(types[x] in ("uint12", "boolean", "std_logic", "unsigned(0 TO 11)") for x in state_names + context_names)

def record(name, fields):
    return "TYPE " + name + " IS RECORD\n" + "\n".join(f"  {x} : {types[x]};" for x in fields) + "\nEND RECORD;"

package = "LIBRARY ieee; USE ieee.std_logic_1164.ALL; USE ieee.numeric_std.ALL;\nPACKAGE sweep_types IS\n" + subtype[0] + "\n" + record("sweep_state", state_names) + "\n" + record("sweep_context", context_names) + "\nEND PACKAGE;\n"
(OUT / "sweep_types.vhd").write_text(package)
(OUT / "reference_process.vhd.txt").write_text(reference)
(OUT / "candidate_process.vhd.txt").write_text(candidate)

def entity(name, body):
    # Add only a private arbitrary-state load branch. The original complete
    # process body, its clock enable and last-assignment priorities stay intact.
    hook = "IF rising_edge(o_clk) THEN"
    assert body.count(hook) == 1
    load = "\nIF seed='1' THEN\n" + "\n".join(f"  {x}<=state_seed.{x};" for x in state_names) + "\nELSE\n"
    wrapped = body.replace(hook, hook + load)
    end_hook = "END PROCESS OSWEEP;"
    wrapped = wrapped.replace(end_hook, "END IF;\n" + end_hook)
    # The inserted extra END IF closes the outer edge conditional; the original
    # final END IF now closes the private seed branch. Nested priorities remain.
    declarations = "\n".join(f"SIGNAL {x} : {types[x]};" for x in state_names + context_names)
    assignments = "\n".join(f"{x}<=context_in.{x};" for x in context_names)
    assignments += "\n" + "\n".join(f"state_out.{x}<={x};" for x in state_names)
    return f"""LIBRARY ieee; USE ieee.std_logic_1164.ALL; USE ieee.numeric_std.ALL;
USE work.sweep_types.ALL;
ENTITY {name} IS PORT(o_clk,seed : IN std_logic; state_seed : IN sweep_state;
                     context_in : IN sweep_context; state_out : OUT sweep_state); END;
ARCHITECTURE extracted OF {name} IS
{declarations}
{function[0]}
BEGIN
{assignments}
{wrapped}
END;
"""

for name, body in (("sweep_reference", reference), ("sweep_candidate", candidate), ("sweep_mutant", mutant)):
    (OUT / f"{name}.vhd").write_text(entity(name, body))

def miter(name, variant):
    return f"""LIBRARY ieee; USE ieee.std_logic_1164.ALL; USE ieee.numeric_std.ALL;
USE work.sweep_types.ALL;
ENTITY {name} IS PORT(o_clk,seed : IN std_logic; state_seed : IN sweep_state;
                     context_in : IN sweep_context; match : OUT std_logic); END;
ARCHITECTURE compare OF {name} IS SIGNAL a,b : sweep_state;
BEGIN
ref: ENTITY work.sweep_reference PORT MAP(o_clk,seed,state_seed,context_in,a);
dut: ENTITY work.{variant} PORT MAP(o_clk,seed,state_seed,context_in,b);
match<='1' WHEN a=b ELSE '0';
END;
"""

(OUT / "sweep_miter.vhd").write_text(miter("sweep_miter", "sweep_candidate"))
(OUT / "sweep_mutant_miter.vhd").write_text(miter("sweep_mutant_miter", "sweep_mutant"))

# Native VHDL exhaustive predicate: 16,777,216 legal x/t pairs. Integer
# expressions retain x+1=4096 and t-1=-1 rather than unsigned twelve-bit wrap.
predicate_tb = f"""LIBRARY ieee; USE ieee.std_logic_1164.ALL; USE work.sweep_types.ALL;
ENTITY predicate_tb IS END; ARCHITECTURE test OF predicate_tb IS BEGIN
PROCESS VARIABLE o_hcpt,o_htotal : uint12; VARIABLE a,b,m : boolean;
VARIABLE bad : natural:=0;
BEGIN
FOR t IN 0 TO 4095 LOOP FOR x IN 0 TO 4095 LOOP
o_hcpt:=x; o_htotal:=t;
a:=o_hcpt+1<o_htotal; b:=o_htotal>0 AND o_hcpt<o_htotal-1;
m:=o_hcpt<o_htotal;
ASSERT a=b REPORT "Actual VHDL predicates differ" SEVERITY failure;
ASSERT a=(integer(t)-integer(x)>1) REPORT "Independent integer-distance oracle differs" SEVERITY failure;
IF a/=m THEN bad:=bad+1; END IF;
END LOOP; END LOOP;
ASSERT bad=4095 REPORT "Off-by-one control not detected exhaustively" SEVERITY failure;
REPORT "PREDICATE_PASS pairs=16777216 mutant_counterexamples=4095";
WAIT; END PROCESS; END;
"""
(OUT / "predicate_tb.vhd").write_text(predicate_tb)

# Independently modeled edge transitions, checked against actual complete
# extracted processes. Use records so every state bit is compared each edge.
oracle = """
FUNCTION edge_oracle(q : sweep_state; c : sweep_context) RETURN sweep_state IS
VARIABLE n : sweep_state:=q;
BEGIN
IF c.o_ce='1' THEN
IF integer(c.o_htotal)-integer(q.o_hcpt)>1 THEN n.o_hcpt:=(q.o_hcpt+1) MOD 4096;
ELSE
n.o_hcpt:=0;
IF q.o_vcpt_sync<4095 THEN n.o_vcpt_sync:=q.o_vcpt_sync+1; END IF;
IF integer(c.o_vtotal)-integer(q.o_vcpt_pre3)<=1 THEN n.o_vcpt_pre3:=0;
ELSIF q.o_vrr_sync2 THEN n.o_vcpt_pre3:=c.o_vsstart; n.o_sync:=false;
ELSE n.o_vcpt_pre3:=(q.o_vcpt_pre3+1) MOD 4096; END IF;
n.o_vcpt_pre2:=q.o_vcpt_pre3; n.o_vcpt_pre:=q.o_vcpt_pre2; n.o_vcpt:=q.o_vcpt_pre;
END IF;
n.o_end(0):=to_std_logic(q.o_vcpt>=c.o_vdisp);
n.o_dev(0):=to_std_logic(q.o_hcpt<c.o_hdisp AND q.o_vcpt<c.o_vdisp);
n.o_pev(0):=to_std_logic(q.o_hcpt>=c.o_hmin AND q.o_hcpt<=c.o_hmax AND q.o_vcpt>=c.o_vmin AND q.o_vcpt<=c.o_vmax);
n.o_hsv(0):=to_std_logic(q.o_hcpt>=c.o_hsstart AND q.o_hcpt<c.o_hsend);
n.o_vsv(0):=to_std_logic((q.o_vcpt=c.o_vsstart AND q.o_hcpt>=c.o_hsstart) OR (q.o_vcpt>c.o_vsstart AND q.o_vcpt<c.o_vsend) OR (q.o_vcpt=c.o_vsend AND q.o_hcpt<c.o_hsstart));
n.o_vss:=to_std_logic(q.o_vcpt_pre2>=c.o_vmin AND q.o_vcpt_pre2<=c.o_vmax);
n.o_hsv(1 TO 11):=q.o_hsv(0 TO 10); n.o_vsv(1 TO 11):=q.o_vsv(0 TO 10);
n.o_dev(1 TO 11):=q.o_dev(0 TO 10); n.o_pev(1 TO 11):=q.o_pev(0 TO 10); n.o_end(1 TO 11):=q.o_end(0 TO 10);
IF c.o_run='0' THEN n.o_hsv(2):='0'; n.o_vsv(2):='0'; n.o_dev(2):='0'; n.o_pev(2):='0'; n.o_end(2):='0'; END IF;
END IF;
n.o_vcpt_sync2:=q.o_vcpt_sync; n.o_vrr_min:=q.o_vcpt_sync2<c.o_vtotal;
n.o_vrr_min2:=q.o_vrr_min; n.o_vrr_max:=q.o_vcpt_sync2<c.o_vrrmax; n.o_vrr_max2:=q.o_vrr_max;
IF c.o_isync2='1' THEN n.o_vcpt_sync:=0; n.o_sync_max:=q.o_vrr_max2; IF q.o_vrr_min2 THEN n.o_sync:=true; END IF; END IF;
n.o_vcpt2:=q.o_vcpt_pre3;
n.o_vrr_sync:=c.o_vrr='1' AND (q.o_sync OR q.o_sync_max) AND q.o_vcpt2>=c.o_vdisp AND q.o_vcpt2<c.o_vsstart;
n.o_vrr_sync2:=q.o_vrr_sync;
IF c.AT_LOCAL_CONFIG AND c.at_config_retime='1' THEN
n.o_hcpt:=0;
IF c.vtotal>0 THEN n.o_vcpt_pre3:=c.vtotal-1; n.o_vcpt_pre2:=c.vtotal-1; n.o_vcpt_pre:=c.vtotal-1; n.o_vcpt:=c.vtotal-1; n.o_vcpt2:=c.vtotal-1;
ELSE n.o_vcpt_pre3:=0; n.o_vcpt_pre2:=0; n.o_vcpt_pre:=0; n.o_vcpt:=0; n.o_vcpt2:=0; END IF;
n.o_dev:=(OTHERS=>'0'); n.o_pev:=(OTHERS=>'0'); n.o_hsv:=(OTHERS=>'0'); n.o_vsv:=(OTHERS=>'0'); n.o_end:=(OTHERS=>'1');
n.o_vcpt_sync:=0; n.o_sync:=false; n.o_sync_max:=false; n.o_vrr_sync:=false; n.o_vrr_sync2:=false;
END IF;
RETURN n; END FUNCTION;
"""

def random_assignment(prefix, names):
    statements=[]
    for x in names:
        kind=types[x]
        expr="rand12" if kind=="uint12" else "rand12 MOD 2=1" if kind=="boolean" else "to_std_logic(rand12 MOD 2=1)" if kind=="std_logic" else "to_unsigned(rand12,12)"
        statements.append(f"{prefix}.{x}:={expr};")
    return "\n".join(statements)

transition_tb = f"""LIBRARY ieee; USE ieee.std_logic_1164.ALL; USE ieee.numeric_std.ALL; USE std.env.ALL;
USE work.sweep_types.ALL;
ENTITY transition_tb IS END;
ARCHITECTURE test OF transition_tb IS
SIGNAL clk,seed : std_logic:='0'; SIGNAL s,observed_reference,observed_candidate : sweep_state; SIGNAL observed_context : sweep_context;
{function[0]}
{oracle}
BEGIN
ref: ENTITY work.sweep_reference PORT MAP(clk,seed,s,observed_context,observed_reference);
dut: ENTITY work.sweep_candidate PORT MAP(clk,seed,s,observed_context,observed_candidate);
PROCESS
VARIABLE q,e : sweep_state; VARIABLE v : sweep_context;
VARIABLE rng : unsigned(31 DOWNTO 0):=x"2A351C81"; VARIABLE cases,edges : natural:=0;
IMPURE FUNCTION rand12 RETURN natural IS BEGIN
rng:=rng(30 DOWNTO 0) & (rng(31) XOR rng(21) XOR rng(1) XOR rng(0)); RETURN to_integer(rng(11 DOWNTO 0)); END;
PROCEDURE pulse IS BEGIN clk<='0'; WAIT FOR 1 ns; clk<='1'; WAIT FOR 1 ns; clk<='0'; WAIT FOR 1 ns; END;
PROCEDURE check IS BEGIN
s<=q; observed_context<=v; seed<='1'; pulse;
ASSERT observed_reference=q AND observed_candidate=q REPORT "Arbitrary-state seed differs" SEVERITY failure;
seed<='0';
FOR j IN 0 TO 3 LOOP
IF j>0 THEN {random_assignment('v', context_names)} END IF;
observed_context<=v; e:=edge_oracle(q,v); pulse;
ASSERT observed_reference=e REPORT "Original complete process disagrees with independent edge oracle" SEVERITY failure;
ASSERT observed_candidate=e REPORT "Private candidate disagrees with independent edge oracle" SEVERITY failure;
q:=e; edges:=edges+1;
END LOOP; cases:=cases+1; END;
BEGIN
FOR i IN 0 TO 9999 LOOP
{random_assignment('q', state_names)}
{random_assignment('v', context_names)}
-- Directed boundary cross-product starts from arbitrary complete state.
IF i<64 THEN
CASE i MOD 4 IS WHEN 0=>v.o_htotal:=0; q.o_hcpt:=4095;
WHEN 1=>v.o_htotal:=4095; q.o_hcpt:=4094;
WHEN 2=>v.o_htotal:=1; q.o_hcpt:=0;
WHEN OTHERS=>v.o_htotal:=4095; q.o_hcpt:=4093; END CASE;
v.o_ce:=to_std_logic((i/4) MOD 2=1); v.AT_LOCAL_CONFIG:=(i/8) MOD 2=1;
v.at_config_retime:=to_std_logic((i/16) MOD 2=1); v.o_isync2:=to_std_logic((i/32) MOD 2=1);
v.vtotal:=0;
END IF; check;
END LOOP;
REPORT "TRANSITION_PASS cases=" & integer'image(cases) & " edges=" & integer'image(edges);
stop; WAIT; END PROCESS;
END;
"""
(OUT / "transition_tb.vhd").write_text(transition_tb)

command = """set -e
ghdl --version > ghdl-version.txt
ghdl -a --std=93 sweep_types.vhd sweep_reference.vhd sweep_candidate.vhd sweep_mutant.vhd sweep_miter.vhd sweep_mutant_miter.vhd predicate_tb.vhd
ghdl -e --std=93 predicate_tb
ghdl -r --std=93 predicate_tb --assert-level=error
ghdl -a --std=08 sweep_types.vhd sweep_reference.vhd sweep_candidate.vhd transition_tb.vhd
ghdl -e --std=08 transition_tb
ghdl -r --std=08 transition_tb --assert-level=error
ghdl synth --std=93 --out=verilog sweep_miter > sweep_miter.v
ghdl synth --std=93 --out=verilog sweep_mutant_miter > sweep_mutant_miter.v
"""
run("native-vhdl", ["docker", "run", "--rm", "--pull=never", "-v", f"{OUT}:/results", "-w", "/results", IMAGE, "bash", "-lc", command])
assert "warning:" not in (OUT / "native-vhdl.log").read_text(), "unexpected native VHDL diagnostic"
for name in ("sweep_miter", "sweep_mutant_miter"):
    script=f"read_verilog {name}.v; prep -top {name}; flatten; opt; sat -seq 3 -set-at 1 seed 1 -set-at 2 seed 0 -set-at 3 seed 0 -prove match 1 -prove-skip 2 -verify -show-inputs -show-outputs"
    run(name, ["yosys", "-Q", "-p", script], expect=0 if name=="sweep_miter" else 1)
    log=(OUT/f"{name}.log").read_text()
    assert "SUCCESS" in log if name=="sweep_miter" else "proof did fail" in log

assert sha(SOURCE)==source_sha, "production source changed during proof"
receipt={"schema":1,"status":"PRIVATE_OSWEEP_COMPARE_EQUIVALENCE_PASS",
         "production_unchanged":True,"sources_sha256":{"sys/ascal.vhd":source_sha,"run_proof.py":sha(__file__)},
         "domain":"actual VHDL uint12 natural0..4095; integer intermediates, no unsigned wrap",
         "rewrite":{"reference":needle,"candidate":replacement},
         "exhaustive_predicate_pairs":16777216,"predicate_mutant_counterexamples":4095,
         "native_process_cases":10000,"native_process_edges":40000,
         "formal":"actual GHDL-synthesized complete processes; arbitrary seeded state, all context fields unconstrained; one-step induction basis after arbitrary-state load",
         "state_fields":state_names,"context_fields":context_names,
         "negative_control":"wrong end-line predicate x<t rejected natively and by complete-process SAT",
         "limits":["private extracted process proof; no production source edit", "not whole-scaler regression or Quartus placement/timing proof", "all fields modeled as binary legal values; std_logic unknowns not architectural inputs"],
         "artifacts_sha256":{p.name:sha(p) for p in sorted(OUT.iterdir()) if p.is_file() and p.name!="receipt.json"}}
(OUT/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({"status":receipt["status"],"receipt":str(OUT/"receipt.json")}))
