LIBRARY ieee; USE ieee.std_logic_1164.ALL; USE ieee.numeric_std.ALL;
USE work.sweep_types.ALL;
ENTITY sweep_miter IS PORT(o_clk,seed : IN std_logic; state_seed : IN sweep_state;
                     context_in : IN sweep_context; match : OUT std_logic); END;
ARCHITECTURE compare OF sweep_miter IS SIGNAL a,b : sweep_state;
BEGIN
ref: ENTITY work.sweep_reference PORT MAP(o_clk,seed,state_seed,context_in,a);
dut: ENTITY work.sweep_candidate PORT MAP(o_clk,seed,state_seed,context_in,b);
match<='1' WHEN a=b ELSE '0';
END;
