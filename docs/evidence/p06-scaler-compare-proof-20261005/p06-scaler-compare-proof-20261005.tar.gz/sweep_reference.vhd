LIBRARY ieee; USE ieee.std_logic_1164.ALL; USE ieee.numeric_std.ALL;
USE work.sweep_types.ALL;
ENTITY sweep_reference IS PORT(o_clk,seed : IN std_logic; state_seed : IN sweep_state;
                     context_in : IN sweep_context; state_out : OUT sweep_state); END;
ARCHITECTURE extracted OF sweep_reference IS
SIGNAL o_dev : unsigned(0 TO 11);
SIGNAL o_end : unsigned(0 TO 11);
SIGNAL o_hcpt : uint12;
SIGNAL o_hsv : unsigned(0 TO 11);
SIGNAL o_pev : unsigned(0 TO 11);
SIGNAL o_sync : boolean;
SIGNAL o_sync_max : boolean;
SIGNAL o_vcpt : uint12;
SIGNAL o_vcpt2 : uint12;
SIGNAL o_vcpt_pre : uint12;
SIGNAL o_vcpt_pre2 : uint12;
SIGNAL o_vcpt_pre3 : uint12;
SIGNAL o_vcpt_sync : uint12;
SIGNAL o_vcpt_sync2 : uint12;
SIGNAL o_vrr_max : boolean;
SIGNAL o_vrr_max2 : boolean;
SIGNAL o_vrr_min : boolean;
SIGNAL o_vrr_min2 : boolean;
SIGNAL o_vrr_sync : boolean;
SIGNAL o_vrr_sync2 : boolean;
SIGNAL o_vss : std_logic;
SIGNAL o_vsv : unsigned(0 TO 11);
SIGNAL AT_LOCAL_CONFIG : boolean;
SIGNAL at_config_retime : std_logic;
SIGNAL o_ce : std_logic;
SIGNAL o_hdisp : uint12;
SIGNAL o_hmax : uint12;
SIGNAL o_hmin : uint12;
SIGNAL o_hsend : uint12;
SIGNAL o_hsstart : uint12;
SIGNAL o_htotal : uint12;
SIGNAL o_isync2 : std_logic;
SIGNAL o_run : std_logic;
SIGNAL o_vdisp : uint12;
SIGNAL o_vmax : uint12;
SIGNAL o_vmin : uint12;
SIGNAL o_vrr : std_logic;
SIGNAL o_vrrmax : uint12;
SIGNAL o_vsend : uint12;
SIGNAL o_vsstart : uint12;
SIGNAL o_vtotal : uint12;
SIGNAL vtotal : uint12;
FUNCTION to_std_logic (a : boolean) RETURN std_logic IS
	BEGIN
		IF a THEN RETURN '1';
		ELSE RETURN '0';
		END IF;
	END FUNCTION to_std_logic;
BEGIN
AT_LOCAL_CONFIG<=context_in.AT_LOCAL_CONFIG;
at_config_retime<=context_in.at_config_retime;
o_ce<=context_in.o_ce;
o_hdisp<=context_in.o_hdisp;
o_hmax<=context_in.o_hmax;
o_hmin<=context_in.o_hmin;
o_hsend<=context_in.o_hsend;
o_hsstart<=context_in.o_hsstart;
o_htotal<=context_in.o_htotal;
o_isync2<=context_in.o_isync2;
o_run<=context_in.o_run;
o_vdisp<=context_in.o_vdisp;
o_vmax<=context_in.o_vmax;
o_vmin<=context_in.o_vmin;
o_vrr<=context_in.o_vrr;
o_vrrmax<=context_in.o_vrrmax;
o_vsend<=context_in.o_vsend;
o_vsstart<=context_in.o_vsstart;
o_vtotal<=context_in.o_vtotal;
vtotal<=context_in.vtotal;
state_out.o_dev<=o_dev;
state_out.o_end<=o_end;
state_out.o_hcpt<=o_hcpt;
state_out.o_hsv<=o_hsv;
state_out.o_pev<=o_pev;
state_out.o_sync<=o_sync;
state_out.o_sync_max<=o_sync_max;
state_out.o_vcpt<=o_vcpt;
state_out.o_vcpt2<=o_vcpt2;
state_out.o_vcpt_pre<=o_vcpt_pre;
state_out.o_vcpt_pre2<=o_vcpt_pre2;
state_out.o_vcpt_pre3<=o_vcpt_pre3;
state_out.o_vcpt_sync<=o_vcpt_sync;
state_out.o_vcpt_sync2<=o_vcpt_sync2;
state_out.o_vrr_max<=o_vrr_max;
state_out.o_vrr_max2<=o_vrr_max2;
state_out.o_vrr_min<=o_vrr_min;
state_out.o_vrr_min2<=o_vrr_min2;
state_out.o_vrr_sync<=o_vrr_sync;
state_out.o_vrr_sync2<=o_vrr_sync2;
state_out.o_vss<=o_vss;
state_out.o_vsv<=o_vsv;
OSWEEP:PROCESS(o_clk) IS
	BEGIN
		IF rising_edge(o_clk) THEN
IF seed='1' THEN
  o_dev<=state_seed.o_dev;
  o_end<=state_seed.o_end;
  o_hcpt<=state_seed.o_hcpt;
  o_hsv<=state_seed.o_hsv;
  o_pev<=state_seed.o_pev;
  o_sync<=state_seed.o_sync;
  o_sync_max<=state_seed.o_sync_max;
  o_vcpt<=state_seed.o_vcpt;
  o_vcpt2<=state_seed.o_vcpt2;
  o_vcpt_pre<=state_seed.o_vcpt_pre;
  o_vcpt_pre2<=state_seed.o_vcpt_pre2;
  o_vcpt_pre3<=state_seed.o_vcpt_pre3;
  o_vcpt_sync<=state_seed.o_vcpt_sync;
  o_vcpt_sync2<=state_seed.o_vcpt_sync2;
  o_vrr_max<=state_seed.o_vrr_max;
  o_vrr_max2<=state_seed.o_vrr_max2;
  o_vrr_min<=state_seed.o_vrr_min;
  o_vrr_min2<=state_seed.o_vrr_min2;
  o_vrr_sync<=state_seed.o_vrr_sync;
  o_vrr_sync2<=state_seed.o_vrr_sync2;
  o_vss<=state_seed.o_vss;
  o_vsv<=state_seed.o_vsv;
ELSE


			IF o_ce='1' THEN
				-- Output pixels count
				IF o_hcpt+1<o_htotal THEN
					o_hcpt<=(o_hcpt+1) MOD 4096;
				ELSE
					o_hcpt<=0;

					IF o_vcpt_sync /= 4095 THEN
						o_vcpt_sync <= o_vcpt_sync+1;
					END IF;

					IF o_vcpt_pre3+1>=o_vtotal THEN
						o_vcpt_pre3<=0;
					ELSIF o_vrr_sync2 THEN
						o_vcpt_pre3<=o_vsstart;
						o_sync<=false;
					ELSE
						o_vcpt_pre3<=(o_vcpt_pre3+1) MOD 4096;
					END IF;

					o_vcpt_pre2<=o_vcpt_pre3;
					o_vcpt_pre<=o_vcpt_pre2;
					o_vcpt<=o_vcpt_pre;
				END IF;

				o_end(0)<=to_std_logic(o_vcpt>=o_vdisp);
				o_dev(0)<=to_std_logic(o_hcpt<o_hdisp AND o_vcpt<o_vdisp);
				o_pev(0)<=to_std_logic(o_hcpt>=o_hmin AND o_hcpt<=o_hmax AND
											  o_vcpt>=o_vmin AND o_vcpt<=o_vmax);
				o_hsv(0)<=to_std_logic(o_hcpt>=o_hsstart AND o_hcpt<o_hsend);
				o_vsv(0)<=to_std_logic((o_vcpt=o_vsstart AND o_hcpt>=o_hsstart) OR
											  (o_vcpt>o_vsstart AND o_vcpt<o_vsend) OR
											  (o_vcpt=o_vsend   AND o_hcpt<o_hsstart));

				o_vss<=to_std_logic(o_vcpt_pre2>=o_vmin AND o_vcpt_pre2<=o_vmax);
				o_hsv(1 TO 11)<=o_hsv(0 TO 10);
				o_vsv(1 TO 11)<=o_vsv(0 TO 10);
				o_dev(1 TO 11)<=o_dev(0 TO 10);
				o_pev(1 TO 11)<=o_pev(0 TO 10);
				o_end(1 TO 11)<=o_end(0 TO 10);

				IF o_run='0' THEN
					o_hsv(2)<='0';
					o_vsv(2)<='0';
					o_dev(2)<='0';
					o_pev(2)<='0';
					o_end(2)<='0';
				END IF;
			END IF;

			o_vcpt_sync2<=o_vcpt_sync;
			o_vrr_min<=(o_vcpt_sync2<o_vtotal);
			o_vrr_min2<=o_vrr_min;
			o_vrr_max<=(o_vcpt_sync2<o_vrrmax);
			o_vrr_max2<=o_vrr_max;

			IF o_isync2='1' THEN
				o_vcpt_sync<=0;
				o_sync_max<=o_vrr_max2;
				IF o_vrr_min2 THEN
					o_sync<=true;
				END iF;
			END IF;

			o_vcpt2<=o_vcpt_pre3;
			o_vrr_sync<=(o_vrr='1' AND (o_sync OR o_sync_max) AND o_vcpt2>=o_vdisp AND o_vcpt2<o_vsstart);
			o_vrr_sync2<=o_vrr_sync;

			-- A new raster can be taller than the old VS position. Restart in
			-- its final blank line so the change cannot expose a partial active
			-- frame. Ordinary aspect/framebuffer changes keep the cadence intact.
			IF AT_LOCAL_CONFIG AND at_config_retime='1' THEN
				o_hcpt<=0;
				IF vtotal>0 THEN
					o_vcpt_pre3<=vtotal-1; o_vcpt_pre2<=vtotal-1;
					o_vcpt_pre<=vtotal-1; o_vcpt<=vtotal-1; o_vcpt2<=vtotal-1;
				ELSE
					o_vcpt_pre3<=0; o_vcpt_pre2<=0; o_vcpt_pre<=0; o_vcpt<=0; o_vcpt2<=0;
				END IF;
				o_dev<=(OTHERS=>'0'); o_pev<=(OTHERS=>'0');
				o_hsv<=(OTHERS=>'0'); o_vsv<=(OTHERS=>'0'); o_end<=(OTHERS=>'1');
				o_vcpt_sync<=0; o_sync<=false; o_sync_max<=false;
				o_vrr_sync<=false; o_vrr_sync2<=false;
			END IF;

	 END IF;
	END IF;
END PROCESS OSWEEP;
END;
