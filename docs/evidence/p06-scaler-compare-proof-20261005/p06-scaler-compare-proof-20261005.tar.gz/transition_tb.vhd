LIBRARY ieee; USE ieee.std_logic_1164.ALL; USE ieee.numeric_std.ALL; USE std.env.ALL;
USE work.sweep_types.ALL;
ENTITY transition_tb IS END;
ARCHITECTURE test OF transition_tb IS
SIGNAL clk,seed : std_logic:='0'; SIGNAL s,observed_reference,observed_candidate : sweep_state; SIGNAL observed_context : sweep_context;
FUNCTION to_std_logic (a : boolean) RETURN std_logic IS
	BEGIN
		IF a THEN RETURN '1';
		ELSE RETURN '0';
		END IF;
	END FUNCTION to_std_logic;

FUNCTION edge_oracle(q : sweep_state; c : sweep_context) RETURN sweep_state IS
VARIABLE n : sweep_state:=q;
BEGIN
IF c.o_ce='1' THEN
IF integer(c.o_htotal)-integer(q.o_hcpt)>1 THEN n.o_hcpt:=(q.o_hcpt+1) MOD 4096;
ELSE
n.o_hcpt:=0;
IF q.o_vcpt_sync<4095 THEN n.o_vcpt_sync:=q.o_vcpt_sync+1; END IF;
IF integer(c.o_vtotal)-integer(q.o_vcpt_pre3)<=1 THEN n.o_vcpt_pre3:=0;
ELSIF q.o_vrr_sync2 THEN n.o_vcpt_pre3:=c.o_vsstart; n.o_sync:=false;
ELSE n.o_vcpt_pre3:=(q.o_vcpt_pre3+1) MOD 4096; END IF;
n.o_vcpt_pre2:=q.o_vcpt_pre3; n.o_vcpt_pre:=q.o_vcpt_pre2; n.o_vcpt:=q.o_vcpt_pre;
END IF;
n.o_end(0):=to_std_logic(q.o_vcpt>=c.o_vdisp);
n.o_dev(0):=to_std_logic(q.o_hcpt<c.o_hdisp AND q.o_vcpt<c.o_vdisp);
n.o_pev(0):=to_std_logic(q.o_hcpt>=c.o_hmin AND q.o_hcpt<=c.o_hmax AND q.o_vcpt>=c.o_vmin AND q.o_vcpt<=c.o_vmax);
n.o_hsv(0):=to_std_logic(q.o_hcpt>=c.o_hsstart AND q.o_hcpt<c.o_hsend);
n.o_vsv(0):=to_std_logic((q.o_vcpt=c.o_vsstart AND q.o_hcpt>=c.o_hsstart) OR (q.o_vcpt>c.o_vsstart AND q.o_vcpt<c.o_vsend) OR (q.o_vcpt=c.o_vsend AND q.o_hcpt<c.o_hsstart));
n.o_vss:=to_std_logic(q.o_vcpt_pre2>=c.o_vmin AND q.o_vcpt_pre2<=c.o_vmax);
n.o_hsv(1 TO 11):=q.o_hsv(0 TO 10); n.o_vsv(1 TO 11):=q.o_vsv(0 TO 10);
n.o_dev(1 TO 11):=q.o_dev(0 TO 10); n.o_pev(1 TO 11):=q.o_pev(0 TO 10); n.o_end(1 TO 11):=q.o_end(0 TO 10);
IF c.o_run='0' THEN n.o_hsv(2):='0'; n.o_vsv(2):='0'; n.o_dev(2):='0'; n.o_pev(2):='0'; n.o_end(2):='0'; END IF;
END IF;
n.o_vcpt_sync2:=q.o_vcpt_sync; n.o_vrr_min:=q.o_vcpt_sync2<c.o_vtotal;
n.o_vrr_min2:=q.o_vrr_min; n.o_vrr_max:=q.o_vcpt_sync2<c.o_vrrmax; n.o_vrr_max2:=q.o_vrr_max;
IF c.o_isync2='1' THEN n.o_vcpt_sync:=0; n.o_sync_max:=q.o_vrr_max2; IF q.o_vrr_min2 THEN n.o_sync:=true; END IF; END IF;
n.o_vcpt2:=q.o_vcpt_pre3;
n.o_vrr_sync:=c.o_vrr='1' AND (q.o_sync OR q.o_sync_max) AND q.o_vcpt2>=c.o_vdisp AND q.o_vcpt2<c.o_vsstart;
n.o_vrr_sync2:=q.o_vrr_sync;
IF c.AT_LOCAL_CONFIG AND c.at_config_retime='1' THEN
n.o_hcpt:=0;
IF c.vtotal>0 THEN n.o_vcpt_pre3:=c.vtotal-1; n.o_vcpt_pre2:=c.vtotal-1; n.o_vcpt_pre:=c.vtotal-1; n.o_vcpt:=c.vtotal-1; n.o_vcpt2:=c.vtotal-1;
ELSE n.o_vcpt_pre3:=0; n.o_vcpt_pre2:=0; n.o_vcpt_pre:=0; n.o_vcpt:=0; n.o_vcpt2:=0; END IF;
n.o_dev:=(OTHERS=>'0'); n.o_pev:=(OTHERS=>'0'); n.o_hsv:=(OTHERS=>'0'); n.o_vsv:=(OTHERS=>'0'); n.o_end:=(OTHERS=>'1');
n.o_vcpt_sync:=0; n.o_sync:=false; n.o_sync_max:=false; n.o_vrr_sync:=false; n.o_vrr_sync2:=false;
END IF;
RETURN n; END FUNCTION;

BEGIN
ref: ENTITY work.sweep_reference PORT MAP(clk,seed,s,observed_context,observed_reference);
dut: ENTITY work.sweep_candidate PORT MAP(clk,seed,s,observed_context,observed_candidate);
PROCESS
VARIABLE q,e : sweep_state; VARIABLE v : sweep_context;
VARIABLE rng : unsigned(31 DOWNTO 0):=x"2A351C81"; VARIABLE cases,edges : natural:=0;
IMPURE FUNCTION rand12 RETURN natural IS BEGIN
rng:=rng(30 DOWNTO 0) & (rng(31) XOR rng(21) XOR rng(1) XOR rng(0)); RETURN to_integer(rng(11 DOWNTO 0)); END;
PROCEDURE pulse IS BEGIN clk<='0'; WAIT FOR 1 ns; clk<='1'; WAIT FOR 1 ns; clk<='0'; WAIT FOR 1 ns; END;
PROCEDURE check IS BEGIN
s<=q; observed_context<=v; seed<='1'; pulse;
ASSERT observed_reference=q AND observed_candidate=q REPORT "Arbitrary-state seed differs" SEVERITY failure;
seed<='0';
FOR j IN 0 TO 3 LOOP
IF j>0 THEN v.AT_LOCAL_CONFIG:=rand12 MOD 2=1;
v.at_config_retime:=to_std_logic(rand12 MOD 2=1);
v.o_ce:=to_std_logic(rand12 MOD 2=1);
v.o_hdisp:=rand12;
v.o_hmax:=rand12;
v.o_hmin:=rand12;
v.o_hsend:=rand12;
v.o_hsstart:=rand12;
v.o_htotal:=rand12;
v.o_isync2:=to_std_logic(rand12 MOD 2=1);
v.o_run:=to_std_logic(rand12 MOD 2=1);
v.o_vdisp:=rand12;
v.o_vmax:=rand12;
v.o_vmin:=rand12;
v.o_vrr:=to_std_logic(rand12 MOD 2=1);
v.o_vrrmax:=rand12;
v.o_vsend:=rand12;
v.o_vsstart:=rand12;
v.o_vtotal:=rand12;
v.vtotal:=rand12; END IF;
observed_context<=v; e:=edge_oracle(q,v); pulse;
ASSERT observed_reference=e REPORT "Original complete process disagrees with independent edge oracle" SEVERITY failure;
ASSERT observed_candidate=e REPORT "Private candidate disagrees with independent edge oracle" SEVERITY failure;
q:=e; edges:=edges+1;
END LOOP; cases:=cases+1; END;
BEGIN
FOR i IN 0 TO 9999 LOOP
q.o_dev:=to_unsigned(rand12,12);
q.o_end:=to_unsigned(rand12,12);
q.o_hcpt:=rand12;
q.o_hsv:=to_unsigned(rand12,12);
q.o_pev:=to_unsigned(rand12,12);
q.o_sync:=rand12 MOD 2=1;
q.o_sync_max:=rand12 MOD 2=1;
q.o_vcpt:=rand12;
q.o_vcpt2:=rand12;
q.o_vcpt_pre:=rand12;
q.o_vcpt_pre2:=rand12;
q.o_vcpt_pre3:=rand12;
q.o_vcpt_sync:=rand12;
q.o_vcpt_sync2:=rand12;
q.o_vrr_max:=rand12 MOD 2=1;
q.o_vrr_max2:=rand12 MOD 2=1;
q.o_vrr_min:=rand12 MOD 2=1;
q.o_vrr_min2:=rand12 MOD 2=1;
q.o_vrr_sync:=rand12 MOD 2=1;
q.o_vrr_sync2:=rand12 MOD 2=1;
q.o_vss:=to_std_logic(rand12 MOD 2=1);
q.o_vsv:=to_unsigned(rand12,12);
v.AT_LOCAL_CONFIG:=rand12 MOD 2=1;
v.at_config_retime:=to_std_logic(rand12 MOD 2=1);
v.o_ce:=to_std_logic(rand12 MOD 2=1);
v.o_hdisp:=rand12;
v.o_hmax:=rand12;
v.o_hmin:=rand12;
v.o_hsend:=rand12;
v.o_hsstart:=rand12;
v.o_htotal:=rand12;
v.o_isync2:=to_std_logic(rand12 MOD 2=1);
v.o_run:=to_std_logic(rand12 MOD 2=1);
v.o_vdisp:=rand12;
v.o_vmax:=rand12;
v.o_vmin:=rand12;
v.o_vrr:=to_std_logic(rand12 MOD 2=1);
v.o_vrrmax:=rand12;
v.o_vsend:=rand12;
v.o_vsstart:=rand12;
v.o_vtotal:=rand12;
v.vtotal:=rand12;
-- Directed boundary cross-product starts from arbitrary complete state.
IF i<64 THEN
CASE i MOD 4 IS WHEN 0=>v.o_htotal:=0; q.o_hcpt:=4095;
WHEN 1=>v.o_htotal:=4095; q.o_hcpt:=4094;
WHEN 2=>v.o_htotal:=1; q.o_hcpt:=0;
WHEN OTHERS=>v.o_htotal:=4095; q.o_hcpt:=4093; END CASE;
v.o_ce:=to_std_logic((i/4) MOD 2=1); v.AT_LOCAL_CONFIG:=(i/8) MOD 2=1;
v.at_config_retime:=to_std_logic((i/16) MOD 2=1); v.o_isync2:=to_std_logic((i/32) MOD 2=1);
v.vtotal:=0;
END IF; check;
END LOOP;
REPORT "TRANSITION_PASS cases=" & integer'image(cases) & " edges=" & integer'image(edges);
stop; WAIT; END PROCESS;
END;
