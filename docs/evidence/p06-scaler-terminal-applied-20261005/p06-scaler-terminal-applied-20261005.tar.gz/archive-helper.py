import hashlib,io,json,sys,tarfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
label=sys.argv[1]
sha=lambda b:hashlib.sha256(b).hexdigest()
if label=='scaler-applied':
    stem='p06-scaler-terminal-applied-20261005'
    dirs=[stem,stem+'-initial-diagnostics',stem+'-tab-diagnostic-binding']
    receipt=json.loads((root/'build'/stem/'receipt.json').read_text())
    assert receipt['status']=='OSWEEP_TERMINAL_COMPARE_EQUIVALENCE_PASS'
    sources=receipt['sources_sha256']
    assert receipt['reference_matches_private_proof']
    interpretation='Applied one predicate only; exhaustive/native/formal equivalence and full-file baseline-relative VHDL analysis PASS. No fit or full-regression claim.'
elif label=='selector-rejected':
    stem='p06-selector-entry-bound-proof-20261005'
    dirs=[stem]
    receipt=json.loads((root/'build'/stem/'receipt.json').read_text())
    sources={'vendor/spk286/rtl/spk286_selector.sv':receipt['source_sha256'],
             'build/prove-p06-selector-entry-bound-20261005.py':receipt['helper_sha256']}
    comparison=json.loads((root/'build'/stem/'mapping-comparison.json').read_text())
    assert comparison['result']['candidate']['depth']['all']['descriptor_limit_valid']>comparison['result']['reference']['depth']['all']['descriptor_limit_valid']
    interpretation='NOT_ADOPTED: exact arithmetic equivalence PASS, but generic comparator depth9 to12 despite2 fewer gates. Production CPU unchanged. Generic mapping is not an FPGA fit.'
else: raise ValueError(label)
dest=root/'docs/evidence'/stem
dest.mkdir(exist_ok=False)
payload={}
for dirname in dirs:
    directory=root/'build'/dirname
    assert directory.resolve().is_relative_to(root/'build') and not directory.is_symlink()
    for p in directory.rglob('*'):
        assert not p.is_symlink()
        if p.is_file():payload['trials/'+dirname+'/'+p.relative_to(directory).as_posix()]=p.read_bytes()
for name,digest in sources.items():
    data=(root/name).read_bytes()
    assert sha(data)==digest,name
    payload['source/'+name]=data
payload['archive-helper.py']=Path(__file__).read_bytes()
archive=dest/(stem+'.tar.gz')
with tarfile.open(archive,'w:gz',compresslevel=9) as target:
    for name,data in payload.items():
        member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;member.mtime=0
        target.addfile(member,io.BytesIO(data))
with tarfile.open(archive) as target:
    assert set(target.getnames())==set(payload)
    for member in target:assert target.extractfile(member).read()==payload[member.name]
for name,digest in sources.items():assert sha((root/name).read_bytes())==digest,name
(dest/'receipt.json').write_bytes((root/'build'/stem/'receipt.json').read_bytes())
if label=='selector-rejected':(dest/'mapping-comparison.json').write_bytes((root/'build'/stem/'mapping-comparison.json').read_bytes())
manifest={'status':'SEALED_SOURCE_BOUND_BOUNDED_PROOF','archive':archive.name,'sha256':sha(archive.read_bytes()),
    'bytes':archive.stat().st_size,'members':len(payload),'source_sha256':sources,
    'verification':'Every member read back equal before cleanup','interpretation':interpretation}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',newline='\n')
(dest/'cleanup.json').write_text(json.dumps({'status':'PENDING','targets':['build/'+d for d in dirs],
    'archive_sha256':manifest['sha256']},indent=2)+'\n',newline='\n')
print('BOUNDED_PROOF_SEALED',label,len(payload),archive.stat().st_size)
