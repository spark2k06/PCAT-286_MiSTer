module miter(input[15:0] selector,table_limit,input[23:0] table_base);
wire [12:0] old_index;
wire [0:0] old_table_indicator;
wire [1:0] old_rpl;
wire [0:0] old_null_selector;
wire [20:0] old_descriptor_end;
wire [0:0] old_descriptor_limit_valid;
wire [0:0] old_descriptor_selector_valid;
wire [23:0] old_descriptor_address;
wire [0:0] old_descriptor_address_carry;
wire [12:0] new_index;
wire [0:0] new_table_indicator;
wire [1:0] new_rpl;
wire [0:0] new_null_selector;
wire [20:0] new_descriptor_end;
wire [0:0] new_descriptor_limit_valid;
wire [0:0] new_descriptor_selector_valid;
wire [23:0] new_descriptor_address;
wire [0:0] new_descriptor_address_carry;
reference old_instance(.selector(selector),.table_limit(table_limit),.table_base(table_base),.index(old_index),.table_indicator(old_table_indicator),.rpl(old_rpl),.null_selector(old_null_selector),.descriptor_end(old_descriptor_end),.descriptor_limit_valid(old_descriptor_limit_valid),.descriptor_selector_valid(old_descriptor_selector_valid),.descriptor_address(old_descriptor_address),.descriptor_address_carry(old_descriptor_address_carry));
candidate new_instance(.selector(selector),.table_limit(table_limit),.table_base(table_base),.index(new_index),.table_indicator(new_table_indicator),.rpl(new_rpl),.null_selector(new_null_selector),.descriptor_end(new_descriptor_end),.descriptor_limit_valid(new_descriptor_limit_valid),.descriptor_selector_valid(new_descriptor_selector_valid),.descriptor_address(new_descriptor_address),.descriptor_address_carry(new_descriptor_address_carry));
always @* begin
assert(old_index == new_index);
assert(old_table_indicator == new_table_indicator);
assert(old_rpl == new_rpl);
assert(old_null_selector == new_null_selector);
assert(old_descriptor_end == new_descriptor_end);
assert(old_descriptor_limit_valid == new_descriptor_limit_valid);
assert(old_descriptor_selector_valid == new_descriptor_selector_valid);
assert(old_descriptor_address == new_descriptor_address);
assert(old_descriptor_address_carry == new_descriptor_address_carry);
end
endmodule
