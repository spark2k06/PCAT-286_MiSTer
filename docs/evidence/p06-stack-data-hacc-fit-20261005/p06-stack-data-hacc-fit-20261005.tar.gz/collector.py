#!/usr/bin/env python3
"""Seal the stack DATA/HACC fit after exact input binding and original STA.

No synthesis, simulation, source editing, cleanup or full regression is run.
Every directory and proof receipt is supplied explicitly; old collectors and
sealed packets remain unchanged.
"""
import argparse
from collections import Counter
import hashlib
import io
import json
from pathlib import Path
import re
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[2]
CORNERS = {'7_slow_1100mv_100c', '7_slow_1100mv_-40c',
           'MIN_fast_1100mv_100c', 'MIN_fast_1100mv_-40c'}
APPROVED_BINDER_V1 = '89f0e3d2cd9cce43802228b75b59837edf91c98085b99db748f33fba75d310cc'
INFRA = ROOT / 'build/p06-stack-data-hacc-fit-binding-20261005'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def require(ok, message):
    if not ok:
        raise ValueError(message)


def minimum(summary, kind, group='global'):
    return min((v[kind][group]['tool_worst_slack_ns'], c) for c, v in summary['corners'].items())


def bind_report_inventory(summary, directory):
    actual = {p.relative_to(directory).as_posix(): sha(p)
              for p in directory.rglob('*') if p.is_file()}
    require(actual == summary['report_hashes'], 'STA reports differ from summarized inventory: ' + str(directory))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--label', default='stack-data-hacc')
    parser.add_argument('--fit', type=Path, required=True)
    parser.add_argument('--original-sdc', type=Path, required=True)
    parser.add_argument('--baseline', type=Path,
                        default=ROOT / 'build/p06-null-segment-allfeatures-20261005-v1')
    parser.add_argument('--baseline-packet', type=Path,
                        default=ROOT / 'docs/evidence/p06-null-segment-fit-20261005')
    parser.add_argument('--binding-before', type=Path, required=True)
    parser.add_argument('--binding-after', type=Path, required=True)
    parser.add_argument('--source-binder', type=Path,
                        default=INFRA / 'bind_sources_v2.py')
    parser.add_argument('--mirror-transition-plan', type=Path,
                        default=INFRA / 'transition-plan.v1.json')
    parser.add_argument('--before-source-binder', type=Path,
                        help='explicitly retain the original binder if the read-only helper was tightened after freeze')
    parser.add_argument('--proof-packet', action='append', type=Path, required=True)
    parser.add_argument('--include-proof-archives', action='store_true',
                        help='normally keep existing sealed archives by SHA reference to avoid duplicating bulk')
    parser.add_argument('--launch-file', action='append', type=Path, default=[])
    parser.add_argument('--dest', type=Path, required=True)
    args = parser.parse_args()
    for key in ('baseline', 'baseline_packet', 'binding_before', 'binding_after', 'source_binder', 'mirror_transition_plan'):
        setattr(args, key, getattr(args, key).resolve())
    args.before_source_binder = (args.before_source_binder or args.source_binder).resolve()
    require(re.fullmatch(r'[a-z0-9-]+', args.label), 'Unsafe label')
    fit, original, dest = args.fit.resolve(), args.original_sdc.resolve(), args.dest.resolve()
    require(fit.is_relative_to(ROOT / 'build') and original.is_relative_to(ROOT / 'build'), 'Run outside owned build/')
    require(dest.is_relative_to(ROOT) and not dest.exists(), 'Evidence destination must be fresh inside repo')
    require((fit / 'completed.txt').is_file() and (original / 'completed.txt').is_file(), 'STA incomplete')
    require('Full Compilation was successful. 0 errors' in (fit / 'compile.log').read_text(), 'Compile failed')
    require('All original fitted artifacts verified unchanged after original-SDC STA' in
            (original / 'original-artifacts-verified.log').read_text(), 'Original-SDC preservation not sealed')
    sys.path.insert(0, str(fit / 'work/scripts'))
    from audit_fixed50_fit import resources, fitted_seed, GROUPS
    from analyze_pcat_resources import parse
    from check_sync_microcode_image import analyze_compiled_image
    from summarize_at_50mhz_timing import parse_report, table_rows
    current, base, osdc = read(fit / 'summary.json'), read(args.baseline / 'summary.json'), read(original / 'summary.json')
    manifest = read(fit / 'manifest.json')
    bind_report_inventory(current, fit / 'timing')
    bind_report_inventory(osdc, original / 'reports')
    require(set(current['corners']) == set(osdc['corners']) == CORNERS, 'Four-corner scope mismatch')
    require(current['snapshot_manifest_sha256'] == sha(fit / 'manifest.json'), 'Summary snapshot binding mismatch')
    require(current['system_sdc_overlay_sha256'] is None, 'Candidate STA used an overlay')
    require(current['container_image'] == (fit / 'container-image.txt').read_text().strip(), 'Container identity mismatch')
    before, after = read(args.binding_before), read(args.binding_after)
    require(sha(args.source_binder) == sha(args.before_source_binder) == APPROVED_BINDER_V1,
            'Unreviewed source binder version')
    for binding, helper in ((before, args.before_source_binder), (after, args.source_binder)):
        require(binding['status'] == 'NEXT_FIT_SOURCE_PROOF_BINDINGS_PASS', 'Input proof binder not accepted')
        require(binding['full_regression'] == 'USER_PAUSE_AFTER_CURRENT_FIT_NOT_RUN', 'Latest pause instruction not reflected')
        require(sha(helper) in binding['input_sha256'].values(),
                'Selected source binder was not used for this receipt')
        require(sha(args.mirror_transition_plan) in binding['input_sha256'].values(),
                'Named mirror-transition plan was not bound by this receipt')
    require(before['vendor_ledger_sha256'] == after['vendor_ledger_sha256'] == sha(fit / 'vendor-ledger.json'),
            'Fit does not retain the exact frozen canonical ledger')
    before_inputs, after_inputs = (Counter(binding['input_sha256'].values()) for binding in (before, after))
    before_inputs.subtract([sha(args.before_source_binder)])
    after_inputs.subtract([sha(args.source_binder)])
    require(before_inputs == after_inputs, 'Proof, ledger, helper or receipt content changed during fit')
    require(before['sources_sha256'] == manifest['source_sha256'], 'Precompile binding differs from frozen snapshot')
    effective = {n: sha(fit / 'work' / n) for n in manifest['source_sha256']}
    require(after['sources_sha256'] == effective, 'Postcompile binding differs from actual effective sources')
    for name, digest in before['sources_sha256'].items():
        if effective[name] != digest:
            require(name == 'build_id.v' and after['controlled_build_date'] ==
                    {'snapshot': digest, 'compiled': effective[name]}, 'Unexpected effective source delta')
    for key in ('exact_source_transitions', 'canonical_vendor_imports', 'vendor_files',
                'named_nonfitted_mirror_changes', 'unchanged_constraints_settings', 'placement_seed',
                'vendor_ledger_sha256', 'generation_manifest_sha256'):
        require(before[key] == after[key], 'Proof/input identity changed during fit: ' + key)
    expected_counts = {(c, g, k) for c in CORNERS for g in GROUPS for k in ('setup', 'hold')}
    expected_counts |= {(c, 'global', k) for c in CORNERS for k in ('recovery', 'removal')}
    counts = [r.split() for r in (fit / 'timing/path_counts.txt').read_text().splitlines()]
    require(len(counts) == len(expected_counts) and {tuple(r[:3]) for r in counts} == expected_counts,
            'Timing selector/corner inventory differs')
    for c in CORNERS:
        require(set(current['corners'][c]['setup']) == set(GROUPS) and
                set(current['corners'][c]['hold']) == set(GROUPS), 'Missing timing group')
        for kind in ('loops', 'latches', 'generated_clock', 'virtual_clock', 'partial_multicycle',
                     'multicycle_consistency', 'pll_cross_check', 'uncertainty'):
            require(current['corner_metadata'][c]['check_timing_issues'][kind] == 0, 'Timing health issue: ' + kind)
        require(current['corner_metadata'][c]['unclocked_node_families'] ==
                base['corner_metadata'][c]['unclocked_node_families'], 'Inherited unclocked scope changed')
        require(current['corner_metadata'][c]['check_timing_issues'] ==
                base['corner_metadata'][c]['check_timing_issues'], 'Declared platform timing coverage changed')
        for kind in ('setup', 'hold', 'recovery', 'removal'):
            for group, value in current['corners'][c][kind].items():
                report = fit / 'timing' / c / (group + '_' + kind + '.rpt')
                text = report.read_text(); actual = parse_report(report)
                require(actual['top_paths'] and abs(actual['top_paths'][0]['slack_ns'] - value['tool_worst_slack_ns']) < 1e-6,
                        'Raw fitted slack differs from summary: ' + str(report))
                if group == 'global':
                    command = text.split('Tcl Command:', 1)[1].split('Options:', 1)[0]
                    require(not re.search(r'-(from|to)(?:_clock)?\s', command), 'Global timing report is filtered')
    inventory = (fit / 'timing/collections.txt').read_text().splitlines()
    prior_inventory = (args.baseline / 'timing/collections.txt').read_text().splitlines()
    for prefix in ('macro=', 'clock='):
        require(sorted(x for x in inventory if x.startswith(prefix)) ==
                sorted(x for x in prior_inventory if x.startswith(prefix)), 'Features/clocks changed')
    sdc = fit / 'work/SYSTEM.sdc'
    require(effective['SYSTEM.sdc'] == read(args.baseline / 'manifest.json')['source_sha256']['SYSTEM.sdc'],
            'Production SDC changed')
    require('set_min_delay -from $at_dac_write_index -to $at_dac_write_address 0.500' in sdc.read_text(),
            'Supplemental palette requirement changed')
    require('AT SDC DAC minimum route: 8 sources, 288 endpoints' in (fit / 'compile.log').read_text(),
            'Compile DAC selector binding missing')
    mapped = set(re.findall(r'AT SDC DAC minimum route: (\d+) sources, (\d+) endpoints',
                            (fit / 'timing.log').read_text()))
    require(len(mapped) == 1 and all(int(a) >= 8 and int(b) >= 288 for a, b in mapped), 'Mapped DAC scope missing')
    baseline_packet_manifest = read(args.baseline_packet / 'manifest.json')
    baseline_archive = args.baseline_packet / baseline_packet_manifest['archive']
    require(sha(baseline_archive) == baseline_packet_manifest['sha256'], 'Baseline archive changed')
    with tarfile.open(baseline_archive) as packet:
        baseline_result = json.loads(packet.extractfile('result.json').read())
        baseline_overlay = packet.extractfile('original-sdc/overlay/SYSTEM.sdc').read()
        prior_original = json.loads(packet.extractfile('original-sdc/summary.json').read())
    for c in CORNERS:
        require(osdc['corner_metadata'][c]['check_timing_issues'] == prior_original['corner_metadata'][c]['check_timing_issues'] and
                osdc['corner_metadata'][c]['unclocked_node_families'] == prior_original['corner_metadata'][c]['unclocked_node_families'],
                'Original-SDC declared platform scope changed')
        for kind in ('setup', 'hold', 'recovery', 'removal'):
            for group, value in osdc['corners'][c][kind].items():
                report = original / 'reports' / c / (group + '_' + kind + '.rpt')
                text = report.read_text(); actual = parse_report(report)
                require(actual['top_paths'] and abs(actual['top_paths'][0]['slack_ns'] - value['tool_worst_slack_ns']) < 1e-6,
                        'Raw original-SDC slack differs: ' + str(report))
                if group == 'global':
                    command = text.split('Tcl Command:', 1)[1].split('Options:', 1)[0]
                    require(not re.search(r'-(from|to)(?:_clock)?\s', command), 'Original global report filtered')
    coverage = {}
    for label, directory in (('fit', fit/'timing'), ('original-sdc', original/'reports')):
        coverage[label] = {}
        for c in CORNERS:
            raw = (directory/c/'unconstrained.rpt').read_text()
            values = {r[0]: [int(v) for v in r[1:]] for r in table_rows(raw.split('; Clock Status Summary',1)[0])
                      if len(r) == 3 and r[1].isdigit() and r[2].isdigit()}
            require(values.get('Illegal Clocks') == values.get('Unconstrained Clocks') == [0,0], 'Illegal/unconstrained clock')
            coverage[label][c] = values
    original_manifest = read(original / 'manifest.json')
    require(original_manifest['parent_fit'] == fit.name and
            original_manifest['source_sha256'] == manifest['source_sha256'] and
            original_manifest['head'] == manifest['head'],
            'Original-SDC STA is not bound to this source snapshot')
    require(osdc['snapshot_manifest_sha256'] == sha(original / 'manifest.json') and
            osdc['container_image'] == current['container_image'] ==
            (original / 'container-image.txt').read_text().strip(),
            'Original-SDC STA summary or container identity mismatch')
    for name, digest in original_manifest['preserved_fitted_artifacts_sha256'].items():
        require(sha(fit / 'work' / name) == digest, 'Fitted artifact changed during original-SDC audit')
    require(osdc['system_sdc_overlay_sha256'] == original_manifest['system_sdc_overlay_sha256'] ==
            sha(original / 'overlay/SYSTEM.sdc') == hashlib.sha256(baseline_overlay).hexdigest(),
            'Original-SDC overlay differs from independently sealed seed2 reference')
    rom = analyze_compiled_image(fit)
    rows = parse(fit / 'work/output_files/PCAT-286.fit.rpt')
    cpu = next(row for row in rows if row['path'].endswith('|spk286_profiled:cpu'))
    resource = resources(fit / 'work/output_files')
    resource['cpu'] = {k: cpu[k]['inclusive'] for k in ('alm_needed', 'alm_placed', 'registers', 'io_registers', 'memory_bits', 'm10k')}
    seed = fitted_seed((fit / 'work/PCAT-286.qsf').read_text(), (fit / 'work/output_files/PCAT-286.fit.rpt').read_text())
    require(seed == before['placement_seed'], 'Fitted seed differs from bound seed')
    margins = {k: minimum(current, k) for k in ('setup', 'hold', 'recovery', 'removal')}
    positive = all(v[0] > 0 for v in margins.values()) and all(
        minimum(current, kind, group)[0] > 0 for kind in ('setup', 'hold') for group in GROUPS)
    positive = positive and all(minimum(osdc, kind)[0] > 0
                                for kind in ('setup', 'hold', 'recovery', 'removal'))
    sta = (fit/'work/output_files/PCAT-286.sta.summary').read_text(encoding='latin-1')
    sta_rows = [(m[1],float(m[2]),float(m[3])) for m in re.finditer(
        r'Type\s*:\s*(.+?)\nSlack\s*:\s*(-?[\d.]+)\nTNS\s*:\s*(-?[\d.]+)',sta)]
    require(len(sta_rows) > 50 and any('Minimum Pulse Width' in n for n,_,_ in sta_rows), 'Complete physical STA summary/pulse rows absent')
    positive = positive and all(slack > 0 and tns >= 0 for _,slack,tns in sta_rows)
    rbf = fit / 'work/output_files/PCAT-286.rbf'
    result = {'status': 'ALL_REPORTED_MARGINS_POSITIVE' if positive else 'TIMING_OPEN_CHECK_REPORTED_MARGINS',
              'label': args.label, 'candidate': fit.relative_to(ROOT).as_posix(), 'seed': seed,
              'baseline': args.baseline.relative_to(ROOT).as_posix(), 'baseline_resources': baseline_result['resources'],
              'resources': resource, 'allgroups': {k: {g: minimum(current, k, g) for g in GROUPS} for k in ('setup', 'hold')},
              'with_extra_route_requirement': margins, 'same_fit_original_sdc':
              {k: minimum(osdc, k) for k in ('setup', 'hold', 'recovery', 'removal')},
              'binding_before_sha256': sha(args.binding_before), 'binding_after_sha256': sha(args.binding_after),
              'source_binder_sha256': {'before': sha(args.before_source_binder), 'after': sha(args.source_binder)},
              'binder_update_scope': 'UNCHANGED exact helper and inputs; BUILD_DATE is the sole permitted effective source delta',
              'exact_source_transitions': after['exact_source_transitions'], 'frozen_source_count': len(effective),
              'canonical_vendor_imports': after['canonical_vendor_imports'], 'compiled_rom': rom,
              'unconstrained_coverage': coverage, 'sta_summary_sha256': sha(fit/'work/output_files/PCAT-286.sta.summary'),
              'sta_summary_rows': [{'type':n,'slack_ns':s,'tns_ns':t} for n,s,t in sta_rows],
              'rbf': {'path': rbf.relative_to(ROOT).as_posix(), 'bytes': rbf.stat().st_size, 'sha256': sha(rbf)},
              'full_regression': 'USER_PAUSE_AFTER_CURRENT_FIT_NOT_RUN',
              'hardware': 'NOT_RUN', 'acceptance': 'This packet does not claim full regression or hardware validation.'}
    files = {'collector.py': Path(__file__), 'source-binder.py': args.source_binder,
             'source-binder.before.py': args.before_source_binder,
             'parent-source-binder.py': INFRA/'parent_binder_frozen.py',
             'mirror-input-transition-plan.json': args.mirror_transition_plan,
             'input-bindings.before.json': args.binding_before, 'input-bindings.after.json': args.binding_after,
             'compiled-rom/' + rom['mif']: fit / 'work' / rom['mif']}
    for name in effective:
        files['effective-source/' + name] = fit / 'work' / name
    for label, run in [('fit', fit), ('original-sdc', original)]:
        for path in run.rglob('*'):
            if not path.is_file():
                continue
            parts = path.relative_to(run).parts
            if parts[0] == 'work' and (len(parts) < 3 or parts[1] != 'output_files' or path.suffix in ('.rbf', '.sof', '.smsg')):
                continue
            files[label + '/' + path.relative_to(run).as_posix()] = path
    proof_identities = {}
    for folder in args.proof_packet:
        pm = read(folder / 'manifest.json')
        spec = pm['archive']
        name,digest = (spec['name'],spec['sha256']) if isinstance(spec,dict) else (spec,pm['sha256'])
        archive = folder / name
        require(sha(archive) == digest, 'New proof archive mismatch')
        proof_identities[folder.name] = {'sha256': digest,
                                        'archive': archive.resolve().relative_to(ROOT).as_posix(),
                                        'included': args.include_proof_archives}
        for path in folder.iterdir():
            if path.is_file() and (path.suffix in ('.json', '.md') or
                                  args.include_proof_archives and path.suffix == '.gz'):
                files['proof/' + folder.name + '/' + path.name] = path
    result['new_proof_archives_sha256'] = proof_identities
    for path in args.launch_file:
        files['launch/' + path.name] = path
    dest.mkdir(parents=True)
    (dest / 'result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
    (dest / 'hierarchy.json').write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8', newline='\n')
    files.update({'result.json': dest / 'result.json', 'hierarchy.json': dest / 'hierarchy.json'})
    bindings = {name: {'sha256': sha(path), 'bytes': path.stat().st_size} for name, path in files.items()}
    archive = dest / ('p06-' + args.label + '-fit-20261005.tar.gz')
    with tarfile.open(archive, 'w:gz', compresslevel=6) as target:
        for name, path in sorted(files.items()):
            data = path.read_bytes()
            require(sha(path) == bindings[name]['sha256'], 'Archive input changed: ' + name)
            info = tarfile.TarInfo(name)
            info.size, info.mtime, info.mode = len(data), 0, 0o644
            target.addfile(info, io.BytesIO(data))
    with tarfile.open(archive) as target:
        require(set(target.getnames()) == set(files), 'Archive membership differs')
        for member in target:
            data = target.extractfile(member).read()
            require(hashlib.sha256(data).hexdigest() == bindings[member.name]['sha256'] and
                    len(data) == bindings[member.name]['bytes'] and data == files[member.name].read_bytes(),
                    'Archive readback differs: ' + member.name)
    require({n: sha(fit / 'work' / n) for n in effective} == effective, 'Effective fitted source changed while sealing')
    (dest / 'manifest.json').write_text(json.dumps({'status': 'SEALED_EXACT_SOURCE_BOUND_FIT_AND_ORIGINAL_SDC_STA',
        'archive': archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size,
        'members': len(files), 'members_sha256': bindings, 'frozen_head': manifest['head'],
        'fitted_source_count': len(effective), 'canonical_vendor_imports': after['canonical_vendor_imports'],
        'rbf': result['rbf'], 'full_regression': result['full_regression'],
        'verification': 'Every archived member read back equal before cleanup'}, indent=2) + '\n', encoding='utf-8', newline='\n')
    (dest / 'cleanup.json').write_text(json.dumps({'status': 'PENDING', 'archive_sha256': sha(archive),
        'rbf_sha256': result['rbf']['sha256'], 'instruction': 'Preserve complete source snapshot until same-source full regression is frozen; no deletion by this collector.'}, indent=2) + '\n', encoding='utf-8', newline='\n')
    print('NEW_FIT_SEALED', args.label, result['status'], len(files), archive.stat().st_size)


if __name__ == '__main__':
    main()
