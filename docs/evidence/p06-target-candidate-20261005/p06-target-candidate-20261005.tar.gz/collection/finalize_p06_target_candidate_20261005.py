from pathlib import Path
import hashlib
import json
import re
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'build/p06-target-handoff-allfeatures-20261005-v2'
DEST = ROOT / 'docs/evidence/p06-target-candidate-20261005'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', newline='\n')

assert not DEST.exists() or not any(DEST.iterdir())
DEST.mkdir(exist_ok=True)
snapshot = json.loads((RUN / 'manifest.json').read_text())
generated_during_flow = {}
for name, digest in snapshot['source_sha256'].items():
    after = sha(RUN / 'work' / name)
    if after != digest:
        assert name == 'build_id.v', name
        assert (RUN / 'work' / name).read_text().strip() == '`define BUILD_DATE "261005"'
        assert 'clock format' in (RUN / 'work/sys/build_id.tcl').read_text()
        generated_during_flow[name] = {'before_sha256': digest, 'after_sha256': after,
                                      'generator': 'sys/build_id.tcl', 'reason': 'standard compile-flow date macro'}
generation = json.loads((ROOT / 'vendor/spk286/rtl/timed/generation.json').read_text())
for name, digest in generation['sources_sha256'].items():
    assert sha(ROOT / name) == digest, name
    assert sha(RUN / 'work' / name) == digest, name
for name, digest in generation['generated_sha256'].items():
    assert sha(ROOT / 'vendor/spk286/rtl/timed' / name) == digest, name
    assert sha(RUN / 'work/vendor/spk286/rtl/timed' / name) == digest, name

summary = (RUN / 'work/output_files/PCAT-286.fit.summary').read_text()
def resource(pattern):
    return int(re.search(pattern, summary).group(1).replace(',', ''))
rows = json.loads((RUN / 'hierarchy-resources.json').read_text())['entities']
cpu = next(row for row in rows if row['entity'] == 'spk286_machine_cpu')
resources = {
    'equivalent_alms': resource(r'Logic utilization \(in ALMs\) : ([\d,]+)'),
    'placed_alms': int(rows[0]['alm_placed']['inclusive']),
    'registers': resource(r'Total registers : ([\d,]+)'),
    'memory_bits': resource(r'Total block memory bits : ([\d,]+)'),
    'm10k': resource(r'Total RAM Blocks : ([\d,]+)'),
    'dsp': resource(r'Total DSP Blocks : ([\d,]+)'),
    'plls': resource(r'Total PLLs : ([\d,]+)'),
}
resources['placed_alms_percent'] = 100 * resources['placed_alms'] / 41910
cpu_resources = {key: cpu[key]['inclusive'] for key in ('alm_needed', 'alm_placed', 'registers', 'io_registers', 'memory_bits', 'm10k', 'dsp')}
baseline = json.loads((ROOT / 'build/p06-ready-chain-allfeatures-20261004-v1/fitted-resources.json').read_text())
timing = json.loads((RUN / 'summary.json').read_text())
worst = {}
for kind in ('setup', 'hold'):
    for group in ('global', 'clk50_internal', 'cpu', 'sdram_input', 'sdram_output'):
        values = [(corner, data[kind][group]['tool_worst_slack_ns']) for corner, data in timing['corners'].items()
                  if data[kind][group]['tool_worst_slack_ns'] is not None]
        corner, value = min(values, key=lambda item: item[1])
        worst[f'{group}_{kind}'] = {'corner': corner, 'slack_ns': value}
fitted = {
    'status': 'NEW_RBF_GENERATED_SETUP_NOT_CLOSED_HARDWARE_PENDING',
    'resources': resources, 'cpu_resources': cpu_resources,
    'baseline_run': 'build/p06-ready-chain-allfeatures-20261004-v1',
    'resource_delta_vs_ready_chain': {key: value-baseline['resources'][key] for key, value in resources.items()},
    'cpu_delta_vs_ready_chain': {key: value-baseline['cpu_resources'][key] for key, value in cpu_resources.items()},
    'timing_worst': worst,
    'rbf_sha256': sha(RUN / 'work/output_files/PCAT-286.rbf'),
    'rbf_bytes': (RUN / 'work/output_files/PCAT-286.rbf').stat().st_size,
    'report_sha256': sha(RUN / 'work/output_files/PCAT-286.fit.rpt'),
    'fit_summary_sha256': sha(RUN / 'work/output_files/PCAT-286.fit.summary'),
    'source_manifest_sha256': sha(RUN / 'manifest.json'),
    'scope': 'Same all-features configuration, seed 1, physical 50 MHz. OPL2 enabled. No hardware or timing-closure acceptance claim.'
}
save(RUN / 'fitted-resources.json', fitted)
save(DEST / 'fitted-resources.json', fitted)
save(DEST / 'baseline-resources.json', baseline)

files = {}
def add(path, name):
    assert path.is_file(), path
    assert name not in files, name
    files[name] = path
for name in snapshot['source_sha256']:
    add(RUN / 'work' / name, 'source/' + name)
for name in ('manifest.json', 'tracked.patch', 'git-status.txt', 'container-image.txt',
             'project-check.log', 'profile-check.log', 'compile-started.txt', 'compile.log',
             'bitstreams.sha256', 'rbf-info.txt', 'timing.log', 'summary.json',
             'hierarchy-resources.json', 'fitted-resources.json'):
    add(RUN / name, 'fit/' + name)
for path in sorted((RUN / 'timing').rglob('*')):
    if path.is_file(): add(path, 'fit/timing/' + path.relative_to(RUN / 'timing').as_posix())
for path in sorted((RUN / 'work/output_files').iterdir()):
    if path.suffix in ('.rpt', '.summary'):
        add(path, 'fit/output_files/' + path.name)
compat = ROOT / 'build/p06-target-compat-all-20261005-v2'
for path in sorted(compat.rglob('*')):
    if path.is_file() and not any(part == 'obj' for part in path.relative_to(compat).parts):
        if path.suffix in ('.log', '.json', '.sv', '.txt'):
            add(path, 'compatibility/' + path.relative_to(compat).as_posix())
machine = ROOT / 'build/p06-target-machine-profiles-20261005-v1'
for path in sorted(machine.iterdir()):
    if path.is_file(): add(path, 'machine/' + path.name)
components = ROOT / 'build/p06-target-components-20261005-v2'
for path in sorted(components.rglob('*')):
    if path.is_file() and not any(part.endswith('-verilator') for part in path.relative_to(components).parts):
        if path.suffix in ('.log', '.json', '.sv', '.ys'):
            add(path, 'components-before-shared-leaf-fold/' + path.relative_to(components).as_posix())
for label in ('p06-target-components-20261005-v1', 'p06-target-compat-focused-20261005-v1',
              'p06-target-compat-all-20261005-v1', 'p06-target-handoff-allfeatures-20261005-v1'):
    directory = ROOT / 'build' / label
    if directory.exists():
        for path in sorted(directory.rglob('*')):
            if path.is_file() and path.suffix in ('.log', '.json') and path.stat().st_size < 500000:
                add(path, 'superseded/' + label + '/' + path.relative_to(directory).as_posix())
for path in sorted((ROOT / 'build').glob('p06-target-*-driver.log')):
    add(path, 'drivers/' + path.name)
sync = ROOT / 'build/p06-standalone-sync-20261005'
for path in sorted(sync.iterdir()):
    if path.is_file(): add(path, 'standalone-sync/' + path.name)
add(Path(__file__), 'collection/finalize_p06_target_candidate_20261005.py')
archive = DEST / 'p06-target-candidate-20261005.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=6) as out:
    for name, path in sorted(files.items()): out.add(path, arcname=name, recursive=False)
identities = {name: {'sha256': sha(path), 'bytes': path.stat().st_size} for name, path in sorted(files.items())}
with tarfile.open(archive, 'r:gz') as check:
    members = check.getmembers()
    assert {member.name for member in members} == set(identities)
    for member in members:
        assert member.isfile()
        raw = check.extractfile(member).read()
        assert hashlib.sha256(raw).hexdigest() == identities[member.name]['sha256'], member.name
        assert len(raw) == identities[member.name]['bytes']
save(DEST / 'manifest.json', {
    'status': 'SEALED_NEW_RBF_AND_DIRECTED_RESULTS_NO_FULL_REGRESSION_CLAIM',
    'archive': archive.name, 'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size,
    'members_verified': len(identities), 'files': identities,
    'source_identity': 'Frozen compile inputs verified, with the standard build-date macro transformation declared separately; current generator inputs and generated CPU match the fit snapshot.',
    'generated_during_compile_flow': generated_during_flow,
    'compatibility_scope': 'Recovered 177 Icarus + 56 Verilator completed run records / 22 complete MAX raw-stream comparisons. Not the unfinished 26-bank matrix. IOPL 6 MHz separately PASS in the diagnosis packet.',
    'regression': 'USER_DEFERRED',
    'excluded': 'Quartus databases, compiled objects and simulator binaries. RBF/SOF retained separately under the fit run output_files.'
})
print('CANDIDATE_PACKET_SEALED', len(identities), 'members', archive.stat().st_size, 'bytes')
print(json.dumps({'resources': resources, 'cpu_resources': cpu_resources, 'worst': worst}, indent=2))
