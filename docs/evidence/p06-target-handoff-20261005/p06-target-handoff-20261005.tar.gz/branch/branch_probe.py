"""Source-bound historical target-handoff comparison; all generated files stay beside this file.

Run in WSL with the repository root as cwd. The original COM is copied into
every image. Standalone branch probes do not replace or calibrate T286REF.
"""
from pathlib import Path
import csv
import hashlib
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
from trace_p06_r0_ideal import sources, run, sha

TOP = 'p06_branch_probe_tb'

def generate():
    original = ROOT / 'docs/evidence/p06-timing-reference-20261003/T286REF.COM'
    com = original.read_bytes()
    if sha(original) != '006a7be0bd962859bf929e6b0d6678c400607461ed095c9e164789acf05f2643':
        raise RuntimeError('Unchanged COM guard failed')
    cases = []
    def emit(name, bootstrap, patches, branch_ip, target_ip, target_bytes, expected_retirements):
        image = bytearray([0xF4] * 65536)
        image[256:256+len(com)] = com
        image[0x40:0x40+len(bootstrap)] = bootstrap
        for ip, data in patches.items(): image[ip:ip+len(data)] = data
        path = OUT / (name + '.hex')
        path.write_text('\n'.join(f'{b:02x}' for b in image) + '\n')
        cases.append({'name': name, 'image': path, 'branch_ip': branch_ip,
                      'target_ip': target_ip, 'target_hex': target_bytes.hex(),
                      'target_length': len(target_bytes), 'expected_retirements': expected_retirements})
    # CLI; MOV SP,FF00; AX/BX/DX/DI/CX matching T286REF; near JMP probe.
    setup = bytes.fromhex('fabc00ffb83412bb7856babc9abff0deb9020039c0')
    jump_ip = 0x40+len(setup)
    setup += b'\xe9' + ((0x480-jump_ip-3) & 65535).to_bytes(2,'little')
    for branch, opcode in [('je',0x74), ('jmp',0xEB), ('loop',0xE2)]:
        for length in range(1,7):
            target = (bytes.fromhex('40') if length == 1 else
                      bytes.fromhex('89d8') if length == 2 else
                      b'\x3e'*(length-3) + bytes.fromhex('b83412'))
            for odd in (0,1):
                ip = 0x500+odd
                emit(f'{branch}-len{length}-a{odd}', setup,
                     {0x480: bytes([opcode, ip-0x482]), ip: target+b'\xf4'},
                     0x480, ip, target, 1)
    for kernel, ip, length in [('baseline',0x488,3),('b0',0x499,13)]:
        setup = bytearray.fromhex('fabc00ffb83412bb7856babc9abff0deb90001')
        call_ip=0x40+len(setup)
        setup += b'\xe8'+((ip-call_ip-3)&65535).to_bytes(2,'little')+b'\xf4'
        expected = bytes.fromhex('e2fec3') if kernel=='baseline' else bytes.fromhex('39c07502740140eb0190e2f4c3')
        if com[ip-256:ip-256+length] != expected: raise RuntimeError('Original kernel guard')
        emit(kernel, setup, {}, ip, ip, expected, 256*(1 if kernel=='baseline' else 5))
    fixture = (ROOT/'sim/spk286_timing/spk286_r0_profile_trace_tb.sv').read_text()
    fixture = fixture[:fixture.index('    always @(posedge clk) begin : observer')]
    fixture = fixture.replace('module spk286_r0_profile_trace_tb;', f'module {TOP};')
    fixture = fixture.replace('.timing_read_wait_event(1\'b0), .ready(bus_valid), .data_in,',
                              '.timing_read_wait_event(1\'b0), .ready(cpu_ready), .data_in,')
    # Replace immediate READY peer by an accepted one-edge RAM transaction.
    fixture = fixture[:fixture.index('    // Supply ideal READY data')]
    fixture += r'''
    wire cpu_ready;
    wire [23:0] at_address;
    wire [15:0] at_data_out;
    wire [1:0] at_byte_enable;
    wire at_command_valid, at_write, at_accepted, at_completed;
    wire [3:0] bridge_state;
    wire bridge_error, bridge_deadline;
    logic ram_response_q = 0;
    logic [15:0] ram_data_q;
    logic ram_write_q;
    spk286_at_bus_bridge u_bridge (
        .clk, .reset, .cpu_sample_edge(1'b1), .timing_historical(historical),
        .timing_cpu_boundary(cpu_boundary), .timing_deadline_miss(bridge_deadline),
        .cpu_bus_valid(bus_valid), .cpu_address(address), .cpu_data_out(data_out),
        .cpu_data_oe(data_oe), .cpu_bus_write(bus_write), .cpu_bus_bhe_n(bus_bhe_n),
        .cpu_bus_status(bus_status), .cpu_bus_lock(bus_lock), .memory_drain_pending(1'b0),
        .cpu_memory_word_capable(1'b1), .cpu_io_word_capable(1'b0), .cpu_ready, .cpu_data_in(data_in),
        .at_valid(), .at_command_valid, .at_owner(), .at_cycle_class(), .at_address,
        .at_a0(), .at_bhe_n(), .at_byte_enable, .at_data_out, .at_data_oe(), .at_write,
        .at_io(), .at_inta(), .at_code_fetch(), .at_lock(), .at_accepted, .at_completed,
        .at_response_valid(), .at_accept(at_command_valid), .at_ready(ram_response_q),
        .at_read_data(ram_data_q), .at_read_data_valid(ram_response_q && !ram_write_q),
        .bridge_idle(), .debug_state(bridge_state), .retained_io_command(), .retained_io_address(),
        .retained_io_write(), .retained_io_byte_enable(), .retained_io_data_out(),
        .retained_io_data_oe(), .protocol_error(bridge_error)
    );
    always @(posedge clk) begin
        if (reset) ram_response_q <= 0;
        else begin
            if (at_completed) ram_response_q <= 0;
            if (at_accepted) begin
                ram_response_q <= 1;
                ram_write_q <= at_write;
                ram_data_q <= {memory_byte({at_address[23:1],1'b1}),memory_byte({at_address[23:1],1'b0})};
                if (at_write && at_address < 24'h010000) begin
                    if (at_byte_enable[0]) low_ram[{at_address[15:1],1'b0}] <= at_data_out[7:0];
                    if (at_byte_enable[1]) low_ram[{at_address[15:1],1'b1}] <= at_data_out[15:8];
                end
            end
        end
    end
    integer target_ip, target_length, expected_retirements, measured_retirements = 0;
    integer tick = 0, branch_seen = 0, target_seen = 0;
    always @(posedge clk) begin
        if (!reset) begin
            cycle = cycle + 1;
            if (cpu_boundary) tick = tick + 1;
            if (u_cpu.cpu.opcode_start && debug_cs == 16'h106E && debug_ip == 16'(kernel_ip)) branch_seen = 1;
            if (u_cpu.cpu.profile_start_interval && debug_cs == 16'h106E && debug_ip == 16'(target_ip)) target_seen = 1;
            if (u_cpu.cpu.profile_retire_fire && instruction_ip >= 16'(kernel_ip) &&
                instruction_ip < 16'(kernel_ip + kernel_length - ((kind == "baseline" || kind == "b0") ? 1 : 0))) measured_retirements = measured_retirements + 1;
            if (trace_fd != 0)
                $fdisplay(trace_fd, "%0d,%0d,%0d,%0d,%04h,%04h,%04h,%02h,%02h,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%06h,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%032h,%04h",
                    cycle,tick,active,cpu_boundary,debug_cs,debug_ip,instruction_ip,u_cpu.cpu.opcode_q,
                    u_cpu.cpu.queue_consume_data,u_cpu.cpu.opcode_start,u_cpu.cpu.profile_start_interval,
                    u_cpu.cpu.profile_metadata_valid,u_cpu.cpu.profile_metadata_clocks,
                    u_cpu.cpu.profile_retire_fire,u_cpu.cpu.raw_retired,u_cpu.cpu.profile_elapsed,
                    u_cpu.cpu.profile_scheduled,u_cpu.cpu.profile_implementation_extension,
                    u_cpu.cpu.internal_redirect,u_cpu.cpu.instruction_bytes,
                    u_cpu.cpu.queue_count,u_cpu.cpu.queue_consume_valid,u_cpu.cpu.queue_consume_ready,
                    bus_valid,bus_status,address,cpu_ready,u_cpu.cpu.fetch_bus_valid,
                    u_cpu.cpu.fetch_bus_ready,u_cpu.cpu.fetch_response_valid,u_cpu.cpu.fetch_response_ready,
                    at_accepted,at_completed,bridge_state,u_bridge.timing_active_q,u_bridge.timing_tc_q,
                    u_bridge.timing_admission_window_q,bridge_deadline,u_cpu.cpu.profile_metadata_estimated,debug_gpr,debug_flags);
            if (u_cpu.cpu.internal_redirect && u_cpu.cpu.profile_requires_target_length &&
                !u_cpu.cpu.event_active && (u_cpu.cpu.raw_retired || u_cpu.cpu.profile_retire_fire))
                $fatal(1,"Source redirect overlaps its END/public retirement");
            if (u_cpu.cpu.profile_target_pending && u_cpu.cpu.opcode_start)
                $fatal(1,"Target dispatched before source boundary");
            if (shutdown || unsupported_opcode || microcode_fault || control_error || bridge_error)
                $fatal(1,"Production dependency failure");
            if (u_cpu.cpu.profile_retire_fire && u_cpu.cpu.opcode_q == 8'hF4) begin
                if (!branch_seen || !target_seen || measured_retirements != expected_retirements)
                    $fatal(1,"Work count mismatch %0d expected %0d",measured_retirements,expected_retirements);
                if ((kind == "baseline" || kind == "b0") &&
                    (debug_gpr[79:64] !== 16'hFF00 || debug_gpr[31:16] !== 16'h0000 ||
                     debug_gpr[15:0] !== 16'h1234 || debug_gpr[63:48] !== 16'h5678 ||
                     debug_gpr[47:32] !== 16'h9ABC || debug_gpr[127:112] !== 16'hDEF0))
                    $fatal(1,"Exact T286REF architectural mismatch");
                $display("P06_BRANCH_PROBE_PASS profile=%0d kind=%s fabric=%0d ticks=%0d",active,kind,cycle,tick);
                $fclose(trace_fd); $finish;
            end
        end
    end
    initial begin
        if (!$value$plusargs("PROFILE=%d",profile_arg) || !$value$plusargs("KERNEL_IP=%d",kernel_ip) ||
            !$value$plusargs("KERNEL_LENGTH=%d",kernel_length) || !$value$plusargs("TARGET_IP=%d",target_ip) ||
            !$value$plusargs("TARGET_LENGTH=%d",target_length) || !$value$plusargs("EXPECTED=%d",expected_retirements) ||
            !$value$plusargs("KIND=%s",kind) || !$value$plusargs("IMAGE=%s",image_path) ||
            !$value$plusargs("TRACE=%s",trace_path)) $fatal(1,"Missing arguments");
        requested = 3'(profile_arg);
        for (integer i=0;i<65536;i=i+1) low_ram[i]=0;
        $readmemh(image_path,code);
        trace_fd=$fopen(trace_path,"w");
        $fdisplay(trace_fd,"edge,tick,profile,boundary,cs,ip,instruction_ip,opcode,queue_byte,opcode_start,start_interval,metadata_valid,metadata_clocks,retire_fire,raw_retired,elapsed,scheduled,extension,redirect,instruction_bytes,queue_count,consume_valid,consume_ready,bus_valid,bus_status,address,ready,fetch_bus_valid,fetch_bus_ready,fetch_response_valid,fetch_response_ready,at_accepted,at_completed,bridge_state,bridge_active,bridge_tc,admission_window,bridge_deadline,estimated,gpr,flags");
        repeat(8) @(negedge clk); reset=0;
    end
    initial begin #20_000_000; $fatal(1,"Probe watchdog"); end
endmodule
'''
    bench = OUT / (TOP+'.sv')
    bench.write_text(fixture)
    return cases,bench

def summarize(path,case):
    rows=list(csv.DictReader(path.open()))
    def starts(ip): return [r for r in rows if r['start_interval']=='1' and int(r['cs'],16)==0x106e and int(r['ip'],16)==ip]
    def retires(ip): return [r for r in rows if r['retire_fire']=='1' and int(r['instruction_ip'],16)==ip]
    start=starts(case['branch_ip'])[0]
    if case['name'] in ('baseline','b0'):
        final=[r for r in rows if r['retire_fire']=='1' and r['opcode']=='e2'][-1]
        return {'admission_edge':int(start['edge']),'final_loop_edge':int(final['edge']),
                'fabric_clocks':int(final['edge'])-int(start['edge']),
                'processor_boundaries':int(final['tick'])-int(start['tick'])}
    end=retires(case['branch_ip'])[0]
    target=starts(case['target_ip'])[0]
    target_end=retires(case['target_ip'])[0]
    redirects=[r for r in rows if r['redirect']=='1' and int(start['edge'])<=int(r['edge'])<=int(end['edge'])]
    refill=[r for r in rows if r['fetch_bus_ready']=='1' and int(r['address'],16)>=0x106e0+case['target_ip'] and int(r['address'],16)<0x106e0+case['target_ip']+10 and int(r['edge'])>int(redirects[0]['edge'])]
    consumed=[r for r in rows if r['consume_ready']=='1' and r['consume_valid']=='1' and int(target['edge'])<=int(r['edge'])<=int(target_end['edge'])]
    return {'branch_admission_edge':int(start['edge']),'branch_retirement_edge':int(end['edge']),
            'branch_processor_clocks':int(end['tick'])-int(start['tick']),
            'branch_schedule':int(end['scheduled']),'branch_estimated':int(end['estimated']),
            'redirect_edge':int(redirects[0]['edge']),
            'first_target_bus_ready_edge':int(refill[0]['edge']) if refill else None,
            'target_opcode_edge':int(target['edge']),'target_retirement_edge':int(target_end['edge']),
            'target_schedule':int(target_end['scheduled']),
            'last_target_byte_consumed_edge':int(consumed[-1]['edge']),
            'pair_processor_clocks':int(target_end['tick'])-int(start['tick'])}

def main():
    cases,bench=generate()
    src=sources()[:-1]+[ROOT/'rtl/spk286_integration/spk286_at_bus_bridge.sv',bench]
    extra=[ROOT/p for p in ['rtl/spk286_timing/spk286_instruction_timing.sv','rtl/spk286_timing/spk286_instruction_schedule.sv','vendor/spk286/rtl/timed/spk286_profiled.sv','vendor/spk286/rtl/timed/spk286_profiled_events.sv','vendor/spk286/rtl/spk286_prefetch_queue.sv', 'rtl/spk286_timing/spk286_target_handoff.sv', 'rtl/spk286_timing/spk286_target_replay.sv', 'vendor/spk286/rtl/spk286_encoding_preview.sv', 'scripts/trace_p06_r0_ideal.py', 'docs/evidence/p06-timing-reference-20261003/T286REF.COM']]
    inputs={str(p.relative_to(ROOT)):sha(p) for p in src+extra+[Path(__file__),OUT/'prior_branch_receipt.json']}
    receipt={'status':'RUNNING','scope':'Historical target-handoff candidate: production CPU and production bridge, one-edge accepted RAM peer, no downstream cache/refresh/DOS/PIT. Original COM is unchanged; standalone probes are separate synthetic programs.',
             'sources':inputs,'runs':[],'comparisons':[]}
    for simulator in ('iverilog','verilator'):
        if simulator=='iverilog':
            executable=OUT/'branch-iv'
            run(['iverilog','-g2012','-I.','-s',TOP,'-o',executable]+src,OUT/'branch-build.log')
            execute=['vvp',executable]
        else:
            obj=OUT/'branch-verilator-obj'
            run(['verilator','--binary','--timing','--assert','-I.','--top-module',TOP,
                 '-Wno-fatal','-j','2','--Mdir',obj,'-o','branch-vlt']+src,OUT/'branch-verilator-build.log')
            execute=[obj/'branch-vlt']
        for profile in (1,4,6,7):
            for case in cases:
                name=f'{simulator}-p{profile}-{case["name"]}'
                trace=OUT/(name+'.csv'); log=OUT/(name+'.log')
                run(execute+[f'+PROFILE={profile}',f'+KERNEL_IP={case["branch_ip"]}',
                     f'+KERNEL_LENGTH={3 if case["name"]=="baseline" else 13 if case["name"]=="b0" else 2}',
                     f'+TARGET_IP={case["target_ip"]}',f'+TARGET_LENGTH={case["target_length"]}',
                     f'+EXPECTED={case["expected_retirements"]}',f'+KIND={case["name"]}',
                     f'+IMAGE={case["image"]}',f'+TRACE={trace}'],log,timeout=45)
                if 'P06_BRANCH_PROBE_PASS' not in log.read_text(): raise RuntimeError('Missing pass')
                item={k:v for k,v in case.items() if k!='image'}
                item.update({'simulator':simulator,'profile':profile,'trace':str(trace.relative_to(ROOT)),
                             'trace_sha256':sha(trace),**summarize(trace,case)})
                receipt['runs'].append(item)
                (OUT/'branch-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
            print(f'{simulator} profile {profile} completed {len(cases)} branch probes',flush=True)
    for profile in (1,4,6,7):
        for case in cases:
            rows=[list(csv.DictReader((OUT/f'{simulator}-p{profile}-{case["name"]}.csv').open()))
                  for simulator in ('iverilog','verilator')]
            if len(rows[0])!=len(rows[1]): raise RuntimeError('Dual row count mismatch')
            differences=[]
            unused_head_fields={'queue_byte','metadata_valid','metadata_clocks','scheduled','estimated'}
            for a,b in zip(*rows):
                delta={k:[a[k],b[k]] for k in a if a[k]!=b[k]}
                if delta:
                    empty_head=all(r['consume_valid']=='0' and r['opcode_start']=='0' and r['start_interval']=='0' for r in (a,b))
                    if not empty_head or not set(delta)<=unused_head_fields:
                        raise RuntimeError(f'Dual applicable trace mismatch: {case["name"]} edge{a["edge"]} {delta}')
                    differences.append({'edge':int(a['edge']),'unused_empty_queue_fields':delta})
            receipt['comparisons'].append({'profile':profile,'name':case['name'],'rows':len(rows[0]),
                                           'all_applicable_fields_identical':True,'empty_queue_differences':differences})
    for name,digest in inputs.items():
        if sha(ROOT/name)!=digest: raise RuntimeError('Source changed during diagnosis: '+name)
    prior=json.loads((OUT/'prior_branch_receipt.json').read_text())
    comparisons=[]
    for simulator in ('iverilog','verilator'):
        for profile in (1,4,6,7):
            measured={r['name']:r for r in receipt['runs'] if r['simulator']==simulator and r['profile']==profile}
            previous={r['name']:r for r in prior['runs'] if r['simulator']==simulator and r['profile']==profile}
            old_net=(previous['b0']['processor_boundaries']-previous['baseline']['processor_boundaries'])/256
            new_net=(measured['b0']['processor_boundaries']-measured['baseline']['processor_boundaries'])/256
            for case in cases:
                if case['name'] in ('baseline','b0'): continue
                now=measured[case['name']]
                minimum=8 if case['name'].startswith('loop-') else 7+case['target_length']
                if now['branch_processor_clocks'] < minimum:
                    raise RuntimeError('Missing Intel source target allowance: '+str(now))
                if case['name'].startswith('loop-') and now['branch_schedule'] != 8:
                    raise RuntimeError('LOOP acquired undocumented target charge: '+str(now))
            comparisons.append({'simulator':simulator,'profile':profile,'prior_body_net':old_net,
                                'candidate_body_net':new_net,'Intel_body_table_reference':23,
                                'baseline_before':previous['baseline']['processor_boundaries'],
                                'baseline_after':measured['baseline']['processor_boundaries']})
    receipt['prior_comparison']=comparisons
    receipt['archived_builder_sha256']='6c99465e27bf9ded81318d3ae9fa8a9d3a446de463f1bcae895d635404d0b691'
    receipt['status']='P06_BRANCH_TARGET_HANDOFF_DUAL_PASS' 
    (OUT/'branch-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(receipt['status'],flush=True)

if __name__=='__main__': main()
