`timescale 1ns/1ps
// Passive timing diagnosis: unmodified production CPU/profile, ideal RAM.
// The image retains the complete assembled T286REF segment and its kernels.
// A reset-vector jump and an executable bootstrap replace DOS initialization.
module p06_branch_probe_tb;
    logic clk = 0;
    always #10 clk = ~clk;
    logic reset = 1;
    logic [2:0] requested;
    wire [2:0] active;
    wire pending, historical, phase_enable, phase_two, cpu_boundary;
    wire [23:0] address;
    wire [15:0] data_out;
    logic [15:0] data_in;
    wire data_oe, bus_valid, bus_write, bus_bhe_n, bus_lock, hlda;
    wire [3:0] bus_status;
    wire halted, shutdown, control_error, unsupported_opcode, microcode_fault;
    wire operand_blocked, event_completed, retired;
    wire [15:0] debug_cs, debug_ip, debug_flags, instruction_ip;
    wire [127:0] debug_gpr;
    logic [7:0] code [0:65535];
    logic [7:0] low_ram [0:65535];
    integer profile_arg, iterations, kernel_ip, kernel_length, trace_fd;
    integer cycle = 0, first_edge = -1, last_edge = -1, loops_retired = 0;
    integer kernel_retirements = 0, kernel_extensions = 0;
    logic in_kernel = 0;
    string image_path, trace_path, kind;

    spk286_at_cpu_profile u_profile (
        .clk, .reset, .requested, .active, .pending, .historical,
        .phase_enable, .phase_two, .cpu_boundary
    );
    spk286_machine_cpu u_cpu (
        .clk, .reset, .execute_enable(!reset), .historical_enable(historical),
        .cpu_boundary, .timing_read_wait_event(1'b0), .ready(cpu_ready), .data_in,
        .intr(1'b0), .nmi(1'b0), .hold_request(1'b0), .address, .data_out,
        .data_oe, .bus_valid, .bus_write, .bus_bhe_n, .bus_status, .bus_lock, .hlda,
        .halted, .shutdown, .control_error, .unsupported_opcode, .microcode_fault,
        .operand_blocked, .event_completed, .debug_event_vector(), .debug_event_kind(),
        .debug_opcode(), .debug_cs, .debug_cs_base(), .debug_ip, .debug_flags, .debug_gpr,
        .debug_segment_selectors(), .debug_instruction_retired(retired),
        .debug_instruction_ip(instruction_ip), .fetch_blocked(), .debug_fetch_cursor(),
        .debug_micro_pc(), .debug_micro_entry(), .debug_micro_instruction(),
        .debug_micro_active(), .debug_prefetch_count(), .debug_bus_state(), .debug_biu_detail()
    );

    function automatic logic [7:0] memory_byte(input logic [23:0] location);
        if (location >= 24'h0106E0 && location < 24'h0206E0)
            memory_byte = code[16'(location - 24'h0106E0)];
        else if (location < 24'h010000)
            memory_byte = low_ram[location[15:0]];
        else case (location)
            24'hFFFFF0: memory_byte = 8'hEA;
            24'hFFFFF1: memory_byte = 8'h40;
            24'hFFFFF2: memory_byte = 8'h00;
            24'hFFFFF3: memory_byte = 8'h6E;
            24'hFFFFF4: memory_byte = 8'h10;
            default: memory_byte = 8'hF4;
        endcase
    endfunction

    wire cpu_ready;
    wire [23:0] at_address;
    wire [15:0] at_data_out;
    wire [1:0] at_byte_enable;
    wire at_command_valid, at_write, at_accepted, at_completed;
    wire [3:0] bridge_state;
    wire bridge_error, bridge_deadline;
    logic ram_response_q = 0;
    logic [15:0] ram_data_q;
    logic ram_write_q;
    spk286_at_bus_bridge u_bridge (
        .clk, .reset, .cpu_sample_edge(1'b1), .timing_historical(historical),
        .timing_cpu_boundary(cpu_boundary), .timing_deadline_miss(bridge_deadline),
        .cpu_bus_valid(bus_valid), .cpu_address(address), .cpu_data_out(data_out),
        .cpu_data_oe(data_oe), .cpu_bus_write(bus_write), .cpu_bus_bhe_n(bus_bhe_n),
        .cpu_bus_status(bus_status), .cpu_bus_lock(bus_lock), .memory_drain_pending(1'b0),
        .cpu_memory_word_capable(1'b1), .cpu_io_word_capable(1'b0), .cpu_ready, .cpu_data_in(data_in),
        .at_valid(), .at_command_valid, .at_owner(), .at_cycle_class(), .at_address,
        .at_a0(), .at_bhe_n(), .at_byte_enable, .at_data_out, .at_data_oe(), .at_write,
        .at_io(), .at_inta(), .at_code_fetch(), .at_lock(), .at_accepted, .at_completed,
        .at_response_valid(), .at_accept(at_command_valid), .at_ready(ram_response_q),
        .at_read_data(ram_data_q), .at_read_data_valid(ram_response_q && !ram_write_q),
        .bridge_idle(), .debug_state(bridge_state), .retained_io_command(), .retained_io_address(),
        .retained_io_write(), .retained_io_byte_enable(), .retained_io_data_out(),
        .retained_io_data_oe(), .protocol_error(bridge_error)
    );
    always @(posedge clk) begin
        if (reset) ram_response_q <= 0;
        else begin
            if (at_completed) ram_response_q <= 0;
            if (at_accepted) begin
                ram_response_q <= 1;
                ram_write_q <= at_write;
                ram_data_q <= {memory_byte({at_address[23:1],1'b1}),memory_byte({at_address[23:1],1'b0})};
                if (at_write && at_address < 24'h010000) begin
                    if (at_byte_enable[0]) low_ram[{at_address[15:1],1'b0}] <= at_data_out[7:0];
                    if (at_byte_enable[1]) low_ram[{at_address[15:1],1'b1}] <= at_data_out[15:8];
                end
            end
        end
    end
    integer target_ip, target_length, expected_retirements, measured_retirements = 0;
    integer tick = 0, branch_seen = 0, target_seen = 0;
    always @(posedge clk) begin
        if (!reset) begin
            cycle = cycle + 1;
            if (cpu_boundary) tick = tick + 1;
            if (u_cpu.cpu.opcode_start && debug_cs == 16'h106E && debug_ip == 16'(kernel_ip)) branch_seen = 1;
            if (u_cpu.cpu.profile_start_interval && debug_cs == 16'h106E && debug_ip == 16'(target_ip)) target_seen = 1;
            if (u_cpu.cpu.profile_retire_fire && instruction_ip >= 16'(kernel_ip) &&
                instruction_ip < 16'(kernel_ip + kernel_length - ((kind == "baseline" || kind == "b0") ? 1 : 0))) measured_retirements = measured_retirements + 1;
            if (trace_fd != 0)
                $fdisplay(trace_fd, "%0d,%0d,%0d,%0d,%04h,%04h,%04h,%02h,%02h,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%06h,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%032h,%04h",
                    cycle,tick,active,cpu_boundary,debug_cs,debug_ip,instruction_ip,u_cpu.cpu.opcode_q,
                    u_cpu.cpu.queue_consume_data,u_cpu.cpu.opcode_start,u_cpu.cpu.profile_start_interval,
                    u_cpu.cpu.profile_metadata_valid,u_cpu.cpu.profile_metadata_clocks,
                    u_cpu.cpu.profile_retire_fire,u_cpu.cpu.raw_retired,u_cpu.cpu.profile_elapsed,
                    u_cpu.cpu.profile_scheduled,u_cpu.cpu.profile_implementation_extension,
                    u_cpu.cpu.internal_redirect,u_cpu.cpu.instruction_bytes,
                    u_cpu.cpu.queue_count,u_cpu.cpu.queue_consume_valid,u_cpu.cpu.queue_consume_ready,
                    bus_valid,bus_status,address,cpu_ready,u_cpu.cpu.fetch_bus_valid,
                    u_cpu.cpu.fetch_bus_ready,u_cpu.cpu.fetch_response_valid,u_cpu.cpu.fetch_response_ready,
                    at_accepted,at_completed,bridge_state,u_bridge.timing_active_q,u_bridge.timing_tc_q,
                    u_bridge.timing_admission_window_q,bridge_deadline,u_cpu.cpu.profile_metadata_estimated,debug_gpr,debug_flags);
            if (u_cpu.cpu.internal_redirect && u_cpu.cpu.profile_requires_target_length &&
                !u_cpu.cpu.event_active && (u_cpu.cpu.raw_retired || u_cpu.cpu.profile_retire_fire))
                $fatal(1,"Source redirect overlaps its END/public retirement");
            if (u_cpu.cpu.profile_target_pending && u_cpu.cpu.opcode_start)
                $fatal(1,"Target dispatched before source boundary");
            if (shutdown || unsupported_opcode || microcode_fault || control_error || bridge_error)
                $fatal(1,"Production dependency failure");
            if (u_cpu.cpu.profile_retire_fire && u_cpu.cpu.opcode_q == 8'hF4) begin
                if (!branch_seen || !target_seen || measured_retirements != expected_retirements)
                    $fatal(1,"Work count mismatch %0d expected %0d",measured_retirements,expected_retirements);
                if ((kind == "baseline" || kind == "b0") &&
                    (debug_gpr[79:64] !== 16'hFF00 || debug_gpr[31:16] !== 16'h0000 ||
                     debug_gpr[15:0] !== 16'h1234 || debug_gpr[63:48] !== 16'h5678 ||
                     debug_gpr[47:32] !== 16'h9ABC || debug_gpr[127:112] !== 16'hDEF0))
                    $fatal(1,"Exact T286REF architectural mismatch");
                $display("P06_BRANCH_PROBE_PASS profile=%0d kind=%s fabric=%0d ticks=%0d",active,kind,cycle,tick);
                $fclose(trace_fd); $finish;
            end
        end
    end
    initial begin
        if (!$value$plusargs("PROFILE=%d",profile_arg) || !$value$plusargs("KERNEL_IP=%d",kernel_ip) ||
            !$value$plusargs("KERNEL_LENGTH=%d",kernel_length) || !$value$plusargs("TARGET_IP=%d",target_ip) ||
            !$value$plusargs("TARGET_LENGTH=%d",target_length) || !$value$plusargs("EXPECTED=%d",expected_retirements) ||
            !$value$plusargs("KIND=%s",kind) || !$value$plusargs("IMAGE=%s",image_path) ||
            !$value$plusargs("TRACE=%s",trace_path)) $fatal(1,"Missing arguments");
        requested = 3'(profile_arg);
        for (integer i=0;i<65536;i=i+1) low_ram[i]=0;
        $readmemh(image_path,code);
        trace_fd=$fopen(trace_path,"w");
        $fdisplay(trace_fd,"edge,tick,profile,boundary,cs,ip,instruction_ip,opcode,queue_byte,opcode_start,start_interval,metadata_valid,metadata_clocks,retire_fire,raw_retired,elapsed,scheduled,extension,redirect,instruction_bytes,queue_count,consume_valid,consume_ready,bus_valid,bus_status,address,ready,fetch_bus_valid,fetch_bus_ready,fetch_response_valid,fetch_response_ready,at_accepted,at_completed,bridge_state,bridge_active,bridge_tc,admission_window,bridge_deadline,estimated,gpr,flags");
        repeat(8) @(negedge clk); reset=0;
    end
    initial begin #20_000_000; $fatal(1,"Probe watchdog"); end
endmodule
