#!/usr/bin/env python3
"""Transparent Verilator proxy; retire only this run's completed PCH files."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

OWNED = Path(__file__).resolve().parent
WORK = (OWNED / 'work').resolve()
args = sys.argv[1:]
result = subprocess.run(['/usr/bin/verilator', *args])
removed = []
if '--Mdir' in args:
    mdir = Path(args[args.index('--Mdir') + 1]).resolve()
    if WORK not in mdir.parents:
        raise RuntimeError(f'PCH directory outside owned workspace: {mdir}')
    for path in sorted(mdir.glob('*.gch')):
        resolved = path.resolve()
        if resolved.parent != mdir or path.is_symlink() or not path.is_file():
            raise RuntimeError('Unexpected PCH target')
        removed.append({'path': str(path.relative_to(OWNED)), 'bytes': path.stat().st_size})
        path.unlink()
with (OWNED / 'pch-cleanup.jsonl').open('a') as stream:
    stream.write(json.dumps({'time': time.time(), 'command': ['/usr/bin/verilator', *args],
                             'exit_code': result.returncode, 'removed': removed}) + '\n')
sys.exit(result.returncode)
