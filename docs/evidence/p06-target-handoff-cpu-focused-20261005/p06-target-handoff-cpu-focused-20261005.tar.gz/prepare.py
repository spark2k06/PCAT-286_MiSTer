from __future__ import annotations
import hashlib, json, os, pathlib, shutil, subprocess, tarfile

ROOT = pathlib.Path(__file__).resolve().parents[2]
OUT = pathlib.Path(__file__).resolve().parent
OLD = ROOT / 'docs/evidence/p06-target-handoff-regression-deferred-20261005'
manifest = json.loads((OLD / 'manifest.json').read_text())
def identity(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
names = set(subprocess.check_output(['git', 'ls-files', '-z', '--', 'vendor/spk286'], cwd=ROOT).decode().split('\0')) - {''}
names.update(('vendor/spk286/rtl/spk286_encoding_preview.sv', 'vendor/spk286/sim/unit/spk286_encoding_preview_tb.sv', 'vendor/spk286/sim/unit/spk286_length_boundary_tb.sv', 'vendor/spk286/tests/test_instruction_syntax.py'))
source = {}
for name in sorted(names):
    path = ROOT / name
    source[name] = identity(path)
    dest = OUT / 'snapshot' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, dest)
corpus_root = pathlib.Path('D:/GitHub/SPK286/.cache/singlestep-80286')
corpus = {name: identity(corpus_root / name) for name in manifest['partial_receipt']['inputs']['corpus']}
receipt = {'schema_version': 1, 'git_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip(), 'live_root': str(ROOT), 'source': source, 'corpus_root': str(corpus_root), 'corpus': corpus, 'compile_reuse': 'none; fresh owned snapshot and fresh standard builds', 'scope': 'bounded lint, reset/state dual simulation, 470 stack/control SingleStep smoke, Yosys sanity; full regression explicitly USER_DEFERRED'}
(OUT / 'input-manifest.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
with tarfile.open(OLD / manifest['archive']['name'], 'r:gz') as archive:
    for name in ('pch_cleanup_verilator.py', 'bin/verilator'):
        data = archive.extractfile(name).read()
        dest = OUT / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
print(json.dumps({'files': len(source), 'source_bytes': sum(value['bytes'] for value in source.values()), 'corpus_files': len(corpus), 'owned_path': str(OUT)}))
