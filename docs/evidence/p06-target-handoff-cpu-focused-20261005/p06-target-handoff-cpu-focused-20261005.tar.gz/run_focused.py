from __future__ import annotations
import hashlib, json, os, pathlib, subprocess, time

OUT = pathlib.Path(__file__).resolve().parent
ROOT = OUT.parents[1]
CPU = OUT / 'snapshot/vendor/spk286'
WORK = OUT / 'work'
INPUTS = json.loads((OUT / 'input-manifest.json').read_text())
CORPUS = pathlib.Path('/mnt/d/GitHub/SPK286/.cache/singlestep-80286')

def identity(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def tree_bytes(path):
    return sum(p.stat().st_size for p in path.rglob('*') if p.is_file())

def check_sources():
    differences = []
    for label, base in (('live', ROOT), ('snapshot', OUT / 'snapshot')):
        for name, expected in INPUTS['source'].items():
            # Independently owned new bench is not compiled by any selected stage.
            # Its sibling proof binds final live bytes; preserve frozen copy here.
            if label == 'live' and name == 'vendor/spk286/sim/unit/spk286_length_boundary_tb.sv':
                continue
            try:
                actual = identity(base / name)
            except OSError:
                actual = None
            if actual != expected:
                differences.append({'tree': label, 'name': name, 'expected': expected, 'actual': actual})
    for name, expected in INPUTS['corpus'].items():
        try:
            actual = identity(CORPUS / name)
        except OSError:
            actual = None
        if actual != expected:
            differences.append({'tree': 'readonly_corpus', 'name': name, 'expected': expected, 'actual': actual})
    return differences

WORK.mkdir(exist_ok=True)
(OUT / 'tmp').mkdir(exist_ok=True)
(OUT / 'logs').mkdir(exist_ok=True)
for script in (CPU / 'scripts').glob('*.sh'):
    script.chmod(0o755)
(OUT / 'bin/verilator').chmod(0o755)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', SPK286_BUILD_DIR=str(WORK), SPK286_BUILD_JOBS='2', SPK286_SINGLESTEP_ROOT=str(CORPUS), TMPDIR=str(OUT / 'tmp'), TMP=str(OUT / 'tmp'), TEMP=str(OUT / 'tmp'), PATH=str(OUT / 'bin') + os.pathsep + os.environ['PATH'])
stages = [
    ('lint', ['bash', 'scripts/lint.sh']),
    ('reset_verilator', ['bash', 'scripts/test_verilator.sh']),
    ('reset_iverilog', ['bash', 'scripts/test_iverilog.sh']),
    ('core_state_dual', ['bash', 'scripts/test_units.sh', 'both', 'spk286_core']),
    ('state_fixture', ['python3', '-B', '-m', 'tools.state_vectors']),
    ('state_cases', ['python3', '-B', '-m', 'tools.state_vectors', '--source', 'tests/fixtures/state_vectors.json']),
    ('stack_control_smoke', ['python3', '-B', '-m', 'tools.run_singlestep', '--stack-control', '--smoke']),
    ('yosys', ['bash', 'scripts/synth_check.sh']),
]
receipt = {'schema_version': 1, 'scope': INPUTS['scope'], 'inputs': INPUTS, 'compile_reuse': INPUTS['compile_reuse'], 'started_unix': time.time(), 'cwd': str(CPU), 'build_dir': str(WORK), 'runner_sha256': identity(pathlib.Path(__file__))['sha256'], 'pch_policy': 'transparent forwarding of all standard Verilator flags; delete only owned Mdir .gch after build process completion', 'stages': [], 'status': 'RUNNING', 'peak_owned_bytes': 0}
receipt['live_guard_exclusions'] = {'vendor/spk286/sim/unit/spk286_length_boundary_tb.sv': 'Independent sibling-owned fixture, not compiled or executed by these selected stages. Snapshot copy remains bound; sibling supplies separate source-bound focused proof.'}
receipt['tool_versions'] = {}
for name, command in [('python', ['python3', '--version']), ('verilator', ['/usr/bin/verilator', '--version']), ('iverilog', ['iverilog', '-V']), ('yosys', ['yosys', '-V'])]:
    result = subprocess.run(command, capture_output=True, text=True)
    receipt['tool_versions'][name] = {'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}

def save():
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')

receipt['source_identity_differences_before'] = check_sources()
if receipt['source_identity_differences_before']:
    receipt['status'] = 'SOURCE_DRIFT'
    save()
    raise SystemExit('Source drift before focused checks')
save()
try:
    for name, command in stages:
        started = time.time()
        print('START ' + name, flush=True)
        log_path = OUT / 'logs' / (name + '.log')
        with log_path.open('w') as log:
            child = subprocess.Popen(command, cwd=CPU, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            receipt['active'] = {'stage': name, 'pid': child.pid, 'process_group': child.pid, 'command': command}
            save()
            next_update = time.time() + 30
            while child.poll() is None:
                time.sleep(1)
                if time.time() >= next_update:
                    size = tree_bytes(OUT)
                    receipt['peak_owned_bytes'] = max(receipt['peak_owned_bytes'], size)
                    print(f'PROGRESS {name} elapsed={int(time.time()-started)}s own={size//1048576}MiB', flush=True)
                    next_update = time.time() + 30
                    save()
                    if size > 15 * 1024**3:
                        os.killpg(child.pid, 15)
                        raise RuntimeError('Owned temporary storage exceeded 15GiB')
            exit_code = child.wait()
        result = {'name': name, 'command': command, 'exit_code': exit_code, 'elapsed_seconds': round(time.time() - started, 3), 'log': str(log_path.relative_to(OUT)), 'log_identity': identity(log_path)}
        receipt['stages'].append(result)
        receipt.pop('active', None)
        save()
        print(f'END {name} exit={exit_code} elapsed={result["elapsed_seconds"]}s', flush=True)
        if exit_code:
            raise RuntimeError('Focused stage failed: ' + name)
    receipt['source_identity_differences_after'] = check_sources()
    receipt['status'] = 'PASS' if not receipt['source_identity_differences_after'] else 'SOURCE_DRIFT'
except BaseException as error:
    receipt['status'] = 'FAIL'
    receipt['error'] = repr(error)
finally:
    receipt['ended_unix'] = time.time()
    receipt['elapsed_seconds'] = round(receipt['ended_unix'] - receipt['started_unix'], 3)
    receipt['peak_owned_bytes'] = max(receipt['peak_owned_bytes'], tree_bytes(OUT))
    receipt['source_identity_differences_after'] = check_sources()
    save()
print('FOCUSED ' + receipt['status'], flush=True)
raise SystemExit(0 if receipt['status'] == 'PASS' else 1)
