from __future__ import annotations
import gzip, hashlib, io, json, pathlib, tarfile

OUT = pathlib.Path(__file__).resolve().parent
ROOT = OUT.parents[1]
EVIDENCE = ROOT / 'docs/evidence/p06-target-handoff-cpu-focused-20261005'
RECEIPT = json.loads((OUT / 'receipt.json').read_text())
if RECEIPT['status'] != 'PASS' or RECEIPT['source_identity_differences_before'] or RECEIPT['source_identity_differences_after']:
    raise SystemExit('Refusing accepted packet without all focused checks and source guards PASS')
def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

members = {}
for name in ('prepare.py', 'run_focused.py', 'seal.py', 'input-manifest.json', 'receipt.json', 'receipt-preflight-uncompiled-fixture-drift.json', 'receipt-proxy-path-failure.json', 'lint-proxy-path-failure.log', 'pch_cleanup_verilator.py', 'pch-cleanup.jsonl', 'bin/verilator'):
    path = OUT / name
    if path.exists():
        members[name] = path.read_bytes()
for folder in ('snapshot', 'logs', 'work/reports', 'work/state-vectors', 'work/singlestep'):
    for path in sorted((OUT / folder).rglob('*')):
        if path.is_file():
            members[path.relative_to(OUT).as_posix()] = path.read_bytes()
for path in sorted((OUT / 'work/verilator').rglob('*__verFiles.dat')):
    members[path.relative_to(OUT).as_posix()] = path.read_bytes()
for path in sorted((OUT / 'work/verilator').rglob('*__ver.d')):
    members[path.relative_to(OUT).as_posix()] = path.read_bytes()
for path in sorted((OUT / 'work').rglob('*.gch')):
    raise RuntimeError('Unexpected leftover PCH after transparent cleanup: ' + str(path))
EVIDENCE.mkdir(parents=True, exist_ok=False)
archive = EVIDENCE / 'p06-target-handoff-cpu-focused-20261005.tar.gz'
with archive.open('wb') as stream:
    with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(members.items()):
                item = tarfile.TarInfo(name)
                item.size = len(data)
                item.mode = 0o644
                item.mtime = 0
                tar.addfile(item, io.BytesIO(data))
member_ids = {name: identity(data) for name, data in members.items()}
with tarfile.open(archive, 'r:gz') as tar:
    if set(tar.getnames()) != set(member_ids):
        raise RuntimeError('Archive member set mismatch')
    for name, expected in member_ids.items():
        if identity(tar.extractfile(name).read()) != expected:
            raise RuntimeError('Archive readback mismatch: ' + name)
manifest = {'schema_version': 1, 'status': 'PASS_BOUNDED_CPU_CHECKS', 'full_regression': 'USER_DEFERRED; no full regression PASS claimed', 'archive': {'name': archive.name, **identity(archive.read_bytes())}, 'receipt': RECEIPT, 'members': member_ids, 'readback': 'all member bytes and archive SHA256 verified before temporary cleanup'}
(EVIDENCE / 'manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
print(json.dumps({'archive': manifest['archive'], 'members': len(members), 'temporary_bytes_before_cleanup': sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file())}))
