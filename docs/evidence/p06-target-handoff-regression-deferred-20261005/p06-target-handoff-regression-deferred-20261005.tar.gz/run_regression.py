#!/usr/bin/env python3
"""Fresh, frozen, source-bound execution of the actual vendor make regression."""
import hashlib
import json
import os
from pathlib import Path
import re
import selectors
import signal
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
CPU = OUT / 'snapshot/vendor/spk286'
CORPUS = Path('/mnt/d/GitHub/SPK286/.cache/singlestep-80286')
MANIFEST = json.loads((OUT / 'input-manifest.json').read_text())
WORK = (OUT / 'work').resolve()


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def identities(root, entries):
    return {name: {'bytes': (root / name).stat().st_size, 'sha256': sha(root / name)}
            for name in entries}


def main():
    if (OUT / 'regression.log').exists() or WORK.exists():
        raise RuntimeError('Fresh execution directory required')
    source = identities(ROOT, MANIFEST['source'])
    frozen = identities(OUT / 'snapshot', MANIFEST['source'])
    corpus = identities(CORPUS, MANIFEST['corpus'])
    if source != MANIFEST['source'] or frozen != source or corpus != MANIFEST['corpus']:
        raise RuntimeError('Prepared source or corpus changed before execution')
    WORK.mkdir()
    (OUT / 'tmp').mkdir()
    env = os.environ.copy()
    env.update(SPK286_BUILD_DIR=str(WORK), SPK286_BUILD_JOBS='2',
               SPK286_SINGLESTEP_ROOT=str(CORPUS), PYTHONDONTWRITEBYTECODE='1',
               TMPDIR=str(OUT / 'tmp'), TEMP=str(OUT / 'tmp'), TMP=str(OUT / 'tmp'))
    bindir = OUT / 'bin'
    bindir.mkdir()
    proxy = OUT / 'pch_cleanup_verilator.py'
    (bindir / 'verilator').write_text('#!/usr/bin/env bash\nexec python3 -B "' + str(proxy) + '" "$@"\n')
    (bindir / 'verilator').chmod(0o755)
    env['PATH'] = str(bindir) + os.pathsep + env['PATH']
    versions = {}
    for name, command in [('python', ['python3', '--version']), ('verilator', ['/usr/bin/verilator', '--version']),
                          ('iverilog', ['iverilog', '-V']), ('yosys', ['yosys', '-V']), ('make', ['make', '--version'])]:
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        if result.returncode:
            raise RuntimeError(f'Tool unavailable: {name}')
        versions[name] = result.stdout.splitlines()[0]
    started = time.time()
    receipt = {'schema_version': 1, 'status': 'RUNNING', 'started_unix': started,
               'command': ['make', 'regression'], 'snapshot_cwd': str(CPU),
               'build_dir': str(WORK), 'tool_versions': versions,
               'inputs': MANIFEST, 'runner_sha256': sha(Path(__file__)),
               'pch_proxy_sha256': sha(proxy), 'compile_reuse': 0,
               'scope': 'Literal vendor make regression; every compilation/execution fresh. Existing expand-down Verilator policy retained. This includes inherited SST smoke, not exhaustive physical corpus or PCAT/OS regression.',
               'pch_policy': 'Forward every Verilator argument unchanged to /usr/bin/verilator; delete only this run-owned Mdir .gch after compiler exits. No executable/object/functional-result reuse.'}
    receipt_path = OUT / 'receipt.json'
    receipt_path.write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'status': 'RUNNING', 'source_files': len(source), 'corpus_files': len(corpus),
                      'build_dir': str(WORK)}), flush=True)
    completed = {'icarus': set(), 'verilator': set()}
    markers = []
    progress_at = storage_at = time.time()
    peak_bytes = 0
    with (OUT / 'regression.log').open('w') as log:
        proc = subprocess.Popen(['make', 'regression'], cwd=CPU, env=env,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, bufsize=1, start_new_session=True)
        selector = selectors.DefaultSelector()
        selector.register(proc.stdout, selectors.EVENT_READ)
        halted = None
        while True:
            ready = selector.select(timeout=1)
            for _, _ in ready:
                line = proc.stdout.readline()
                if line:
                    log.write(line); log.flush()
                    match = re.search(r'sim/unit/(spk286_\w+)_tb\.sv.*(?:Verilog \$finish|\$finish called)', line)
                    if match:
                        completed['verilator' if 'Verilog $finish' in line else 'icarus'].add(match.group(1))
                    if 'PASS' in line or 'FAIL' in line or 'SKIP' in line or re.search(r'^Ran \d+ tests', line):
                        markers.append(line.rstrip())
                elif proc.poll() is not None:
                    selector.unregister(proc.stdout)
            now = time.time()
            if now - storage_at >= 60:
                temp_bytes = sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file())
                peak_bytes = max(peak_bytes, temp_bytes)
                if temp_bytes > 15 * 1024**3:
                    halted = 'OWNED_STORAGE_LIMIT'; os.killpg(proc.pid, signal.SIGTERM)
                storage_at = now
            if now - progress_at >= 60:
                progress = {'status': 'RUNNING', 'elapsed_minutes': round((now - started) / 60, 1),
                            'unit_finishes': {k: len(v) for k, v in completed.items()},
                            'last_marker': markers[-1] if markers else '', 'peak_owned_bytes': peak_bytes}
                (OUT / 'progress.json').write_text(json.dumps(progress, indent=2) + '\n')
                print(json.dumps(progress), flush=True); progress_at = now
            if proc.poll() is not None and not selector.get_map():
                break
        code = proc.wait()
    source_after = identities(ROOT, MANIFEST['source'])
    frozen_after = identities(OUT / 'snapshot', MANIFEST['source'])
    corpus_after = identities(CORPUS, MANIFEST['corpus'])
    differences = {name: [key for key in before if before[key] != after[key]]
                   for name, before, after in [('source', source, source_after),
                                                ('snapshot', frozen, frozen_after),
                                                ('corpus', corpus, corpus_after)]}
    text = (OUT / 'regression.log').read_text()
    # Registry count and explicit inherited skip are independent acceptance
    # controls, beyond the make exit status and final marker.
    units_text = (CPU / 'scripts/test_units.sh').read_text().split('if [[ "$unit" != all ]]')[0]
    registry = [name for group in re.findall(r'tests\+?=\((.*?)\)', units_text, re.S) for name in group.split()]
    expected_icarus = set(registry)
    expected_verilator = expected_icarus - {'spk286_protected_expand_down'}
    missing = {'icarus': sorted(expected_icarus - completed['icarus']),
               'verilator': sorted(expected_verilator - completed['verilator'])}
    receipt.update(status='PASS' if code == 0 and 'REGRESSION PASS' in text and
                   not any(differences.values()) and not any(missing.values()) else 'FAIL',
                   exit_code=code, ended_unix=time.time(), elapsed_seconds=time.time() - started,
                   halted=halted, source_identity_differences=differences,
                   snapshot_after=frozen_after, corpus_after=corpus_after,
                   unit_finishes={k: sorted(v) for k, v in completed.items()},
                   expected_unit_banks={'icarus': len(expected_icarus), 'verilator': len(expected_verilator)},
                   missing_unit_finishes=missing, markers=markers, peak_owned_bytes=peak_bytes,
                   regression_log_sha256=sha(OUT / 'regression.log'))
    receipt_path.write_text(json.dumps(receipt, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'status': receipt['status'], 'exit_code': code,
                      'elapsed_minutes': round(receipt['elapsed_seconds'] / 60, 1),
                      'unit_finishes': {k: len(v) for k, v in completed.items()},
                      'missing': missing}), flush=True)
    return 0 if receipt['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
