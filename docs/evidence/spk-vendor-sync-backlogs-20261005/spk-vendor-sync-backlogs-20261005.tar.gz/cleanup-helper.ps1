param([Parameter(Mandatory=$true)][string]$Packet)
$ErrorActionPreference = 'Stop'
$taskRoot = (Resolve-Path -LiteralPath 'D:\GitHub\PCAT-286_MiSTer').Path
$buildPrefix = Join-Path $taskRoot 'build\'
$packetPath = (Resolve-Path -LiteralPath (Join-Path $taskRoot $Packet)).Path
if (-not $packetPath.StartsWith((Join-Path $taskRoot 'docs\evidence\'), [StringComparison]::OrdinalIgnoreCase)) { throw 'Invalid evidence destination' }
$receiptPath = Join-Path $packetPath 'cleanup.json'
$receipt = Get-Content -LiteralPath $receiptPath -Raw | ConvertFrom-Json
if ($receipt.status -notin @('PENDING', 'DELETING_VERIFIED_OWNED_TEMPORARIES')) { throw 'Cleanup already completed' }
$resuming = $receipt.status -eq 'DELETING_VERIFIED_OWNED_TEMPORARIES'
$manifest = Get-Content -LiteralPath (Join-Path $packetPath 'manifest.json') -Raw | ConvertFrom-Json
$archivePath = Join-Path $packetPath $manifest.archive
if ((Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash.ToLower() -ne $receipt.archive_sha256) { throw 'Sealed archive hash mismatch' }
$targets = @()
[long]$logicalBytes = 0
foreach ($relative in @($receipt.targets | Select-Object -Unique)) {
    $candidate = Join-Path $taskRoot $relative
    if ($resuming -and -not (Test-Path -LiteralPath $candidate)) { continue }
    $resolved = (Resolve-Path -LiteralPath $candidate).Path
    if (-not $resolved.StartsWith($buildPrefix, [StringComparison]::OrdinalIgnoreCase)) { throw "Target outside build: $resolved" }
    $item = Get-Item -LiteralPath $resolved -Force
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Reparse target: $resolved" }
    $entries = if ($item.PSIsContainer) { @(Get-ChildItem -LiteralPath $resolved -Recurse -Force) } else { @($item) }
    if (@($entries | Where-Object { $_.Attributes -band [IO.FileAttributes]::ReparsePoint }).Count) { throw "Reparse child: $resolved" }
    $tracked = @(& git -C $taskRoot ls-files -- $relative)
    if ($LASTEXITCODE -ne 0 -or $tracked.Count) { throw "Tracked or unchecked target: $relative" }
    foreach ($entry in $entries) { if (-not $entry.PSIsContainer) { $logicalBytes += $entry.Length } }
    $targets += $resolved
}
$receipt.status = 'DELETING_VERIFIED_OWNED_TEMPORARIES'
if ($resuming) {
    $receipt | Add-Member -NotePropertyName resumed_after_duplicate_target -NotePropertyValue $true -Force
    $receipt | Add-Member -NotePropertyName interrupted_pass_planned_logical_bytes -NotePropertyValue $receipt.removed_logical_bytes -Force
    $receipt | Add-Member -NotePropertyName byte_accounting_note -NotePropertyValue 'Interrupted pass included a duplicate top-elaboration target in its planned sum; removed_logical_bytes below counts only the remaining resumed deletion, not the interrupted pass.' -Force
}
$receipt | Add-Member -NotePropertyName removed_logical_bytes -NotePropertyValue $logicalBytes -Force
$receipt | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $receiptPath -Encoding utf8
foreach ($resolved in $targets) { Remove-Item -LiteralPath $resolved -Recurse -Force }
foreach ($resolved in $targets) { if (Test-Path -LiteralPath $resolved) { throw "Cleanup incomplete: $resolved" } }
if ($manifest.rbf) {
    $rbfPath = Join-Path $taskRoot $manifest.rbf.path
    if ((Get-FileHash -LiteralPath $rbfPath -Algorithm SHA256).Hash.ToLower() -ne $receipt.rbf_sha256) { throw 'Retained RBF hash mismatch' }
}
$receipt.status = 'CLEANED_VERIFIED'
$receipt | Add-Member -NotePropertyName completed_utc -NotePropertyValue ([DateTime]::UtcNow.ToString('o')) -Force
$receipt | Add-Member -NotePropertyName free_bytes_C -NotePropertyValue ([IO.DriveInfo]::new('C:\').AvailableFreeSpace) -Force
$receipt | Add-Member -NotePropertyName free_bytes_D -NotePropertyValue ([IO.DriveInfo]::new('D:\').AvailableFreeSpace) -Force
$receipt | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $receiptPath -Encoding utf8
Write-Output "OWNED_TEMPORARIES_CLEANED $logicalBytes bytes"
