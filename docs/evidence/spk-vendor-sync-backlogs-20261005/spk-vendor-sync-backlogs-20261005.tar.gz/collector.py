import hashlib,io,json,tarfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
packet=root/'docs/evidence/spk-vendor-sync-backlogs-20261005'
packet.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
folders=('p06-spk-vendor-sync-20261005','p06-spk-vendor-sync-fixture-20261005-v3','p06-spk-sync-directed-20261005')
files={}
for directory in folders:
    folder=root/'build'/directory
    data=json.loads((folder/'receipt.json').read_text())
    assert 'PASS' in data['status'],directory
    for name,value in data.get('sources_sha256',{}).items():assert sha(root/name)==value,name
    (packet/(directory+'.json')).write_text(json.dumps(data,indent=2)+'\n',newline='\n')
    for p in folder.rglob('*'):
        if p.is_file() and '.git' not in p.parts:files['tests/'+directory+'/'+p.relative_to(folder).as_posix()]=p
for directory in ('p06-spk-vendor-sync-fixture-20261005-v1','p06-spk-vendor-sync-fixture-20261005-v2'):
    for p in (root/'build'/directory).rglob('*'):
        if p.is_file() and '.git' not in p.parts:files['trial/'+directory+'/'+p.relative_to(root/'build'/directory).as_posix()]=p
for name in ('scripts/sync_spk286_vendor.py','scripts/test_sync_spk286_vendor.py','docs/imports/current-spk286.json',
    'docs/REMAINING_WORK.md','vendor/spk286/docs/REMAINING_WORK.md','docs/SOURCE_PROVENANCE.md',
    'README.md','docs/KNOWN_LIMITATIONS.md','docs/MILESTONE_STATUS.md','docs/BIOS_BACKLOG.md','docs/optimization/README.md'):
    files['source/'+name]=root/name
for p in packet.iterdir():files[p.name]=p
files['collector.py']=Path(__file__)
files['validation-runner.py']=root/'build/validate-spk-sync-and-backlogs-20261005.py'
files['cleanup-helper.ps1']=root/'build/cleanup-p06-sealed-owned-20261005.ps1'
archive=packet/'spk-vendor-sync-backlogs-20261005.tar.gz'
bindings={name:{'sha256':sha(p),'bytes':p.stat().st_size} for name,p in sorted(files.items())}
with tarfile.open(archive,'w:gz',compresslevel=9) as target:
    for name,p in sorted(files.items()):
        data=p.read_bytes();entry=tarfile.TarInfo(name);entry.size=len(data);entry.mtime=0
        target.addfile(entry,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as target:
    assert set(target.getnames())==set(files)
    for entry in target:
        data=target.extractfile(entry).read()
        assert data==files[entry.name].read_bytes() and hashlib.sha256(data).hexdigest()==bindings[entry.name]['sha256'],entry.name
(packet/'manifest.json').write_text(json.dumps({'status':'SPK_VENDOR_SYNC_BACKLOGS_SEALED_PASS',
    'archive':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members_sha256':bindings,
    'verification':'Every archive member read back equal before cleanup',
    'full_regression':'USER_DEFERRED','rtl_scope':'65 shared portable CPU/microcode plus 5 downstream generated files unchanged; active fit frozen separately'},indent=2)+'\n',newline='\n')
targets=list(folders)+['p06-spk-vendor-sync-fixture-20261005-v1','p06-spk-vendor-sync-fixture-20261005-v2']
(packet/'cleanup.json').write_text(json.dumps({'status':'PENDING','archive_sha256':sha(archive),
    'targets':['build/'+x for x in targets]},indent=2)+'\n',newline='\n')
print('SPK_VENDOR_SYNC_BACKLOGS_SEALED_PASS',archive.stat().st_size,len(files),flush=True)
