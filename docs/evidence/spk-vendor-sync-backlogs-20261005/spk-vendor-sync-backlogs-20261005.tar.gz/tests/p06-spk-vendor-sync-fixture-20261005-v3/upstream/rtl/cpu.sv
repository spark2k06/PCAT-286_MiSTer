module cpu; endmodule
