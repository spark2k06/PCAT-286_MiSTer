upstream old timed wrapper
