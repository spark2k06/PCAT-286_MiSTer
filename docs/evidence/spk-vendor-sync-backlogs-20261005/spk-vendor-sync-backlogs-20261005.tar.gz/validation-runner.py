import hashlib,json,re,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
out=root/'build/p06-spk-sync-directed-20261005'
assert not (out/'receipt.json').exists(),'Completed validation is immutable'
out.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
commands=[
    ('project',['scripts/check_pcat_project.py']),
    ('microcode',['vendor/spk286/tools/microcode/compile_microcode.py','--check']),
    ('generation',['scripts/build_p06_profile_cpu.py','--output',str(out/'generated')]),
]
import sys
for label,args in commands:
    result=subprocess.run([sys.executable,'-B',*args],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
    (out/(label+'.log')).write_bytes(result.stdout)
    assert result.returncode==0,(label,result.stdout.decode(errors='replace'))
names=('generation.json','repeat-local-contract.json','spk286_profiled.sv','spk286_profiled_events.sv','spk286_profiled_micro_executor.sv')
for name in names:
    assert (out/'generated'/name).read_bytes()==(root/'vendor/spk286/rtl/timed'/name).read_bytes(),name
docs=('README.md','docs/REMAINING_WORK.md','docs/KNOWN_LIMITATIONS.md','docs/MILESTONE_STATUS.md',
      'docs/BIOS_BACKLOG.md','docs/SOURCE_PROVENANCE.md','docs/optimization/README.md','vendor/spk286/docs/REMAINING_WORK.md')
links=0;broken=[]
for name in docs:
    p=root/name
    for match in re.finditer(r'\]\(([^)]+)\)',p.read_text(encoding='utf8')):
        value=match.group(1).split('#')[0].split(' "')[0].strip('<>')
        if not value or re.match(r'^[a-zA-Z]+:',value):continue
        if not (p.parent/value).exists():broken.append((name,value))
        links+=1
assert not broken,broken
(out/'receipt.json').write_text(json.dumps({'status':'SPK286_VENDOR_PROJECT_GENERATION_BACKLOG_LINKS_PASS',
    'scope':'Project source check, microcode consistency, all five downstream generated files byte-equal, local file-link existence for current documentation. No full regression or timing claim.',
    'generated_sha256':{n:sha(out/'generated'/n) for n in names},'local_links_checked':links,
    'source_sha256':{n:sha(root/n) for n in docs},'sync_provenance_sha256':sha(root/'docs/imports/current-spk286.json')},indent=2)+'\n')
print('SPK286_VENDOR_PROJECT_GENERATION_BACKLOG_LINKS_PASS',links,flush=True)
