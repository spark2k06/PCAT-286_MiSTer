from pathlib import Path
import ast
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
EXT = Path('D:/GitHub/SPK286')
VENDOR = ROOT / 'vendor/spk286'
OUT = Path(__file__).resolve().parent


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    return digest(path.read_bytes())


def once(text, old, new):
    if text.count(old) != 1:
        raise ValueError((old, text.count(old)))
    return text.replace(old, new)


groups = {
    'functional-core': ['rtl/spk286.sv', 'rtl/spk286_fetch.sv'],
    'required-adapters': [
        'sim/unit/spk286_signals.svh', 'sim/unit/spk286_biu_tb.sv',
        'sim/unit/spk286_biu_hold_lock_tb.sv', 'sim/unit/spk286_biu_width_io_tb.sv',
        'sim/unit/spk286_execution_tb.sv', 'sim/unit/spk286_microcode_execution_tb.sv',
        'sim/unit/spk286_adjust_instructions_tb.sv'],
    'compiler': ['tools/microcode/compile_microcode.py'],
}
selected = {rel: (VENDOR / rel).read_bytes()
            for paths in groups.values() for rel in paths}
# Only declare the existing CPU debug output in the wildcard bench header.
# Keep its formatting and all existing probes/outputs intact.
header = (EXT / 'sim/unit/spk286_signals.svh').read_text()
header = once(header, 'wire [3:0] bus_status;\n',
              'wire [3:0] bus_status;\nwire [7:0] debug_biu_detail;\n')
selected['sim/unit/spk286_signals.svh'] = header.encode()

# Migrate the obsolete local sentinel oracle to actual architectural #UD
# acceptance. Stop before entry writes: these historical harnesses do not model
# stack writes/IRET. Preserve the original MOV signatures before resuming.
micro = selected['sim/unit/spk286_microcode_execution_tb.sv'].decode()
micro = once(micro, '    integer phase_cycles = 0;',
             '    integer phase_cycles = 0, sentinel_cases = 0;')
micro = once(micro, "        memory[ip[11:0] + 12'd3] = 8'h90;",
             "        memory[ip[11:0] + 12'd3] = 8'h0F;\n        memory[ip[11:0] + 12'd4] = 8'hFF;")
micro = once(micro, '    task automatic run_to_retire;', '''    task automatic run_to_ud_accept(input logic [15:0] fault_ip);
        phase_cycles = 0;
        while (!dut.event_active && phase_cycles < 300) begin
            check(!(bus_valid && bus_write), "sentinel acceptance precedes stack writes");
            service(); phase_cycles = phase_cycles + 1;
            check(retirements == 1 && !instruction_retired,
                  "invalid sentinel cannot retire or duplicate the MOV");
        end
        check(phase_cycles > 0 && phase_cycles < 300 && dut.event_active && dut.event_cancel,
              "invalid sentinel reaches first architectural fault acceptance");
        check(debug_event_vector == 8'd6 && debug_event_kind == 3'd1 &&
              !debug_event_error_valid && !unsupported_opcode && !event_completed,
              "invalid sentinel is #UD without a local unsupported latch or entry completion");
        check(dut.event_ip == fault_ip && dut.event_cs == saved_selectors[16 +: 16] &&
              dut.event_flags == 16'h7ED7,
              "#UD retains the sentinel CS:IP and original FLAGS");
        check(debug_gpr == expected_gpr && debug_flags == 16'h7ED7 &&
              debug_segment_selectors == saved_selectors && debug_segment_bases == saved_bases &&
              debug_segment_limits == saved_limits && debug_segment_access == saved_access,
              "pre-entry #UD leaves the MOV signature and all architectural state intact");
        check(!(bus_valid && bus_write) && retirements == 1 && !instruction_retired,
              "stop #UD before any stack write or second retirement");
        sentinel_cases = sentinel_cases + 1;
        $display("MICROCODE_EXECUTION_SENTINEL_CASE origin=%h cycles=%0d retires=%0d", fault_ip, phase_cycles, retirements);
        execute_enable = 0;
    endtask
    task automatic run_to_retire;''')
micro = once(micro, '''                    execute_enable = 1;
                    check(!unsupported_opcode && retirements == 1,
                          "post-retirement stream remains free of local unsupported latch");
                    check_architecture(base_ip + 16'd3);''',
'''                    check_architecture(base_ip + 16'd3);
                    execute_enable = 1;
                    run_to_ud_accept(base_ip + 16'd3);''')
micro = once(micro, '        check(underfill_cycles > 0, "immediate fetch exercised queue underfill");',
             '        check(sentinel_cases == 48, "every original MOV vector exercises architectural sentinel acceptance");\n        $display("MICROCODE_EXECUTION_SENTINEL_PASS cases=%0d", sentinel_cases);\n        check(underfill_cycles > 0, "immediate fetch exercised queue underfill");')
selected['sim/unit/spk286_microcode_execution_tb.sv'] = micro.encode()

execution = selected['sim/unit/spk286_execution_tb.sv'].decode()
execution = once(execution, "    logic single_done = 1'b0, multi_done = 1'b0;",
                 "    logic single_done = 1'b0, multi_done = 1'b0;\n    logic [127:0] saved_ud_gpr;")
execution = once(execution, '''        // An unsupported second byte of the 0F escape is an architectural #UD
        // event; the old local "unsupported opcode" latch must stay clear.''',
'''        // An invalid 0F second byte must reach architectural #UD acceptance.
        // Stop before stack entry: retain origin and the complete MOV signature.
        saved_ud_gpr = debug_gpr;''')
execution = once(execution, '''        memory[24] = 8'h00; memory[25] = 8'h03; // vector 6 -> 0000:0300
        memory[26] = 8'h00; memory[27] = 8'h00;
        load_byte(16'h0300, 8'hCF);
''', '')
execution = once(execution, '''        for (cycles = 0; cycles < 600 && !event_completed; cycles = cycles + 1)
            service_cycle();
        if (!event_completed || debug_event_vector !== 8'd6 || unsupported_opcode ||
            debug_gpr[15:0] !== 16'h1234 || debug_flags !== 16'h0043)
            $fatal(1, "0F invalid form did not raise architectural #UD");''',
'''        for (cycles = 0; cycles < 600 && !dut.event_active; cycles = cycles + 1) begin
            if ((bus_valid && bus_write) || instruction_retired)
                $fatal(1, "invalid sentinel retired or entered the stack before acceptance");
            service_cycle();
        end
        if (cycles == 0 || cycles >= 600 || !dut.event_active || !dut.event_cancel ||
            debug_event_vector !== 8'd6 || debug_event_kind !== 3'd1 ||
            debug_event_error_valid || unsupported_opcode || instruction_retired || event_completed ||
            (bus_valid && bus_write) || dut.event_ip !== 16'h0200 || dut.event_cs !== 16'h0000 ||
            dut.event_flags !== 16'h0043 || debug_gpr !== saved_ud_gpr || debug_flags !== 16'h0043)
            $fatal(1, "0F invalid form failed pre-entry #UD/context/signature preservation");
        execute_enable = 1'b0;
        $display("EXECUTION_SENTINEL_PASS origin=%h cycles=%0d", dut.event_ip, cycles);''')
selected['sim/unit/spk286_execution_tb.sv'] = execution.encode()

baseline = json.loads((EXT / 'tools/profile_cpu_baseline.json').read_text())
updates = {rel: sha(VENDOR / rel) for rel in groups['functional-core']}
contract = {
    'schema_version': 1,
    'scope': 'Selected standalone CPU-only READY chaining milestone; historical baseline remains immutable; board bus and clocks are external',
    'baseline_contract_path': 'tools/profile_cpu_baseline.json',
    'baseline_contract_sha256': sha(EXT / 'tools/profile_cpu_baseline.json'),
    'functional_updates_sha256': updates,
    'expected_profiled_sha256': {
        name: sha(VENDOR / 'rtl/timed' / name)
        for name in baseline['expected_profiled_sha256']},
    'probe_fixture_sha256': {
        'sim/unit/spk286_signals.svh': digest(selected['sim/unit/spk286_signals.svh'])},
}
selected['tools/profile_cpu_ready_chain.json'] = (json.dumps(contract, indent=2) + '\n').encode()
gen = (EXT / 'scripts/build_p06_profile_cpu.py').read_text()
gen = once(gen, 'The pinned functional engine is never edited. This first',
           'The selected functional milestone is explicitly bound separately from the historical baseline. This')
gen = once(gen, baseline['baseline_sha256']['rtl/spk286.sv'], updates['rtl/spk286.sv'])
addition = '''

# Keep profile_cpu_baseline.json and the old profile receipt unchanged.
FUNCTIONAL_UPDATES = {
    "rtl/spk286.sv": "%s",
    "rtl/spk286_fetch.sv": "%s",
}
SELECTED_CONTRACT = "tools/profile_cpu_ready_chain.json"


def load_selected_contract():
    contract = json.loads((ROOT / SELECTED_CONTRACT).read_text())
    if contract["schema_version"] != 1 or contract["baseline_contract_path"] != "tools/profile_cpu_baseline.json":
        raise ValueError("Unsupported standalone selected profile contract")
    if sha(ROOT / contract["baseline_contract_path"]) != contract["baseline_contract_sha256"]:
        raise ValueError("Historical standalone baseline contract changed")
    if contract["functional_updates_sha256"] != FUNCTIONAL_UPDATES:
        raise ValueError("Selected functional update scope changed")
    return contract
''' % (updates['rtl/spk286.sv'], updates['rtl/spk286_fetch.sv'])
gen = once(gen, '\n\ndef sha(path):', addition + '\n\ndef sha(path):')
gen = once(gen,
           '    baseline = json.loads((ROOT / "tools/profile_cpu_baseline.json").read_text())\n    for name, expected in baseline["baseline_sha256"].items():\n        if sha(ROOT / name) != expected:',
           '    selected_contract = load_selected_contract()\n    baseline = json.loads((ROOT / selected_contract["baseline_contract_path"]).read_text())\n    for name, expected in baseline["baseline_sha256"].items():\n        if sha(ROOT / name) != FUNCTIONAL_UPDATES.get(name, expected):')
gen = once(gen,
           '    sources = {**ORIGINALS, "scripts/build_p06_profile_cpu.py": sha(Path(__file__)),',
           '    sources = {**ORIGINALS, **FUNCTIONAL_UPDATES, SELECTED_CONTRACT: sha(ROOT / SELECTED_CONTRACT),\n        "tools/profile_cpu_baseline.json": sha(ROOT / "tools/profile_cpu_baseline.json"),\n        "scripts/build_p06_profile_cpu.py": sha(Path(__file__)),')
gen = once(gen,
           '    manifest = {"status": "PROFILED_CPU_GENERATED_NOT_ACCEPTED", "sources_sha256": sources,',
           '    manifest = {"status": "PROFILED_CPU_GENERATED_NOT_ACCEPTED", "sources_sha256": sources,\n        "historical_baseline_sha256": baseline["baseline_sha256"],\n        "selected_functional_sha256": {name: sha(ROOT / name) for name in baseline["ordered_rtl_sources"]},')
gen = once(gen, 'pinned standalone functional CPU unchanged',
           'historical standalone baseline retained; selected READY chaining functional milestone explicitly bound')
selected['scripts/build_p06_profile_cpu.py'] = gen.encode()
check = (EXT / 'scripts/check_p06_profile_cpu.py').read_text()
check = once(check, 'from build_p06_profile_cpu import ROOT, build, sha',
             'from build_p06_profile_cpu import ROOT, build, sha, load_selected_contract, SELECTED_CONTRACT')
check = once(check, '    contract = json.loads((ROOT / "tools/profile_cpu_baseline.json").read_text())',
             '    selected_contract = load_selected_contract()\n    contract = json.loads((ROOT / selected_contract["baseline_contract_path"]).read_text())')
check = once(check, 'contract["expected_profiled_sha256"][name]',
             'selected_contract["expected_profiled_sha256"][name]')
check = once(check, 'contract["probe_fixture_sha256"][signal_fixture.relative_to(ROOT).as_posix()]',
             'selected_contract["probe_fixture_sha256"][signal_fixture.relative_to(ROOT).as_posix()]')
check = once(check, '               ROOT / "tools/profile_cpu_baseline.json", timing, schedule, bench,',
             '               ROOT / "tools/profile_cpu_baseline.json", ROOT / SELECTED_CONTRACT, timing, schedule, bench,')
check = once(check, '        "baseline_sha256": contract["baseline_sha256"],',
             '        "baseline_sha256": contract["baseline_sha256"],\n        "selected_contract_sha256": sha(ROOT / SELECTED_CONTRACT),\n        "functional_updates_sha256": selected_contract["functional_updates_sha256"],\n        "selected_functional_sha256": {name: sha(ROOT / name) for name in contract["ordered_rtl_sources"]},')
selected['scripts/check_p06_profile_cpu.py'] = check.encode()
groups['portable-profile-contract'] = [
    'tools/profile_cpu_ready_chain.json', 'scripts/build_p06_profile_cpu.py',
    'scripts/check_p06_profile_cpu.py']

records = []
for group, paths in groups.items():
    patch = ''
    for rel in paths:
        old = (EXT / rel).read_bytes() if (EXT / rel).exists() else b''
        new = selected[rel]
        if rel.endswith('.py'):
            ast.parse(new.decode(), filename=rel)
        path = OUT / 'staged' / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(new)
        records.append({'group': group, 'path': rel,
                        'preimage_sha256': digest(old) if (EXT / rel).exists() else None,
                        'selected_sha256': digest(new),
                        'vendor_identity': (VENDOR / rel).exists() and digest(new) == sha(VENDOR / rel)})
        patch += ''.join(difflib.unified_diff(
            old.decode().splitlines(True), new.decode().splitlines(True),
            fromfile='a/' + rel if old else '/dev/null', tofile='b/' + rel))
    (OUT / (group + '.patch')).write_text(patch, newline='\n')
manifest = {
    'status': 'PROPOSED_READ_ONLY_PLAN_NOT_APPLIED_NOT_TESTED',
    'standalone_expected_head': '86a76ce', 'standalone_root': EXT.as_posix(),
    'groups': groups, 'files': records,
    'preserved': ['tools/profile_cpu_baseline.json', 'docs/evidence/profile-cpu-20261004/receipt.json',
                  'microcode/source/*', 'microcode/generated/*', 'tests/fixtures/*', 'Makefile',
                  'scripts/synth_check.sh', 'sim/unit/spk286_core_tb.sv', 'sim/verilator/state_inputs.h'],
    'generated_after_apply': ['rtl/timed/spk286_profiled.sv', 'rtl/timed/spk286_profiled_events.sv',
                              'rtl/timed/generation.json'],
    'external_mutations': False, 'tests_run': False,
}
(OUT / 'stage-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', newline='\n')
print('PROPOSAL: %d staged files; no external mutations or tests' % len(records))
print('stage-manifest.json SHA256 ' + sha(OUT / 'stage-manifest.json'))
print('Selected generated sources ' + json.dumps(contract['expected_profiled_sha256']))
