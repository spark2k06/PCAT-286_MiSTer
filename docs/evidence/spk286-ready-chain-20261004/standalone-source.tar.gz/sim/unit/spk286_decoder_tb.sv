`timescale 1ns/1ps

module spk286_decoder_tb;
    logic [7:0] opcode;
    logic extended_opcode = 1'b0;
    wire supported;
    wire invalid_opcode;
    wire [2:0] destination, source_index;
    wire [spk286_microcode_pkg::MC_ADDR_WIDTH-1:0] entry;
    integer checks = 0;
    spk286_decoder dut (.*);
    initial begin
        for (integer i = 0; i < 256; i = i + 1) begin
            opcode = 8'(i); #1;
            if (supported !== (i == 155 || i == 99 || i == 105 || i == 107 || (i >= 216 && i <= 223) || (i >= 228 && i <= 231) || (i >= 236 && i <= 239) || (i >= 108 && i <= 111) || (i >= 164 && i <= 167) || (i >= 170 && i <= 175) || i == 196 || i == 197 || i == 154 || i == 234 || i == 202 || i == 203 || i == 96 || i == 97 || i == 98 || i == 200 || i == 201 || i == 6 || i == 7 || i == 14 || i == 22 || i == 23 || i == 30 || i == 31 || i == 140 || i == 142 || i == 39 || i == 47 || i == 55 || i == 63 || i == 212 || i == 213 || i == 254 || i == 134 || i == 135 || i == 141 || (i >= 144 && i <= 151) || (i >= 160 && i <= 163) || i == 215 || i == 192 || i == 193 || (i >= 208 && i <= 211) || (i >= 64 && i < 80) || i == 152 || i == 153 || i == 158 || i == 159 || i == 245 || i == 248 || i == 249 || i == 252 || i == 253 || i == 132 || i == 133 || i == 168 || i == 169 || i == 246 || i == 247 || i == 156 || i == 157 || (i >= 204 && i <= 207) || i == 244 || i == 250 || i == 251 ||
                              (i >= 80 && i <= 95) || (i >= 112 && i <= 127) || i == 104 || i == 106 || i == 143 || i == 255 ||
                              i == 194 || i == 195 || (i >= 224 && i <= 227) || i == 232 || i == 233 || i == 235 ||
                              (i >= 176 && i <= 191) || i == 136 || i == 138 || i == 198 || i == 199 || i == 128 || i == 137 || i == 139 || i == 129 || i == 131 ||
                              i == 214 ||
                              (i < 64 && (i % 8 <= 5)))) $fatal(1, "opcode support %h", opcode);
            if (i == 214 && (destination != 0 || source_index != 0 ||
                entry != spk286_microcode_pkg::MC_ENTRY_LOAD_CARRY_BYTE))
                $fatal(1, "SALC destination/entry metadata");
            if (invalid_opcode !== (i >= 100 && i <= 103))
                $fatal(1, "primary opcode classification %h", opcode);
            if (i >= 184 && i <= 191 && (destination !== 3'(i - 184) ||
                entry !== spk286_microcode_pkg::MC_ENTRY_MOV_R16_IMM16))
                $fatal(1, "MOV decoder metadata %h", opcode);
            if (i == 137 && entry !== spk286_microcode_pkg::MC_ENTRY_MOV_RM16_R16)
                $fatal(1, "MOV RM destination entry");
            if (i == 139 && entry !== spk286_microcode_pkg::MC_ENTRY_MOV_R16_RM16)
                $fatal(1, "MOV REG destination entry");
            if (i < 64 && i % 8 == 1 && entry !== spk286_microcode_pkg::MC_ENTRY_ALU_RM16_R16)
                $fatal(1, "ALU RM destination entry");
            if (i < 64 && i % 8 == 3 && entry !== spk286_microcode_pkg::MC_ENTRY_ALU_R16_RM16)
                $fatal(1, "ALU REG destination entry");
            if (i < 64 && i % 8 == 5 && (entry !== spk286_microcode_pkg::MC_ENTRY_ALU_AX_IMM16 || destination != 0))
                $fatal(1, "ALU accumulator entry");
            if (i == 129 && entry !== spk286_microcode_pkg::MC_ENTRY_ALU_RM16_IMM16)
                $fatal(1, "ALU immediate word entry");
            if (i == 131 && entry !== spk286_microcode_pkg::MC_ENTRY_ALU_RM16_IMM8S)
                $fatal(1, "ALU sign extended immediate entry");
            if (i >= 176 && i <= 183 && (destination !== 3'(i-176) || entry !== spk286_microcode_pkg::MC_ENTRY_MOV_R8_IMM8))
                $fatal(1,"byte MOV destination");
            if (i==136 && entry !== spk286_microcode_pkg::MC_ENTRY_MOV_RM8_R8) $fatal(1,"byte MOV r/m entry");
            if (i==138 && entry !== spk286_microcode_pkg::MC_ENTRY_MOV_R8_RM8) $fatal(1,"byte MOV register entry");
            if (i==198 && entry !== spk286_microcode_pkg::MC_ENTRY_MOV_RM8_IMM8) $fatal(1,"byte immediate MOV entry");
            if (i==199 && entry !== spk286_microcode_pkg::MC_ENTRY_MOV_RM16_IMM16) $fatal(1,"word immediate MOV entry");
            if (i==128 && entry !== spk286_microcode_pkg::MC_ENTRY_ALU_RM8_IMM8) $fatal(1,"byte ALU immediate entry");
            if (i<64 && i%8==0 && entry !== spk286_microcode_pkg::MC_ENTRY_ALU_RM8_R8) $fatal(1,"byte ALU r/m entry");
            if (i<64 && i%8==2 && entry !== spk286_microcode_pkg::MC_ENTRY_ALU_R8_RM8) $fatal(1,"byte ALU register entry");
            if (i<64 && i%8==4 && (entry !== spk286_microcode_pkg::MC_ENTRY_ALU_AL_IMM8 || destination != 0)) $fatal(1,"byte ALU accumulator entry");
            if ((i == 246 || i == 247) && entry !== spk286_microcode_pkg::MC_ENTRY_GROUP3_DISPATCH) $fatal(1,"group3 dispatch entry");
            if (i == 255 && entry !== spk286_microcode_pkg::MC_ENTRY_GROUP5_DISPATCH) $fatal(1,"group5 dispatch entry");
            if (i >= 216 && i <= 223 && entry !== spk286_microcode_pkg::MC_ENTRY_ESC_NO_COPROCESSOR)
                $fatal(1, "ESC no-coprocessor entry");
            if (i == 155 && (entry !== spk286_microcode_pkg::MC_ENTRY_WAIT_NO_COPROCESSOR || destination != 0 || source_index != 0))
                $fatal(1, "WAIT no-coprocessor metadata");
            if (i == 254 && entry !== spk286_microcode_pkg::MC_ENTRY_INC_DEC_RM8) $fatal(1,"byte unary entry");
            if ((i==39 || i==47 || i==55 || i==63 || i==212 || i==213) && (destination!=0 || source_index!=0 ||
                entry!=(i>=212?spk286_microcode_pkg::MC_ENTRY_ADJUST_RADIX:spk286_microcode_pkg::MC_ENTRY_ADJUST_DIRECT)))
                $fatal(1,"adjust source/destination/entry metadata");
            if ((i==6 || i==14 || i==22 || i==30) && entry!=spk286_microcode_pkg::MC_ENTRY_PUSH_SEG) $fatal(1,"segment push entry");
            if ((i==7 || i==23 || i==31) && entry!=spk286_microcode_pkg::MC_ENTRY_POP_SEG) $fatal(1,"segment pop entry");
            if (i==140 && entry!=spk286_microcode_pkg::MC_ENTRY_MOV_RM16_SEG) $fatal(1,"segment read entry");
            if (i==142 && entry!=spk286_microcode_pkg::MC_ENTRY_MOV_SEG_RM16) $fatal(1,"segment write entry");
            if (i==96 && entry!=spk286_microcode_pkg::MC_ENTRY_PUSH_ALL) $fatal(1,"PUSHA entry");
            if (i==97 && entry!=spk286_microcode_pkg::MC_ENTRY_POP_ALL) $fatal(1,"POPA entry");
            if (i==98 && entry!=spk286_microcode_pkg::MC_ENTRY_CHECK_BOUNDS) $fatal(1,"BOUND entry");
            if (i==200 && entry!=spk286_microcode_pkg::MC_ENTRY_ENTER_FRAME) $fatal(1,"ENTER entry");
            if (i==201 && entry!=spk286_microcode_pkg::MC_ENTRY_LEAVE_FRAME) $fatal(1,"LEAVE entry");
            if((i==196 || i==197) && entry!=spk286_microcode_pkg::MC_ENTRY_LOAD_POINTER) $fatal(1,"far pointer load entry");
            if(i==154 && entry!=spk286_microcode_pkg::MC_ENTRY_CALL_FAR_IMM) $fatal(1,"far immediate call entry");
            if(i==234 && entry!=spk286_microcode_pkg::MC_ENTRY_JMP_FAR_IMM) $fatal(1,"far immediate jump entry");
            if(i==202 && entry!=spk286_microcode_pkg::MC_ENTRY_RET_FAR_IMM) $fatal(1,"far adjusted return entry");
            if(i==203 && entry!=spk286_microcode_pkg::MC_ENTRY_RET_FAR) $fatal(1,"far return entry");
            if ((i==164 || i==165) && entry!=spk286_microcode_pkg::MC_ENTRY_STRING_MOVE) $fatal(1,"MOVS entry");
            if ((i==166 || i==167) && entry!=spk286_microcode_pkg::MC_ENTRY_STRING_COMPARE) $fatal(1,"CMPS entry");
            if ((i==170 || i==171) && entry!=spk286_microcode_pkg::MC_ENTRY_STRING_STORE) $fatal(1,"STOS entry");
            if ((i==172 || i==173) && entry!=spk286_microcode_pkg::MC_ENTRY_STRING_LOAD) $fatal(1,"LODS entry");
            if ((i==174 || i==175) && entry!=spk286_microcode_pkg::MC_ENTRY_STRING_SCAN) $fatal(1,"SCAS entry");
            if ((i==228 || i==236) && (destination!=0 || entry!=spk286_microcode_pkg::MC_ENTRY_IN_AL_PORT)) $fatal(1,"IN AL entry");
            if ((i==229 || i==237) && (destination!=0 || entry!=spk286_microcode_pkg::MC_ENTRY_IN_AX_PORT)) $fatal(1,"IN AX entry");
            if ((i==230 || i==238) && (destination!=0 || entry!=spk286_microcode_pkg::MC_ENTRY_OUT_PORT_AL)) $fatal(1,"OUT AL entry");
            if ((i==231 || i==239) && (destination!=0 || entry!=spk286_microcode_pkg::MC_ENTRY_OUT_PORT_AX)) $fatal(1,"OUT AX entry");
            if (i==108 && entry!=spk286_microcode_pkg::MC_ENTRY_STRING_INPUT_BYTE) $fatal(1,"INSB entry");
            if (i==109 && entry!=spk286_microcode_pkg::MC_ENTRY_STRING_INPUT_WORD) $fatal(1,"INSW entry");
            if (i==110 && entry!=spk286_microcode_pkg::MC_ENTRY_STRING_OUTPUT_BYTE) $fatal(1,"OUTSB entry");
            if (i==111 && entry!=spk286_microcode_pkg::MC_ENTRY_STRING_OUTPUT_WORD) $fatal(1,"OUTSW entry");
            if(i==105 && entry!=spk286_microcode_pkg::MC_ENTRY_IMUL_R16_RM16_IMM16) $fatal(1,"IMUL immediate word entry");
            if(i==107 && entry!=spk286_microcode_pkg::MC_ENTRY_IMUL_R16_RM16_IMM8S) $fatal(1,"IMUL signed byte entry");
            if (i == 99 && (entry !== spk286_microcode_pkg::MC_ENTRY_SYSTEM_ARPL || destination != 0 || source_index != 0)) $fatal(1, "ARPL decoder metadata");
            checks = checks + 1;
        end
        extended_opcode = 1'b1;
        // Retain the downstream exhaustive 0F classification matrix as well
        // as the standalone per-entry metadata checks below.
        for (integer i = 0; i < 256; i = i + 1) begin
            opcode = 8'(i); #1;
            if (invalid_opcode !== !(i == 0 || i == 1 || i == 2 || i == 3 || i == 5 || i == 6) ||
                supported !== (i == 0 || i == 1 || i == 2 || i == 3 || i == 5 || i == 6))
                $fatal(1, "extended opcode classification %h", opcode);
            checks++;
        end
        opcode = 8'h01; #1;
        if (supported !== 1'b1 || entry !== spk286_microcode_pkg::MC_ENTRY_SYSTEM_GROUP_0F01)
            $fatal(1, "0F 01 extended decoder entry");
        opcode = 8'h00; #1;
        if (supported !== 1'b1 || entry !== spk286_microcode_pkg::MC_ENTRY_SYSTEM_GROUP_0F00)
            $fatal(1, "0F 00 extended decoder entry");
        opcode = 8'h02; #1;
        if (supported !== 1'b1 || entry !== spk286_microcode_pkg::MC_ENTRY_SYSTEM_LOAD_ACCESS)
            $fatal(1, "0F 02 extended decoder entry");
        opcode = 8'h03; #1;
        if (supported !== 1'b1 || entry !== spk286_microcode_pkg::MC_ENTRY_SYSTEM_LOAD_LIMIT)
            $fatal(1, "0F 03 extended decoder entry");
        opcode = 8'h06; #1;
        if (supported !== 1'b1 || entry !== spk286_microcode_pkg::MC_ENTRY_SYSTEM_CLTS)
            $fatal(1, "0F 06 extended decoder entry");
        opcode = 8'h05; #1;
        if (supported !== 1'b1 || invalid_opcode !== 1'b0 || entry !== spk286_microcode_pkg::MC_ENTRY_LOADALL)
            $fatal(1, "0F 05 LOADALL classification/entry");
        opcode = 8'h0F; #1;
        if (supported !== 1'b0 || invalid_opcode !== 1'b1) $fatal(1, "unsupported extended opcode classification");
        opcode = 8'h04; #1;
        if (invalid_opcode !== 1'b1) $fatal(1, "0F 04 invalid classification");
        checks = checks + 7;
        $display("DECODER PASS: %0d opcode checks; MOV and word ALU forms", checks);
        $finish;
    end
endmodule
