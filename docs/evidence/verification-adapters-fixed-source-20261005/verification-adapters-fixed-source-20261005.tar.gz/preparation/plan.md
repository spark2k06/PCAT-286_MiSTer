# Full regression preparation — 2026-10-05

Status: **PREPARED_NOT_EXECUTED**. This packet is a read-only registry audit and execution plan. No regression, corpus replay, fit or source regeneration was launched to prepare it. The user has authorized the complete regression **after setup and hold close**. The root agent decides when that condition is satisfied and owns the final source freeze, execution and commits.

## Entry condition and source identity

1. Require strictly positive global setup and hold at all four existing Quartus corners, with original timing coverage and constraints retained. Check recovery/removal, pulse widths, actual global reports, path inventory, warnings and RAM inference as part of the current fit audit. An old source-bound timing checker must not be made to accept new RTL by substituting hashes alone.
2. Freeze the exact candidate and all bench/compiler/helper/configuration files after directed adapter repairs and standalone/vendor synchronization. Record Git HEAD, dirty diff (including the pre-existing DMA source-list change), upstream provenance, generated CPU hash, tool versions and every external input. The current preparation hashes must be refreshed before execution; they are not the regression's source manifest.
3. All production performance changes are fixed on. `config.tcl` has no retired CPU options; audio features remain enabled. Do not run an options-off matrix. MAX is the fixed fast CPU; historical profiles are 6, 8, 10, 12.5, 16, 20 and 25 MHz on the existing physical 50 MHz clock.
4. Use a fresh owned run directory. Do not reuse or overwrite failed runs or previous source snapshots. A repair/replay gets a separate source-bound receipt and leaves the original result unchanged.

## Existing full-run entry point and gaps

The tracked coordinator is `tools/perf01/run_full_regression.py`. Its `--production-only` mode copies RTL, vendor, scripts, sim, SW, tests and tools into a frozen workspace, registers CPU banks and root shell tests and runs physical cohorts and mutation audits. Its historical default command is:

```sh
python3 -B tools/perf01/run_full_regression.py "$RUN" \
  --corpus /mnt/d/GitHub/SPK286/.cache/singlestep-80286 --production-only
```

**Do not launch that command unchanged for the final current regression.** The coordinator presently runs three expensive lanes concurrently, forces two build jobs and puts its main CPU build in WSL `/tmp` (host C: VHD). It lacks the current Python profile/live-speed/timing/palette/floppy proof gates and still excludes the now-production `test_at_bus_latency.sh`. A bounded private coordinator or equivalent sequential stage execution must preserve every registered stage while addressing those resource and coverage gaps. Its final status also does not reject `current_inputs_changed`; the acceptance collector must require both frozen and current sources unchanged.

The historical report `docs/optimization/P18_P19_FULL_REGRESSION_20261002.md` records **203 raw PASS and 48 raw FAIL**, followed by 37 successful independent repairs/replays and 11 remaining unaccepted checks. Its original aggregate remains FAIL. The 1 h 48 min 42 s duration is history, not an estimate for the larger current matrix. `SPK286_MICROCODE_REGRESSION_REPAIR_20261004.md` documents subsequent adapter fixes (114 Python microcode tests and 155 retained negatives); these are rerun on the new frozen candidate.

Preparation identified two further adapters requiring directed repair before the complete run: `test_p05_limit_equivalence.py` still expects the removed P05 conditional; `test_at_stack_offset_arithmetic.sh` still binds the entire executor to an October 2 hash. Keep their independent original expressions, boundary expectations and real negative controls; replace obsolete extraction/source binding with actual current cone extraction and proof. Parent has separately authorized those focused repairs. No RTL change is part of them.

The current unit registry must include the existing `spk286_event_arbitration` bench, which was present in the prior bounded packet and missing before the latest vendor synchronization. Re-read the registry at freeze time. The accompanying JSON records the actual current names, rather than trusting an old count.

## Required matrices

| Area | Required execution and acceptance |
|---|---|
| Fixed fast CPU | Every actual registered bank in `vendor/spk286/scripts/test_units.sh`: Icarus plus Verilator; restore/explicitly execute event arbitration if the registry still omits it. Full `spk286_protected_expand_down` runs in Icarus under its existing documented policy. Do not set `SPK286_EXPAND_DOWN_TERMINATION_SMOKE=1`. |
| CPU tools | Current microcode `--check`, audit and all Python unit tests; strict production lint; reset/data/state fixtures, simulator failure propagation, Yosys sanity; isolated MCL86 tool tests and pinned public ROM round trips. |
| Physical corpus | All 307 required files: exactly 1,386,996 executed/passed, zero failed, original three revoked records, one exact E7 physical-capture NOT EVALUABLE; required population 1,386,997. Validate unique identities, population/category counts and pinned input blobs with `phase7_complete_reports`, not a PASS string. Full D6/D8 supplementary SALC/ESC cohorts add 6,000 cases. |
| Mutation audits | All 20 registered families: phase3 boundaries, ALU, stack/control, events, byte/prefix, scalar, shift, data, unary, adjust, segment, stack/frame, far, strings, I/O, multiply/divide, double fault, phase8, late task and null LDTR. Preserve adapter/comparison audits and synthetic I/O. A compile error, arbitrary nonzero result or host timeout is not functional mutant rejection. |
| PCAT integration | Every current root `test_*.sh` except the existing historical Git-counterfactual `test_at_code_buffer_equivalence.sh`; the fixed production `test_at_bus_latency.sh` is mandatory. Include I1/A1..A5, machine, SDRAM/owner/buffer, FDC read/write/DMA/protection, PIC/PIT/refresh/RTC, keyboard/mouse/audio/video, ROM and firmware banks. All-five audio configuration remains active. |
| Historical compatibility | `test_p06_profile_compatibility.py`: 26 banks × all eight profiles in Icarus (208), seven designated banks × eight in Verilator (56), plus 26 MAX per-edge reference comparisons, total 290 receipt entries. Use digest traces; keep the documented fixture/watchdog adaptation and original assertions. |
| Live speed | Full `test_p06_live_speed.py`, without `--cpu-only`: dual/four-state clock checks; all 64 requested/current profile pairs with three bridge latency modes (192 cases), unsafe-boundary negatives, replay/selector/drain, bus-wait, HLT/IRQ/NMI checks. `test_p06_target_handoff_integration.py --profiles 0,1,2,3,4,5,6,7 --dual` complements the full compatibility matrix. |
| Current transformed cones | P05 limit; REP local/branch; metadata budgets; carry-save deadlines; execution deadline; null-segment commit; scaler terminal compare; software palette address encoding; buffer idle-payload and retained-FDC proofs with their exact independent reference inputs, fresh direct benches and negatives. Do not substitute the candidate for a reference. |
| Platform helper checks | Current timing parser/net-bound/luminance tests; memory performance comparison tests; profile/configuration, preview, target, replay, fault-boundary, turnaround and floppy composed/write-protection helpers; vendor sync tool tests. Artifact-specific timing/source-placement/official-primitive/ROM-patch helpers need the correct current or frozen original input, not an invented fixture. |

The JSON contains the exact current root shell/Python registry, source hashes and command templates. Python scripts that are input-specific are not silently excluded: they get resolved prerequisite inputs and a result, or a plainly reported unavailable/unaccepted stage. Alias entry points (PowerShell SDRAM capture versus the shell equivalent; nested Make phase gates) are coverage mappings rather than duplicate multi-million-case runs. Preserve evidence/policy checks separately from executable success: existing five phase7 notes, E7 physical evidence and publication hold are not closed by simulated regression.

## Commands for bounded execution after the gate

Commands below are templates; the final coordinator must resolve `$FROZEN`, `$RUN`, `$CORPUS` and reference paths to exact manifested directories and record each command, cwd, environment, start/end, PID, exit status, log hash and timeout. One compile workload runs at a time, with `SPK286_BUILD_JOBS=1` wherever honored. Several helpers internally use `-j 4`; run them alone. Do not change HDL watchdogs or corpus selection to meet a host deadline.

```sh
# Frozen CPU root, common full-source fast implementation.
cd "$FROZEN/vendor/spk286"
SPK286_BUILD_JOBS=1 SPK286_BUILD_DIR="$RUN/cpu" bash scripts/build_verilator.sh
python3 -B -m tools.microcode.compile_microcode --check
python3 -B -m tools.microcode.audit_microcode --output "$RUN/microcode-audit"
python3 -B -m unittest discover -s tests -v
SPK286_BUILD_DIR="$RUN/cpu" bash scripts/lint.sh

# Repeat once for each exact unit in the refreshed registry, sequentially.
SPK286_BUILD_JOBS=1 SPK286_BUILD_DIR="$RUN/units/$UNIT" \
  bash scripts/test_units.sh both "$UNIT"

# Keep the executable until physical cohorts and adapter audits finish.
python3 -B -m tools.run_phase7_physical --repo "$CORPUS" \
  --executable "$RUN/cpu/verilator/obj_dir/spk286_smoke" \
  --build-dir "$RUN/physical-required"
python3 -B -m tools.phase7_complete_reports --repo "$CORPUS" \
  --directory "$RUN/physical-required/singlestep" --output "$RUN/physical-identity.json"
# Repeat for opcodes D6 and D8; include prefixes and exceptions unchanged.
python3 -B -m tools.run_singlestep --repo "$CORPUS" --opcode "$OPCODE" \
  --executable "$RUN/cpu/verilator/obj_dir/spk286_smoke" \
  --build-dir "$RUN/physical-$OPCODE" --full --include-prefixes --include-exceptions

cd "$FROZEN"
# Execute every refreshed functional shell registry entry separately.
SPK286_BUILD_JOBS=1 PCAT_BUILD_DIR="$RUN/machine/$STAGE" \
  bash "scripts/$SCRIPT"
# Stack offset's optional positional output is explicit and must be fresh.
bash scripts/test_at_stack_offset_arithmetic.sh "$RUN/stack-offset"

# One leaf per compatibility bank, all profiles; keep metadata until aggregate.
python3 -B scripts/test_p06_profile_compatibility.py --output "$RUN/profiles/$UNIT" \
  --profiles 0,1,2,3,4,5,6,7 --units "$UNIT" --trace-storage digest
# Once every leaf is complete, use the script's --aggregate with all 26 paths.
python3 -B scripts/test_p06_profile_compatibility.py --output "$RUN/profile-aggregate" \
  --aggregate "$RUN/profiles/execution" ...ALL_OTHER_EXACT_LEAF_PATHS...
python3 -B scripts/test_p06_live_speed.py --output "$RUN/live-speed"
python3 -B scripts/test_p06_target_handoff_integration.py --output "$RUN/handoff" \
  --profiles 0,1,2,3,4,5,6,7 --dual
```

The all-corpus command can legitimately exceed a single CPU-bank budget; do not impose a short arbitrary watchdog on 1.39 million cases. Keep the registered host budget wrapper for mutation audits, preserve the original HDL assertions, and record timeout as unaccepted rather than mutate or trim the workload. Additional exact stage commands are in `plan.json`.

The vendor also contains CPU-only `check_p06_profile_cpu.py` and `test_instruction_timing.py`; run the selected generator identity/full lint/oracle gate in its fresh vendor-local build leaf, not just the board-specific matrix. The gate requires output below that copied CPU project's own build directory. Installed vendor `test_*/prove_*` optimization scripts often contain historical Git references and whole-file guards. Their exact inventory is recorded in JSON. They are not automatically registered by `make regression` or the complete coordinator: map their contract coverage to the current full banks and fresh source-bound gates, and report any separately requested historical experiment's real staleness. Do not claim the complete run executed every installed script merely because it executed every registered unit.

## External inputs and honest gaps

- The physical corpus exists at `D:/GitHub/SPK286/.cache/singlestep-80286` (326 MOO.gz files observed). Root/vendor local caches are absent. Use that exact tree read-only; no download or copy. Verify pinned revision, required blob IDs and SHA manifest before/after. Existence is not a corpus PASS.
- MCL86 reference cache availability is recorded separately in the JSON. Missing input stays unavailable, not a newly waived test.
- Required original full Landmark and old SKIP_PM images are absent at the script defaults; V2 SKIP_PM exists. Four old workloads previously lacked the exact original image. Do not substitute V2 for them. Resolve the originals if an authorized existing path is found; otherwise record their real missing-input result and leave coverage open.
- Phoenix A286 1.01 default image is absent. Resolve the exact prior image before its two gates, or record unavailable. Do not substitute MR BIOS.
- `build/mrbios_1.65_286.bin` exists (64 KiB), and its SHA256 `6f936ee53ba58663d1ccc7b80b1f5caba841f3f816c4dca15477ca540f9f252f` matches the exact investigated image required by `test_at_mrbios_restart.sh`. It is not copied by the standard coordinator. Bind it through `AT_MRBIOS_ROM` and hash before/after without packaging proprietary bytes in committed evidence. Run the unchanged **three-restart** fixture. The prior second-restart failure is unresolved; success must come from the current unweakened test, not a reduced restart count.
- BIOS first-fetch has optional ROM variants in addition to its mandatory diagnostic image. Record each unavailable optional variant. Do not erase optional-coverage gaps when its base fixture passes.
- Legacy CheckIT `IDEAL_OWNER` attribution remains an invalidated counterfactual unless a correct adapter is independently justified. Normal physical CheckIT/profile kernels must still run. The existing code-buffer Git-baseline experiment remains separate from production functional acceptance.
- Standalone SPK286 profile generator/source refresh has been handled by the other agent and synchronized through upstream provenance. Reconfirm the frozen import is identical under the documented vendor exclusions. No second CPU backend is silently used as the PCAT proof reference.

## Disk, logs and cleanup

Allocate all new source snapshots, build objects, tmp and logs under the one owned run directory on D:. If a tool truly requires Linux-native storage, use one explicitly inventoried `/tmp/<unique-run-name>` target and record host C: consumption; ordinary Linux unlink does not necessarily shrink its host VHD. No global cache or Docker prune is part of this plan.

Read free C:/D: space before allocation, between compile stages and after cleanup. Suggested operational floors: 10 GiB on C:, 20 GiB on D:. At a floor, stop allocating new stages, preserve current evidence and mark resource interruption honestly; this is an execution limit, not a relaxed functional pass condition. Use one compile workload at a time. Keep trace digests by default; a failure gets a separate focused trace with the same frozen source/stimulus.

After each completed stage, seal command/environment, logs, source/fixture manifests, receipt, exact generated vectors and binary identity. Verify archive inventory and hashes by readback **before** removing regenerable C++/object/PCH outputs. Keep CPU executable until every dependent physical/audit stage completes; keep compatibility metadata until the aggregate has verified all 290 entries. Never delete an active compiler's objects or a previous fit/RBF. The existing dated PCH cleaner preserves today's files and does not by itself clean this run.

Final cleanup uses one shell end-to-end with resolved absolute owned paths validated against the explicit run root and no symlink/reparse traversal. Parent seals compact source-bound evidence and deletes only this task's inventoried temporary directories. Preserve raw failed logs and separate replay receipts; no proprietary BIOS or full corpus binaries are committed. Record actual free-space changes; do not claim host C: bytes reclaimed solely from deleting WSL files.

## Acceptance

Complete executable regression means every mandatory current stage and matrix finished against the identical frozen candidate, every real negative control rejected functionally, every original expected result preserved and no new unexpected omission. Missing firmware, adapter failure, unresolved MR BIOS restart, timeout or resource interruption remains visible and prevents a blanket full-regression PASS. A passing executable matrix still does not establish physical hardware/pin evidence, validate Windows/OS2/game sessions, or remove the existing publication hold. The current RBF's original timing evidence and the final regression source manifest must match.
