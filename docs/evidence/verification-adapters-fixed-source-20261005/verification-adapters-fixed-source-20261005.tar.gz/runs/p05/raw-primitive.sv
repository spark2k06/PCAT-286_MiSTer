module p05_limit_miter(
input [15:0] offset_value, limit_value, input expand_down, is_byte,
output equivalent);
    function automatic logic protected_range_exceeded(
        input logic [15:0] offset_value, limit_value,
        input logic expand_down, is_byte
    );
        protected_range_exceeded = expand_down ?
            (offset_value <= limit_value || (!is_byte && offset_value == 16'hFFFF)) :
            (offset_value > limit_value || (!is_byte && offset_value == limit_value));
    endfunction
wire reference = expand_down ?
 (offset_value <= limit_value || ({1'b0,offset_value} + (is_byte ? 17'd0 : 17'd1) > 17'h0FFFF)) :
 ({1'b0,offset_value} + (is_byte ? 17'd0 : 17'd1) > {1'b0,limit_value});
assign equivalent = protected_range_exceeded(offset_value,limit_value,expand_down,is_byte) == reference;
endmodule
