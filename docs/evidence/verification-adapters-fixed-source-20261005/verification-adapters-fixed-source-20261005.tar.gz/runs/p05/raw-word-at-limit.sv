module p05_limit_miter(
input wire [15:0] address_offset,
input wire address_override,
input wire execute_enable,
input wire io_transfer,
input wire operand_byte,
input wire [15:0] operand_offset,
input wire operand_register_direct,
input wire operand_request,
input wire [1:0] operand_segment,
input wire operand_select_rm,
input wire operand_write,
input wire [1:0] override_segment,
input wire protected_call_stack_access,
input wire protected_call_stack_expand_down,
input wire [15:0] protected_call_stack_limit,
input wire protected_descriptor_access,
input wire protected_event_access,
input wire [15:0] protected_msw,
input wire [31:0] protected_segment_access,
input wire [63:0] protected_segment_limits,
input wire [3:0] protected_segment_present,
input wire [3:0] protected_segment_protected,
input wire [3:0] protected_segment_valid,
input wire protected_tss_access,
input wire [31:0] real_segment_access_state,
input wire [63:0] real_segment_limits,
input wire segment_override,
input wire [1:0] segment_read_index,
input wire [15:0] stack_offset,
input wire stack_request,
input wire string_destination,
input wire string_request,
input wire [15:0] vector_offset,
input wire vector_request,
output wire equivalent
);
wire [1:0] service_segment;
wire [15:0] service_offset;
wire [1:0] selected_segment_index;
wire [15:0] selected_segment_limit;
wire [7:0] selected_segment_access;
wire protected_segment_is_loaded;
wire protected_segment_is_valid;
wire protected_segment_is_present;
wire protected_segment_is_code;
wire protected_segment_is_readable;
wire protected_segment_is_writable;
wire protected_segment_is_expand_down;
wire protected_selected_range_fault;
wire parallel_operand_within_limit;
wire protected_call_range_fault;
wire protected_access_fault;
wire protected_access_ss_fault;
wire [3:0] operand_io_ranges;
wire [3:0] operand_address_ranges;
wire [3:0] operand_stack_ranges;
wire [3:0] operand_regular_ranges;
wire [3:0] operand_vector_ranges;
wire [3:0] operand_system_ranges;
genvar operand_cache_index;
    assign service_segment = string_request ? (string_destination ? 2'd0 : (segment_override ? override_segment : 2'd3)) : stack_request ? 2'd2 : (segment_override ? override_segment : operand_segment);
    assign service_offset = io_transfer ? 16'd0 : address_override && !stack_request && !vector_request ? address_offset : vector_request ? vector_offset : (stack_request ? stack_offset : operand_offset);
    assign selected_segment_index = execute_enable ? service_segment : segment_read_index;
    assign selected_segment_limit = protected_msw[0] ? protected_segment_limits[selected_segment_index * 16 +: 16] : real_segment_limits[selected_segment_index * 16 +: 16];
    assign selected_segment_access = protected_msw[0] ? protected_segment_access[selected_segment_index * 8 +: 8] : real_segment_access_state[selected_segment_index * 8 +: 8];
    assign protected_segment_is_loaded = protected_msw[0] && protected_segment_protected[service_segment];
    assign protected_segment_is_valid = protected_segment_valid[service_segment];
    assign protected_segment_is_present = protected_segment_present[service_segment];
    assign protected_segment_is_code = selected_segment_access[3];
    assign protected_segment_is_readable = selected_segment_access[1];
    assign protected_segment_is_writable = !protected_segment_is_code && selected_segment_access[1];
    assign protected_segment_is_expand_down = !protected_segment_is_code && selected_segment_access[2];
    assign protected_selected_range_fault = !parallel_operand_within_limit;
    assign parallel_operand_within_limit =
        (protected_event_access || protected_descriptor_access || protected_tss_access || protected_call_stack_access) ? 1'b1 :
        vector_request ? operand_vector_ranges[selected_segment_index] :
        io_transfer ? operand_io_ranges[selected_segment_index] :
        address_override && !stack_request ? operand_address_ranges[selected_segment_index] :
        stack_request ? operand_stack_ranges[selected_segment_index] :
        operand_regular_ranges[selected_segment_index];
    assign protected_call_range_fault = stack_request ?
        protected_range_exceeded(stack_offset, protected_call_stack_limit, protected_call_stack_expand_down, operand_byte) :
        address_override ? protected_range_exceeded(address_offset, protected_call_stack_limit, protected_call_stack_expand_down, operand_byte) :
        protected_range_exceeded(operand_offset, protected_call_stack_limit, protected_call_stack_expand_down, operand_byte);
    assign protected_access_fault = operand_request && operand_select_rm && !operand_register_direct &&
                                   !protected_descriptor_access && !protected_tss_access && !protected_event_access &&
                                   !io_transfer && !vector_request &&
                                    (protected_call_stack_access ?
                                    (service_segment != 2'd2 || protected_call_range_fault) :
                                    (protected_segment_is_loaded &&
                                     (!protected_segment_is_valid || !protected_segment_is_present ||
                                      (protected_segment_is_code ? (!protected_segment_is_readable || operand_write) :
                                       (stack_request ? (!protected_segment_is_writable || service_segment != 2'd2) :
                                        (operand_write && !protected_segment_is_writable))) ||
                                      protected_selected_range_fault)));
    assign protected_access_ss_fault = protected_access_fault && service_segment == 2'd2;
    function automatic logic protected_range_exceeded(
        input logic [15:0] offset_value, limit_value,
        input logic expand_down, is_byte
    );
        protected_range_exceeded = expand_down ?
            (offset_value <= limit_value || (!is_byte && offset_value == 16'hFFFF)) :
            (offset_value > limit_value || 1'b0);
    endfunction
    generate
    for (operand_cache_index = 0; operand_cache_index < 4; operand_cache_index = operand_cache_index + 1) begin : g_operand_cache_range
        wire [15:0] cache_limit = protected_msw[0] ?
            protected_segment_limits[operand_cache_index*16 +: 16] :
            real_segment_limits[operand_cache_index*16 +: 16];
        wire cache_expand_down = protected_msw[0] &&
            !protected_segment_access[operand_cache_index*8+3] &&
            protected_segment_access[operand_cache_index*8+2];
        assign operand_io_ranges[operand_cache_index] =
            !protected_range_exceeded(16'd0, cache_limit, cache_expand_down, operand_byte);
        assign operand_address_ranges[operand_cache_index] =
            !protected_range_exceeded(address_offset, cache_limit, cache_expand_down, operand_byte);
        assign operand_stack_ranges[operand_cache_index] =
            !protected_range_exceeded(stack_offset, cache_limit, cache_expand_down, operand_byte);
        assign operand_regular_ranges[operand_cache_index] =
            !protected_range_exceeded(operand_offset, cache_limit, cache_expand_down, operand_byte);
        assign operand_vector_ranges[operand_cache_index] =
            !protected_range_exceeded(io_transfer ? 16'd0 : vector_offset, 16'hFFFF, cache_expand_down, operand_byte);
        // Six-byte table operands use the ordinary effective offset.
        // Complete each cache's range comparison before the late index mux.
        assign operand_system_ranges[operand_cache_index] = cache_expand_down ?
            (operand_offset <= cache_limit || operand_offset > 16'hFFFA) :
            ({1'b0, operand_offset} + 17'd5 > {1'b0, cache_limit});
    end
    endgenerate
wire reference = 
operand_request && operand_select_rm && !operand_register_direct &&
!protected_descriptor_access && !protected_tss_access && !protected_event_access &&
!io_transfer && !vector_request &&
(protected_call_stack_access ?
 (service_segment != 2'd2 ||
  (protected_call_stack_expand_down ?
   ({1'b0, service_offset} <= {1'b0, protected_call_stack_limit} ||
    ({1'b0, service_offset} + (operand_byte ? 17'd0 : 17'd1) > 17'h0FFFF)) :
   ({1'b0, service_offset} + (operand_byte ? 17'd0 : 17'd1) > {1'b0, protected_call_stack_limit}))) :
 (protected_segment_is_loaded &&
  (!protected_segment_is_valid || !protected_segment_is_present ||
   (protected_segment_is_code ? (!protected_segment_is_readable || operand_write) :
    (stack_request ? (!protected_segment_is_writable || service_segment != 2'd2) :
     (operand_write && !protected_segment_is_writable))) ||
   (protected_segment_is_expand_down ?
    ({1'b0, service_offset} <= {1'b0, selected_segment_limit} ||
     ({1'b0, service_offset} + (operand_byte ? 17'd0 : 17'd1) > 17'h0FFFF)) :
    ({1'b0, service_offset} + (operand_byte ? 17'd0 : 17'd1) > {1'b0, selected_segment_limit})))))
;
assign equivalent = protected_access_fault == reference &&
                    protected_access_ss_fault == (reference && service_segment == 2'd2);
endmodule
