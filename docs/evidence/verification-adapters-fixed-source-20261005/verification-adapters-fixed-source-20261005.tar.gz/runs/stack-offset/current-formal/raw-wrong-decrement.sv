module offset_old(
    input call_parameter_read, call_parameter_write, iret_outer_pop, read_frame_address,
    input allocation_valid_q,
    input [15:0] call_parameter_source_sp_q, stack_cursor_q, return_stack_pointer,
    input [15:0] allocation_q, frame_address_q, stack_native_offset,
    output [15:0] stack_offset
);
    assign stack_offset = call_parameter_read ? call_parameter_source_sp_q :
                          call_parameter_write ? (stack_cursor_q - 16'd2) :
                          iret_outer_pop ? (return_stack_pointer + (allocation_valid_q ? allocation_q : 16'd0)) :
                          read_frame_address ? frame_address_q : stack_native_offset;
endmodule
module offset_candidate(
input wire call_parameter_read,
input wire call_parameter_write,
input wire iret_outer_pop,
input wire read_frame_address,
input wire allocation_valid_q,
input wire [15:0] call_parameter_source_sp_q,
input wire [15:0] stack_cursor_q,
input wire [15:0] return_stack_pointer,
input wire [15:0] allocation_q,
input wire [15:0] frame_address_q,
input wire [15:0] stack_native_offset,
output wire [15:0] stack_offset
);
wire [15:0] call_parameter_write_offset;
wire [15:0] iret_parameter_bytes;
wire [15:0] iret_outer_stack_offset;
    assign call_parameter_write_offset = stack_cursor_q - 16'd1;
    assign iret_parameter_bytes = allocation_valid_q ? allocation_q : 16'd0;
    assign iret_outer_stack_offset = return_stack_pointer + iret_parameter_bytes;
    assign stack_offset = call_parameter_read ? call_parameter_source_sp_q :
                          call_parameter_write ? call_parameter_write_offset :
                          iret_outer_pop ? iret_outer_stack_offset :
                          read_frame_address ? frame_address_q : stack_native_offset;
endmodule

module miter(
input wire call_parameter_read,
input wire call_parameter_write,
input wire iret_outer_pop,
input wire read_frame_address,
input wire allocation_valid_q,
input wire [15:0] call_parameter_source_sp_q,
input wire [15:0] stack_cursor_q,
input wire [15:0] return_stack_pointer,
input wire [15:0] allocation_q,
input wire [15:0] frame_address_q,
input wire [15:0] stack_native_offset,
output wire equivalent
);
wire [15:0] expected, observed;
offset_old u_expected(.call_parameter_read(call_parameter_read),.call_parameter_write(call_parameter_write),.iret_outer_pop(iret_outer_pop),.read_frame_address(read_frame_address),.allocation_valid_q(allocation_valid_q),.call_parameter_source_sp_q(call_parameter_source_sp_q),.stack_cursor_q(stack_cursor_q),.return_stack_pointer(return_stack_pointer),.allocation_q(allocation_q),.frame_address_q(frame_address_q),.stack_native_offset(stack_native_offset),.stack_offset(expected));
offset_candidate u_observed(.call_parameter_read(call_parameter_read),.call_parameter_write(call_parameter_write),.iret_outer_pop(iret_outer_pop),.read_frame_address(read_frame_address),.allocation_valid_q(allocation_valid_q),.call_parameter_source_sp_q(call_parameter_source_sp_q),.stack_cursor_q(stack_cursor_q),.return_stack_pointer(return_stack_pointer),.allocation_q(allocation_q),.frame_address_q(frame_address_q),.stack_native_offset(stack_native_offset),.stack_offset(observed));
assign equivalent = expected == observed;
endmodule
