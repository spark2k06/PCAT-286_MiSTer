// 80286 selector decomposition and complete 8-byte descriptor-table bounds.
// This service is pure combinational PM0 infrastructure. It does not fetch
// memory or commit architectural state.
`timescale 1ns/1ps

module spk286_selector (
    input  logic [15:0] selector,
    input  logic [15:0] table_limit,
    input  logic [23:0] table_base,
    output logic [12:0] index,
    output logic        table_indicator,
    output logic [1:0]  rpl,
    output logic        null_selector,
    output logic [20:0] descriptor_end,
    output logic        descriptor_limit_valid,
    output logic        descriptor_selector_valid,
    output logic [23:0] descriptor_address,
    output logic        descriptor_address_carry
);
    logic [19:0] descriptor_offset;
    logic [24:0] address_sum;

    always_comb begin
        index = selector[15:3];
        table_indicator = selector[2];
        rpl = selector[1:0];
        // Only GDT entry zero is null; LDT entry zero (TI=1) is usable.
        null_selector = selector[15:2] == 14'd0;

        // 13-bit index * 8 plus the final byte is deliberately carried in
        // 21 bits. A truncated 16-bit expression could wrap an invalid entry
        // back into the beginning of a table.
        descriptor_offset = {4'b0, selector[15:3], 3'b000};
        descriptor_end = {1'b0, descriptor_offset} + 21'd7;
        descriptor_limit_valid = descriptor_end <= {5'b0, table_limit};
        descriptor_selector_valid = !null_selector && descriptor_limit_valid;

        address_sum = {1'b0, table_base} + {5'b0, descriptor_offset};
        descriptor_address = address_sum[23:0];
        descriptor_address_carry = address_sum[24];
    end
endmodule

module cone_reference(
input wire  allowed,
input wire  call_gate_candidate_valid_q,
input wire  call_stack_ready_q,
input wire [15:0] call_stack_ss_q,
input wire  descriptor_active_q,
input wire  event_gate_candidate_valid_q,
input wire  iret_outer_ready_q,
input wire [15:0] iret_outer_ss_q,
input wire [8-1:0] operation,
input wire [23:0] protected_gdtr_base,
input wire [15:0] protected_gdtr_limit,
input wire [23:0] protected_ldtr_base,
input wire [15:0] protected_ldtr_limit,
input wire  protected_ldtr_present,
input wire  protected_ldtr_valid,
input wire [15:0] protected_msw,
input wire [1:0] segment_index,
input wire  task_gate_target_active_q,
input wire [15:0] task_gate_target_selector_q,
input wire [2:0] temporary_valid_q,
input wire [15:0] tmp0_q,
input wire [15:0] tmp1_q,
output wire  descriptor_segment_null_commit,
output wire [12:0] descriptor_unused_index,
output wire  descriptor_selector_ti,
output wire [1:0] descriptor_unused_rpl,
output wire  descriptor_selector_null,
output wire [20:0] descriptor_unused_end,
output wire  descriptor_selector_limit_valid,
output wire  descriptor_unused_selector_valid,
output wire [23:0] descriptor_selector_address,
output wire  descriptor_selector_carry
);
    localparam integer MC_FORMAT_VERSION = 27;
    localparam integer MC_ADDR_WIDTH = 10;
    localparam integer MC_WORD_WIDTH = 8;
    localparam integer MC_DEPTH = 743;
    localparam logic [MC_WORD_WIDTH-1:0] MC_INVALID = 8'd0;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_IMM16 = 8'd1;
    localparam logic [MC_WORD_WIDTH-1:0] MC_MOVE = 8'd2;
    localparam logic [MC_WORD_WIDTH-1:0] MC_END = 8'd3;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECODE_MODRM = 8'd4;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_REG16 = 8'd5;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_RM16 = 8'd6;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_REG16 = 8'd7;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_RM16 = 8'd8;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_REG16_TMP1 = 8'd9;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_RM16_TMP1 = 8'd10;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_IMM16_TMP1 = 8'd11;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_IMM8S_TMP1 = 8'd12;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_DST16 = 8'd13;
    localparam logic [MC_WORD_WIDTH-1:0] MC_ALU = 8'd14;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_RESULT_REG16 = 8'd15;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_RESULT_RM16 = 8'd16;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_RESULT_DST = 8'd17;
    localparam logic [MC_WORD_WIDTH-1:0] MC_COMMIT_FLAGS = 8'd18;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_RM16 = 8'd19;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_IMM8S_TMP0 = 8'd20;
    localparam logic [MC_WORD_WIDTH-1:0] MC_PUSH16 = 8'd21;
    localparam logic [MC_WORD_WIDTH-1:0] MC_POP16 = 8'd22;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_IP16 = 8'd23;
    localparam logic [MC_WORD_WIDTH-1:0] MC_TARGET_REL16 = 8'd24;
    localparam logic [MC_WORD_WIDTH-1:0] MC_TARGET_ABS16 = 8'd25;
    localparam logic [MC_WORD_WIDTH-1:0] MC_REDIRECT = 8'd26;
    localparam logic [MC_WORD_WIDTH-1:0] MC_ADJUST_SP16 = 8'd27;
    localparam logic [MC_WORD_WIDTH-1:0] MC_COUNT = 8'd28;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_IMM8 = 8'd29;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_FLAGS = 8'd30;
    localparam logic [MC_WORD_WIDTH-1:0] MC_RESTORE_FLAGS = 8'd31;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SET_IF = 8'd32;
    localparam logic [MC_WORD_WIDTH-1:0] MC_HALT = 8'd33;
    localparam logic [MC_WORD_WIDTH-1:0] MC_REQUEST_EVENT = 8'd34;
    localparam logic [MC_WORD_WIDTH-1:0] MC_EVENT_ACK = 8'd35;
    localparam logic [MC_WORD_WIDTH-1:0] MC_EVENT_FLAGS = 8'd36;
    localparam logic [MC_WORD_WIDTH-1:0] MC_EVENT_CS = 8'd37;
    localparam logic [MC_WORD_WIDTH-1:0] MC_EVENT_IP = 8'd38;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CLEAR_IF_TF = 8'd39;
    localparam logic [MC_WORD_WIDTH-1:0] MC_VECTOR_IP = 8'd40;
    localparam logic [MC_WORD_WIDTH-1:0] MC_VECTOR_CS = 8'd41;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CONTEXT_COMMIT = 8'd42;
    localparam logic [MC_WORD_WIDTH-1:0] MC_POP16_TMP1 = 8'd43;
    localparam logic [MC_WORD_WIDTH-1:0] MC_POP16_TMP2 = 8'd44;
    localparam logic [MC_WORD_WIDTH-1:0] MC_IRET_COMMIT = 8'd45;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_REG8 = 8'd46;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_RM8 = 8'd47;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_REG8 = 8'd48;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_RM8 = 8'd49;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_IMM8_TMP1 = 8'd50;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_REG8_TMP1 = 8'd51;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_RM8_TMP1 = 8'd52;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_DST8 = 8'd53;
    localparam logic [MC_WORD_WIDTH-1:0] MC_MOVE8 = 8'd54;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_RESULT_REG8 = 8'd55;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_RESULT_RM8 = 8'd56;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_RESULT_DST8 = 8'd57;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FLAGS_DECODED = 8'd58;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SIGN_EXTEND8 = 8'd59;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SIGN_FILL16 = 8'd60;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CONST_ONE_TMP1 = 8'd61;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SHIFT = 8'd62;
    localparam logic [MC_WORD_WIDTH-1:0] MC_COUNT_LOW_TMP1 = 8'd63;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_EA = 8'd64;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_REG8_TMP1 = 8'd65;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_REG16_TMP1 = 8'd66;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_TARGET16_TMP1 = 8'd67;
    localparam logic [MC_WORD_WIDTH-1:0] MC_MOVE_SOURCE16_TMP1 = 8'd68;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SET_ADDRESS_TMP1 = 8'd69;
    localparam logic [MC_WORD_WIDTH-1:0] MC_ADD_BASE_TMP0_TMP1 = 8'd70;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DISPATCH_DECODED = 8'd71;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CONST_ZERO_TMP1 = 8'd72;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CONST_ONES_TMP1 = 8'd73;
    localparam logic [MC_WORD_WIDTH-1:0] MC_ADJUST = 8'd74;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_ARITHMETIC = 8'd75;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_SEG16_TMP0 = 8'd76;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_SEG16_TMP0 = 8'd77;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_AX_TMP0 = 8'd78;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_CX_TMP0 = 8'd79;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_DX_TMP0 = 8'd80;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_BX_TMP0 = 8'd81;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_SP_TMP0 = 8'd82;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_BP_TMP0 = 8'd83;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_SI_TMP0 = 8'd84;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_DI_TMP0 = 8'd85;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_AX_TMP0 = 8'd86;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_CX_TMP0 = 8'd87;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_DX_TMP0 = 8'd88;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_BX_TMP0 = 8'd89;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_SP_TMP0 = 8'd90;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_BP_TMP0 = 8'd91;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_SI_TMP0 = 8'd92;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_DI_TMP0 = 8'd93;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SAVE_AUX_TMP0 = 8'd94;
    localparam logic [MC_WORD_WIDTH-1:0] MC_RESTORE_AUX_TMP0 = 8'd95;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SAVE_ALLOCATION_TMP0 = 8'd96;
    localparam logic [MC_WORD_WIDTH-1:0] MC_LOAD_COUNTER_TMP1 = 8'd97;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECREMENT_COUNTER = 8'd98;
    localparam logic [MC_WORD_WIDTH-1:0] MC_BRANCH_ZERO = 8'd99;
    localparam logic [MC_WORD_WIDTH-1:0] MC_BRANCH_NONZERO = 8'd100;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_PUSH8 = 8'd101;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_POP8 = 8'd102;
    localparam logic [MC_WORD_WIDTH-1:0] MC_BEGIN_STACK_CURSOR = 8'd103;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_STACK_TMP0 = 8'd104;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SET_STACK_ADDRESS_TMP0 = 8'd105;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_STACK_ADDRESS_TMP0 = 8'd106;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECREMENT_STACK_ADDRESS = 8'd107;
    localparam logic [MC_WORD_WIDTH-1:0] MC_ALLOCATE_STACK = 8'd108;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_RM32 = 8'd109;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SET_EA_PLUS2 = 8'd110;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_BOUNDS = 8'd111;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_STACK_CURSOR_TMP0 = 8'd112;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_PUSH2 = 8'd113;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_POP2 = 8'd114;
    localparam logic [MC_WORD_WIDTH-1:0] MC_ADD_ALLOCATION_SP = 8'd115;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_STORE_GDTR = 8'd136;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_STORE_IDTR = 8'd137;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_LOAD_GDTR = 8'd138;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_LOAD_IDTR = 8'd139;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_STORE_MSW = 8'd140;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_LOAD_MSW = 8'd141;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_STORE_LDTR = 8'd142;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_STORE_TR = 8'd143;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_LOAD_LDTR = 8'd144;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_LOAD_TR = 8'd145;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_VERIFY_READ = 8'd146;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_VERIFY_WRITE = 8'd147;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_LOAD_ACCESS = 8'd148;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_LOAD_LIMIT = 8'd149;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_ARPL_CHECK = 8'd166;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_ARPL = 8'd167;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_CLTS = 8'd168;
    localparam logic [MC_WORD_WIDTH-1:0] MC_TASK_SWITCH = 8'd169;
    localparam logic [MC_WORD_WIDTH-1:0] MC_TASK_RETURN = 8'd170;
    localparam logic [MC_WORD_WIDTH-1:0] MC_LOADALL = 8'd171;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CARRY_FILL8 = 8'd172;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_PROTECTED_MODE = 8'd193;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_SYSTEM_PRIVILEGE = 8'd194;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_IO_PRIVILEGE = 8'd195;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_NPX_ESC = 8'd196;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_NPX_WAIT = 8'd197;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECODE_ALU_RM16_REG16 = 8'd173;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECODE_ALU_REG16_RM16 = 8'd174;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECODE_ALU_RM8_REG8 = 8'd175;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECODE_ALU_REG8_RM8 = 8'd176;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECODE_MOV_RM16_REG16 = 8'd177;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECODE_MOV_REG16_RM16 = 8'd178;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECODE_MOV_RM8_REG8 = 8'd179;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECODE_MOV_REG8_RM8 = 8'd180;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECODE_UNARY_RM16 = 8'd190;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECODE_UNARY_RM8 = 8'd191;
    localparam logic [MC_WORD_WIDTH-1:0] MC_EXEC_INC_DEC_DST16 = 8'd192;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_ALU_DST16_IMM16 = 8'd181;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_ALU_DST8_IMM8 = 8'd182;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_ALU_RM16_IMM16 = 8'd183;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_ALU_RM16_IMM8S = 8'd184;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_ALU_RM8_IMM8 = 8'd185;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_MOV_DST16_IMM16 = 8'd186;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_MOV_DST8_IMM8 = 8'd187;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_MOV_RM16_IMM16 = 8'd188;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_MOV_RM8_IMM8 = 8'd189;
    localparam logic [MC_WORD_WIDTH-1:0] MC_VALIDATE_CS = 8'd150;
    localparam logic [MC_WORD_WIDTH-1:0] MC_VALIDATE_EVENT_GATE = 8'd151;
    localparam logic [MC_WORD_WIDTH-1:0] MC_EVENT_GATE_IP = 8'd152;
    localparam logic [MC_WORD_WIDTH-1:0] MC_EVENT_GATE_CS = 8'd153;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CLEAR_EVENT_FLAGS = 8'd154;
    localparam logic [MC_WORD_WIDTH-1:0] MC_PUSH_EVENT_ERROR = 8'd155;
    localparam logic [MC_WORD_WIDTH-1:0] MC_VALIDATE_IRET_CS = 8'd156;
    localparam logic [MC_WORD_WIDTH-1:0] MC_IRET_OUTER_FRAME = 8'd157;
    localparam logic [MC_WORD_WIDTH-1:0] MC_VALIDATE_IRET_SS = 8'd158;
    localparam logic [MC_WORD_WIDTH-1:0] MC_VALIDATE_CALL_GATE = 8'd159;
    localparam logic [MC_WORD_WIDTH-1:0] MC_VALIDATE_CALL_CS = 8'd160;
    localparam logic [MC_WORD_WIDTH-1:0] MC_VALIDATE_CALL_STACK = 8'd161;
    localparam logic [MC_WORD_WIDTH-1:0] MC_VALIDATE_CALL_SS = 8'd162;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CALL_GATE_STACK_SWITCH = 8'd163;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_CALL_FRAME = 8'd164;
    localparam logic [MC_WORD_WIDTH-1:0] MC_COPY_CALL_PARAMETERS = 8'd165;
    localparam logic [MC_WORD_WIDTH-1:0] MC_BRANCH_REPEAT_EMPTY = 8'd121;
    localparam logic [MC_WORD_WIDTH-1:0] MC_STEP_STRING_SOURCE = 8'd122;
    localparam logic [MC_WORD_WIDTH-1:0] MC_STEP_STRING_DEST = 8'd123;
    localparam logic [MC_WORD_WIDTH-1:0] MC_REPEAT_COUNT = 8'd124;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_STRING_TMP0 = 8'd125;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_STRING_TMP1 = 8'd126;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_STRING_TMP0 = 8'd127;
    localparam logic [MC_WORD_WIDTH-1:0] MC_BRANCH_REPEAT_CONTINUE = 8'd128;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_STRING_ACCUMULATOR = 8'd129;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_STRING_ACCUMULATOR = 8'd130;
    localparam logic [MC_WORD_WIDTH-1:0] MC_IO_READ8 = 8'd131;
    localparam logic [MC_WORD_WIDTH-1:0] MC_IO_READ16 = 8'd132;
    localparam logic [MC_WORD_WIDTH-1:0] MC_IO_WRITE8 = 8'd133;
    localparam logic [MC_WORD_WIDTH-1:0] MC_IO_WRITE16 = 8'd134;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_PORT = 8'd135;
    localparam logic [MC_WORD_WIDTH-1:0] MC_MULDIV8 = 8'd116;
    localparam logic [MC_WORD_WIDTH-1:0] MC_MULDIV16 = 8'd117;
    localparam logic [MC_WORD_WIDTH-1:0] MC_IMUL_IMM16 = 8'd118;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_RESULT_AX16 = 8'd119;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_RESULT_DX16 = 8'd120;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_MOV_R16_IMM16 = 10'd0;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_MOV_RM16_R16 = 10'd3;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_MOV_R16_RM16 = 10'd7;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ALU_RM16_R16 = 10'd11;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ALU_R16_RM16 = 10'd18;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ALU_AX_IMM16 = 10'd25;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ALU_RM16_IMM16 = 10'd31;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ALU_RM16_IMM8S = 10'd38;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_PUSH_R16 = 10'd45;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_POP_R16 = 10'd48;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_PUSH_IMM16 = 10'd51;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_PUSH_IMM8S = 10'd54;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_POP_RM16 = 10'd57;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_GROUP5_NEAR = 10'd61;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_CALL_REL16 = 10'd67;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_JMP_REL16 = 10'd73;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_BRANCH_REL8 = 10'd77;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_LOOP_REL8 = 10'd81;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_RET_NEAR = 10'd86;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_RET_IMM16 = 10'd90;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_PUSH_FLAGS = 10'd96;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_POP_FLAGS = 10'd99;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_CONTROL_IF = 10'd102;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_HALT_CPU = 10'd104;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SOFTWARE_EVENT = 10'd106;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SOFTWARE_EVENT_IMM8 = 10'd108;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_INTERRUPT_RETURN = 10'd111;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_EVENT_ENTRY = 10'd120;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_EVENT_ENTRY_PROTECTED = 10'd137;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_MOV_R8_IMM8 = 10'd159;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_MOV_RM8_R8 = 10'd162;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_MOV_R8_RM8 = 10'd166;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_MOV_RM8_IMM8 = 10'd170;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_MOV_RM16_IMM16 = 10'd174;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ALU_RM8_R8 = 10'd178;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ALU_R8_RM8 = 10'd185;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ALU_AL_IMM8 = 10'd192;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ALU_RM8_IMM8 = 10'd198;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_CONTROL_FLAGS = 10'd205;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_LOAD_FLAGS_BYTE = 10'd207;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_EXTEND_BYTE = 10'd210;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_EXTEND_WORD = 10'd214;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_INC_DEC_R16 = 10'd218;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SHIFT_RM8_ONE = 10'd224;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SHIFT_RM8_CL = 10'd231;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SHIFT_RM8_IMM8 = 10'd238;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SHIFT_RM16_ONE = 10'd245;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SHIFT_RM16_CL = 10'd252;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SHIFT_RM16_IMM8 = 10'd259;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_LEA_R16_M = 10'd266;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_EXCHANGE_RM8_R8 = 10'd270;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_EXCHANGE_RM16_R16 = 10'd276;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_EXCHANGE_SOURCE_TARGET16 = 10'd282;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_LOAD_DIRECT8 = 10'd287;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_LOAD_DIRECT16 = 10'd292;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_STORE_DIRECT8 = 10'd297;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_STORE_DIRECT16 = 10'd302;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_LOAD_BASE_INDEX8 = 10'd307;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_GROUP3_DISPATCH = 10'd313;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_GROUP5_DISPATCH = 10'd315;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_NOT_RM8 = 10'd317;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_NOT_RM16 = 10'd324;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_NEG_RM8 = 10'd331;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_NEG_RM16 = 10'd338;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_INC_DEC_RM8 = 10'd345;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_INC_DEC_RM16 = 10'd352;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ADJUST_DIRECT = 10'd359;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ADJUST_RADIX = 10'd366;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_MOV_RM16_SEG = 10'd373;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_MOV_SEG_RM16 = 10'd377;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_PUSH_SEG = 10'd381;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_POP_SEG = 10'd384;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_PUSH_ALL = 10'd387;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_POP_ALL = 10'd407;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ENTER_FRAME = 10'd424;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_LEAVE_FRAME = 10'd449;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_CHECK_BOUNDS = 10'd455;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_LOAD_POINTER = 10'd464;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_CALL_FAR_IMM = 10'd474;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_JMP_FAR_IMM = 10'd492;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_CALL_FAR_RM = 10'd498;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_JMP_FAR_RM = 10'd519;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_RET_FAR = 10'd528;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_RET_FAR_IMM = 10'd536;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_MULDIV_RM8 = 10'd547;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_MULDIV_RM16 = 10'd554;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_IMUL_R16_RM16_IMM16 = 10'd562;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_IMUL_R16_RM16_IMM8S = 10'd569;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_STRING_MOVE = 10'd576;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_STRING_COMPARE = 10'd584;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_STRING_STORE = 10'd595;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_STRING_LOAD = 10'd602;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_STRING_SCAN = 10'd609;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_IN_AL_PORT = 10'd619;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_IN_AX_PORT = 10'd624;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_OUT_PORT_AL = 10'd629;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_OUT_PORT_AX = 10'd634;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_STRING_INPUT_BYTE = 10'd639;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_STRING_INPUT_WORD = 10'd648;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_STRING_OUTPUT_BYTE = 10'd657;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_STRING_OUTPUT_WORD = 10'd666;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ESC_NO_COPROCESSOR = 10'd675;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_WAIT_NO_COPROCESSOR = 10'd679;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_GROUP_0F01 = 10'd681;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_STORE_GDTR = 10'd683;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_STORE_IDTR = 10'd685;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_LOAD_GDTR = 10'd687;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_LOAD_IDTR = 10'd689;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_STORE_MSW = 10'd691;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_LOAD_MSW = 10'd693;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_GROUP_0F00 = 10'd695;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_STORE_LDTR = 10'd697;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_STORE_TR = 10'd700;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_LOAD_LDTR = 10'd703;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_LOAD_TR = 10'd707;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_VERIFY_READ = 10'd711;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_VERIFY_WRITE = 10'd715;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_LOAD_ACCESS = 10'd719;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_LOAD_LIMIT = 10'd724;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_ARPL = 10'd729;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_CLTS = 10'd735;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_LOADALL = 10'd737;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_LOAD_CARRY_BYTE = 10'd739;
wire  call_gate_cs_validation_operation;
wire  call_gate_validation_operation;
wire  call_ss_validation_operation;
wire  cs_validation_operation;
wire  descriptor_begin;
wire  descriptor_inspect_operation;
wire  descriptor_load_access;
wire  descriptor_load_ldtr;
wire  descriptor_load_limit;
wire  descriptor_load_operation;
wire  descriptor_load_tr;
wire  descriptor_pre_fault;
wire [15:0] descriptor_selector_value;
wire [23:0] descriptor_table_base;
wire [15:0] descriptor_table_limit;
wire  descriptor_verify_operation;
wire  descriptor_verify_read;
wire  descriptor_verify_write;
wire  iret_cs_validation_operation;
wire  iret_ss_validation_operation;
wire  jmp_gate_cs_validation_operation;
wire  segment_reload_operation;
wire  system_verify_read;
wire  system_verify_write;
    assign call_gate_cs_validation_operation = jmp_gate_cs_validation_operation ||
                                               (allowed && operation == MC_VALIDATE_CALL_CS &&
                                                protected_msw[0] && call_gate_candidate_valid_q);
    assign call_gate_validation_operation = allowed && operation == MC_VALIDATE_CALL_GATE && protected_msw[0];
    assign call_ss_validation_operation = allowed && operation == MC_VALIDATE_CALL_SS && protected_msw[0];
    assign cs_validation_operation = allowed && protected_msw[0] &&
                                     ((operation == MC_VALIDATE_CS &&
                                       !jmp_gate_cs_validation_operation) ||
                                      (operation == MC_VALIDATE_CALL_CS &&
                                       !call_gate_candidate_valid_q));
    assign descriptor_begin = descriptor_load_operation &&
                              ((cs_validation_operation || call_gate_validation_operation || call_gate_cs_validation_operation ||
                                iret_cs_validation_operation) ? temporary_valid_q[1] :
                               iret_ss_validation_operation ? iret_outer_ready_q :
                               call_ss_validation_operation ? call_stack_ready_q : temporary_valid_q[0]) &&
                              !descriptor_active_q;
    assign descriptor_inspect_operation = descriptor_load_access || descriptor_load_limit;
    assign descriptor_load_access = allowed && operation == MC_SYSTEM_LOAD_ACCESS;
    assign descriptor_load_ldtr = allowed && operation == MC_SYSTEM_LOAD_LDTR;
    assign descriptor_load_limit = allowed && operation == MC_SYSTEM_LOAD_LIMIT;
    assign descriptor_load_operation = descriptor_load_ldtr || descriptor_load_tr || descriptor_verify_operation ||
                                      descriptor_inspect_operation || segment_reload_operation || cs_validation_operation ||
                                      call_gate_validation_operation || call_gate_cs_validation_operation || call_ss_validation_operation ||
                                      iret_cs_validation_operation || iret_ss_validation_operation;
    assign descriptor_load_tr = allowed && operation == MC_SYSTEM_LOAD_TR;
    assign descriptor_pre_fault = descriptor_begin &&
                                  (!protected_msw[0] ||
                                   ((descriptor_load_ldtr || descriptor_load_tr) &&
                                    (descriptor_selector_ti || descriptor_selector_carry ||
                                     (!descriptor_selector_null && !descriptor_selector_limit_valid) ||
                                     (descriptor_load_tr && descriptor_selector_null))) ||
                                   (segment_reload_operation &&
                                    (descriptor_selector_carry ||
                                     (!descriptor_selector_null && !descriptor_selector_limit_valid) ||
                                     (descriptor_selector_null && segment_index == 2'd2))) ||
                                   ((cs_validation_operation || call_gate_validation_operation || call_gate_cs_validation_operation ||
                                      iret_cs_validation_operation) &&
                                    (descriptor_selector_carry || descriptor_selector_null ||
                                     (!descriptor_selector_limit_valid) ||
                                     (descriptor_selector_ti && (!protected_ldtr_valid || !protected_ldtr_present)))) ||
                                   (call_ss_validation_operation &&
                                    (descriptor_selector_carry || descriptor_selector_null ||
                                     (!descriptor_selector_limit_valid) ||
                                     (descriptor_selector_ti && (!protected_ldtr_valid || !protected_ldtr_present)))) ||
                                   (iret_ss_validation_operation &&
                                    (descriptor_selector_carry || descriptor_selector_null ||
                                     (!descriptor_selector_limit_valid) ||
                                     (descriptor_selector_ti && (!protected_ldtr_valid || !protected_ldtr_present)))));
    assign descriptor_segment_null_commit = descriptor_begin && segment_reload_operation &&
                                           descriptor_selector_null && !descriptor_pre_fault && segment_index != 2'd2;
    assign descriptor_selector_value = (cs_validation_operation || call_gate_validation_operation ||
                                        call_gate_cs_validation_operation || iret_cs_validation_operation) ?
                                       (task_gate_target_active_q ? task_gate_target_selector_q : tmp1_q) :
                                       iret_ss_validation_operation ? iret_outer_ss_q :
                                       call_ss_validation_operation ? call_stack_ss_q : tmp0_q;
    assign descriptor_table_base = descriptor_selector_ti ? protected_ldtr_base : protected_gdtr_base;
    assign descriptor_table_limit = descriptor_selector_ti ? protected_ldtr_limit : protected_gdtr_limit;
    assign descriptor_verify_operation = descriptor_verify_read || descriptor_verify_write;
    assign descriptor_verify_read = system_verify_read;
    assign descriptor_verify_write = system_verify_write;
    assign iret_cs_validation_operation = allowed && operation == MC_VALIDATE_IRET_CS && protected_msw[0];
    assign iret_ss_validation_operation = allowed && operation == MC_VALIDATE_IRET_SS && protected_msw[0];
    assign jmp_gate_cs_validation_operation = allowed && protected_msw[0] &&
                                              operation == MC_VALIDATE_CS &&
                                              call_gate_candidate_valid_q && !event_gate_candidate_valid_q;
    assign segment_reload_operation = allowed && operation == MC_WRITE_SEG16_TMP0 &&
                                     temporary_valid_q[0] && protected_msw[0];
    assign system_verify_read = allowed && operation == MC_SYSTEM_VERIFY_READ;
    assign system_verify_write = allowed && operation == MC_SYSTEM_VERIFY_WRITE;
    spk286_selector descriptor_selector (
        .selector(descriptor_selector_value), .table_limit(descriptor_table_limit), .table_base(descriptor_table_base),
        .index(descriptor_unused_index), .table_indicator(descriptor_selector_ti), .rpl(descriptor_unused_rpl),
        .null_selector(descriptor_selector_null), .descriptor_end(descriptor_unused_end),
        .descriptor_limit_valid(descriptor_selector_limit_valid),
        .descriptor_selector_valid(descriptor_unused_selector_valid),
        .descriptor_address(descriptor_selector_address), .descriptor_address_carry(descriptor_selector_carry)
    );
endmodule

module cone_candidate(
input wire  allowed,
input wire  call_gate_candidate_valid_q,
input wire  call_stack_ready_q,
input wire [15:0] call_stack_ss_q,
input wire  descriptor_active_q,
input wire  event_gate_candidate_valid_q,
input wire  iret_outer_ready_q,
input wire [15:0] iret_outer_ss_q,
input wire [8-1:0] operation,
input wire [23:0] protected_gdtr_base,
input wire [15:0] protected_gdtr_limit,
input wire [23:0] protected_ldtr_base,
input wire [15:0] protected_ldtr_limit,
input wire  protected_ldtr_present,
input wire  protected_ldtr_valid,
input wire [15:0] protected_msw,
input wire [1:0] segment_index,
input wire  task_gate_target_active_q,
input wire [15:0] task_gate_target_selector_q,
input wire [2:0] temporary_valid_q,
input wire [15:0] tmp0_q,
input wire [15:0] tmp1_q,
output wire  descriptor_segment_null_commit,
output wire [12:0] descriptor_unused_index,
output wire  descriptor_selector_ti,
output wire [1:0] descriptor_unused_rpl,
output wire  descriptor_selector_null,
output wire [20:0] descriptor_unused_end,
output wire  descriptor_selector_limit_valid,
output wire  descriptor_unused_selector_valid,
output wire [23:0] descriptor_selector_address,
output wire  descriptor_selector_carry
);
    localparam integer MC_FORMAT_VERSION = 27;
    localparam integer MC_ADDR_WIDTH = 10;
    localparam integer MC_WORD_WIDTH = 8;
    localparam integer MC_DEPTH = 743;
    localparam logic [MC_WORD_WIDTH-1:0] MC_INVALID = 8'd0;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_IMM16 = 8'd1;
    localparam logic [MC_WORD_WIDTH-1:0] MC_MOVE = 8'd2;
    localparam logic [MC_WORD_WIDTH-1:0] MC_END = 8'd3;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECODE_MODRM = 8'd4;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_REG16 = 8'd5;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_RM16 = 8'd6;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_REG16 = 8'd7;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_RM16 = 8'd8;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_REG16_TMP1 = 8'd9;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_RM16_TMP1 = 8'd10;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_IMM16_TMP1 = 8'd11;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_IMM8S_TMP1 = 8'd12;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_DST16 = 8'd13;
    localparam logic [MC_WORD_WIDTH-1:0] MC_ALU = 8'd14;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_RESULT_REG16 = 8'd15;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_RESULT_RM16 = 8'd16;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_RESULT_DST = 8'd17;
    localparam logic [MC_WORD_WIDTH-1:0] MC_COMMIT_FLAGS = 8'd18;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_RM16 = 8'd19;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_IMM8S_TMP0 = 8'd20;
    localparam logic [MC_WORD_WIDTH-1:0] MC_PUSH16 = 8'd21;
    localparam logic [MC_WORD_WIDTH-1:0] MC_POP16 = 8'd22;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_IP16 = 8'd23;
    localparam logic [MC_WORD_WIDTH-1:0] MC_TARGET_REL16 = 8'd24;
    localparam logic [MC_WORD_WIDTH-1:0] MC_TARGET_ABS16 = 8'd25;
    localparam logic [MC_WORD_WIDTH-1:0] MC_REDIRECT = 8'd26;
    localparam logic [MC_WORD_WIDTH-1:0] MC_ADJUST_SP16 = 8'd27;
    localparam logic [MC_WORD_WIDTH-1:0] MC_COUNT = 8'd28;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_IMM8 = 8'd29;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_FLAGS = 8'd30;
    localparam logic [MC_WORD_WIDTH-1:0] MC_RESTORE_FLAGS = 8'd31;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SET_IF = 8'd32;
    localparam logic [MC_WORD_WIDTH-1:0] MC_HALT = 8'd33;
    localparam logic [MC_WORD_WIDTH-1:0] MC_REQUEST_EVENT = 8'd34;
    localparam logic [MC_WORD_WIDTH-1:0] MC_EVENT_ACK = 8'd35;
    localparam logic [MC_WORD_WIDTH-1:0] MC_EVENT_FLAGS = 8'd36;
    localparam logic [MC_WORD_WIDTH-1:0] MC_EVENT_CS = 8'd37;
    localparam logic [MC_WORD_WIDTH-1:0] MC_EVENT_IP = 8'd38;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CLEAR_IF_TF = 8'd39;
    localparam logic [MC_WORD_WIDTH-1:0] MC_VECTOR_IP = 8'd40;
    localparam logic [MC_WORD_WIDTH-1:0] MC_VECTOR_CS = 8'd41;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CONTEXT_COMMIT = 8'd42;
    localparam logic [MC_WORD_WIDTH-1:0] MC_POP16_TMP1 = 8'd43;
    localparam logic [MC_WORD_WIDTH-1:0] MC_POP16_TMP2 = 8'd44;
    localparam logic [MC_WORD_WIDTH-1:0] MC_IRET_COMMIT = 8'd45;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_REG8 = 8'd46;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_RM8 = 8'd47;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_REG8 = 8'd48;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_RM8 = 8'd49;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_IMM8_TMP1 = 8'd50;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_REG8_TMP1 = 8'd51;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_RM8_TMP1 = 8'd52;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_DST8 = 8'd53;
    localparam logic [MC_WORD_WIDTH-1:0] MC_MOVE8 = 8'd54;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_RESULT_REG8 = 8'd55;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_RESULT_RM8 = 8'd56;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_RESULT_DST8 = 8'd57;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FLAGS_DECODED = 8'd58;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SIGN_EXTEND8 = 8'd59;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SIGN_FILL16 = 8'd60;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CONST_ONE_TMP1 = 8'd61;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SHIFT = 8'd62;
    localparam logic [MC_WORD_WIDTH-1:0] MC_COUNT_LOW_TMP1 = 8'd63;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_EA = 8'd64;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_REG8_TMP1 = 8'd65;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_REG16_TMP1 = 8'd66;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_TARGET16_TMP1 = 8'd67;
    localparam logic [MC_WORD_WIDTH-1:0] MC_MOVE_SOURCE16_TMP1 = 8'd68;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SET_ADDRESS_TMP1 = 8'd69;
    localparam logic [MC_WORD_WIDTH-1:0] MC_ADD_BASE_TMP0_TMP1 = 8'd70;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DISPATCH_DECODED = 8'd71;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CONST_ZERO_TMP1 = 8'd72;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CONST_ONES_TMP1 = 8'd73;
    localparam logic [MC_WORD_WIDTH-1:0] MC_ADJUST = 8'd74;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_ARITHMETIC = 8'd75;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_SEG16_TMP0 = 8'd76;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_SEG16_TMP0 = 8'd77;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_AX_TMP0 = 8'd78;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_CX_TMP0 = 8'd79;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_DX_TMP0 = 8'd80;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_BX_TMP0 = 8'd81;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_SP_TMP0 = 8'd82;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_BP_TMP0 = 8'd83;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_SI_TMP0 = 8'd84;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_DI_TMP0 = 8'd85;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_AX_TMP0 = 8'd86;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_CX_TMP0 = 8'd87;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_DX_TMP0 = 8'd88;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_BX_TMP0 = 8'd89;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_SP_TMP0 = 8'd90;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_BP_TMP0 = 8'd91;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_SI_TMP0 = 8'd92;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_DI_TMP0 = 8'd93;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SAVE_AUX_TMP0 = 8'd94;
    localparam logic [MC_WORD_WIDTH-1:0] MC_RESTORE_AUX_TMP0 = 8'd95;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SAVE_ALLOCATION_TMP0 = 8'd96;
    localparam logic [MC_WORD_WIDTH-1:0] MC_LOAD_COUNTER_TMP1 = 8'd97;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECREMENT_COUNTER = 8'd98;
    localparam logic [MC_WORD_WIDTH-1:0] MC_BRANCH_ZERO = 8'd99;
    localparam logic [MC_WORD_WIDTH-1:0] MC_BRANCH_NONZERO = 8'd100;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_PUSH8 = 8'd101;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_POP8 = 8'd102;
    localparam logic [MC_WORD_WIDTH-1:0] MC_BEGIN_STACK_CURSOR = 8'd103;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_STACK_TMP0 = 8'd104;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SET_STACK_ADDRESS_TMP0 = 8'd105;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_STACK_ADDRESS_TMP0 = 8'd106;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECREMENT_STACK_ADDRESS = 8'd107;
    localparam logic [MC_WORD_WIDTH-1:0] MC_ALLOCATE_STACK = 8'd108;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_RM32 = 8'd109;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SET_EA_PLUS2 = 8'd110;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_BOUNDS = 8'd111;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_STACK_CURSOR_TMP0 = 8'd112;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_PUSH2 = 8'd113;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_POP2 = 8'd114;
    localparam logic [MC_WORD_WIDTH-1:0] MC_ADD_ALLOCATION_SP = 8'd115;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_STORE_GDTR = 8'd136;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_STORE_IDTR = 8'd137;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_LOAD_GDTR = 8'd138;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_LOAD_IDTR = 8'd139;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_STORE_MSW = 8'd140;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_LOAD_MSW = 8'd141;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_STORE_LDTR = 8'd142;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_STORE_TR = 8'd143;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_LOAD_LDTR = 8'd144;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_LOAD_TR = 8'd145;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_VERIFY_READ = 8'd146;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_VERIFY_WRITE = 8'd147;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_LOAD_ACCESS = 8'd148;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_LOAD_LIMIT = 8'd149;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_ARPL_CHECK = 8'd166;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_ARPL = 8'd167;
    localparam logic [MC_WORD_WIDTH-1:0] MC_SYSTEM_CLTS = 8'd168;
    localparam logic [MC_WORD_WIDTH-1:0] MC_TASK_SWITCH = 8'd169;
    localparam logic [MC_WORD_WIDTH-1:0] MC_TASK_RETURN = 8'd170;
    localparam logic [MC_WORD_WIDTH-1:0] MC_LOADALL = 8'd171;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CARRY_FILL8 = 8'd172;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_PROTECTED_MODE = 8'd193;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_SYSTEM_PRIVILEGE = 8'd194;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_IO_PRIVILEGE = 8'd195;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_NPX_ESC = 8'd196;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_NPX_WAIT = 8'd197;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECODE_ALU_RM16_REG16 = 8'd173;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECODE_ALU_REG16_RM16 = 8'd174;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECODE_ALU_RM8_REG8 = 8'd175;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECODE_ALU_REG8_RM8 = 8'd176;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECODE_MOV_RM16_REG16 = 8'd177;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECODE_MOV_REG16_RM16 = 8'd178;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECODE_MOV_RM8_REG8 = 8'd179;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECODE_MOV_REG8_RM8 = 8'd180;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECODE_UNARY_RM16 = 8'd190;
    localparam logic [MC_WORD_WIDTH-1:0] MC_DECODE_UNARY_RM8 = 8'd191;
    localparam logic [MC_WORD_WIDTH-1:0] MC_EXEC_INC_DEC_DST16 = 8'd192;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_ALU_DST16_IMM16 = 8'd181;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_ALU_DST8_IMM8 = 8'd182;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_ALU_RM16_IMM16 = 8'd183;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_ALU_RM16_IMM8S = 8'd184;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_ALU_RM8_IMM8 = 8'd185;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_MOV_DST16_IMM16 = 8'd186;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_MOV_DST8_IMM8 = 8'd187;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_MOV_RM16_IMM16 = 8'd188;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_MOV_RM8_IMM8 = 8'd189;
    localparam logic [MC_WORD_WIDTH-1:0] MC_VALIDATE_CS = 8'd150;
    localparam logic [MC_WORD_WIDTH-1:0] MC_VALIDATE_EVENT_GATE = 8'd151;
    localparam logic [MC_WORD_WIDTH-1:0] MC_EVENT_GATE_IP = 8'd152;
    localparam logic [MC_WORD_WIDTH-1:0] MC_EVENT_GATE_CS = 8'd153;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CLEAR_EVENT_FLAGS = 8'd154;
    localparam logic [MC_WORD_WIDTH-1:0] MC_PUSH_EVENT_ERROR = 8'd155;
    localparam logic [MC_WORD_WIDTH-1:0] MC_VALIDATE_IRET_CS = 8'd156;
    localparam logic [MC_WORD_WIDTH-1:0] MC_IRET_OUTER_FRAME = 8'd157;
    localparam logic [MC_WORD_WIDTH-1:0] MC_VALIDATE_IRET_SS = 8'd158;
    localparam logic [MC_WORD_WIDTH-1:0] MC_VALIDATE_CALL_GATE = 8'd159;
    localparam logic [MC_WORD_WIDTH-1:0] MC_VALIDATE_CALL_CS = 8'd160;
    localparam logic [MC_WORD_WIDTH-1:0] MC_VALIDATE_CALL_STACK = 8'd161;
    localparam logic [MC_WORD_WIDTH-1:0] MC_VALIDATE_CALL_SS = 8'd162;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CALL_GATE_STACK_SWITCH = 8'd163;
    localparam logic [MC_WORD_WIDTH-1:0] MC_CHECK_CALL_FRAME = 8'd164;
    localparam logic [MC_WORD_WIDTH-1:0] MC_COPY_CALL_PARAMETERS = 8'd165;
    localparam logic [MC_WORD_WIDTH-1:0] MC_BRANCH_REPEAT_EMPTY = 8'd121;
    localparam logic [MC_WORD_WIDTH-1:0] MC_STEP_STRING_SOURCE = 8'd122;
    localparam logic [MC_WORD_WIDTH-1:0] MC_STEP_STRING_DEST = 8'd123;
    localparam logic [MC_WORD_WIDTH-1:0] MC_REPEAT_COUNT = 8'd124;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_STRING_TMP0 = 8'd125;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_STRING_TMP1 = 8'd126;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_STRING_TMP0 = 8'd127;
    localparam logic [MC_WORD_WIDTH-1:0] MC_BRANCH_REPEAT_CONTINUE = 8'd128;
    localparam logic [MC_WORD_WIDTH-1:0] MC_READ_STRING_ACCUMULATOR = 8'd129;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_STRING_ACCUMULATOR = 8'd130;
    localparam logic [MC_WORD_WIDTH-1:0] MC_IO_READ8 = 8'd131;
    localparam logic [MC_WORD_WIDTH-1:0] MC_IO_READ16 = 8'd132;
    localparam logic [MC_WORD_WIDTH-1:0] MC_IO_WRITE8 = 8'd133;
    localparam logic [MC_WORD_WIDTH-1:0] MC_IO_WRITE16 = 8'd134;
    localparam logic [MC_WORD_WIDTH-1:0] MC_FETCH_PORT = 8'd135;
    localparam logic [MC_WORD_WIDTH-1:0] MC_MULDIV8 = 8'd116;
    localparam logic [MC_WORD_WIDTH-1:0] MC_MULDIV16 = 8'd117;
    localparam logic [MC_WORD_WIDTH-1:0] MC_IMUL_IMM16 = 8'd118;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_RESULT_AX16 = 8'd119;
    localparam logic [MC_WORD_WIDTH-1:0] MC_WRITE_RESULT_DX16 = 8'd120;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_MOV_R16_IMM16 = 10'd0;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_MOV_RM16_R16 = 10'd3;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_MOV_R16_RM16 = 10'd7;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ALU_RM16_R16 = 10'd11;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ALU_R16_RM16 = 10'd18;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ALU_AX_IMM16 = 10'd25;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ALU_RM16_IMM16 = 10'd31;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ALU_RM16_IMM8S = 10'd38;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_PUSH_R16 = 10'd45;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_POP_R16 = 10'd48;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_PUSH_IMM16 = 10'd51;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_PUSH_IMM8S = 10'd54;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_POP_RM16 = 10'd57;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_GROUP5_NEAR = 10'd61;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_CALL_REL16 = 10'd67;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_JMP_REL16 = 10'd73;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_BRANCH_REL8 = 10'd77;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_LOOP_REL8 = 10'd81;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_RET_NEAR = 10'd86;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_RET_IMM16 = 10'd90;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_PUSH_FLAGS = 10'd96;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_POP_FLAGS = 10'd99;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_CONTROL_IF = 10'd102;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_HALT_CPU = 10'd104;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SOFTWARE_EVENT = 10'd106;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SOFTWARE_EVENT_IMM8 = 10'd108;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_INTERRUPT_RETURN = 10'd111;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_EVENT_ENTRY = 10'd120;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_EVENT_ENTRY_PROTECTED = 10'd137;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_MOV_R8_IMM8 = 10'd159;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_MOV_RM8_R8 = 10'd162;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_MOV_R8_RM8 = 10'd166;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_MOV_RM8_IMM8 = 10'd170;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_MOV_RM16_IMM16 = 10'd174;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ALU_RM8_R8 = 10'd178;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ALU_R8_RM8 = 10'd185;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ALU_AL_IMM8 = 10'd192;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ALU_RM8_IMM8 = 10'd198;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_CONTROL_FLAGS = 10'd205;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_LOAD_FLAGS_BYTE = 10'd207;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_EXTEND_BYTE = 10'd210;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_EXTEND_WORD = 10'd214;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_INC_DEC_R16 = 10'd218;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SHIFT_RM8_ONE = 10'd224;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SHIFT_RM8_CL = 10'd231;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SHIFT_RM8_IMM8 = 10'd238;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SHIFT_RM16_ONE = 10'd245;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SHIFT_RM16_CL = 10'd252;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SHIFT_RM16_IMM8 = 10'd259;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_LEA_R16_M = 10'd266;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_EXCHANGE_RM8_R8 = 10'd270;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_EXCHANGE_RM16_R16 = 10'd276;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_EXCHANGE_SOURCE_TARGET16 = 10'd282;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_LOAD_DIRECT8 = 10'd287;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_LOAD_DIRECT16 = 10'd292;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_STORE_DIRECT8 = 10'd297;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_STORE_DIRECT16 = 10'd302;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_LOAD_BASE_INDEX8 = 10'd307;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_GROUP3_DISPATCH = 10'd313;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_GROUP5_DISPATCH = 10'd315;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_NOT_RM8 = 10'd317;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_NOT_RM16 = 10'd324;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_NEG_RM8 = 10'd331;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_NEG_RM16 = 10'd338;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_INC_DEC_RM8 = 10'd345;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_INC_DEC_RM16 = 10'd352;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ADJUST_DIRECT = 10'd359;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ADJUST_RADIX = 10'd366;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_MOV_RM16_SEG = 10'd373;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_MOV_SEG_RM16 = 10'd377;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_PUSH_SEG = 10'd381;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_POP_SEG = 10'd384;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_PUSH_ALL = 10'd387;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_POP_ALL = 10'd407;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ENTER_FRAME = 10'd424;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_LEAVE_FRAME = 10'd449;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_CHECK_BOUNDS = 10'd455;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_LOAD_POINTER = 10'd464;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_CALL_FAR_IMM = 10'd474;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_JMP_FAR_IMM = 10'd492;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_CALL_FAR_RM = 10'd498;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_JMP_FAR_RM = 10'd519;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_RET_FAR = 10'd528;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_RET_FAR_IMM = 10'd536;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_MULDIV_RM8 = 10'd547;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_MULDIV_RM16 = 10'd554;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_IMUL_R16_RM16_IMM16 = 10'd562;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_IMUL_R16_RM16_IMM8S = 10'd569;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_STRING_MOVE = 10'd576;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_STRING_COMPARE = 10'd584;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_STRING_STORE = 10'd595;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_STRING_LOAD = 10'd602;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_STRING_SCAN = 10'd609;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_IN_AL_PORT = 10'd619;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_IN_AX_PORT = 10'd624;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_OUT_PORT_AL = 10'd629;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_OUT_PORT_AX = 10'd634;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_STRING_INPUT_BYTE = 10'd639;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_STRING_INPUT_WORD = 10'd648;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_STRING_OUTPUT_BYTE = 10'd657;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_STRING_OUTPUT_WORD = 10'd666;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_ESC_NO_COPROCESSOR = 10'd675;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_WAIT_NO_COPROCESSOR = 10'd679;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_GROUP_0F01 = 10'd681;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_STORE_GDTR = 10'd683;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_STORE_IDTR = 10'd685;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_LOAD_GDTR = 10'd687;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_LOAD_IDTR = 10'd689;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_STORE_MSW = 10'd691;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_LOAD_MSW = 10'd693;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_GROUP_0F00 = 10'd695;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_STORE_LDTR = 10'd697;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_STORE_TR = 10'd700;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_LOAD_LDTR = 10'd703;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_LOAD_TR = 10'd707;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_VERIFY_READ = 10'd711;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_VERIFY_WRITE = 10'd715;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_LOAD_ACCESS = 10'd719;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_LOAD_LIMIT = 10'd724;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_ARPL = 10'd729;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_SYSTEM_CLTS = 10'd735;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_LOADALL = 10'd737;
    localparam logic [MC_ADDR_WIDTH-1:0] MC_ENTRY_LOAD_CARRY_BYTE = 10'd739;
wire  call_gate_cs_validation_operation;
wire  call_gate_validation_operation;
wire  call_ss_validation_operation;
wire  cs_validation_operation;
wire  descriptor_begin;
wire  descriptor_inspect_operation;
wire  descriptor_load_access;
wire  descriptor_load_ldtr;
wire  descriptor_load_limit;
wire  descriptor_load_operation;
wire  descriptor_load_tr;
wire  descriptor_pre_fault;
wire [15:0] descriptor_selector_value;
wire [23:0] descriptor_table_base;
wire [15:0] descriptor_table_limit;
wire  descriptor_verify_operation;
wire  descriptor_verify_read;
wire  descriptor_verify_write;
wire  iret_cs_validation_operation;
wire  iret_ss_validation_operation;
wire  jmp_gate_cs_validation_operation;
wire  segment_reload_operation;
wire  system_verify_read;
wire  system_verify_write;
    assign call_gate_cs_validation_operation = jmp_gate_cs_validation_operation ||
                                               (allowed && operation == MC_VALIDATE_CALL_CS &&
                                                protected_msw[0] && call_gate_candidate_valid_q);
    assign call_gate_validation_operation = allowed && operation == MC_VALIDATE_CALL_GATE && protected_msw[0];
    assign call_ss_validation_operation = allowed && operation == MC_VALIDATE_CALL_SS && protected_msw[0];
    assign cs_validation_operation = allowed && protected_msw[0] &&
                                     ((operation == MC_VALIDATE_CS &&
                                       !jmp_gate_cs_validation_operation) ||
                                      (operation == MC_VALIDATE_CALL_CS &&
                                       !call_gate_candidate_valid_q));
    assign descriptor_begin = descriptor_load_operation &&
                              ((cs_validation_operation || call_gate_validation_operation || call_gate_cs_validation_operation ||
                                iret_cs_validation_operation) ? temporary_valid_q[1] :
                               iret_ss_validation_operation ? iret_outer_ready_q :
                               call_ss_validation_operation ? call_stack_ready_q : temporary_valid_q[0]) &&
                              !descriptor_active_q;
    assign descriptor_inspect_operation = descriptor_load_access || descriptor_load_limit;
    assign descriptor_load_access = allowed && operation == MC_SYSTEM_LOAD_ACCESS;
    assign descriptor_load_ldtr = allowed && operation == MC_SYSTEM_LOAD_LDTR;
    assign descriptor_load_limit = allowed && operation == MC_SYSTEM_LOAD_LIMIT;
    assign descriptor_load_operation = descriptor_load_ldtr || descriptor_load_tr || descriptor_verify_operation ||
                                      descriptor_inspect_operation || segment_reload_operation || cs_validation_operation ||
                                      call_gate_validation_operation || call_gate_cs_validation_operation || call_ss_validation_operation ||
                                      iret_cs_validation_operation || iret_ss_validation_operation;
    assign descriptor_load_tr = allowed && operation == MC_SYSTEM_LOAD_TR;
    assign descriptor_pre_fault = descriptor_begin &&
                                  (!protected_msw[0] ||
                                   ((descriptor_load_ldtr || descriptor_load_tr) &&
                                    (descriptor_selector_ti || descriptor_selector_carry ||
                                     (!descriptor_selector_null && !descriptor_selector_limit_valid) ||
                                     (descriptor_load_tr && descriptor_selector_null))) ||
                                   (segment_reload_operation &&
                                    (descriptor_selector_carry ||
                                     (!descriptor_selector_null && !descriptor_selector_limit_valid) ||
                                     (descriptor_selector_null && segment_index == 2'd2))) ||
                                   ((cs_validation_operation || call_gate_validation_operation || call_gate_cs_validation_operation ||
                                      iret_cs_validation_operation) &&
                                    (descriptor_selector_carry || descriptor_selector_null ||
                                     (!descriptor_selector_limit_valid) ||
                                     (descriptor_selector_ti && (!protected_ldtr_valid || !protected_ldtr_present)))) ||
                                   (call_ss_validation_operation &&
                                    (descriptor_selector_carry || descriptor_selector_null ||
                                     (!descriptor_selector_limit_valid) ||
                                     (descriptor_selector_ti && (!protected_ldtr_valid || !protected_ldtr_present)))) ||
                                   (iret_ss_validation_operation &&
                                    (descriptor_selector_carry || descriptor_selector_null ||
                                     (!descriptor_selector_limit_valid) ||
                                     (descriptor_selector_ti && (!protected_ldtr_valid || !protected_ldtr_present)))));
    assign descriptor_segment_null_commit = !descriptor_active_q && segment_reload_operation &&
                                           tmp0_q[15:2] == 14'd0 && segment_index != 2'd2;
    assign descriptor_selector_value = (cs_validation_operation || call_gate_validation_operation ||
                                        call_gate_cs_validation_operation || iret_cs_validation_operation) ?
                                       (task_gate_target_active_q ? task_gate_target_selector_q : tmp1_q) :
                                       iret_ss_validation_operation ? iret_outer_ss_q :
                                       call_ss_validation_operation ? call_stack_ss_q : tmp0_q;
    assign descriptor_table_base = descriptor_selector_ti ? protected_ldtr_base : protected_gdtr_base;
    assign descriptor_table_limit = descriptor_selector_ti ? protected_ldtr_limit : protected_gdtr_limit;
    assign descriptor_verify_operation = descriptor_verify_read || descriptor_verify_write;
    assign descriptor_verify_read = system_verify_read;
    assign descriptor_verify_write = system_verify_write;
    assign iret_cs_validation_operation = allowed && operation == MC_VALIDATE_IRET_CS && protected_msw[0];
    assign iret_ss_validation_operation = allowed && operation == MC_VALIDATE_IRET_SS && protected_msw[0];
    assign jmp_gate_cs_validation_operation = allowed && protected_msw[0] &&
                                              operation == MC_VALIDATE_CS &&
                                              call_gate_candidate_valid_q && !event_gate_candidate_valid_q;
    assign segment_reload_operation = allowed && operation == MC_WRITE_SEG16_TMP0 &&
                                     temporary_valid_q[0] && protected_msw[0];
    assign system_verify_read = allowed && operation == MC_SYSTEM_VERIFY_READ;
    assign system_verify_write = allowed && operation == MC_SYSTEM_VERIFY_WRITE;
    spk286_selector descriptor_selector (
        .selector(descriptor_selector_value), .table_limit(descriptor_table_limit), .table_base(descriptor_table_base),
        .index(descriptor_unused_index), .table_indicator(descriptor_selector_ti), .rpl(descriptor_unused_rpl),
        .null_selector(descriptor_selector_null), .descriptor_end(descriptor_unused_end),
        .descriptor_limit_valid(descriptor_selector_limit_valid),
        .descriptor_selector_valid(descriptor_unused_selector_valid),
        .descriptor_address(descriptor_selector_address), .descriptor_address_carry(descriptor_selector_carry)
    );
endmodule

module miter(
input wire  allowed,
input wire  call_gate_candidate_valid_q,
input wire  call_stack_ready_q,
input wire [15:0] call_stack_ss_q,
input wire  descriptor_active_q,
input wire  event_gate_candidate_valid_q,
input wire  iret_outer_ready_q,
input wire [15:0] iret_outer_ss_q,
input wire [8-1:0] operation,
input wire [23:0] protected_gdtr_base,
input wire [15:0] protected_gdtr_limit,
input wire [23:0] protected_ldtr_base,
input wire [15:0] protected_ldtr_limit,
input wire  protected_ldtr_present,
input wire  protected_ldtr_valid,
input wire [15:0] protected_msw,
input wire [1:0] segment_index,
input wire  task_gate_target_active_q,
input wire [15:0] task_gate_target_selector_q,
input wire [2:0] temporary_valid_q,
input wire [15:0] tmp0_q,
input wire [15:0] tmp1_q
);
wire  old_descriptor_segment_null_commit;
wire [12:0] old_descriptor_unused_index;
wire  old_descriptor_selector_ti;
wire [1:0] old_descriptor_unused_rpl;
wire  old_descriptor_selector_null;
wire [20:0] old_descriptor_unused_end;
wire  old_descriptor_selector_limit_valid;
wire  old_descriptor_unused_selector_valid;
wire [23:0] old_descriptor_selector_address;
wire  old_descriptor_selector_carry;
wire  new_descriptor_segment_null_commit;
wire [12:0] new_descriptor_unused_index;
wire  new_descriptor_selector_ti;
wire [1:0] new_descriptor_unused_rpl;
wire  new_descriptor_selector_null;
wire [20:0] new_descriptor_unused_end;
wire  new_descriptor_selector_limit_valid;
wire  new_descriptor_unused_selector_valid;
wire [23:0] new_descriptor_selector_address;
wire  new_descriptor_selector_carry;
cone_reference old_instance(.allowed(allowed),.call_gate_candidate_valid_q(call_gate_candidate_valid_q),.call_stack_ready_q(call_stack_ready_q),.call_stack_ss_q(call_stack_ss_q),.descriptor_active_q(descriptor_active_q),.event_gate_candidate_valid_q(event_gate_candidate_valid_q),.iret_outer_ready_q(iret_outer_ready_q),.iret_outer_ss_q(iret_outer_ss_q),.operation(operation),.protected_gdtr_base(protected_gdtr_base),.protected_gdtr_limit(protected_gdtr_limit),.protected_ldtr_base(protected_ldtr_base),.protected_ldtr_limit(protected_ldtr_limit),.protected_ldtr_present(protected_ldtr_present),.protected_ldtr_valid(protected_ldtr_valid),.protected_msw(protected_msw),.segment_index(segment_index),.task_gate_target_active_q(task_gate_target_active_q),.task_gate_target_selector_q(task_gate_target_selector_q),.temporary_valid_q(temporary_valid_q),.tmp0_q(tmp0_q),.tmp1_q(tmp1_q),.descriptor_segment_null_commit(old_descriptor_segment_null_commit),.descriptor_unused_index(old_descriptor_unused_index),.descriptor_selector_ti(old_descriptor_selector_ti),.descriptor_unused_rpl(old_descriptor_unused_rpl),.descriptor_selector_null(old_descriptor_selector_null),.descriptor_unused_end(old_descriptor_unused_end),.descriptor_selector_limit_valid(old_descriptor_selector_limit_valid),.descriptor_unused_selector_valid(old_descriptor_unused_selector_valid),.descriptor_selector_address(old_descriptor_selector_address),.descriptor_selector_carry(old_descriptor_selector_carry));
cone_candidate new_instance(.allowed(allowed),.call_gate_candidate_valid_q(call_gate_candidate_valid_q),.call_stack_ready_q(call_stack_ready_q),.call_stack_ss_q(call_stack_ss_q),.descriptor_active_q(descriptor_active_q),.event_gate_candidate_valid_q(event_gate_candidate_valid_q),.iret_outer_ready_q(iret_outer_ready_q),.iret_outer_ss_q(iret_outer_ss_q),.operation(operation),.protected_gdtr_base(protected_gdtr_base),.protected_gdtr_limit(protected_gdtr_limit),.protected_ldtr_base(protected_ldtr_base),.protected_ldtr_limit(protected_ldtr_limit),.protected_ldtr_present(protected_ldtr_present),.protected_ldtr_valid(protected_ldtr_valid),.protected_msw(protected_msw),.segment_index(segment_index),.task_gate_target_active_q(task_gate_target_active_q),.task_gate_target_selector_q(task_gate_target_selector_q),.temporary_valid_q(temporary_valid_q),.tmp0_q(tmp0_q),.tmp1_q(tmp1_q),.descriptor_segment_null_commit(new_descriptor_segment_null_commit),.descriptor_unused_index(new_descriptor_unused_index),.descriptor_selector_ti(new_descriptor_selector_ti),.descriptor_unused_rpl(new_descriptor_unused_rpl),.descriptor_selector_null(new_descriptor_selector_null),.descriptor_unused_end(new_descriptor_unused_end),.descriptor_selector_limit_valid(new_descriptor_selector_limit_valid),.descriptor_unused_selector_valid(new_descriptor_unused_selector_valid),.descriptor_selector_address(new_descriptor_selector_address),.descriptor_selector_carry(new_descriptor_selector_carry));
always @* begin
assert(old_descriptor_segment_null_commit == new_descriptor_segment_null_commit);
assert(old_descriptor_unused_index == new_descriptor_unused_index);
assert(old_descriptor_selector_ti == new_descriptor_selector_ti);
assert(old_descriptor_unused_rpl == new_descriptor_unused_rpl);
assert(old_descriptor_selector_null == new_descriptor_selector_null);
assert(old_descriptor_unused_end == new_descriptor_unused_end);
assert(old_descriptor_selector_limit_valid == new_descriptor_selector_limit_valid);
assert(old_descriptor_unused_selector_valid == new_descriptor_unused_selector_valid);
assert(old_descriptor_selector_address == new_descriptor_selector_address);
assert(old_descriptor_selector_carry == new_descriptor_selector_carry);
end
endmodule
