import hashlib,io,json,tarfile,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
up=Path('D:/GitHub/SPK286')
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text())
def seal(dest,payload,sources,status):
    dest.mkdir(parents=True,exist_ok=False)
    archive=dest/(dest.name+'.tar.gz')
    payload['archive-helper.py']=Path(__file__).read_bytes()
    with tarfile.open(archive,'w:gz',compresslevel=9) as t:
        for name,data in payload.items():
            info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
            t.addfile(info,io.BytesIO(data))
    with tarfile.open(archive) as t:
        assert set(t.getnames())==set(payload)
        for info in t:assert t.extractfile(info).read()==payload[info.name]
    manifest={'status':status,'archive':archive.name,'sha256':sha(archive.read_bytes()),
        'bytes':archive.stat().st_size,'members':len(payload),'source_sha256':sources,
        'verification':'Every member read back equal before cleanup',
        'full_regression':'AUTHORIZED_AFTER_TIMING_CLOSURE_NOT_RUN','hardware':'NOT_RUN'}
    (dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',newline='\n')
    print(dest.name,'SEALED',manifest['bytes'],manifest['members'])
    return manifest
def addtree(payload,directory,prefix):
    assert directory.is_dir() and not directory.is_symlink()
    for p in directory.rglob('*'):
        assert not p.is_symlink()
        if p.is_file():payload[prefix+'/'+p.relative_to(directory).as_posix()]=p.read_bytes()
directed=root/'build/p06-null-segment-directed-20261005-v1'
d=read(directed/'receipt.json')
assert d['status'] in ('NULL_SEGMENT_DIRECTED_PASS','PASS','PASS_WITH_EXPAND_DOWN_VERILATOR_DEFERRED'),d['status']
manifest=read(directed/'manifest.json')
copied=manifest['candidate_sha256'] if 'candidate_sha256' in manifest else manifest['original_copied_sha256']
assert copied['rtl/spk286_micro_executor.sv']=='325f51e6a91ae9c309786c17da8c22aa3264b3084314008b43b7cc41fd44f6db'
mode=sys.argv[1]
if mode=='upstream':
    actual=up/'build/p06-null-segment-applied-20261005'
    receipt=read(actual/'receipt.json')
    assert receipt['status']=='NULL_SEGMENT_COMMIT_SPECIALIZATION_EQUIVALENCE_PASS'
    assert receipt['results']['raw']['candidate_installed'] and receipt['selected_variants']==['raw']
    sources=receipt['sources_sha256']
    payload={}
    addtree(payload,actual,'applied-proof')
    for name,digest in sources.items():
        b=(up/name).read_bytes();assert sha(b)==digest,name
        payload['source/'+name]=b
    retained=read(root/'docs/imports/current-spk286.json')['retained_vendor_only']
    inactive={}
    for name,digest in copied.items():
        b=(directed/'source-tree'/name).read_bytes();assert sha(b)==digest,name
        payload['directed/source/'+name]=b
        if name.startswith(('rtl/','microcode/')):
            if (up/name).exists():assert (up/name).read_bytes()==b,name
            else:
                assert name=='rtl/spk286_system_0f.sv' and digest==retained[name]['sha256']
                for active in (up/'rtl').glob('*.sv'):
                    assert 'spk286_system_0f' not in active.read_text(),active.name
                inactive[name]={'sha256':digest,'classification':'Retained vendor-only CPU module parsed by broad RTL glob but never instantiated by the tested portable CPU tops; exact canonical portable RTL otherwise equal'}
    payload['directed/uninstantiated-vendor-inventory.json']=(json.dumps(inactive,indent=2)+'\n').encode()
    for p in directed.glob('*.json'):payload['directed/'+p.name]=p.read_bytes()
    for p in directed.glob('*.log'):payload['directed/'+p.name]=p.read_bytes()
    for p in (directed/'source-tree/build').rglob('*.log'):
        payload['directed/build/'+p.relative_to(directed/'source-tree/build').as_posix()]=p.read_bytes()
    for name in ('run-p06-null-segment-directed-20261005.py','finish-p06-null-segment-directed-20261005.py'):
        payload['directed/runner/'+name]=(root/'build'/name).read_bytes()
    dest=up/'docs/evidence/null-segment-specialization-20261005'
    seal(dest,payload,sources,'SEALED_CPU_ONLY_APPLIED_PROOF_AND_DIRECTED_CHECKS')
    (dest/'receipt.json').write_bytes((actual/'receipt.json').read_bytes())
    (dest/'directed.json').write_bytes((directed/'receipt.json').read_bytes())
elif mode=='pcat':
    applied=root/'build/p06-null-segment-applied-pcat-20261005'
    receipt=read(applied/'receipt.json')
    assert receipt['status']=='NULL_SEGMENT_COMMIT_SPECIALIZATION_EQUIVALENCE_PASS'
    assert receipt['selected_variants']==['raw','timed'] and all(v['candidate_installed'] for v in receipt['results'].values())
    components=root/'build/p06-null-segment-profile-components-20261005'
    comp=read(components/'components.json')
    assert comp['status']=='PROFILE_COMPONENT_PREPARATION_PASS_NOT_FULL_ACCEPTANCE'
    for name,digest in comp['generated_sha256'].items():assert sha((root/'vendor/spk286/rtl/timed'/name).read_bytes())==digest,name
    sources={**receipt['sources_sha256'],**comp['sources_sha256']}
    for name in ('scripts/build_p06_profile_cpu.py','scripts/p06_repeat_local.py',
        'vendor/spk286/rtl/timed/generation.json','vendor/spk286/rtl/timed/repeat-local-contract.json'):
        sources[name]=sha((root/name).read_bytes())
    payload={}
    dirs=[applied,components,directed,root/'build/p06-null-segment-independent-review-20261005']
    dirs+=sorted((root/'build').glob('p06-null-segment-commit-private-20261005-v*'))
    for p in dirs:addtree(payload,p,'trials/'+p.name)
    for name,digest in sources.items():
        b=(root/name).read_bytes();assert sha(b)==digest,name
        payload['source/'+name]=b
    payload['source/build/prove-p06-null-segment-commit-20261005.py']=(root/'build/prove-p06-null-segment-commit-20261005.py').read_bytes()
    payload['source/build/test_null_segment_commit_equivalence.py']=(root/'build/test_null_segment_commit_equivalence.py').read_bytes()
    for name in ('run-p06-null-segment-directed-20261005.py','finish-p06-null-segment-directed-20261005.py'):
        payload['source/build/'+name]=(root/'build'/name).read_bytes()
    dest=root/'docs/evidence/p06-null-segment-specialization-20261005'
    seal(dest,payload,sources,'SEALED_APPLIED_RAW_TIMED_PROOF_AND_DIRECTED_CHECKS')
    (dest/'receipt.json').write_bytes((applied/'receipt.json').read_bytes())
    (dest/'components.json').write_bytes((components/'components.json').read_bytes())
    (dest/'directed.json').write_bytes((directed/'receipt.json').read_bytes())
    (dest/'review.md').write_bytes((root/'build/p06-null-segment-independent-review-20261005/review.md').read_bytes())
    c={'status':'PENDING',
       'targets':[p.relative_to(root).as_posix() for p in dirs],
       'archive_sha256':read(dest/'manifest.json')['sha256'],
       'policy':'Remove only these owned temporary directories after verifying the sealed archive; source files and user files are retained'}
    (dest/'cleanup.json').write_text(json.dumps(c,indent=2)+'\n',newline='\n')
else:raise ValueError(mode)
