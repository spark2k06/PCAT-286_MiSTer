"""Finish the authorized isolated checks after expensive Verilator deferral."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
from datetime import datetime,timezone

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'build/p06-null-segment-directed-20261005-v1'
TREE=OUT/'source-tree'
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
manifest=json.loads((OUT/'manifest.json').read_text())
expected=manifest['expected_candidate_sha256']
def check():
    for name,digest in expected.items():assert sha(TREE/name)==digest,name
check()
results=json.loads((OUT/'progress.json').read_text())
assert results[-1]['label']=='protected-expand-down-directed' and results[-1]['returncode']!=0
results[-1]['disposition']='DEFERRED_RESOURCE_COST_NOT_A_FUNCTIONAL_FAILURE'
results[-1]['reason']='Owned Verilator frontend PID598367 terminated after RSS9653140KiB was measured at170s; no Verilator PASS claim'
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',SPK286_BUILD_JOBS='1',
    SPK286_BUILD_DIR=str(TREE/'build'),SPK286_EXPAND_DOWN_TERMINATION_SMOKE='1')
for label,simulator,unit,marker,count in (
    ('protected-expand-down-iverilog','iverilog','spk286_protected_expand_down','PROTECTED_EXPAND_DOWN TERMINATION_SMOKE PASS:',1),
    ('segment-lifecycle','both','spk286_segment_lifecycle','SEGMENT_LIFECYCLE PASS:',2)):
    argv=['bash','scripts/test_units.sh',simulator,unit]
    print('DIRECTED_START',label,flush=True)
    started=datetime.now(timezone.utc);log=OUT/(label+'.log')
    with log.open('w') as stream:
        result=subprocess.run(argv,cwd=TREE,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=600)
    results.append({'label':label,'command':argv,'returncode':result.returncode,'started_utc':started.isoformat(),
        'duration_seconds':(datetime.now(timezone.utc)-started).total_seconds(),'log_sha256':sha(log)})
    (OUT/'progress.json').write_text(json.dumps(results,indent=2)+'\n',newline='\n')
    assert result.returncode==0,(label,log)
    assert log.read_text().count(marker)==count,(label,'missing expected simulator PASS markers')
    check();print('DIRECTED_PASS',label,flush=True)
receipt={'status':'PASS_WITH_EXPAND_DOWN_VERILATOR_DEFERRED',
    'scope':'Exact isolated candidate before production application: portable all-input formal, strict --Wall executor lint, foundation and lifecycle in both simulators, exact directed expand-down bank in Icarus',
    'source_bindings':manifest,'results':results,'full_regression':'USER_DEFERRED',
    'expand_down_scope':'Existing termination_smoke mode includes DS/ES null acceptance, null SS #GP/no writes; later full matrix and Verilator were not run',
    'portable_formal_receipt_sha256':sha(TREE/'build/formal/receipt.json'),
    'copied_source_unchanged_after_checks':True,
    'aborted_attempt':{'pid':598367,'parent_pid':598365,'observed_rss_kib':9653140,'observed_elapsed_seconds':170,
        'temporary_disk_bytes_observed':4970250,'termination':'SIGTERM after exact owned executable/path/parent checks; logs preserved',
        'functional_pass_claim':False,'paging_avoidance':'Stopped the expensive compiler to prevent further memory/paging growth; no unrelated process or cache was touched'},
    'artifacts_sha256':{p.name:sha(p) for p in OUT.iterdir() if p.is_file()},
    'continuation_runner_sha256':sha(Path(__file__))}
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',newline='\n')
print(receipt['status'],flush=True)
