"""Prepare and run isolated, exact candidate CPU directed checks only."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parents[1]
CPU=ROOT/'vendor/spk286'
OUT=ROOT/'build/p06-null-segment-directed-20261005-v1'
TREE=OUT/'source-tree'
PROOF=ROOT/'build/p06-null-segment-commit-private-20261005-v6'
HELPER=ROOT/'build/test_null_segment_commit_equivalence.py'
TARGET='rtl/spk286_micro_executor.sv'

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def prepare():
    OUT.mkdir(exist_ok=False);TREE.mkdir()
    ignore=shutil.ignore_patterns('.git','__pycache__','build','db','incremental_db','obj_dir')
    for directory in ('microcode','sim/unit','tools/microcode'):
        shutil.copytree(CPU/directory,TREE/directory,ignore=ignore)
    for directory in ('rtl','scripts','tools'):(TREE/directory).mkdir(exist_ok=True)
    for source in (CPU/'rtl').iterdir():
        if source.is_file():shutil.copy2(source,TREE/'rtl'/source.name)
    for name in ('test_units.sh','rtl_sources.sh'):
        shutil.copy2(CPU/'scripts'/name,TREE/'scripts'/name)
    shutil.copy2(CPU/'tools/__init__.py',TREE/'tools/__init__.py')
    original_files=[p for p in TREE.rglob('*') if p.is_file()]
    original={p.relative_to(TREE).as_posix():sha(p) for p in original_files}
    for name,digest in original.items():assert sha(CPU/name)==digest,name
    proof=json.loads((PROOF/'receipt.json').read_text())
    old=proof['original_assignment'].encode();new=proof['replacement_assignment'].encode()
    candidate=(PROOF/'spk286_micro_executor.sv.candidate').read_bytes()
    raw=(TREE/TARGET).read_bytes()
    if raw==candidate:
        rule='Candidate was already installed; exact bytes match private proof'
    else:
        assert hashlib.sha256(raw).hexdigest()==proof['sources_sha256']['vendor/spk286/'+TARGET]
        assert raw.count(old)==1 and raw.count(new)==0
        raw=raw.replace(old,new,1)
        assert raw==candidate
        (TREE/TARGET).write_bytes(raw)
        rule='Only the exact proved assignment changed; complete candidate bytes match v6'
    (TREE/'scripts/test_null_segment_commit_equivalence.py').write_bytes(HELPER.read_bytes())
    expected={p.relative_to(TREE).as_posix():sha(p) for p in TREE.rglob('*') if p.is_file()}
    manifest={'status':'ISOLATED_CANDIDATE_PREPARED','scope':'Exact copied CPU/test/compiler sources; one proved combinational assignment; no downstream machine, fit or full regression',
        'source_tree':str(TREE),'original_copied_sha256':original,'expected_candidate_sha256':expected,
        'candidate_rule':rule,'proof_receipt_sha256':sha(PROOF/'receipt.json'),
        'portable_helper_sha256':sha(HELPER),'runner_sha256':sha(Path(__file__)),
        'created_utc':datetime.now(timezone.utc).isoformat()}
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',newline='\n')
    # Production and copied test bytes remain unchanged after snapshot creation.
    for name,digest in original.items():assert sha(CPU/name)==digest,name
    print('ISOLATED_CANDIDATE_PREPARED',len(expected),flush=True)

def execute():
    manifest=json.loads((OUT/'manifest.json').read_text())
    expected=manifest['expected_candidate_sha256']
    def check():
        for name,digest in expected.items():assert sha(TREE/name)==digest,name
    check()
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',SPK286_BUILD_JOBS='1',
        SPK286_BUILD_DIR=str(TREE/'build'),SPK286_EXPAND_DOWN_TERMINATION_SMOKE='1')
    commands=[('portable-formal',['python3','-B','scripts/test_null_segment_commit_equivalence.py','--output','build/formal']),
        ('strict-lint',['bash','-lc','source scripts/rtl_sources.sh\nverilator --lint-only --language 1800-2012 --Wall --top-module spk286_micro_executor -Irtl "${rtl_sources[@]}"']),
        ('protected-foundation',['bash','scripts/test_units.sh','both','spk286_protected_foundation']),
        ('protected-expand-down-directed',['bash','scripts/test_units.sh','both','spk286_protected_expand_down']),
        ('segment-lifecycle',['bash','scripts/test_units.sh','both','spk286_segment_lifecycle'])]
    results=[]
    for label,argv in commands:
        print('DIRECTED_START',label,flush=True)
        started=datetime.now(timezone.utc)
        log=OUT/(label+'.log')
        with log.open('w') as stream:
            result=subprocess.run(argv,cwd=TREE,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=600)
        row={'label':label,'command':argv,'returncode':result.returncode,'started_utc':started.isoformat(),
             'duration_seconds':(datetime.now(timezone.utc)-started).total_seconds(),'log_sha256':sha(log)}
        results.append(row)
        (OUT/'progress.json').write_text(json.dumps(results,indent=2)+'\n',newline='\n')
        assert result.returncode==0,(label,log)
        output=log.read_text()
        if label=='strict-lint':assert 'Warning' not in output and 'Error' not in output
        elif label!='portable-formal':
            marker={'protected-foundation':'PROTECTED_FOUNDATION PASS:',
                    'protected-expand-down-directed':'PROTECTED_EXPAND_DOWN TERMINATION_SMOKE PASS:',
                    'segment-lifecycle':'SEGMENT_LIFECYCLE PASS:'}[label]
            assert output.count(marker)==2,(label,'both simulators must report PASS',output[-1000:])
        check()
        print('DIRECTED_PASS',label,flush=True)
    receipt={'status':'NULL_SEGMENT_ISOLATED_DIRECTED_PASS','scope':'Candidate before production application: strict executor lint and three exact upstream benches in both simulators; no full regression',
        'source_bindings':manifest,'results':results,'full_regression':'USER_DEFERRED',
        'expand_down_scope':'Existing termination_smoke mode includes DS/ES null acceptance, null SS #GP/no writes; later full matrix not run',
        'portable_formal_receipt_sha256':sha(TREE/'build/formal/receipt.json'),
        'copied_source_unchanged_after_checks':True,'artifacts_sha256':{p.name:sha(p) for p in OUT.iterdir() if p.is_file()}}
    (OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',newline='\n')
    print(receipt['status'],flush=True)

if __name__=='__main__':
    import sys
    if sys.argv[1:]==['--prepare']:prepare()
    elif sys.argv[1:]==['--run']:execute()
    else:raise SystemExit('Use --prepare with native Python, then --run in WSL')
