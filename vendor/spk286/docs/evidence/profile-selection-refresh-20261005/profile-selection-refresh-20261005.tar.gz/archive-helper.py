import hashlib,io,json,tarfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
up=Path('D:/GitHub/SPK286')
private=root/'build/spk286-selected-generator-refresh-private-20261005-v1'
tree=private/'source-tree'
actual=up/'build/p06-selected-profile-applied-20261005'
sha=lambda b:hashlib.sha256(b).hexdigest()
p=json.loads((private/'receipt.json').read_text());a=json.loads((actual/'receipt.json').read_text())
assert p['status']=='PRIVATE_STANDALONE_SELECTED_GENERATOR_REFRESH_PASS'
assert a['status']=='CPU_ONLY_PROFILE_FOCUSED_PASS_NOT_HOST_ACCEPTANCE'
assert a['schedule_oracle_checks_per_simulator']==45 and a['passive_full_top_prefix_cases_per_simulator']==8
assert a['independent_metadata_cases_per_simulator']==43878
payload={}
for name,digest in p['sources_sha256'].items():
    b=(tree/name).read_bytes();assert sha(b)==digest,name
    assert (up/name).read_bytes()==b,name
    payload['source/'+name]=b
for base,prefix in ((private,'private'),(actual,'applied')):
    for f in base.rglob('*'):
        assert not f.is_symlink()
        if f.is_file() and f.suffix in ('.json','.log','.diff','.py','.sv','.svh','.txt'):
            if f.suffix in ('.sv','.svh') and 'negative' not in f.parts and base==private and 'source-tree' in f.parts:continue
            payload[prefix+'/'+f.relative_to(base).as_posix()]=f.read_bytes()
payload['archive-helper.py']=Path(__file__).read_bytes()
dest=up/'docs/evidence/profile-selection-refresh-20261005';dest.mkdir(parents=True,exist_ok=False)
archive=dest/(dest.name+'.tar.gz')
with tarfile.open(archive,'w:gz',compresslevel=9) as t:
    for name,b in payload.items():
        info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=0
        t.addfile(info,io.BytesIO(b))
with tarfile.open(archive) as t:
    assert set(t.getnames())==set(payload)
    for info in t:assert t.extractfile(info).read()==payload[info.name]
manifest={'status':'SEALED_APPLIED_STANDALONE_PROFILE_SELECTION_REFRESH_PASS',
    'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),
    'members':len(payload),'source_revision':p['source_revision'],
    'source_sha256':p['sources_sha256'],'verification':'Every member read back equal before cleanup',
    'full_regression':'AUTHORIZED_AFTER_TIMING_CLOSURE_NOT_RUN','hardware':'NOT_RUN',
    'interpretation':'Only current generator pins/guards and dated selected contract; raw CPU/microcode and all timing policy/table/test bytes unchanged; PCAT active fit and timed overlay unaffected'}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',newline='\n')
(dest/'receipt.json').write_bytes((actual/'receipt.json').read_bytes())
(dest/'private.json').write_bytes((private/'receipt.json').read_bytes())
backlog=up/'docs/REMAINING_WORK.md';s=backlog.read_text()
start=s.index('- **Current standalone profile selection refresh: P1.**')
end=s.index('- **Current complete regression:',start)
backlog.write_text(s[:start]+s[end:],newline='\n')
note=up/'docs/NULL_SEGMENT_COMMIT_SPECIALIZATION_20261005.md';s=note.read_text()
anchor='The standalone profile generator\'s historical selection already predates'
start=s.index(anchor)
note.write_text(s[:start]+('The previously stale standalone selection is refreshed with the dated\n'
    '`tools/profile_cpu_selected_20261005.json`, retaining both historical\n'
    'contracts unchanged. [Applied maintenance evidence](evidence/profile-selection-refresh-20261005/manifest.json)\n'
    'records deterministic generation, installed identity, strict full-CPU lint,\n'
    'dual schedule/prefix/metadata oracles, reset/fetch checks and seven rejected\n'
    'identity mutants. CPU, timing policy and test expectations are unchanged.\n'),newline='\n')
print('UPSTREAM_PROFILE_MAINTENANCE_SEALED',manifest['bytes'],manifest['members'])
