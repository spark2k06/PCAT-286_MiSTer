# Proposed standalone READY chaining synchronization

Status: review proposal with authorized focused staging validation in progress.
No external writes, commits, broad regression or generated-source installation
have been performed by this task. Two execution banks are being tested in
Icarus and Verilator only under `build/spk286-ready-chain-port-probes-20261004-v1`.

Standalone source: `D:/GitHub/SPK286`, clean HEAD `86a76ce`, branch
`codex/protected-mode-windows31`. Parent owns applying the reviewed proposal and
the eventual commit. All proposed files and diffs are contained in this build
directory. Check clean HEAD and every preimage SHA in `stage-manifest.json`
immediately before applying; do not overwrite later work.

## Functional identity

`functional-closure-bridge.json` records all 40 ordered functional RTL sources
from the standalone baseline, against the frozen vendor inputs used by broad
v3. Before applying, 38 are byte-identical. The only differing functional files
are `rtl/spk286.sv` and `rtl/spk286_fetch.sv`. The proposed files make all 40
byte-identical to the v3 snapshot and current vendor. All 20 literal `.mc`
sources and the three generated ROM/package files are already identical and
are left untouched.

The standalone instruction schedule and timing metadata modules are also
byte-identical to their PCAT equivalents. The generated profiled CPU should
therefore have SHA `847a6930469e67d7345847e39f57ab51a5fe3556c73f8741d5e9c7d69c6038c7`
after regeneration; profiled events remain
`a158e55b5b0a66060784c4901576fb717842cc9a009e3656d5feaaf76b51fbef`.
These are selected expectations to be checked by actual generation, not a claim
that standalone generation has already been run.

The vendor wildcard source list has one extra `rtl/spk286_system_0f.sv`, absent
standalone and outside the standalone functional closure. It is not instantiated
by the selected CPU and is not proposed for copying. Fresh standalone lint and
source-list capture must record this literal difference. No native pin, board,
SDRAM, clock, OSD or chipset interface is added to standalone.

## Minimum proposed patches: 13 files

| Patch | Files | Reason |
|---|---|---|
| `functional-core.patch` | CPU caller and fetch | Exact READY chaining RTL, conservative byte reservation, response backpressure and cancel handling already under the vendor gate. |
| `required-adapters.patch` | Shared signals header | Declare the existing `debug_biu_detail` output so `dut(.*)` elaborates. This does not create a new CPU output or input. |
| same | Three BIU benches | Declare their existing `debug_detail` output for wildcard binding. No stimulus or oracle changes. |
| same | `spk286_execution_tb.sv` | Replace the obsolete F1 unsupported latch expectation with an explicit `0F FF` architectural #UD acceptance check before the first stack write. Preserve retained fault origin 0200, CS, FLAGS and the complete GPR signature; reject retirement or unsupported latch. |
| same | `spk286_microcode_execution_tb.sv` | Replace F1 with `0F FF` after each MOV and actually resume to first #UD acceptance. Preserve original MOV register/IP/FLAGS/segment, pause, retirement and duplicate response checks before resuming. Require all 48 cases to retain fault origin base_ip+3, CS and FLAGS with no second retirement, unsupported latch, stack write or GPR/segment mutation. |
| same | Adjust instructions bench | Add 16 generic fabric waits to CODE transactions only, preserving architectural vectors, operands and expected outputs. This restores the positive radix starvation coverage assertion with early fetch. Vendor focal dual execution proved the unchanged expectations and positive coverage before v3 launch. |
| `compiler.patch` | Compiler | Run LOADALL protocol validation for its named entry even after the LOADALL token is deleted. No `.mc`, control encodings or generated ROM changes. |
| `portable-profile-contract.patch` | Generator, checker, new selected contract | Explicitly admit only the two new functional files while retaining the historical baseline contract and receipts. Bind selected generated sources and the updated probe header. |

The shared header is a one-line functional addition, retaining standalone
formatting and existing declarations. `header-declarations-bridge.json` proves
the proposed header and vendor header consist solely of the same 136
declarations, with equal net/variable kinds, names, widths and initializers.
Their textual grouping/order differs. This is a static equivalence check, not
byte identity. If exact bench input identity is required for reuse,
copying the vendor header only changes declaration formatting beyond that one
wire; its new hash must replace the probe hash in the selected contract.

## Historical and standalone contracts preserved

Do not modify `tools/profile_cpu_baseline.json` or the historical
`docs/evidence/profile-cpu-20261004/receipt.json`. The proposed
`tools/profile_cpu_ready_chain.json` pins the old baseline file itself, adds the
two explicit functional source updates, and specifies selected generated/probe
identities. The generator validates all 40 functional dependencies with only
those two overrides. New manifests/receipts record the historical baseline and
the current selected source map separately.

Regenerate `rtl/timed/spk286_profiled.sv`, `spk286_profiled_events.sv` and
`generation.json` from the proposed standalone generator after applying. Do not
copy PCAT's generation receipt, since its paths, generator hashes and historical
dependencies are different. Do not hand-edit generated CPU or ROM artifacts.

Keep standalone `Makefile`, `scripts/synth_check.sh`, `spk286_core_tb.sv`,
`sim/verilator/state_inputs.h`, all historical documentation/evidence, and its
modern microcode fixtures. The core bench has extra checks for supported policy
0/2 (`+max_policy`); vendor's shorter bench must not remove these. The standalone
Yosys runner includes four extra selector/descriptor/protected-state/LOADALL
service checks that must remain.

## Differences not included in the minimum patch

The following real differences require fresh standalone checks or a separately
reviewed adapter change. They are not certified just by the 40-file RTL bridge.

* **Python tests and catalog:** standalone already uses the modern 171/172
  control catalog in its fixtures. For example register execution reads its
  correct SALC fixture; IO uses `microcode_phase9_loadall_sources.json`.
  Do not copy the six vendor helpers that translate its old fixture catalogs.
  Run the standalone Python/microcode suite fresh with the new compiler.
* **Microcode negative tests:** standalone `test_microcode_data.py` accepts
  older audit wording; vendor checks the specific audit error marker. Its
  `test_microcode_far.py` still uses format 16 and pre-existing frame token
  mutations where vendor uses genuinely invalid format 13 and `CHECK_POP2`
  mutation. Inspect any fresh failure and repair only with an unchanged-source
  positive control and a true independent negative property. Their saved diffs
  are proposals for review, not automatically included.
* **LOADALL Python oracle:** standalone lacks vendor's
  `tests/test_microcode_loadall.py`. Copying it is optional, requires explicit
  review, and adds positive roundtrip/unchanged-prefix checks plus rejection of
  removed/duplicated tokens using literal modern `[171,3]`. It would strengthen
  coverage of the compiler fix and leave fixture/ROM bytes unchanged. It is not
  included in the 13-file minimum patch.
* **Core bench:** extra standalone policy assertions and `+max_policy`; execute
  fresh baseline and MAX in both simulators.
* **Event lifecycle:** standalone defaults `real_mode_fetch_wrap=0`, while the
  unchanged CPU already implements real-mode wrap. Vendor bench/runner defaults
  1. Run standalone with explicit `+real_mode_fetch_wrap=1`, preserving all
  architecturally selected assertions; record the declared profile. Do not
  claim the no-wrap oracle is applicable to the selected wrapping CPU.
* **Unit registry:** vendor additionally includes event arbitration. It does not
  remove existing cases. The new bank is not included here; vendor evidence can
  retain its CPU property coverage because the actual event RTL is identical.
  Adding the independent bank to the standalone suite later requires review.
* **Mutation audits:** five standalone tools differ. The diffs are saved under
  `diffs/tools__audit_*.diff`, but no auditor is copied into this proposal. Their
  fresh stages are required if kept: events uses the older trap-priority probe;
  phase8/segment/unary expect an assertion that may be reached after an earlier
  equally exact assertion; singlestep's old unsupported latch probe requires
  architectural #UD instead. Any repair must preserve mutants, pristine control
  and precise expected failures. Arbitrary nonzero exits are not acceptable.
* **CI fixture and Makefile:** standalone intentionally preserves a CI shell
  fixture after removing its workflow and adds timing/phase8 targets. Keep them,
  run their differing Python or release stages fresh if claiming those gates.
* **State smoke:** standalone explicitly drives policy 0 before reset; vendor
  omits that assignment. Keep the initialization and run fresh state/verilator
  smoke rather than inferring exact harness identity.
* **Synthesis checks:** run fresh full standalone synthesis sanity, including its
  four additional module checks and mapped top. Shared v3 checks alone do not
  certify these extra steps.

## Acceptance composition, avoiding a duplicate broad run

1. Require final PASS and archived source bindings from vendor broad v3; this
   proposal deliberately does not mark an in-progress gate accepted.
2. Apply the reviewed minimum patch only after clean/preimage checks.
3. Recompute every standalone functional RTL, literal `.mc`, generated ROM and
   timing module SHA; require exact selected identities against the final frozen
   vendor evidence, not just HEAD or copied filenames.
4. Run fresh every standalone test/release stage whose executable input graph or
   oracle differs from v3. Minimum extra scopes are standalone Python/microcode,
   profile deterministic generation and installed identity, strict lint,
   schedule/prefix/metadata/reset probes, the preserved core policy probes,
   explicitly selected event wrap case, state smoke, differing mutation audits,
   and its extra Yosys steps. Shared header declarations have a static semantic
   bridge, but retain that limit explicitly; do not silently call different
   bytes identical.
5. Archive both original shared vendor evidence and fresh standalone results
   with their full source graphs. Credit only their named scopes. This is a
   composed acceptance record, not a false claim that standalone `make
   regression` was rerun in full.
6. Commit standalone functional source, regenerated profile artifacts, portable
   selected contract and reviewed adapters once all applicable gates pass.
   Parent alone owns that later action.

## Files for review

* `stage-manifest.json`: exact old/new SHA for the 13 staged files.
* `functional-closure-bridge.json`: all 40 RTL, 20 `.mc`, timing and frozen v3
  identities, plus the original baseline/receipt digests.
* `header-declarations-bridge.json`: static header declaration equivalence.
* Four `.patch` files and `staged/`: proposed external paths/content only.
* `comparison.json` and `diffs/`: broader read-only inventory explaining why a
  directory copy is unsafe.
* `prepare_plan.py`: read-only external input access and local staging writer;
  no apply, simulator, generator execution or commit operation.

## Extra execution adapter review

The first proposed microcode adapter copied the vendor NOP termination and
checked the local unsupported latch immediately after enabling execution. An
independent review correctly identified that it did not preserve the original
post-MOV sentinel progression coverage. That proposal was replaced before any
external apply. The current staged adapters explicitly service the stream until
the first real fault acceptance, require a positive number of cycles and use
watchdogs rather than per-case delays.

Both historical harnesses read memory but do not model stack writes/IRET.
Consequently the new checks deliberately stop at the registered
`dut.event_active && dut.event_cancel` acceptance edge, before fault entry can
change SP or FLAGS. `dut.event_ip`, `event_cs` and `event_flags` are the retained
architectural context, independent of the live IP after consuming the 0F
introducer. Vector 6, fault kind 1, no error code, unchanged full signatures,
absence of stack writes and no second retirement are required. This preserves
the old positive sentinel intent without adding a board interface, artificial
execution stop, fixed delay or stack model.
