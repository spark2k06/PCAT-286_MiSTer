#!/usr/bin/env bash
set -euo pipefail
ulimit -c 0
task_root=$(cd "$(dirname "$0")" && pwd)
cd "$task_root/cpu"
source scripts/rtl_sources.sh
out="$task_root/directed-v2"
[[ ! -e "$out" ]]
mkdir "$out"
verilator --version > "$out/tools.txt"
iverilog -V >> "$out/tools.txt" 2>&1
sha256sum "${rtl_sources[@]}" rtl/timed/*.sv rtl/spk286_timing/*.sv sim/unit/spk286_signals.svh \
  sim/unit/spk286_call_stack_precheck_tb.sv sim/unit/spk286_call_gate_accessed_tb.sv \
  sim/unit/spk286_protected_event_outer_tb.sv sim/unit/spk286_protected_return_restart_tb.sv \
  sim/unit/spk286_stack_frame_lifecycle_tb.sv > "$out/source.sha256"
verilator --lint-only --language 1800-2012 --Wall --top-module spk286 \
  -Irtl "${rtl_sources[@]}" > "$out/raw-lint.log" 2>&1
verilator --lint-only --language 1800-2012 --Wall --top-module spk286_profiled \
  -Irtl "${rtl_sources[@]}" rtl/timed/*.sv rtl/spk286_timing/*.sv > "$out/timed-lint.log" 2>&1
for unit in spk286_call_stack_precheck spk286_call_gate_accessed spk286_protected_event_outer \
  spk286_protected_return_restart spk286_stack_frame_lifecycle; do
  top="${unit}_tb"; stem="$out/$unit"
  mkdir "$stem"
  timeout 120 iverilog -g2012 -Irtl -Isim/unit -s "$top" -o "$stem/test.vvp" \
    "${rtl_sources[@]}" "sim/unit/$top.sv" > "$stem/iverilog-build.log" 2>&1
  timeout 180 vvp "$stem/test.vvp" | tee "$stem/iverilog-run.log"
  timeout 480 verilator --binary --build-jobs 1 --timing --assert --language 1800-2012 \
    --top-module "$top" --Mdir "$stem/verilator" -Irtl -Isim/unit -o directed \
    "${rtl_sources[@]}" "sim/unit/$top.sv" > "$stem/verilator-build.log" 2>&1
  timeout 180 "$stem/verilator/directed" | tee "$stem/verilator-run.log"
  grep ' PASS:' "$stem/iverilog-run.log" > "$stem/iverilog-result.txt"
  grep ' PASS:' "$stem/verilator-run.log" > "$stem/verilator-result.txt"
  cmp "$stem/iverilog-result.txt" "$stem/verilator-result.txt"
done
sha256sum -c "$out/source.sha256" > "$out/source-check.log"
echo PRIVATE_STACK_DATA_SELECTOR_DIRECTED_PASS
