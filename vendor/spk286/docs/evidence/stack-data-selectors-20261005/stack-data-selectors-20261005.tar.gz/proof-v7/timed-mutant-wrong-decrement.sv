// One logical byte/word service, shared by REG and RM. Byte register
// encoding selects AL..BL/AH..BH independently of word-register encoding.
// Register access completes locally; memory completes through the BIU response.
`timescale 1ns/1ps
module operand_step #(parameter bit USE_PARALLEL_RANGE = 1'b0) (
    input  logic clk, reset, cancel,
    input logic pending_state, blocked_state,
    output logic pending_next, blocked_next,
    input  logic request_valid, request_write, request_check, request_byte, select_rm,
    input  logic [15:0] write_data,
    output logic done, unlimited_memory_done,
    output logic [15:0] read_data,
    input  logic [127:0] register_state,
    input  logic [2:0] reg_index, rm_index,
    input  logic register_direct,
    input  logic [23:0] physical_address,
    input  logic [15:0] offset, segment_limit,
    input  logic segment_expand_down, parallel_within_limit,
    output logic blocked,
    output logic gpr_write_en, gpr_write_byte,
    output logic [2:0] gpr_write_index,
    output logic [15:0] gpr_write_data,
    output logic memory_request,
    input  logic memory_request_ready,
    output logic memory_write, memory_byte,
    output logic [23:0] memory_address,
    output logic [15:0] memory_write_data,
    input  logic memory_response_valid,
    output logic memory_response_ready,
    output logic timing_wait,
    input  logic [15:0] memory_read_data
);
    wire pending_q = pending_state;
    assign blocked = blocked_state;
    logic is_memory, allowed, within_limit;
    logic [2:0] register_index, word_index;
    logic [15:0] register_word;
    assign register_index = select_rm ? rm_index : reg_index;
    assign is_memory = select_rm && !register_direct;
    assign within_limit = USE_PARALLEL_RANGE ? parallel_within_limit : segment_expand_down ?
                          (offset > segment_limit &&
                           (request_byte || offset != 16'hFFFF)) :
                          (offset < segment_limit ||
                           (request_byte && offset == segment_limit));
    assign allowed = request_valid && !reset && !cancel && !blocked;
    assign memory_request = allowed && is_memory && !pending_q && within_limit && !request_check;
    assign memory_write = request_write;
    assign memory_byte = request_byte;
    assign memory_address = physical_address;
    assign memory_write_data = write_data;
    assign memory_response_ready = allowed && pending_q;
    // Observe only genuine memory-service stalls: BIU admission or an
    // outstanding response. Register accesses, checks, limit faults,
    // cancellation and the response-acceptance cycle are not waits.
    assign timing_wait = allowed && is_memory &&
                         ((!pending_q && !request_check && within_limit && !memory_request_ready) ||
                          (pending_q && !memory_response_valid));
    assign done = allowed && ((request_check && (!is_memory || within_limit) && !pending_q) || (!is_memory && !pending_q) || (pending_q && memory_response_valid));
    // Completion predicate for a valid memory request with unlimited range.
    // The caller must establish request_valid, is_memory and within_limit.
    // Retain cancellation, blocking and the existing pending/response handshake.
    assign unlimited_memory_done = !reset && !cancel && !blocked &&
                                   ((request_check && !pending_q) ||
                                    (pending_q && memory_response_valid));
    assign word_index = request_byte ? {1'b0, register_index[1:0]} : register_index;
    assign register_word = register_state[word_index * 16 +: 16];
    assign read_data = is_memory ? memory_read_data : (request_byte ?
                       {8'd0, (register_index[2] ? register_word[15:8] : register_word[7:0])} : register_word);
    assign gpr_write_en = done && request_write && !is_memory && !request_check;
    assign gpr_write_index = register_index;
    assign gpr_write_byte = request_byte;
    assign gpr_write_data = write_data;
    always @* begin
        pending_next = pending_state; blocked_next = blocked_state;
        if (reset || cancel) begin
            pending_next = 1'b0;
            blocked_next = 1'b0;
        end else begin
            if (allowed && is_memory && !within_limit) blocked_next = 1'b1;
            if (memory_request && memory_request_ready) pending_next = 1'b1;
            if (memory_response_ready && memory_response_valid) pending_next = 1'b0;
        end
    end
endmodule

module cone_reference(
input wire [15:0] address_offset,
input wire address_override,
input wire [15:0] allocation_q,
input wire allocation_valid_q,
input wire arithmetic_fault,
input wire bounds_fault,
input wire call_gate_candidate_valid_q,
input wire call_gate_stack_switch_active_q,
input wire [1:0] call_gate_stack_switch_phase_q,
input wire [1:0] call_gate_target_dpl_q,
input wire call_parameter_active_q,
input wire [1:0] call_parameter_phase_q,
input wire [15:0] call_parameter_source_sp_q,
input wire [7:0] call_ss_access_q,
input wire [23:0] call_ss_base_q,
input wire [15:0] call_ss_limit_q,
input wire [7:0] cs_candidate_access_q,
input wire [3:0] cs_candidate_class_q,
input wire cs_candidate_valid_q,
input wire demanded_code_fault,
input wire event_error_valid,
input wire execute_enable,
input wire [15:0] frame_address_q,
input wire frame_address_valid_q,
input wire invalid_form,
input wire invalid_opcode_fault,
input wire [15:0] io_port,
input wire io_transfer,
input wire [1:0] iret_outer_phase_q,
input wire length_fault,
input wire loadall_fault,
input wire [15:0] loadall_fault_error_code,
input wire [7:0] loadall_fault_vector,
input wire [7:0] micro_word,
input wire operand_blocked,
input wire operand_byte,
input wire [15:0] operand_offset,
input wire operand_register_direct,
input wire operand_request,
input wire [1:0] operand_segment,
input wire operand_select_rm,
input wire operand_write,
input wire operation_valid,
input wire [1:0] override_segment,
input wire profile_raw_operation_valid,
input wire [1:0] protected_cpl,
input wire protected_descriptor_access,
input wire [23:0] protected_descriptor_address,
input wire protected_event_access,
input wire [23:0] protected_event_address,
input wire protected_fetch_fault,
input wire [15:0] protected_msw,
input wire protected_return_cursor_q,
input wire [31:0] protected_segment_access,
input wire [95:0] protected_segment_bases,
input wire [63:0] protected_segment_limits,
input wire [3:0] protected_segment_present,
input wire [3:0] protected_segment_protected,
input wire [3:0] protected_segment_valid,
input wire protected_tss_access,
input wire [23:0] protected_tss_address,
input wire push_enabled,
input wire range_fault,
input wire [31:0] real_segment_access_state,
input wire [95:0] real_segment_bases,
input wire [63:0] real_segment_limits,
input wire reset,
input wire [15:0] segment_offset,
input wire segment_override,
input wire [1:0] segment_read_index,
input wire semantic_cancel,
input wire service_start,
input wire [15:0] stack_cursor_q,
input wire [15:0] stack_native_offset,
input wire [15:0] stack_pointer,
input wire string_destination,
input wire string_request,
input wire system_fault,
input wire [15:0] system_fault_error_code,
input wire [7:0] system_fault_vector,
input wire system_limit_fault,
input wire task_event_switch_skip,
input wire task_return_skip,
input wire task_switch_skip,
input wire [2:0] temporary_valid_q,
input wire [15:0] tmp1_q,
input wire [15:0] vector_offset,
input wire vector_request,
output wire observed_stack_request,
output wire observed_protected_call_stack_access,
output wire [15:0] observed_protected_call_stack_limit,
output wire observed_protected_call_stack_expand_down,
output wire [15:0] observed_service_offset,
output wire observed_parallel_operand_within_limit,
output wire observed_parallel_system_cache_fault,
output wire observed_protected_access_fault,
output wire observed_protected_access_ss_fault,
output wire [1:0] observed_selected_segment_index,
output wire [15:0] observed_selected_segment_limit,
output wire [7:0] observed_selected_segment_access,
output wire [23:0] observed_selected_segment_base,
output wire [23:0] observed_segment_address,
output wire [23:0] observed_operand_physical_address,
output wire observed_fault_request,
output wire [7:0] observed_fault_vector,
output wire observed_fault_error_valid,
output wire [15:0] observed_fault_error_code,
output wire [15:0] observed_stack_offset,
output wire [23:0] observed_protected_call_stack_address
);
wire [1:0] service_segment;
wire [15:0] service_offset;
wire [1:0] selected_segment_index;
wire [15:0] selected_segment_limit;
wire [7:0] selected_segment_access;
wire protected_segment_is_loaded;
wire protected_segment_is_valid;
wire protected_segment_is_present;
wire protected_segment_is_code;
wire protected_segment_is_readable;
wire protected_segment_is_writable;
wire protected_segment_is_expand_down;
wire protected_selected_range_fault;
wire parallel_operand_within_limit;
wire protected_call_range_fault;
wire protected_access_fault;
wire protected_access_ss_fault;
wire [3:0] operand_io_ranges;
wire [3:0] operand_address_ranges;
wire [3:0] operand_stack_ranges;
wire [3:0] operand_regular_ranges;
wire [3:0] operand_vector_ranges;
wire [3:0] operand_system_ranges;
genvar operand_cache_index;
    assign service_segment = string_request ? (string_destination ? 2'd0 : (segment_override ? override_segment : 2'd3)) : stack_request ? 2'd2 : (segment_override ? override_segment : operand_segment);
    assign service_offset = io_transfer ? 16'd0 : address_override && !stack_request && !vector_request ? address_offset : vector_request ? vector_offset : (stack_request ? stack_offset : operand_offset);
    assign selected_segment_index = execute_enable ? service_segment : segment_read_index;
    assign selected_segment_limit = protected_msw[0] ? protected_segment_limits[selected_segment_index * 16 +: 16] : real_segment_limits[selected_segment_index * 16 +: 16];
    assign selected_segment_access = protected_msw[0] ? protected_segment_access[selected_segment_index * 8 +: 8] : real_segment_access_state[selected_segment_index * 8 +: 8];
    assign protected_segment_is_loaded = protected_msw[0] && protected_segment_protected[service_segment];
    assign protected_segment_is_valid = protected_segment_valid[service_segment];
    assign protected_segment_is_present = protected_segment_present[service_segment];
    assign protected_segment_is_code = selected_segment_access[3];
    assign protected_segment_is_readable = selected_segment_access[1];
    assign protected_segment_is_writable = !protected_segment_is_code && selected_segment_access[1];
    assign protected_segment_is_expand_down = !protected_segment_is_code && selected_segment_access[2];
    assign protected_selected_range_fault = !parallel_operand_within_limit;
    assign parallel_operand_within_limit =
        (protected_event_access || protected_descriptor_access || protected_tss_access || protected_call_stack_access) ? 1'b1 :
        vector_request ? operand_vector_ranges[selected_segment_index] :
        io_transfer ? operand_io_ranges[selected_segment_index] :
        address_override && !stack_request ? operand_address_ranges[selected_segment_index] :
        stack_request ? operand_stack_ranges[selected_segment_index] :
        operand_regular_ranges[selected_segment_index];
    assign protected_call_range_fault = stack_request ?
        protected_range_exceeded(stack_offset, protected_call_stack_limit, protected_call_stack_expand_down, operand_byte) :
        address_override ? protected_range_exceeded(address_offset, protected_call_stack_limit, protected_call_stack_expand_down, operand_byte) :
        protected_range_exceeded(operand_offset, protected_call_stack_limit, protected_call_stack_expand_down, operand_byte);
    assign protected_access_fault = operand_request && operand_select_rm && !operand_register_direct &&
                                   !protected_descriptor_access && !protected_tss_access && !protected_event_access &&
                                   !io_transfer && !vector_request &&
                                    (protected_call_stack_access ?
                                    (service_segment != 2'd2 || protected_call_range_fault) :
                                    (protected_segment_is_loaded &&
                                     (!protected_segment_is_valid || !protected_segment_is_present ||
                                      (protected_segment_is_code ? (!protected_segment_is_readable || operand_write) :
                                       (stack_request ? (!protected_segment_is_writable || service_segment != 2'd2) :
                                        (operand_write && !protected_segment_is_writable))) ||
                                      protected_selected_range_fault)));
    assign protected_access_ss_fault = protected_access_fault && service_segment == 2'd2;
    function automatic logic protected_range_exceeded(
        input logic [15:0] offset_value, limit_value,
        input logic expand_down, is_byte
    );
        protected_range_exceeded = expand_down ?
            (offset_value <= limit_value || (!is_byte && offset_value == 16'hFFFF)) :
            (offset_value > limit_value || (!is_byte && offset_value == limit_value));
    endfunction
    generate
    for (operand_cache_index = 0; operand_cache_index < 4; operand_cache_index = operand_cache_index + 1) begin : g_operand_cache_range
        wire [15:0] cache_limit = protected_msw[0] ?
            protected_segment_limits[operand_cache_index*16 +: 16] :
            real_segment_limits[operand_cache_index*16 +: 16];
        wire cache_expand_down = protected_msw[0] &&
            !protected_segment_access[operand_cache_index*8+3] &&
            protected_segment_access[operand_cache_index*8+2];
        assign operand_io_ranges[operand_cache_index] =
            !protected_range_exceeded(16'd0, cache_limit, cache_expand_down, operand_byte);
        assign operand_address_ranges[operand_cache_index] =
            !protected_range_exceeded(address_offset, cache_limit, cache_expand_down, operand_byte);
        assign operand_stack_ranges[operand_cache_index] =
            !protected_range_exceeded(stack_offset, cache_limit, cache_expand_down, operand_byte);
        assign operand_regular_ranges[operand_cache_index] =
            !protected_range_exceeded(operand_offset, cache_limit, cache_expand_down, operand_byte);
        assign operand_vector_ranges[operand_cache_index] =
            !protected_range_exceeded(io_transfer ? 16'd0 : vector_offset, 16'hFFFF, cache_expand_down, operand_byte);
        // Six-byte table operands use the ordinary effective offset.
        // Complete each cache's range comparison before the late index mux.
        assign operand_system_ranges[operand_cache_index] = cache_expand_down ?
            (operand_offset <= cache_limit || operand_offset > 16'hFFFA) :
            ({1'b0, operand_offset} + 17'd5 > {1'b0, cache_limit});
    end
    endgenerate
wire allowed;
wire copy_call_parameters;
wire read_frame_address;
wire call_gate_outer_required;
wire call_parameter_read;
wire call_parameter_write;
wire iret_outer_frame_operation;
wire iret_outer_required;
wire iret_outer_pop;
wire push_operation;
wire push_event_error;
wire push_transfer;
wire push_event_error_transfer;
wire call_gate_stack_switch_operation;
wire call_gate_stack_write;
wire pop_operation;
wire stack_request;
wire [15:0] call_parameter_write_offset;
wire [15:0] iret_parameter_bytes;
wire [15:0] return_stack_pointer;
wire [15:0] iret_outer_stack_offset;
wire [15:0] stack_offset;
wire protected_call_stack_access;
wire [23:0] protected_call_stack_address;
wire [15:0] protected_call_stack_limit;
wire protected_call_stack_expand_down;
wire implementation_allowed;
    assign allowed = operation_valid && !reset && !semantic_cancel && !service_start &&
                     !task_switch_skip && !task_return_skip && !task_event_switch_skip;
    assign copy_call_parameters = implementation_allowed && micro_word == 8'd165;
    assign read_frame_address = implementation_allowed && micro_word == 8'd106 && frame_address_valid_q;
    assign call_gate_outer_required = protected_msw[0] && call_gate_candidate_valid_q && cs_candidate_valid_q &&
                                     (call_gate_target_dpl_q < protected_cpl) &&
                                     !(cs_candidate_class_q == 4'd1 && cs_candidate_access_q[2]);
    assign call_parameter_read = copy_call_parameters && call_gate_outer_required &&
                                 call_parameter_active_q && call_parameter_phase_q == 2'd0;
    assign call_parameter_write = copy_call_parameters && call_gate_outer_required &&
                                  call_parameter_active_q && call_parameter_phase_q == 2'd1;
    assign iret_outer_frame_operation = implementation_allowed && micro_word == 8'd157;
    assign iret_outer_required = protected_msw[0] && protected_return_cursor_q &&
                                 temporary_valid_q[1] && (tmp1_q[1:0] > protected_cpl);
    assign iret_outer_pop = iret_outer_frame_operation && iret_outer_required && iret_outer_phase_q < 2'd2;
    assign push_operation = implementation_allowed && micro_word == 8'd21 && temporary_valid_q[0];
    assign push_event_error = implementation_allowed && micro_word == 8'd155;
    assign push_transfer = push_operation && push_enabled;
    assign push_event_error_transfer = push_event_error && push_enabled && event_error_valid;
    assign call_gate_stack_switch_operation = implementation_allowed && micro_word == 8'd163;
    assign call_gate_stack_write = call_gate_stack_switch_operation && call_gate_stack_switch_active_q &&
                                   call_gate_stack_switch_phase_q < 2'd2;
    assign pop_operation = implementation_allowed && (micro_word == 8'd22 ||
                                      micro_word == 8'd43 ||
                                      micro_word == 8'd44 || iret_outer_pop);
    assign stack_request = !range_fault &&
                           (push_transfer || push_event_error_transfer || pop_operation || read_frame_address ||
                            call_gate_stack_write || call_parameter_read || call_parameter_write);
    assign call_parameter_write_offset = stack_cursor_q - 16'd2;
    assign iret_parameter_bytes = allocation_valid_q ? allocation_q : 16'd0;
    assign return_stack_pointer = protected_return_cursor_q ? stack_cursor_q : stack_pointer;
    assign iret_outer_stack_offset = return_stack_pointer + iret_parameter_bytes;
    assign stack_offset = call_parameter_read ? call_parameter_source_sp_q :
                          call_parameter_write ? call_parameter_write_offset :
                          iret_outer_pop ? iret_outer_stack_offset :
                          read_frame_address ? frame_address_q : stack_native_offset;
    assign protected_call_stack_access = call_gate_stack_switch_active_q && call_gate_outer_required &&
                                        stack_request && !read_frame_address && !call_parameter_read;
    assign protected_call_stack_address = call_ss_base_q + {8'd0, stack_offset};
    assign protected_call_stack_limit = call_ss_limit_q;
    assign protected_call_stack_expand_down = call_ss_access_q[2];
    assign implementation_allowed = profile_raw_operation_valid && !reset && !semantic_cancel && !service_start &&
                     !task_switch_skip && !task_return_skip && !task_event_switch_skip;
wire parallel_system_cache_fault;
    assign parallel_system_cache_fault = operand_system_ranges[selected_segment_index];
wire [23:0] selected_segment_base;
    assign selected_segment_base = protected_msw[0] ? protected_segment_bases[selected_segment_index * 24 +: 24] : real_segment_bases[selected_segment_index * 24 +: 24];
wire [23:0] segment_address;
    assign segment_address = selected_segment_base + {8'h00, (execute_enable ? service_offset : segment_offset)};
wire loadall_fault_has_error;
    assign loadall_fault_has_error = loadall_fault_vector == 8'd8 || loadall_fault_vector == 8'd10 ||
                                    loadall_fault_vector == 8'd11 || loadall_fault_vector == 8'd12 || loadall_fault_vector == 8'd13;
wire system_fault_has_error;
    assign system_fault_has_error = system_fault_vector == 8'd8 || system_fault_vector == 8'd10 ||
                                   system_fault_vector == 8'd11 || system_fault_vector == 8'd12 || system_fault_vector == 8'd13;
wire fault_request;
    assign fault_request = range_fault || bounds_fault || arithmetic_fault || operand_blocked || invalid_form ||
                           invalid_opcode_fault || system_limit_fault || system_fault ||
                           protected_access_fault || protected_fetch_fault || demanded_code_fault || length_fault || loadall_fault;
wire [7:0] fault_vector;
    assign fault_vector = (invalid_form || invalid_opcode_fault) ? 8'd6 : loadall_fault ? loadall_fault_vector : system_fault ? system_fault_vector :
                          (protected_access_ss_fault || ((system_limit_fault || range_fault) && protected_msw[0] && service_segment == 2'd2)) ? 8'd12 : protected_access_fault ? 8'd13 :
                          protected_fetch_fault ? 8'd13 : bounds_fault ? 8'd5 : arithmetic_fault ? 8'd0 : 8'd13;
wire fault_error_valid;
    assign fault_error_valid = protected_msw[0] && !(invalid_form || invalid_opcode_fault) &&
                              (loadall_fault ? loadall_fault_has_error :
                               system_fault ? system_fault_has_error :
                               (protected_access_ss_fault ||
                                ((system_limit_fault || range_fault) && protected_msw[0] && service_segment == 2'd2) ||
                                protected_access_fault || protected_fetch_fault || (!bounds_fault && !arithmetic_fault)));
wire [15:0] fault_error_code;
    assign fault_error_code = system_fault ? system_fault_error_code :
                              loadall_fault ? loadall_fault_error_code : 16'd0;
logic [23:0] operand_physical_address;
    always_comb begin
        operand_physical_address = segment_address;
        if (vector_request) operand_physical_address = {8'd0, vector_offset};
        if (io_transfer) operand_physical_address = {8'd0, io_port};
        if (protected_call_stack_access) operand_physical_address = protected_call_stack_address;
        if (protected_tss_access) operand_physical_address = protected_tss_address;
        if (protected_descriptor_access) operand_physical_address = protected_descriptor_address;
        if (protected_event_access) operand_physical_address = protected_event_address;
    end
assign observed_stack_request = stack_request;
assign observed_protected_call_stack_access = protected_call_stack_access;
assign observed_protected_call_stack_limit = protected_call_stack_limit;
assign observed_protected_call_stack_expand_down = protected_call_stack_expand_down;
assign observed_service_offset = service_offset;
assign observed_parallel_operand_within_limit = parallel_operand_within_limit;
assign observed_parallel_system_cache_fault = parallel_system_cache_fault;
assign observed_protected_access_fault = protected_access_fault;
assign observed_protected_access_ss_fault = protected_access_ss_fault;
assign observed_selected_segment_index = selected_segment_index;
assign observed_selected_segment_limit = selected_segment_limit;
assign observed_selected_segment_access = selected_segment_access;
assign observed_selected_segment_base = selected_segment_base;
assign observed_segment_address = segment_address;
assign observed_operand_physical_address = operand_physical_address;
assign observed_fault_request = fault_request;
assign observed_fault_vector = fault_vector;
assign observed_fault_error_valid = fault_error_valid;
assign observed_fault_error_code = fault_error_code;
assign observed_stack_offset = stack_offset;
assign observed_protected_call_stack_address = protected_call_stack_address;
endmodule

module cone_candidate(
input wire [15:0] address_offset,
input wire address_override,
input wire [15:0] allocation_q,
input wire allocation_valid_q,
input wire arithmetic_fault,
input wire bounds_fault,
input wire call_gate_candidate_valid_q,
input wire call_gate_stack_switch_active_q,
input wire [1:0] call_gate_stack_switch_phase_q,
input wire [1:0] call_gate_target_dpl_q,
input wire call_parameter_active_q,
input wire [1:0] call_parameter_phase_q,
input wire [15:0] call_parameter_source_sp_q,
input wire [7:0] call_ss_access_q,
input wire [23:0] call_ss_base_q,
input wire [15:0] call_ss_limit_q,
input wire [7:0] cs_candidate_access_q,
input wire [3:0] cs_candidate_class_q,
input wire cs_candidate_valid_q,
input wire demanded_code_fault,
input wire event_error_valid,
input wire execute_enable,
input wire [15:0] frame_address_q,
input wire frame_address_valid_q,
input wire invalid_form,
input wire invalid_opcode_fault,
input wire [15:0] io_port,
input wire io_transfer,
input wire [1:0] iret_outer_phase_q,
input wire length_fault,
input wire loadall_fault,
input wire [15:0] loadall_fault_error_code,
input wire [7:0] loadall_fault_vector,
input wire [7:0] micro_word,
input wire operand_blocked,
input wire operand_byte,
input wire [15:0] operand_offset,
input wire operand_register_direct,
input wire operand_request,
input wire [1:0] operand_segment,
input wire operand_select_rm,
input wire operand_write,
input wire operation_valid,
input wire [1:0] override_segment,
input wire profile_raw_operation_valid,
input wire [1:0] protected_cpl,
input wire protected_descriptor_access,
input wire [23:0] protected_descriptor_address,
input wire protected_event_access,
input wire [23:0] protected_event_address,
input wire protected_fetch_fault,
input wire [15:0] protected_msw,
input wire protected_return_cursor_q,
input wire [31:0] protected_segment_access,
input wire [95:0] protected_segment_bases,
input wire [63:0] protected_segment_limits,
input wire [3:0] protected_segment_present,
input wire [3:0] protected_segment_protected,
input wire [3:0] protected_segment_valid,
input wire protected_tss_access,
input wire [23:0] protected_tss_address,
input wire push_enabled,
input wire range_fault,
input wire [31:0] real_segment_access_state,
input wire [95:0] real_segment_bases,
input wire [63:0] real_segment_limits,
input wire reset,
input wire [15:0] segment_offset,
input wire segment_override,
input wire [1:0] segment_read_index,
input wire semantic_cancel,
input wire service_start,
input wire [15:0] stack_cursor_q,
input wire [15:0] stack_native_offset,
input wire [15:0] stack_pointer,
input wire string_destination,
input wire string_request,
input wire system_fault,
input wire [15:0] system_fault_error_code,
input wire [7:0] system_fault_vector,
input wire system_limit_fault,
input wire task_event_switch_skip,
input wire task_return_skip,
input wire task_switch_skip,
input wire [2:0] temporary_valid_q,
input wire [15:0] tmp1_q,
input wire [15:0] vector_offset,
input wire vector_request,
output wire observed_stack_request,
output wire observed_protected_call_stack_access,
output wire [15:0] observed_protected_call_stack_limit,
output wire observed_protected_call_stack_expand_down,
output wire [15:0] observed_service_offset,
output wire observed_parallel_operand_within_limit,
output wire observed_parallel_system_cache_fault,
output wire observed_protected_access_fault,
output wire observed_protected_access_ss_fault,
output wire [1:0] observed_selected_segment_index,
output wire [15:0] observed_selected_segment_limit,
output wire [7:0] observed_selected_segment_access,
output wire [23:0] observed_selected_segment_base,
output wire [23:0] observed_segment_address,
output wire [23:0] observed_operand_physical_address,
output wire observed_fault_request,
output wire [7:0] observed_fault_vector,
output wire observed_fault_error_valid,
output wire [15:0] observed_fault_error_code,
output wire [15:0] observed_stack_offset,
output wire [23:0] observed_protected_call_stack_address
);
wire [1:0] service_segment;
wire [15:0] service_offset;
wire [1:0] selected_segment_index;
wire [15:0] selected_segment_limit;
wire [7:0] selected_segment_access;
wire protected_segment_is_loaded;
wire protected_segment_is_valid;
wire protected_segment_is_present;
wire protected_segment_is_code;
wire protected_segment_is_readable;
wire protected_segment_is_writable;
wire protected_segment_is_expand_down;
wire protected_selected_range_fault;
wire parallel_operand_within_limit;
wire protected_call_range_fault;
wire protected_access_fault;
wire protected_access_ss_fault;
wire [3:0] operand_io_ranges;
wire [3:0] operand_address_ranges;
wire [3:0] operand_stack_ranges;
wire [3:0] operand_regular_ranges;
wire [3:0] operand_vector_ranges;
wire [3:0] operand_system_ranges;
genvar operand_cache_index;
    assign service_segment = string_request ? (string_destination ? 2'd0 : (segment_override ? override_segment : 2'd3)) : stack_request ? 2'd2 : (segment_override ? override_segment : operand_segment);
    assign service_offset = io_transfer ? 16'd0 : address_override && !stack_request && !vector_request ? address_offset : vector_request ? vector_offset : (stack_request ? stack_offset : operand_offset);
    assign selected_segment_index = execute_enable ? service_segment : segment_read_index;
    assign selected_segment_limit = protected_msw[0] ? protected_segment_limits[selected_segment_index * 16 +: 16] : real_segment_limits[selected_segment_index * 16 +: 16];
    assign selected_segment_access = protected_msw[0] ? protected_segment_access[selected_segment_index * 8 +: 8] : real_segment_access_state[selected_segment_index * 8 +: 8];
    assign protected_segment_is_loaded = protected_msw[0] && protected_segment_protected[service_segment];
    assign protected_segment_is_valid = protected_segment_valid[service_segment];
    assign protected_segment_is_present = protected_segment_present[service_segment];
    assign protected_segment_is_code = selected_segment_access[3];
    assign protected_segment_is_readable = selected_segment_access[1];
    assign protected_segment_is_writable = !protected_segment_is_code && selected_segment_access[1];
    assign protected_segment_is_expand_down = !protected_segment_is_code && selected_segment_access[2];
    assign protected_selected_range_fault = !parallel_operand_within_limit;
    assign parallel_operand_within_limit =
        (protected_event_access || protected_descriptor_access || protected_tss_access || protected_call_stack_access) ? 1'b1 :
        vector_request ? operand_vector_ranges[selected_segment_index] :
        io_transfer ? operand_io_ranges[selected_segment_index] :
        address_override && !stack_request ? operand_address_ranges[selected_segment_index] :
        stack_request ? operand_stack_ranges[selected_segment_index] :
        operand_regular_ranges[selected_segment_index];
    assign protected_call_range_fault = stack_request ?
        protected_range_exceeded(stack_offset, protected_call_stack_limit, protected_call_stack_expand_down, operand_byte) :
        address_override ? protected_range_exceeded(address_offset, protected_call_stack_limit, protected_call_stack_expand_down, operand_byte) :
        protected_range_exceeded(operand_offset, protected_call_stack_limit, protected_call_stack_expand_down, operand_byte);
    assign protected_access_fault = operand_request && operand_select_rm && !operand_register_direct &&
                                   !protected_descriptor_access && !protected_tss_access && !protected_event_access &&
                                   !io_transfer && !vector_request &&
                                    (protected_call_stack_access ?
                                    (service_segment != 2'd2 || protected_call_range_fault) :
                                    (protected_segment_is_loaded &&
                                     (!protected_segment_is_valid || !protected_segment_is_present ||
                                      (protected_segment_is_code ? (!protected_segment_is_readable || operand_write) :
                                       (stack_request ? (!protected_segment_is_writable || service_segment != 2'd2) :
                                        (operand_write && !protected_segment_is_writable))) ||
                                      protected_selected_range_fault)));
    assign protected_access_ss_fault = protected_access_fault && service_segment == 2'd2;
    function automatic logic protected_range_exceeded(
        input logic [15:0] offset_value, limit_value,
        input logic expand_down, is_byte
    );
        protected_range_exceeded = expand_down ?
            (offset_value <= limit_value || (!is_byte && offset_value == 16'hFFFF)) :
            (offset_value > limit_value || (!is_byte && offset_value == limit_value));
    endfunction
    generate
    for (operand_cache_index = 0; operand_cache_index < 4; operand_cache_index = operand_cache_index + 1) begin : g_operand_cache_range
        wire [15:0] cache_limit = protected_msw[0] ?
            protected_segment_limits[operand_cache_index*16 +: 16] :
            real_segment_limits[operand_cache_index*16 +: 16];
        wire cache_expand_down = protected_msw[0] &&
            !protected_segment_access[operand_cache_index*8+3] &&
            protected_segment_access[operand_cache_index*8+2];
        assign operand_io_ranges[operand_cache_index] =
            !protected_range_exceeded(16'd0, cache_limit, cache_expand_down, operand_byte);
        assign operand_address_ranges[operand_cache_index] =
            !protected_range_exceeded(address_offset, cache_limit, cache_expand_down, operand_byte);
        assign operand_stack_ranges[operand_cache_index] =
            !protected_range_exceeded(stack_offset, cache_limit, cache_expand_down, operand_byte);
        assign operand_regular_ranges[operand_cache_index] =
            !protected_range_exceeded(operand_offset, cache_limit, cache_expand_down, operand_byte);
        assign operand_vector_ranges[operand_cache_index] =
            !protected_range_exceeded(io_transfer ? 16'd0 : vector_offset, 16'hFFFF, cache_expand_down, operand_byte);
        // Six-byte table operands use the ordinary effective offset.
        // Complete each cache's range comparison before the late index mux.
        assign operand_system_ranges[operand_cache_index] = cache_expand_down ?
            (operand_offset <= cache_limit || operand_offset > 16'hFFFA) :
            ({1'b0, operand_offset} + 17'd5 > {1'b0, cache_limit});
    end
    endgenerate
wire allowed;
wire copy_call_parameters;
wire read_frame_address;
wire call_gate_outer_required;
wire call_parameter_read;
wire call_parameter_write;
wire iret_outer_frame_operation;
wire iret_outer_required;
wire iret_outer_pop;
wire push_operation;
wire push_event_error;
wire push_transfer;
wire push_event_error_transfer;
wire call_gate_stack_switch_operation;
wire call_gate_stack_write;
wire pop_operation;
wire stack_request;
wire [15:0] call_parameter_write_offset;
wire [15:0] iret_parameter_bytes;
wire [15:0] return_stack_pointer;
wire [15:0] iret_outer_stack_offset;
wire [15:0] stack_offset;
wire protected_call_stack_access;
wire [23:0] protected_call_stack_address;
wire [15:0] protected_call_stack_limit;
wire protected_call_stack_expand_down;
wire implementation_allowed;
wire call_parameter_read_data_select;
wire call_parameter_write_data_select;
wire iret_outer_data_select;
wire frame_address_data_select;
    assign allowed = operation_valid && !reset && !semantic_cancel && !service_start &&
                     !task_switch_skip && !task_return_skip && !task_event_switch_skip;
    assign copy_call_parameters = implementation_allowed && micro_word == 8'd165;
    assign read_frame_address = implementation_allowed && micro_word == 8'd106 && frame_address_valid_q;
    assign call_gate_outer_required = protected_msw[0] && call_gate_candidate_valid_q && cs_candidate_valid_q &&
                                     (call_gate_target_dpl_q < protected_cpl) &&
                                     !(cs_candidate_class_q == 4'd1 && cs_candidate_access_q[2]);
    assign call_parameter_read = copy_call_parameters && call_gate_outer_required &&
                                 call_parameter_active_q && call_parameter_phase_q == 2'd0;
    assign call_parameter_write = copy_call_parameters && call_gate_outer_required &&
                                  call_parameter_active_q && call_parameter_phase_q == 2'd1;
    assign iret_outer_frame_operation = implementation_allowed && micro_word == 8'd157;
    assign iret_outer_required = protected_msw[0] && protected_return_cursor_q &&
                                 temporary_valid_q[1] && (tmp1_q[1:0] > protected_cpl);
    assign iret_outer_pop = iret_outer_frame_operation && iret_outer_required && iret_outer_phase_q < 2'd2;
    assign push_operation = implementation_allowed && micro_word == 8'd21 && temporary_valid_q[0];
    assign push_event_error = implementation_allowed && micro_word == 8'd155;
    assign push_transfer = push_operation && push_enabled;
    assign push_event_error_transfer = push_event_error && push_enabled && event_error_valid;
    assign call_gate_stack_switch_operation = implementation_allowed && micro_word == 8'd163;
    assign call_gate_stack_write = call_gate_stack_switch_operation && call_gate_stack_switch_active_q &&
                                   call_gate_stack_switch_phase_q < 2'd2;
    assign pop_operation = implementation_allowed && (micro_word == 8'd22 ||
                                      micro_word == 8'd43 ||
                                      micro_word == 8'd44 || iret_outer_pop);
    assign stack_request = !range_fault &&
                           (push_transfer || push_event_error_transfer || pop_operation || read_frame_address ||
                            call_gate_stack_write || call_parameter_read || call_parameter_write);
    assign call_parameter_write_offset = stack_cursor_q - 16'd1;
    assign iret_parameter_bytes = allocation_valid_q ? allocation_q : 16'd0;
    assign return_stack_pointer = protected_return_cursor_q ? stack_cursor_q : stack_pointer;
    assign iret_outer_stack_offset = return_stack_pointer + iret_parameter_bytes;
    assign stack_offset = call_parameter_read_data_select ? call_parameter_source_sp_q :
                          call_parameter_write_data_select ? call_parameter_write_offset :
                          iret_outer_data_select ? iret_outer_stack_offset :
                          frame_address_data_select ? frame_address_q : stack_native_offset;
    assign protected_call_stack_access = call_gate_stack_switch_active_q && call_gate_outer_required &&
                                        stack_request && !read_frame_address && !call_parameter_read;
    assign protected_call_stack_address = call_ss_base_q + {8'd0, stack_offset};
    assign protected_call_stack_limit = call_ss_limit_q;
    assign protected_call_stack_expand_down = call_ss_access_q[2];
    assign implementation_allowed = profile_raw_operation_valid && !reset && !semantic_cancel && !service_start &&
                     !task_switch_skip && !task_return_skip && !task_event_switch_skip;
    assign call_parameter_read_data_select = micro_word == 8'd165 &&
                                            call_gate_outer_required && call_parameter_active_q && call_parameter_phase_q == 2'd0;
    assign call_parameter_write_data_select = micro_word == 8'd165 &&
                                             call_gate_outer_required && call_parameter_active_q && call_parameter_phase_q == 2'd1;
    assign iret_outer_data_select = micro_word == 8'd157 &&
                                    iret_outer_required && iret_outer_phase_q < 2'd2;
    assign frame_address_data_select = micro_word == 8'd106 && frame_address_valid_q;
wire parallel_system_cache_fault;
    assign parallel_system_cache_fault = operand_system_ranges[selected_segment_index];
wire [23:0] selected_segment_base;
    assign selected_segment_base = protected_msw[0] ? protected_segment_bases[selected_segment_index * 24 +: 24] : real_segment_bases[selected_segment_index * 24 +: 24];
wire [23:0] segment_address;
    assign segment_address = selected_segment_base + {8'h00, (execute_enable ? service_offset : segment_offset)};
wire loadall_fault_has_error;
    assign loadall_fault_has_error = loadall_fault_vector == 8'd8 || loadall_fault_vector == 8'd10 ||
                                    loadall_fault_vector == 8'd11 || loadall_fault_vector == 8'd12 || loadall_fault_vector == 8'd13;
wire system_fault_has_error;
    assign system_fault_has_error = system_fault_vector == 8'd8 || system_fault_vector == 8'd10 ||
                                   system_fault_vector == 8'd11 || system_fault_vector == 8'd12 || system_fault_vector == 8'd13;
wire fault_request;
    assign fault_request = range_fault || bounds_fault || arithmetic_fault || operand_blocked || invalid_form ||
                           invalid_opcode_fault || system_limit_fault || system_fault ||
                           protected_access_fault || protected_fetch_fault || demanded_code_fault || length_fault || loadall_fault;
wire [7:0] fault_vector;
    assign fault_vector = (invalid_form || invalid_opcode_fault) ? 8'd6 : loadall_fault ? loadall_fault_vector : system_fault ? system_fault_vector :
                          (protected_access_ss_fault || ((system_limit_fault || range_fault) && protected_msw[0] && service_segment == 2'd2)) ? 8'd12 : protected_access_fault ? 8'd13 :
                          protected_fetch_fault ? 8'd13 : bounds_fault ? 8'd5 : arithmetic_fault ? 8'd0 : 8'd13;
wire fault_error_valid;
    assign fault_error_valid = protected_msw[0] && !(invalid_form || invalid_opcode_fault) &&
                              (loadall_fault ? loadall_fault_has_error :
                               system_fault ? system_fault_has_error :
                               (protected_access_ss_fault ||
                                ((system_limit_fault || range_fault) && protected_msw[0] && service_segment == 2'd2) ||
                                protected_access_fault || protected_fetch_fault || (!bounds_fault && !arithmetic_fault)));
wire [15:0] fault_error_code;
    assign fault_error_code = system_fault ? system_fault_error_code :
                              loadall_fault ? loadall_fault_error_code : 16'd0;
logic [23:0] operand_physical_address;
    always_comb begin
        operand_physical_address = segment_address;
        if (vector_request) operand_physical_address = {8'd0, vector_offset};
        if (io_transfer) operand_physical_address = {8'd0, io_port};
        if (protected_call_stack_access) operand_physical_address = protected_call_stack_address;
        if (protected_tss_access) operand_physical_address = protected_tss_address;
        if (protected_descriptor_access) operand_physical_address = protected_descriptor_address;
        if (protected_event_access) operand_physical_address = protected_event_address;
    end
assign observed_stack_request = stack_request;
assign observed_protected_call_stack_access = protected_call_stack_access;
assign observed_protected_call_stack_limit = protected_call_stack_limit;
assign observed_protected_call_stack_expand_down = protected_call_stack_expand_down;
assign observed_service_offset = service_offset;
assign observed_parallel_operand_within_limit = parallel_operand_within_limit;
assign observed_parallel_system_cache_fault = parallel_system_cache_fault;
assign observed_protected_access_fault = protected_access_fault;
assign observed_protected_access_ss_fault = protected_access_ss_fault;
assign observed_selected_segment_index = selected_segment_index;
assign observed_selected_segment_limit = selected_segment_limit;
assign observed_selected_segment_access = selected_segment_access;
assign observed_selected_segment_base = selected_segment_base;
assign observed_segment_address = segment_address;
assign observed_operand_physical_address = operand_physical_address;
assign observed_fault_request = fault_request;
assign observed_fault_vector = fault_vector;
assign observed_fault_error_valid = fault_error_valid;
assign observed_fault_error_code = fault_error_code;
assign observed_stack_offset = stack_offset;
assign observed_protected_call_stack_address = protected_call_stack_address;
endmodule

module miter(
input wire [15:0] address_offset,
input wire address_override,
input wire [15:0] allocation_q,
input wire allocation_valid_q,
input wire arithmetic_fault,
input wire blocked_state,
input wire bounds_fault,
input wire call_gate_candidate_valid_q,
input wire call_gate_stack_switch_active_q,
input wire [1:0] call_gate_stack_switch_phase_q,
input wire [1:0] call_gate_target_dpl_q,
input wire call_parameter_active_q,
input wire [1:0] call_parameter_phase_q,
input wire [15:0] call_parameter_source_sp_q,
input wire [7:0] call_ss_access_q,
input wire [23:0] call_ss_base_q,
input wire [15:0] call_ss_limit_q,
input wire clk,
input wire [7:0] cs_candidate_access_q,
input wire [3:0] cs_candidate_class_q,
input wire cs_candidate_valid_q,
input wire demanded_code_fault,
input wire event_error_valid,
input wire execute_enable,
input wire [15:0] frame_address_q,
input wire frame_address_valid_q,
input wire invalid_form,
input wire invalid_opcode_fault,
input wire [15:0] io_port,
input wire io_transfer,
input wire [1:0] iret_outer_phase_q,
input wire length_fault,
input wire loadall_fault,
input wire [15:0] loadall_fault_error_code,
input wire [7:0] loadall_fault_vector,
input wire [15:0] memory_read_data,
input wire memory_request_ready,
input wire memory_response_valid,
input wire [7:0] micro_word,
input wire operand_blocked,
input wire operand_byte,
input wire operand_check,
input wire [15:0] operand_offset,
input wire [2:0] operand_reg,
input wire operand_register_direct,
input wire operand_request,
input wire [2:0] operand_rm,
input wire [1:0] operand_segment,
input wire operand_select_rm,
input wire operand_write,
input wire [15:0] operand_write_data,
input wire operation_valid,
input wire [1:0] override_segment,
input wire pending_state,
input wire profile_raw_operation_valid,
input wire [1:0] protected_cpl,
input wire protected_descriptor_access,
input wire [23:0] protected_descriptor_address,
input wire protected_event_access,
input wire [23:0] protected_event_address,
input wire protected_fetch_fault,
input wire [15:0] protected_msw,
input wire protected_return_cursor_q,
input wire [31:0] protected_segment_access,
input wire [95:0] protected_segment_bases,
input wire protected_segment_is_expand_down,
input wire [63:0] protected_segment_limits,
input wire [3:0] protected_segment_present,
input wire [3:0] protected_segment_protected,
input wire [3:0] protected_segment_valid,
input wire protected_tss_access,
input wire [23:0] protected_tss_address,
input wire push_enabled,
input wire range_fault,
input wire [31:0] real_segment_access_state,
input wire [95:0] real_segment_bases,
input wire [63:0] real_segment_limits,
input wire [127:0] register_state,
input wire reset,
input wire [15:0] segment_limit,
input wire [15:0] segment_offset,
input wire segment_override,
input wire [1:0] segment_read_index,
input wire semantic_cancel,
input wire service_start,
input wire [15:0] stack_cursor_q,
input wire [15:0] stack_native_offset,
input wire [15:0] stack_pointer,
input wire string_destination,
input wire string_request,
input wire system_fault,
input wire [15:0] system_fault_error_code,
input wire [7:0] system_fault_vector,
input wire system_limit_fault,
input wire task_event_switch_skip,
input wire task_return_skip,
input wire task_switch_skip,
input wire [2:0] temporary_valid_q,
input wire [15:0] tmp1_q,
input wire [15:0] vector_offset,
input wire vector_request
);
wire reference_stack_request;
wire reference_protected_call_stack_access;
wire [15:0] reference_protected_call_stack_limit;
wire reference_protected_call_stack_expand_down;
wire [15:0] reference_service_offset;
wire reference_parallel_operand_within_limit;
wire reference_parallel_system_cache_fault;
wire reference_protected_access_fault;
wire reference_protected_access_ss_fault;
wire [1:0] reference_selected_segment_index;
wire [15:0] reference_selected_segment_limit;
wire [7:0] reference_selected_segment_access;
wire [23:0] reference_selected_segment_base;
wire [23:0] reference_segment_address;
wire [23:0] reference_operand_physical_address;
wire reference_fault_request;
wire [7:0] reference_fault_vector;
wire reference_fault_error_valid;
wire [15:0] reference_fault_error_code;
wire [15:0] reference_stack_offset;
wire [23:0] reference_protected_call_stack_address;
wire reference_operand_done;
wire reference_operand_unlimited_memory_done;
wire [15:0] reference_operand_read_data;
wire reference_operand_blocked;
wire reference_operand_gpr_write_en;
wire reference_operand_gpr_write_byte;
wire [2:0] reference_operand_gpr_write_index;
wire [15:0] reference_operand_gpr_write_data;
wire reference_operand_memory_request;
wire reference_operand_memory_write;
wire reference_operand_memory_byte;
wire [23:0] reference_operand_memory_address;
wire [15:0] reference_operand_memory_write_data;
wire reference_operand_memory_response_ready;
wire reference_operand_timing_wait;
wire reference_operand_pending_next;
wire reference_operand_blocked_next;
cone_reference reference_instance(.address_offset(address_offset),.address_override(address_override),.allocation_q(allocation_q),.allocation_valid_q(allocation_valid_q),.arithmetic_fault(arithmetic_fault),.bounds_fault(bounds_fault),.call_gate_candidate_valid_q(call_gate_candidate_valid_q),.call_gate_stack_switch_active_q(call_gate_stack_switch_active_q),.call_gate_stack_switch_phase_q(call_gate_stack_switch_phase_q),.call_gate_target_dpl_q(call_gate_target_dpl_q),.call_parameter_active_q(call_parameter_active_q),.call_parameter_phase_q(call_parameter_phase_q),.call_parameter_source_sp_q(call_parameter_source_sp_q),.call_ss_access_q(call_ss_access_q),.call_ss_base_q(call_ss_base_q),.call_ss_limit_q(call_ss_limit_q),.cs_candidate_access_q(cs_candidate_access_q),.cs_candidate_class_q(cs_candidate_class_q),.cs_candidate_valid_q(cs_candidate_valid_q),.demanded_code_fault(demanded_code_fault),.event_error_valid(event_error_valid),.execute_enable(execute_enable),.frame_address_q(frame_address_q),.frame_address_valid_q(frame_address_valid_q),.invalid_form(invalid_form),.invalid_opcode_fault(invalid_opcode_fault),.io_port(io_port),.io_transfer(io_transfer),.iret_outer_phase_q(iret_outer_phase_q),.length_fault(length_fault),.loadall_fault(loadall_fault),.loadall_fault_error_code(loadall_fault_error_code),.loadall_fault_vector(loadall_fault_vector),.micro_word(micro_word),.operand_blocked(operand_blocked),.operand_byte(operand_byte),.operand_offset(operand_offset),.operand_register_direct(operand_register_direct),.operand_request(operand_request),.operand_segment(operand_segment),.operand_select_rm(operand_select_rm),.operand_write(operand_write),.operation_valid(operation_valid),.override_segment(override_segment),.profile_raw_operation_valid(profile_raw_operation_valid),.protected_cpl(protected_cpl),.protected_descriptor_access(protected_descriptor_access),.protected_descriptor_address(protected_descriptor_address),.protected_event_access(protected_event_access),.protected_event_address(protected_event_address),.protected_fetch_fault(protected_fetch_fault),.protected_msw(protected_msw),.protected_return_cursor_q(protected_return_cursor_q),.protected_segment_access(protected_segment_access),.protected_segment_bases(protected_segment_bases),.protected_segment_limits(protected_segment_limits),.protected_segment_present(protected_segment_present),.protected_segment_protected(protected_segment_protected),.protected_segment_valid(protected_segment_valid),.protected_tss_access(protected_tss_access),.protected_tss_address(protected_tss_address),.push_enabled(push_enabled),.range_fault(range_fault),.real_segment_access_state(real_segment_access_state),.real_segment_bases(real_segment_bases),.real_segment_limits(real_segment_limits),.reset(reset),.segment_offset(segment_offset),.segment_override(segment_override),.segment_read_index(segment_read_index),.semantic_cancel(semantic_cancel),.service_start(service_start),.stack_cursor_q(stack_cursor_q),.stack_native_offset(stack_native_offset),.stack_pointer(stack_pointer),.string_destination(string_destination),.string_request(string_request),.system_fault(system_fault),.system_fault_error_code(system_fault_error_code),.system_fault_vector(system_fault_vector),.system_limit_fault(system_limit_fault),.task_event_switch_skip(task_event_switch_skip),.task_return_skip(task_return_skip),.task_switch_skip(task_switch_skip),.temporary_valid_q(temporary_valid_q),.tmp1_q(tmp1_q),.vector_offset(vector_offset),.vector_request(vector_request),.observed_stack_request(reference_stack_request),.observed_protected_call_stack_access(reference_protected_call_stack_access),.observed_protected_call_stack_limit(reference_protected_call_stack_limit),.observed_protected_call_stack_expand_down(reference_protected_call_stack_expand_down),.observed_service_offset(reference_service_offset),.observed_parallel_operand_within_limit(reference_parallel_operand_within_limit),.observed_parallel_system_cache_fault(reference_parallel_system_cache_fault),.observed_protected_access_fault(reference_protected_access_fault),.observed_protected_access_ss_fault(reference_protected_access_ss_fault),.observed_selected_segment_index(reference_selected_segment_index),.observed_selected_segment_limit(reference_selected_segment_limit),.observed_selected_segment_access(reference_selected_segment_access),.observed_selected_segment_base(reference_selected_segment_base),.observed_segment_address(reference_segment_address),.observed_operand_physical_address(reference_operand_physical_address),.observed_fault_request(reference_fault_request),.observed_fault_vector(reference_fault_vector),.observed_fault_error_valid(reference_fault_error_valid),.observed_fault_error_code(reference_fault_error_code),.observed_stack_offset(reference_stack_offset),.observed_protected_call_stack_address(reference_protected_call_stack_address));
operand_step #(.USE_PARALLEL_RANGE(1'b1)) reference_operand(.clk(clk),.reset(reset),.cancel(semantic_cancel),.request_valid(operand_request && !reference_protected_access_fault),.request_byte(operand_byte),.request_write(operand_write),.request_check(operand_check),.select_rm(operand_select_rm),.write_data(operand_write_data),.register_state(register_state),.reg_index(operand_reg),.rm_index(operand_rm),.register_direct(operand_register_direct && !protected_descriptor_access && !protected_tss_access && !reference_protected_call_stack_access && !protected_event_access && !address_override && !reference_stack_request && !vector_request && !io_transfer),.physical_address(reference_operand_physical_address),.offset((protected_event_access || protected_descriptor_access || protected_tss_access || reference_protected_call_stack_access) ? 16'd0 : reference_service_offset),.segment_limit((protected_event_access || protected_descriptor_access || protected_tss_access || reference_protected_call_stack_access) ? 16'hFFFF : (vector_request ? 16'hFFFF : segment_limit)),.segment_expand_down(protected_msw[0] && protected_segment_is_expand_down && !reference_protected_call_stack_access && !protected_event_access && !protected_descriptor_access && !protected_tss_access),.parallel_within_limit(reference_parallel_operand_within_limit),.memory_request_ready(memory_request_ready),.memory_response_valid(memory_response_valid),.memory_read_data(memory_read_data),.pending_state(pending_state),.blocked_state(blocked_state),.done(reference_operand_done),.unlimited_memory_done(reference_operand_unlimited_memory_done),.read_data(reference_operand_read_data),.blocked(reference_operand_blocked),.gpr_write_en(reference_operand_gpr_write_en),.gpr_write_byte(reference_operand_gpr_write_byte),.gpr_write_index(reference_operand_gpr_write_index),.gpr_write_data(reference_operand_gpr_write_data),.memory_request(reference_operand_memory_request),.memory_write(reference_operand_memory_write),.memory_byte(reference_operand_memory_byte),.memory_address(reference_operand_memory_address),.memory_write_data(reference_operand_memory_write_data),.memory_response_ready(reference_operand_memory_response_ready),.timing_wait(reference_operand_timing_wait),.pending_next(reference_operand_pending_next),.blocked_next(reference_operand_blocked_next));
wire candidate_stack_request;
wire candidate_protected_call_stack_access;
wire [15:0] candidate_protected_call_stack_limit;
wire candidate_protected_call_stack_expand_down;
wire [15:0] candidate_service_offset;
wire candidate_parallel_operand_within_limit;
wire candidate_parallel_system_cache_fault;
wire candidate_protected_access_fault;
wire candidate_protected_access_ss_fault;
wire [1:0] candidate_selected_segment_index;
wire [15:0] candidate_selected_segment_limit;
wire [7:0] candidate_selected_segment_access;
wire [23:0] candidate_selected_segment_base;
wire [23:0] candidate_segment_address;
wire [23:0] candidate_operand_physical_address;
wire candidate_fault_request;
wire [7:0] candidate_fault_vector;
wire candidate_fault_error_valid;
wire [15:0] candidate_fault_error_code;
wire [15:0] candidate_stack_offset;
wire [23:0] candidate_protected_call_stack_address;
wire candidate_operand_done;
wire candidate_operand_unlimited_memory_done;
wire [15:0] candidate_operand_read_data;
wire candidate_operand_blocked;
wire candidate_operand_gpr_write_en;
wire candidate_operand_gpr_write_byte;
wire [2:0] candidate_operand_gpr_write_index;
wire [15:0] candidate_operand_gpr_write_data;
wire candidate_operand_memory_request;
wire candidate_operand_memory_write;
wire candidate_operand_memory_byte;
wire [23:0] candidate_operand_memory_address;
wire [15:0] candidate_operand_memory_write_data;
wire candidate_operand_memory_response_ready;
wire candidate_operand_timing_wait;
wire candidate_operand_pending_next;
wire candidate_operand_blocked_next;
cone_candidate candidate_instance(.address_offset(address_offset),.address_override(address_override),.allocation_q(allocation_q),.allocation_valid_q(allocation_valid_q),.arithmetic_fault(arithmetic_fault),.bounds_fault(bounds_fault),.call_gate_candidate_valid_q(call_gate_candidate_valid_q),.call_gate_stack_switch_active_q(call_gate_stack_switch_active_q),.call_gate_stack_switch_phase_q(call_gate_stack_switch_phase_q),.call_gate_target_dpl_q(call_gate_target_dpl_q),.call_parameter_active_q(call_parameter_active_q),.call_parameter_phase_q(call_parameter_phase_q),.call_parameter_source_sp_q(call_parameter_source_sp_q),.call_ss_access_q(call_ss_access_q),.call_ss_base_q(call_ss_base_q),.call_ss_limit_q(call_ss_limit_q),.cs_candidate_access_q(cs_candidate_access_q),.cs_candidate_class_q(cs_candidate_class_q),.cs_candidate_valid_q(cs_candidate_valid_q),.demanded_code_fault(demanded_code_fault),.event_error_valid(event_error_valid),.execute_enable(execute_enable),.frame_address_q(frame_address_q),.frame_address_valid_q(frame_address_valid_q),.invalid_form(invalid_form),.invalid_opcode_fault(invalid_opcode_fault),.io_port(io_port),.io_transfer(io_transfer),.iret_outer_phase_q(iret_outer_phase_q),.length_fault(length_fault),.loadall_fault(loadall_fault),.loadall_fault_error_code(loadall_fault_error_code),.loadall_fault_vector(loadall_fault_vector),.micro_word(micro_word),.operand_blocked(operand_blocked),.operand_byte(operand_byte),.operand_offset(operand_offset),.operand_register_direct(operand_register_direct),.operand_request(operand_request),.operand_segment(operand_segment),.operand_select_rm(operand_select_rm),.operand_write(operand_write),.operation_valid(operation_valid),.override_segment(override_segment),.profile_raw_operation_valid(profile_raw_operation_valid),.protected_cpl(protected_cpl),.protected_descriptor_access(protected_descriptor_access),.protected_descriptor_address(protected_descriptor_address),.protected_event_access(protected_event_access),.protected_event_address(protected_event_address),.protected_fetch_fault(protected_fetch_fault),.protected_msw(protected_msw),.protected_return_cursor_q(protected_return_cursor_q),.protected_segment_access(protected_segment_access),.protected_segment_bases(protected_segment_bases),.protected_segment_limits(protected_segment_limits),.protected_segment_present(protected_segment_present),.protected_segment_protected(protected_segment_protected),.protected_segment_valid(protected_segment_valid),.protected_tss_access(protected_tss_access),.protected_tss_address(protected_tss_address),.push_enabled(push_enabled),.range_fault(range_fault),.real_segment_access_state(real_segment_access_state),.real_segment_bases(real_segment_bases),.real_segment_limits(real_segment_limits),.reset(reset),.segment_offset(segment_offset),.segment_override(segment_override),.segment_read_index(segment_read_index),.semantic_cancel(semantic_cancel),.service_start(service_start),.stack_cursor_q(stack_cursor_q),.stack_native_offset(stack_native_offset),.stack_pointer(stack_pointer),.string_destination(string_destination),.string_request(string_request),.system_fault(system_fault),.system_fault_error_code(system_fault_error_code),.system_fault_vector(system_fault_vector),.system_limit_fault(system_limit_fault),.task_event_switch_skip(task_event_switch_skip),.task_return_skip(task_return_skip),.task_switch_skip(task_switch_skip),.temporary_valid_q(temporary_valid_q),.tmp1_q(tmp1_q),.vector_offset(vector_offset),.vector_request(vector_request),.observed_stack_request(candidate_stack_request),.observed_protected_call_stack_access(candidate_protected_call_stack_access),.observed_protected_call_stack_limit(candidate_protected_call_stack_limit),.observed_protected_call_stack_expand_down(candidate_protected_call_stack_expand_down),.observed_service_offset(candidate_service_offset),.observed_parallel_operand_within_limit(candidate_parallel_operand_within_limit),.observed_parallel_system_cache_fault(candidate_parallel_system_cache_fault),.observed_protected_access_fault(candidate_protected_access_fault),.observed_protected_access_ss_fault(candidate_protected_access_ss_fault),.observed_selected_segment_index(candidate_selected_segment_index),.observed_selected_segment_limit(candidate_selected_segment_limit),.observed_selected_segment_access(candidate_selected_segment_access),.observed_selected_segment_base(candidate_selected_segment_base),.observed_segment_address(candidate_segment_address),.observed_operand_physical_address(candidate_operand_physical_address),.observed_fault_request(candidate_fault_request),.observed_fault_vector(candidate_fault_vector),.observed_fault_error_valid(candidate_fault_error_valid),.observed_fault_error_code(candidate_fault_error_code),.observed_stack_offset(candidate_stack_offset),.observed_protected_call_stack_address(candidate_protected_call_stack_address));
operand_step #(.USE_PARALLEL_RANGE(1'b1)) candidate_operand(.clk(clk),.reset(reset),.cancel(semantic_cancel),.request_valid(operand_request && !candidate_protected_access_fault),.request_byte(operand_byte),.request_write(operand_write),.request_check(operand_check),.select_rm(operand_select_rm),.write_data(operand_write_data),.register_state(register_state),.reg_index(operand_reg),.rm_index(operand_rm),.register_direct(operand_register_direct && !protected_descriptor_access && !protected_tss_access && !candidate_protected_call_stack_access && !protected_event_access && !address_override && !candidate_stack_request && !vector_request && !io_transfer),.physical_address(candidate_operand_physical_address),.offset((protected_event_access || protected_descriptor_access || protected_tss_access || candidate_protected_call_stack_access) ? 16'd0 : candidate_service_offset),.segment_limit((protected_event_access || protected_descriptor_access || protected_tss_access || candidate_protected_call_stack_access) ? 16'hFFFF : (vector_request ? 16'hFFFF : segment_limit)),.segment_expand_down(protected_msw[0] && protected_segment_is_expand_down && !candidate_protected_call_stack_access && !protected_event_access && !protected_descriptor_access && !protected_tss_access),.parallel_within_limit(candidate_parallel_operand_within_limit),.memory_request_ready(memory_request_ready),.memory_response_valid(memory_response_valid),.memory_read_data(memory_read_data),.pending_state(pending_state),.blocked_state(blocked_state),.done(candidate_operand_done),.unlimited_memory_done(candidate_operand_unlimited_memory_done),.read_data(candidate_operand_read_data),.blocked(candidate_operand_blocked),.gpr_write_en(candidate_operand_gpr_write_en),.gpr_write_byte(candidate_operand_gpr_write_byte),.gpr_write_index(candidate_operand_gpr_write_index),.gpr_write_data(candidate_operand_gpr_write_data),.memory_request(candidate_operand_memory_request),.memory_write(candidate_operand_memory_write),.memory_byte(candidate_operand_memory_byte),.memory_address(candidate_operand_memory_address),.memory_write_data(candidate_operand_memory_write_data),.memory_response_ready(candidate_operand_memory_response_ready),.timing_wait(candidate_operand_timing_wait),.pending_next(candidate_operand_pending_next),.blocked_next(candidate_operand_blocked_next));
always @* begin
if(reference_stack_request) assert(reference_stack_offset == candidate_stack_offset);
if(reference_protected_call_stack_access) assert(reference_protected_call_stack_address == candidate_protected_call_stack_address);
assert(reference_stack_request == candidate_stack_request);
assert(reference_protected_call_stack_access == candidate_protected_call_stack_access);
assert(reference_protected_call_stack_limit == candidate_protected_call_stack_limit);
assert(reference_protected_call_stack_expand_down == candidate_protected_call_stack_expand_down);
assert(reference_service_offset == candidate_service_offset);
assert(reference_parallel_operand_within_limit == candidate_parallel_operand_within_limit);
assert(reference_parallel_system_cache_fault == candidate_parallel_system_cache_fault);
assert(reference_protected_access_fault == candidate_protected_access_fault);
assert(reference_protected_access_ss_fault == candidate_protected_access_ss_fault);
assert(reference_selected_segment_index == candidate_selected_segment_index);
assert(reference_selected_segment_limit == candidate_selected_segment_limit);
assert(reference_selected_segment_access == candidate_selected_segment_access);
assert(reference_selected_segment_base == candidate_selected_segment_base);
assert(reference_segment_address == candidate_segment_address);
assert(reference_operand_physical_address == candidate_operand_physical_address);
assert(reference_fault_request == candidate_fault_request);
assert(reference_fault_vector == candidate_fault_vector);
assert(reference_fault_error_valid == candidate_fault_error_valid);
assert(reference_fault_error_code == candidate_fault_error_code);
assert(reference_operand_done == candidate_operand_done);
assert(reference_operand_unlimited_memory_done == candidate_operand_unlimited_memory_done);
assert(reference_operand_read_data == candidate_operand_read_data);
assert(reference_operand_blocked == candidate_operand_blocked);
assert(reference_operand_gpr_write_en == candidate_operand_gpr_write_en);
assert(reference_operand_gpr_write_byte == candidate_operand_gpr_write_byte);
assert(reference_operand_gpr_write_index == candidate_operand_gpr_write_index);
assert(reference_operand_gpr_write_data == candidate_operand_gpr_write_data);
assert(reference_operand_memory_request == candidate_operand_memory_request);
assert(reference_operand_memory_write == candidate_operand_memory_write);
assert(reference_operand_memory_byte == candidate_operand_memory_byte);
assert(reference_operand_memory_address == candidate_operand_memory_address);
assert(reference_operand_memory_write_data == candidate_operand_memory_write_data);
assert(reference_operand_memory_response_ready == candidate_operand_memory_response_ready);
assert(reference_operand_timing_wait == candidate_operand_timing_wait);
assert(reference_operand_pending_next == candidate_operand_pending_next);
assert(reference_operand_blocked_next == candidate_operand_blocked_next);
end
endmodule
